﻿param(
    [Parameter(Mandatory=$true)]
    [string]$jobName,
    [Parameter(Mandatory=$true)]
    [string]$targetServer,
    [string]$jobPath = "\\na-dc-cm-01\D$\Jenkins\Slave\jobs",
    [Parameter(Mandatory=$true)]
    [string]$configName,
    [string]$build,
    [switch]$deployDatabase,
    [string]$packages = "all"
)

function Log([string]$message)
{
    Write-Host $message -ForegroundColor Green
}

function DeployDatabase([string]$configFile, [string]$service, [string]$dbPackageDir)
{
    $dbPackagePath = "$dbPackageDir\db"
    ### Load configuration file
    Log "Loading configuration file $configFile"

    if((Test-Path $configFile) -eq $false)
    {
        throw "Config file not found: $configFile" 
    }

    $envObj = LoadJsonObject $configFile

    Log "Retrieving configuration from $configFile"

    ### Determine service name
    $environment = GetEnvironmentNameFromConfig $envObj   
    $envPrefix = GetPrefix $environment
    $databasesObj = GetPropertyValueFromConfig $envObj "Databases" $true

    $massPayConnObj = GetPropertyValueFromConfig $databasesObj "MassPayments" $true
    $dbServer = GetPropertyValueFromConfig $massPayConnObj "host" $true
    $dbName = GetPropertyValueFromConfig $massPayConnObj "database" $true  
    $prefixed = GetPropertyValueFromConfig $massPayConnObj "prefixed" $true 
    
    if ($prefixed -eq $true) {$dbName = $envPrefix+$dbName}
    Log "Database name will be $dbName"

    if((Test-Path -Path "$PSScriptRoot\db" -PathType Container) -eq $true)
    {
        Log "Removing existing files from $PSScriptRoot\db"
        Remove-Item "$PSScriptRoot\db\*" -Recurse -Force -ErrorAction Stop
    } 

    Log "Copying DB package from $dbPackagePath to $PSScriptRoot"
    Copy-Item $dbPackagePath "$PSScriptRoot" -Recurse -Force 
    
    Write-Host "Deploying database $dbName to server $dbServer..."
    & $PSScriptRoot\db\CreateDatabase.ps1 -dbName $dbName -server $dbServer
    Write-Host "Upgrading database $dbName to server $dbServer..."
    & $PSScriptRoot\db\UpgradeDatabase.ps1 -server $dbServer -databaseName $dbName -forceUpgrade -upgradeEf

    if ($LastExitCode -ne 0)
    {
        throw "Database deployment failed"
    }
}

Log "Beginning invoke deployment script"

Log ""
Log "Command line arguments:"
Log "=========================================================================="
Log "jobName = $jobName"
Log "targetServer = $targetServer"
Log "configName = $configName"
Log "build = $build"
Log "packages = $packages"
Log "=========================================================================="  
Log ""

. "$PSScriptRoot\Helper.ps1"
$buildsPath = "$jobPath\$jobName\builds"

if(!$build)
{
    Log "Determining latest build for job $jobName"

    $buildFolders = Get-ChildItem -Path $buildsPath -ErrorAction Stop | Where-Object {$_.PSIsContainer -eq $true -and $_.Name -match "^\d+$"} | ForEach-Object {$_.Name}
    $build = ($buildFolders | Measure -Maximum).Maximum

    Log "Latest build package: $build"
}

$stagingDir = "\\$targetServer\Staging\$jobName`_$build"
Log "Copying deployment artifacts to $stagingDir"

if((Test-Path -Path $stagingDir -PathType Container) -eq $true)
{
    Log "Removing existing files from $stagingDir"
    Remove-Item $stagingDir\* -Recurse -Force -ErrorAction Stop
} else
{
    Log "Creating directory $stagingDir"
    New-Item $stagingDir -ItemType "directory" -ErrorAction Stop 
}

$buildFiles = "$buildsPath\$build\*"    
Log "Copying build package from $buildFiles to $stagingDir, excluding DB"
Copy-Item $buildFiles $stagingDir -Recurse -Container -Exclude DB -ErrorAction Stop

$buildFiles = "$buildsPath\$build\*"    
Log "Copying config file $PSScriptRoot\$configName.json to $stagingDir\Environment_Config.json"
Copy-Item "$PSScriptRoot\$configName.json" -destination "$stagingDir\Environment_Config.json" -ErrorAction Stop

if ($deployDatabase)
{
    DeployDatabase "$PSScriptRoot\$configName.json" "MassPayments" "$buildsPath\$build"
}

$deployFilename = "Deploy.ps1"

Log "Running deploy script on $targetServer"
& "$PSScriptRoot\paexec.exe" "\\$targetServer" -s -dfr /accepteula cmd /c "pushd $stagingDir & PowerShell.exe -NoLogo –ExecutionPolicy Bypass -Command "".\$deployFilename"" $packages"


if ($LastExitCode -ne 0)
{
    throw "Remote deployment failed"
}

