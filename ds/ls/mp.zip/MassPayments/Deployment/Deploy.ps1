﻿param(
    [string[]]$packages = @("all"),
    [string]$configFile = "Environment_Config.json"
)

function Log([string]$message)
{
    Write-Host $message -ForegroundColor Green
}

Log "Beginning deployment script"
Log "Running under account: $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"

$installPackageDir = "$PSScriptRoot"
$configFile="$installPackageDir\$configFile"
$installScript = "$installPackageDir\install.ps1"
$uninstallScript = "$installPackageDir\uninstall.ps1"

Log ""
Log "Script Variables:"
Log "=========================================================================="
Log "config file = $configFile"
Log "installPackageDir = $installPackageDir"
Log "installScript = $installScript"
Log "uninstallScript = $uninstallScript"
Log "=========================================================================="  
Log ""

Log "Searching for deployment scripts in $installPackageDir"

if((Test-Path $configFile) -eq $false) {throw "Cannot find config file $configFile"}
if((Test-Path $installScript) -eq $false) {throw "Cannot find install script $installScript"}
if((Test-Path $uninstallScript) -eq $false) {throw "Cannot find uninstall script $uninstallScript"}

Log "Searching for zipped files to install"
 
$zipFiles = Get-ChildItem -Path $installPackageDir -Filter *.zip -ErrorAction Stop | Where-Object {$_.PSIsContainer -eq $false} | ForEach-Object {($_.BaseName)}

if (-not($packages.Contains("all")))
{
    $zipFiles = $packages|?{$zipFiles -contains $_}
}

Log "$($zipFiles.Count) zipped files will be installed"

ForEach($zipFile in $zipFiles)
{
    if ($zipFile.Contains("DB")) {continue}
    
    $serviceType = "endpoint"
    if ($zipFile.Contains("WebService")) {$serviceType = "custom"}

    Log ""
    Log ""
    Log "=========================================================================="
    Log ""
    Log "Installing service $zipFile"
    Log ""
    Log "=========================================================================="
    Log ""
    Log "Running script $uninstallScript -service $zipFile -configFile $configFile"
    & $uninstallScript -service $zipFile -configFile $configFile -serviceType $serviceType
    Log "Running script $installScript -service $zipFile -configFile $configFile"
    & $installScript -service $zipFile -configFile $configFile -serviceType $serviceType  
}

