﻿param(    
    [Parameter(Position=0,Mandatory=1)]
    [string]$service,
    [Parameter(Position=1,Mandatory=1)]
    [string]$configFile,
    [string]$serviceType = "endpoint"
)

function DeployService()
{
    ### Start Log
    $logFileName = "$PSScriptRoot\$service`_install_$(Get-Date -f yyyyMMdd_HHmmss).log"
    $ErrorActionPreference="SilentlyContinue"
    Stop-Transcript | out-null    
    Start-Transcript -path $logFileName
    $ErrorActionPreference = "Continue"

    Log "Beginning installation script for service $service"
    Log "Running under account: $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"

    Log ""
    Log "Command line arguments:"
    Log "=========================================================================="
    Log "service = $service"
    Log "configFile = $configFile"
    Log "=========================================================================="  
    Log ""

    ### Load configuration file
    Log "Loading configuration file $configFile"

    if((Test-Path $configFile) -eq $false)
    {
        throw "Config file not found: $configFile" 
    }

    $envObj = LoadJsonObject $configFile

    Log "Retrieving configuration from $configFile"

    ### Determine service name
    $environment = GetEnvironmentNameFromConfig $envObj   
    $envPrefix = GetPrefix $environment
    $serviceName = GetServiceName $environment $service 
    Log "Service name will be $serviceName"

    $packageZipFile = "$PSScriptRoot\$service.zip"
    
    $targetPath = GetTargetPath $envObj $service 
    $serviceTargetPath = GetServiceTargetPath $environment $service $targetPath
    ExtractPackageToTargetPath $packageZipFile $serviceTargetPath
    
    $serviceExt = ".dll.config"
    $hostExe = "NServiceBus.Host.exe"
    
    if ($serviceType.ToLower() -eq "custom") 
    {
        $serviceExt = ".exe.config"
        $hostExe = "$service.exe"
    }
    $isEndpoint = ($serviceType.ToLower() -eq "endpoint") 

    Log "Updating $serviceTargetPath\ConnectionStrings.config"
    if ($isEndpoint)
    {
        ### update ConnectionStrings.config
        $connStringConfigFile = "$serviceTargetPath\ConnectionStrings.config"
        $connStringConfigXml = Get-Content $connStringConfigFile -ErrorAction Stop 
        $databasesObj = GetPropertyValueFromConfig $envObj "Databases"
        $connStringConfigXml = UpdateConnectionStringConfig $connStringConfigXml $databasesObj $envPrefix
        Log "Saving $connStringConfigFile"
        $connStringConfigXml.Save($connStringConfigFile)
    }
	
    Log "Updating $serviceTargetPath\$service$serviceExt"
    $appConfigFile = "$serviceTargetPath\$service$serviceExt"
    $appConfigXml = Get-Content $appConfigFile -ErrorAction Stop    

    $serversObj = GetPropertyValueFromConfig $envObj "Servers" $true
    $appConfigXml = UpdateServicesAddressConfig $appConfigXml $serversObj 

    $appSettingsObj = GetPropertyValueFromConfig $envObj "AppSettings" $true
    $serviceAppSettingObj = GetPropertyValueFromConfig $appSettingsObj $service $true
    $appConfigXml = UpdateAppSettingConfig $appConfigXml $serviceAppSettingObj 

    $messageEndpointMappingObj = GetPropertyValueFromConfig $envObj "MessageEndpointMapping" 
    $serviceMessageEndpointMappingObj = GetPropertyValueFromConfig $messageEndpointMappingObj $service
    $appConfigXml = UpdateMessageEndpointMapping $appConfigXml $serviceMessageEndpointMappingObj

    $appConfigXml = UpdateTraceLogConfig $appConfigXml $envObj $serviceName
    
    if($service -eq "MassPayments"){
        CreateEventLog "MassPay" $serviceName
        $appConfigXml = UpdateConfigForEventLog $appConfigXml "MassPay" $serviceName
    }
    
    if($service -eq "Subscriptions"){
        CreateEventLog "SNQS" $serviceName
        $appConfigXml = UpdateConfigForEventLog $appConfigXml "SNQS" $serviceName
    }
        
    Log "Saving $appConfigFile"
    $appConfigXml.Save($appConfigFile)

    $serviceAccountObj = GetPropertyValueFromConfig $envObj "ServiceAccount" 
    InstallService $serviceName $serviceTargetPath $hostExe (GetPropertyValueFromConfig $envObj "ServiceAutoStart" $true) $serviceAccountObj

    ### Stop Log
    $ErrorActionPreference="SilentlyContinue"
    Stop-Transcript
    $ErrorActionPreference="Continue"
}           

function InstallService([string]$serviceName, [string]$targetPath, [string]$hostExe, [string]$autoStart, [object]$serviceAccountObj)
{
    Log "Installing $serviceName ..."
    $hostExe = "`"$targetPath\$hostExe`" -service /serviceName:`"$serviceName`""
    $startupType = if($autoStart) {"Automatic"} else {"Manual"}

    Log "Installing $serviceName service using binary path $hostExe"    
    New-Service -BinaryPathName $hostExe -Name $serviceName -DisplayName $serviceName -Description $serviceName -StartupType $startupType -ErrorAction Stop

    ### Check the correct service is set
    $serviceObject = Get-WmiObject win32_service -Filter "Name='$serviceName'" -ErrorAction Stop
    
    $serviceAccount = GetPropertyValueFromConfig $serviceAccountObj "ServiceUser" $false
    $servicePassword = GetPropertyValueFromConfig $serviceAccountObj "ServiceUserPassword" $false
    
    if($serviceAccount)
    {
        ### Manually set service account
        Log "Setting service account to $serviceAccount"
        $serviceChangeResult = $serviceObject.Change($null,$null,$null,$null,$null,$null,$serviceAccount,$servicePassword,$null,$null,$null)

        if($serviceChangeResult.ReturnValue -ne 0)
        {
            throw "Cannot change the service account to $serviceAccount"    
        }
    }

    ## Start service (if required)
    if($autoStart -eq $true)
    {
        Log "Starting service $serviceName"
        Start-Service -Name $serviceName
    }

    Log "Finished install script for service $serviceName"
}


function CreateEventLog([string]$eventLogName, [string]$eventSourceName)
{
    Log "Creating event log (Name: $eventLogName, Source: $eventSourceName)"

    if ([System.Diagnostics.EventLog]::SourceExists($eventSourceName) -eq $true)
    {
        Log "Event log source $eventSourceName already exists"  
    }
    else
    {
        New-EventLog -source $eventSourceName -LogName $eventLogName -ErrorAction Stop
        Limit-EventLog -LogName $eventLogName -OverflowAction OverwriteAsNeeded -MaximumSize 32768kb -ErrorAction Stop
        Write-EventLog -LogName $eventLogName -Source $eventSourceName -EventId 3001 -EntryType Information -Category 0 -Message "Log source $eventSourceName created" -ErrorAction Stop  
    }
}

. "$PSScriptRoot\Helper.ps1"
DeployService