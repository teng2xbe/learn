﻿param(
    [Parameter(Position=0,Mandatory=1)]
    [string]$service,
    [Parameter(Position=2,Mandatory=1)]
    [string]$configFile,
    [string]$serviceType = "endpoint"
)

function Uninstall()
{
    ### Start Log
    $logFileName = "$PSScriptRoot\$service`_uninstall_$(Get-Date -f yyyyMMdd_HHmmss).log"
    $ErrorActionPreference="SilentlyContinue"
    Stop-Transcript | out-null
    Start-Transcript -path $logFileName
    $ErrorActionPreference = "Continue"

    Log "Beginning uninstall script for service $service"
    Log "Running under account: $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"

    Log ""
    Log "Command line arguments:"
    Log "=========================================================================="
    Log "service = $service" 
    Log "configFile = $configFile" 
    Log "=========================================================================="  
    Log ""

    ### Load configuration file
    Log "Loading configuration file $configFile"

    if((Test-Path $configFile) -eq $false)
    {
        throw "Config file not found: $configFile" 
    }

    $envObj = LoadJsonObject $configFile

    Log "Retrieving configuration from $configFile"


    ### Determine service name
	$environment = GetEnvironmentNameFromConfig $envObj   
    $envPrefix = GetPrefix $environment
    $serviceName = GetServiceName $environment $service 
    Log "Service name to uninstall is $serviceName"
	
    $targetPath = GetTargetPath $envObj $service
    $serviceTargetPath = GetServiceTargetPath $environment $service $targetPath

    Log ""
    Log "Configuration properties:"
    Log "=========================================================================="
    Log "environment = $environment"
    #Log "targetPath = $targetPath"
    Log "=========================================================================="  
    Log ""

    ### Ensuring service exists
    Log "Checking service $serviceName exists"
    if(!(Get-Service $serviceName -ErrorAction SilentlyContinue))
    {
        Log "Cannot find service $serviceName"
    }
    else
    {
        ### Stop the service
        Log "Stopping service $serviceName"
        $serviceObject = Get-WmiObject win32_service -Filter "Name='$serviceName'"

        if($serviceObject.State -ne "Stopped")
        {
            $serviceStopResult = $serviceObject.StopService()
            if($serviceStopResult.ReturnValue -ne 0)
            {
                throw "Cannot stop service $serviceName"
            }
        } else
        {
            Log "Service is already stopped"   
        }

        $hostExe = $serviceObject.PathName.Split('"')[1]
        Log "Uninstalling $serviceName service using $hostExe"

        if ($serviceType.ToLower() -eq "endpoint")
        {
            ### Uninstall NServiceBus windows service
            if(!(Test-Path $hostExe) -eq $true)
            {
                Log "Cannot find $hostExe"
                Log "Manually removing service $serviceName"
                $serviceDeleteResult = $serviceObject.Delete()

                if($serviceDeleteResult.ReturnValue -ne 0)
                {
                    throw "Cannot delete the service $serviceName"    
                }
            } else
            {
                & "$hostExe" -uninstall "-serviceName=$serviceName" 2>&1 | Out-Host
            
                if ($LASTEXITCODE -ne 0)
                {
                    throw "NServiceBusHost.Host.exe returned an error"
                }       
            }
        }
        else
        {
            Log "Manually removing service $serviceName"
            $serviceDeleteResult = $serviceObject.Delete()

            if($serviceDeleteResult.ReturnValue -ne 0)
            {
                throw "Cannot delete the service $serviceName"    
            }
        }

        ### Remove the installation directory
        $installPath = Split-Path $hostExe -Parent
        Log "Removing installation directory $installPath"
        if(!(Test-Path $installPath) -eq $true)
        {
            Log "$installPath does not exist" 
        }
        else
        {
            Remove-Item $installPath -Recurse -Force
        }         
    }

    Log "Finished uninstall script for service $serviceName"

    ### Stop Log
    $ErrorActionPreference="SilentlyContinue"
    Stop-Transcript
    $ErrorActionPreference = "Continue"
}

. "$PSScriptRoot\Helper.ps1"
Uninstall