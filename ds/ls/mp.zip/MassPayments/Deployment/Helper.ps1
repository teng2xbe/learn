function GetDBMapping([string]$name)
{
    switch ($name)
    { 
        "MassPayments" {
            return @("MassPayments.ConnectionString", 
                     "MPIQ.ConnectionString", 
                     "PAIN.ConnectionString", 
                     "SubscriptionsAndNotifications",
                     "SubscriptionsQuery",
                     "NServiceBus/Transport",
                     "NServiceBus/Persistence",
                     "MassPaymentsQuery")}
    
        "Dispatcher" {
            return @("Dispatcher.ConnectionString")}    
        "BI" {
            return @("BI.ConnectionString")}
        "FBS" {
            return @("FBS.ConnectionString")}
        "ServiceControl" {
            return @("NServiceBus/Transport/error", 
                     "NServiceBus/Transport/audit",
                     "NServiceBus/Transport/Particular.ServiceControl")} 
    }
}

function GetWcfServiceMapping([string]$name)
{
    switch ($name)
    { 
        "MassPayments" {
            return @("MassPaymentsService")}   
        "CCTMassPayments" {
            return @("CCTMassPayments")}    
        "CCTEntityManagement" {
            return @("CCTEntityManagement", "CCTEntityManagementForPain")}
        "SubscriptionsAndNotification"{
            return @("SubscriptionsQuery")}
        "MassPaymentsQuery"{
            return @("MassPaymentsQuery")}
    }
}

function GetUriServiceMapping([string]$name)
{
    switch ($name)
    { 
        "MassPayments" {
            return @("MassPayments.Services.MassPaymentsService.MassPaymentsServiceFacade")}   
        "MassPaymentsWebService" {
            return @("MassPaymentsWeb.Services.MassPaymentsWebService.MassPaymentsWebService")}    
        "SubscriptionsAndNotification" {
             return @("SubscriptionsQuery.Services.SubscriptionsQueryService.SubscriptionsQueryServiceFacade")}
        "MassPaymentsQuery" {
             return @("MassPaymentsQuery.Services.MassPaymentsQueryService.MassPaymentsQueryServiceFacade")}
    }
}

function GetSpotWSServiceMapping([string]$name)
{
    switch ($name)
    { 
        "SpotWS" {
            return @("SpotWS.Common.FacadeInterface.ICertificateAuthenticationService, SpotWS.Common",
                     "SpotWS.Common.FacadeInterface.IErrorLoggingService, SpotWS.Common")}   
    }
}

function GetServiceAddressValue([string]$name, [string]$hostName, [string]$port)
{
    switch ($name)
    {
        "MassPaymentsService" 
            {return "net.tcp://$hostName`:$port/Design_Time_Addresses/MassPayments/MassPaymentsServiceFacade/" }
        "CCTMassPayments" 
            {return "net.tcp://$hostName`:$port/Design_Time_Addresses/CCTTransaction/MassPaymentsServiceFacade/" }
        "CCTEntityManagement" 
            {return "net.tcp://$hostName`:$port/Design_Time_Addresses/CCTEntityManagement/MassPaymentsServiceFacade/" }
        "CCTEntityManagementForPain" 
            {return "net.tcp://$hostName`:$port/Design_Time_Addresses/CCTEntityManagement/MassPaymentsServiceFacade/" }
        "MassPayments.Services.MassPaymentsService.MassPaymentsServiceFacade" 
            {return "net.tcp://$hostname`:$port/Design_Time_Addresses/MassPayments/MassPaymentsServiceFacade/" }
        "MassPaymentsWeb.Services.MassPaymentsWebService.MassPaymentsWebService" 
            {return "http://$hostname`:$port/Design_Time_Addresses/MassPaymentsWeb/MassPaymentsServiceFacade/" }
        "SpotWS.Common.FacadeInterface.ICertificateAuthenticationService, SpotWS.Common"
            {return "tcp://$hostname`:$port/SpotWS.UtilityService/CertificateAuthenticationFacade"}
        "SpotWS.Common.FacadeInterface.IErrorLoggingService, SpotWS.Common"
            {return "tcp://$hostname`:$port/SpotWS.UtilityService/ErrorLoggingFacade"}
        "SubscriptionsQuery.Services.SubscriptionsQueryService.SubscriptionsQueryServiceFacade"
            {return "net.tcp://$hostname`:$port/Design_Time_Addresses/SubscriptionsQuery/SubscriptionsQueryServiceFacade/"}
        "SubscriptionsQuery"
            {return "net.tcp://$hostname`:$port/Design_Time_Addresses/SubscriptionsQuery/SubscriptionsQueryServiceFacade/"}
		"MassPaymentsQuery"
            {return "net.tcp://$hostname`:$port/Design_Time_Addresses/MassPaymentsQuery/MassPaymentsQueryServiceFacade/"}
        "MassPaymentsQuery.Services.MassPaymentsQueryService.MassPaymentsQueryServiceFacade"
            {return "net.tcp://$hostname`:$port/Design_Time_Addresses/MassPaymentsQuery/MassPaymentsQueryServiceFacade/"}
    }
}

function LoadJsonObject([string]$jsonFile)
{
    if((Test-Path $jsonFile) -eq $false)
    {
        throw "Config file not found: $jsonFile" 
    }
    
    $jsonObj = Get-Content -Raw -Path $jsonFile | ConvertFrom-Json
    
    if ($jsonObj.GetType().Name -ne "PSCustomObject")
    {
        throw "Unable to deserialize the contents of $jsonFile to a JSON object"
    }

    return $jsonObj
}

function GetEnvironmentNameFromConfig([object]$envConfigObj, [bool]$required)
{
    return GetPropertyValueFromConfig $envConfigObj "EnvironmentName" $required
}

function GetPropertyValueFromConfig([object]$jsonObj, [string]$attributeName, [bool]$required = $false)
{
    try
    {
        if ([bool]($jsonObj.psobject.Members.Name -eq $attributeName))
        {
            return $jsonObj.$attributeName
        }
    } catch {}

    if ($required -eq $true)
    {
        throw "Required attribute '$attributeName' is missing"
    }

    return $null
}

function UpdateAppSettingConfig ([xml]$xml, [object]$envAppSettingConfigObj)
{
    $projKeys = @($envAppSettingConfigObj.psobject.Members | where { $_.MemberType -eq "NoteProperty" }).Name

    foreach($key in $projKeys)
    {
        $newValue = GetPropertyValueFromConfig $envAppSettingConfigObj $key $true
        SetAppSettingsValue $xml $key $newValue
    }

    return $xml
}

function UpdateConnectionStringConfig ([xml]$xml, [object]$databaseObj, [string]$prefix)
{
    $dbServerNames = @($databaseObj.psobject.Members | where { $_.MemberType -eq "NoteProperty" }).Name

    foreach($dbServerName in $dbServerNames)
    {
        $connStringObj = GetPropertyValueFromConfig $databaseObj $dbServerName $true
        $hostName = GetPropertyValueFromConfig $connStringObj 'host' $true
        $dbName = GetPropertyValueFromConfig $connStringObj 'database' $true
        $shouldPrefix = GetPropertyValueFromConfig $connStringObj 'prefixed'         

        foreach ($connStringName in (GetDBMapping $dbServerName))
        {
            $newValue = GenerateConnectionString $hostName $dbName $shouldPrefix $connStringName $prefix
            SetNodeAttributeValue $xml "//connectionStrings/add[@name='$connStringName']" "connectionString" $newValue
        }
    }

    return $xml
}

function UpdateMessageEndpointMapping ([xml]$xml, [object]$messageEndpointMappingObj)
{
    $assemblies = @($messageEndpointMappingObj.psobject.Members | where { $_.MemberType -eq "NoteProperty" }).Name
    foreach($assembly in $assemblies)
    {
        $endpoint = GetPropertyValueFromConfig $messageEndpointMappingObj $assembly $false
        
        SetNodeAttributeValue $xml "//UnicastBusConfig/MessageEndpointMappings/add[@Assembly='$assembly']" "Endpoint" $endpoint
    }

    return $xml
}

function UpdateServicesAddressConfig ([xml]$xml, [object]$serversObj)
{
    $servers = @($serversObj.psobject.Members | where { $_.MemberType -eq "NoteProperty" }).Name
    foreach($server in $servers)
    {
        $serverObj = GetPropertyValueFromConfig $serversObj $server $true
        $hostName = GetPropertyValueFromConfig $serverObj "host" $true
        $port = GetPropertyValueFromConfig $serverObj "port" $true
           
        foreach ($name in (GetWcfServiceMapping $server))
        {
            $address = GetServiceAddressValue $name $hostName $port
            SetNodeAttributeValue $xml "//system.serviceModel/client/endpoint[@name='$name']" "address" $address
        }
        foreach ($name in (GetUriServiceMapping $server))
        {
            $address = GetServiceAddressValue $name $hostName $port
            SetNodeAttributeValue $xml "//system.serviceModel/services/service[@name='$name']/host/baseAddresses/add" "baseAddress" $address
        }
        foreach ($name in (GetSpotWSServiceMapping $server))
        {
            $address = GetServiceAddressValue $name $hostName $port
            SetNodeAttributeValue $xml "//system.runtime.remoting/application/client/wellknown[@type='$name']" "url" $address
        }
    }

    return $xml
}

function UpdateTraceLogConfig ([xml]$xml, [object]$envObj, [string]$serviceName)
{
    if ($serviceName.Contains("WebService"))
    {
        $traceLogPath = GetPropertyValueFromConfig $envObj "MPWSTraceLogPath" $false
    }
    elseif($serviceName.Contains("Subscriptions"))
    {
        $traceLogPath = GetPropertyValueFromConfig $envObj "SubscriptionsTraceLogPath" $false
    }
    else
    {
        $traceLogPath = GetPropertyValueFromConfig $envObj "MPTraceLogPath" $false
    }
    
    SetNodeAttributeValue $xml "//system.diagnostics/sharedListeners/add" "initializeData" "$traceLogPath\$serviceName`Log.svclog"
        
    return $xml
}

function UpdateConfigForEventLog ([xml]$xml, [string]$eventLogName, [string]$eventSourceName)
{
    SetAppSettingsValue $xml "CustomEventLog.LogName" $eventLogName
    SetAppSettingsValue $xml "CustomEventLog.SourceName" $eventSourceName
        
    return $xml
}

function GetServiceName([string]$environment, [string]$service)
{
    if ($environment -eq "") {return $service}
    return "$environment`_$service"
}

function GetPrefix([string]$environment, [string]$service)
{
    if ($environment -eq "") {return ""}
    return $environment + "_"
}

function GetServiceTargetPath([string]$environment, [string]$service, [string]$targetPath)
{
    $serviceName = GetServiceName $environment $service
    return "$targetPath\$serviceName"
}

function GetServiceLogPath([string]$environment, [string]$service, [string]$logPath)
{
    $serviceName = GetServiceName $environment $service
    return "$logPath\$serviceName"
}

function SetAppSettingsValue([xml]$xml, [string]$key, [string]$newValue)
{
    Log "Updating appSettings node with key $key (value = $newValue)"
    
    $node = GetAppSettingsNode $xml $key

    if($node)
    {
        $node.SetAttribute("value", "$newValue")
    }
    else
    {
        Log "Cannot find appSettings node with key $key"
    }
}
function GetAppSettingsNode([xml]$xml, [string]$key)
{
    return GetNode $xml "//appSettings/add[@key='$key']"
}

function SetNodeAttributeValue([xml]$xml, [string]$nodeXPath, [string]$attribute, [string]$newValue)
{
    Log "Updating $nodeXPath node ($attribute = $newValue)"
    
    $node = GetNode $xml $nodeXPath

    if($node)
    {
        $node.SetAttribute($attribute, "$newValue")
    }
    else
    {
        Log "Cannot find node with xPath $nodeXPath"
    }
}

function SetNodeAttributeValues([xml]$xml, [string]$nodeXPath, [string]$attribute, [string[]]$newValues)
{
    Log "Updating $nodeXPath node ($attribute = $newValue)"
    
    $SelectNodes  = GetNode $xml $nodeXPath
    
    if($node)
    {
        $node.SetAttribute($attribute, "$newValue")
    }
    else
    {
        Log "Cannot find node with xPath $nodeXPath"
    }
}

function GetNode([xml]$xml, [string]$nodeXPath)
{
    $node = $xml.SelectSingleNode($nodeXPath)

    return $node
}

function GenerateConnectionString([string]$dbServer, [string]$dbName, [string]$shouldPrefix, [string]$name, [string]$prefix)
{
    if ($shouldPrefix -eq "true")
    {
        $dbName = $prefix + $dbName
    }
    
    $appendStrng = GenerateConnectionAppendString $name
   
    return "data source=$dbServer;initial catalog=$dbName;$appendStrng"
}


function GenerateConnectionAppendString([string]$configKey)
{
    if (IsServiceControlConnectionStringSpecific $configKey)
    {
        return "Integrated Security=True;queue schema=dbo;"
    }
    #this is just to differentiate persistence and transport 
    #inorder for nhibernate not to break when SET NOCOUNT is set to ON by default
    if ($configKey.Contains("NServiceBus/Persistence")) 
    {
        return "Integrated Security=True;packet size=4096;"
    }

    return "Integrated Security=SSPI;packet size=4096;"
}

function IsServiceControlConnectionStringSpecific([string]$configKey)
{
    if ($configKey.Contains("Particular.ServiceControl") -or 
        $configKey.Contains("NServiceBus/Transport/audit") -or 
        $configKey.Contains("NServiceBus/Transport/error") 
        )
    {
        return $true
    }

    return $false
}

function ExtractPackageToTargetPath ([string]$packageZipFile, [string]$serviceTargetPath)
{
    Log "Creating target directory $serviceTargetPath"
    if ((Test-Path $serviceTargetPath) -eq $True)
    {
        Log "Target directory already exists. Removing directory."
        Remove-Item $serviceTargetPath -Recurse -Force -ErrorAction Stop
    }

    New-Item $serviceTargetPath -type directory -ErrorAction Stop

    Log "Extracting package $packageZipFile to target directory"

    if((Test-Path $packageZipFile) -eq $false)
    {
        Log "Package zip file not found: $packageZipFile" 
        return
    }

    Add-Type -AssemblyName System.Io.Compression.Filesystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($packageZipFile, $serviceTargetPath)
}

function Log([string]$message)
{
    Write-Host $message -ForegroundColor Green
}

function GetTargetPath([object]$envConfigObj, [string]$service)
{
    if ($service -eq "MassPaymentsWebService")
    {
        return GetPropertyValueFromConfig $envConfigObj "MPWSTargetPath" $true
    }
    else
    {
        return GetPropertyValueFromConfig $envConfigObj "MPTargetPath" $true
    }
}