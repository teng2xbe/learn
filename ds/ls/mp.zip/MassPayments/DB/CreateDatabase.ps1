param(
	[Parameter(Mandatory=$true)]
    [string]$dbName,
    [string]$server = "localhost",
	[string]$dbNamePrefix,
    [bool]$recreateDatabase = $false,
	[string] $serverDropFolder = ""
)

Set-StrictMode -Version Latest

function CreateDB 
{
	if ($recreateDatabase)
	{
		$snapshotFullPath = "$PSScriptRoot\Snapshot\$dbName"
		if((Test-Path $snapshotFullPath))
		{
			Write-Host "Restoring from snapshot..."
			& $PSScriptRoot\RestoreDB.ps1 -dbName $dbName -server $server -dbNamePrefix $dbNamePrefix -serverDropFolder $serverDropFolder
			Write-Host "Finished restoring from snapshot." -ForegroundColor Green
		}
		else
		{
			Write-Host "Creating database $dbNamePrefix$dbName..."
            DeleteDatabase $dbNamePrefix$dbName
			CreateDatabase $dbNamePrefix$dbName
			Write-Host "Finished creating database $dbNamePrefix$dbName..." -ForegroundColor Green
		}
	}
	else
	{
		CreateDatabase $dbNamePrefix$dbName
	}
}

function CreateDatabase ([string]$database)
{
    Write-Host "Attempting to create database [$database] on server $server..."
	Write-Host "--------------------------------------------------------------"

	if (DatabaseExists $database)
	{
		Write-Host "Database [$database] already exists."
		Write-Host "--------------------------------------------------------------"
		Return
	}

	$connectionString = "Data Source=$server; " + "Integrated Security=True; " + "Initial Catalog=master"
	$connection = new-object system.data.SqlClient.SQLConnection($connectionString)
	$connection.Open()

	$sqlCommand = "USE master CREATE DATABASE $database"
	$command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)	
	if ($command.ExecuteNonQuery() -ne -1)
	{
		throw "Failed to create database [$database] on server $server"
	}
	else
	{
		Write-Host "Successfully created database [$database] on server $server" -ForegroundColor Green
	}
	Write-Host "--------------------------------------------------------------"

	$connection.Close()
}

function DeleteDatabase ([string]$database)
{
    Write-Host "Attempting to delete database [$database] on server $server..."
	Write-Host "--------------------------------------------------------------"		

	if (-not (DatabaseExists $database))
	{
		Write-Host "Database [$database] was not found."
		Write-Host "--------------------------------------------------------------"
		Return
	}

	$connectionString = "Data Source=$server; " + "Integrated Security=True; " + "Initial Catalog=master"
	$connection = new-object system.data.SqlClient.SQLConnection($connectionString)
	$connection.Open()	

	$sqlCommand = "USE master ALTER DATABASE $database SET SINGLE_USER WITH ROLLBACK IMMEDIATE DROP DATABASE $database"
	$command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)	
	if ($command.ExecuteNonQuery() -ne -1)
	{
		throw "Failed to delete database [$database] on server $server"
	}
	else
	{
		Write-Host "Successfully deleted database [$database] on server $server" -ForegroundColor Green
	}
	Write-Host "--------------------------------------------------------------"

	$connection.Close()
}

function DatabaseExists([string]$database)
{
    Write-Host "Checking if database [$database] on server $server exists..."

    $connectionString = "Data Source=$server; "+"Integrated Security=True; "+"Initial Catalog=master"
    $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
    $connection.Open()
 
	$sqlCommand = "USE master SELECT 1 WHERE EXISTS (SELECT name FROM master.sys.databases WHERE name = N'$database')"
	$command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)
	if ($command.ExecuteScalar() -eq 1)
	{
        Write-Host "Database [$database] exists on server $server ..."    
		return $true
	}

    Write-Host "Database [$database] does not exists on server $server ..."    
    return $false
    $connection.Close()
}


if ($recreateDatabase -eq $false) 
{ 
    $recreateDatabase = -not (DatabaseExists $dbNamePrefix$dbName) 
}

CreateDB

