param(
	[Parameter(Mandatory=$true)]
    [string]$dbName,
    [string]$server = "localhost",
    [string]$snapshotDir = "$PSScriptRoot\Snapshot",
	[string]$dbNamePrefix,
	[string]$serverDropFolder = ""
)

Set-StrictMode -Version Latest
$env:PSModulePath = $env:PSModulePath + ";$PSScriptRoot;$PSScriptRoot\PSModules;$PSScriptRoot\..\PSModules;"

$snapshotPath="$snapshotDir\$dbName"
$dataFile = "$($dbName)"
$logFile = "$($dbName)_log"

function RestoreDB
{	
	if (-Not ([string]::IsNullOrWhiteSpace($dbNamePrefix)))
	{
		$dbName = $dbNamePrefix + $dbName
	}

    Write-Host "Restoring $dbName..."    

    if((Test-Path $snapshotPath) -eq $false)
    {
        throw "Snapshot file $snapshotPath was not found." 
    }
    
    Write-Host "Kill all sessions before Dropping databases"
sqlcmd -S $server -d master -E  -b -w 2000 -Q "ALTER DATABASE $dbName SET OFFLINE WITH ROLLBACK IMMEDIATE; ALTER DATABASE $dbName SET ONLINE" 
    #if(-not $LASTEXITCODE -eq 0) { throw "Failed to set database $dbName offline and online." }	

    Write-Host "Removing previously existing database '$dbName', if any, on server '$server' ..."
sqlcmd -S $server -E -Q "DROP DATABASE $dbName"
    if(-not $LASTEXITCODE -eq 0) { throw "Failed to drop existing database $dbName." }	

    Write-Host "Creating new database '$dbName' on server '$server' ..."
sqlcmd -b -S $server -E -Q "CREATE DATABASE $dbName"
    if(-not $LASTEXITCODE -eq 0) { throw "Failed to create new database $dbName." }	

    Write-Host "Restoring database from $snapshotPath"
#    set TMP_SNAPSHOT=%TMP%\%DB_SNAPSHOT_NAME%
#    if not exist %TMP_SNAPSHOT% copy %DB_SNAPSHOT_PATH% %TMP_SNAPSHOT%
sqlcmd -b -S $server -E -Q "use master;declare @phyname varchar(256); select @phyname=substring(physical_name, 1, charindex('master.mdf', physical_name)-1) from sys.database_files where name='master'; declare @phydata varchar(256); set @phydata=@phyname+'$($dbName)_Data.MDF'; declare @phylog varchar(256); set @phylog=@phyname+'$($dbName)_Log.LDF'; RESTORE DATABASE $dbName FROM DISK='$snapshotPath' WITH MOVE '$dataFile' TO @phydata, MOVE '$logFile' TO @phylog, REPLACE"
    if(-not $LASTEXITCODE -eq 0) { throw "Failed to restore the database $dbName from snapshot." }	
    
    Write-Host "Set database to simple recovery mode"
sqlcmd -S $server -d $dbName -E -b -w 2000 -Q "alter database $dbName set recovery simple"
    if(-not $LASTEXITCODE -eq 0) { throw "Failed to set simple recovery mode for database $dbName." }	

    Write-Host "Set database  $dbName to release unused space."
sqlcmd -S $server -d $dbName -E -b -w 2000 -Q "alter database $dbName set auto_shrink on" #> nul
    if(-not $LASTEXITCODE -eq 0) { throw "Failed to set database $dbName to release unused space." }	

    Write-Host "Shrink database $dbName."
sqlcmd -S $server -d $dbName -E -b -w 2000 -Q  "DBCC SHRINKDATABASE(N'$dbName' )"
    if(-not $LASTEXITCODE -eq 0) { throw "Failed to shrink database $dbName." }	

    Write-Host "Restoring database $dbName successfully completed." -ForegroundColor Green
}

try
{
	if (-Not ([string]::IsNullOrWhiteSpace($serverDropFolder)))
	{
		Write-Host "Moving $dbName snapshot to location accessible to SQL server ($serverDropFolder)..."
		$rndFilename = [System.IO.Path]::GetRandomFileName()
		Copy-Item -Path $snapshotPath -Destination "$serverDropFolder\$rndFilename.bak" -Force
		$snapshotPath = "$serverDropFolder\$rndFilename.bak"
		Write-Host "Done"
	}

	RestoreDB
}
finally
{
	if (-Not ([string]::IsNullOrWhiteSpace($serverDropFolder)))
	{
		if (Test-Path $snapshotPath)
		{
			Write-Host "Removing $dbName snapshot from drop folder ($snapshotPath)..."
			Remove-Item $snapshotPath
			Write-Host "Done"
		}
	}
}


