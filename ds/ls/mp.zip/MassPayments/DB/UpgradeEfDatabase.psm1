function DeployEfDatabase([string]$dbServer, [string]$dbName, [string] $dbPackageDir){
	$appConfigPath = "$dbPackageDir\efdb\app.config"
	Write-Host "Loading app config file $appConfigPath" -ForegroundColor Green
    [xml]$appConfigXml = Get-Content $appConfigPath -ErrorAction Stop

    Write-Host "Updating data sources and database names in $appConfigPath" -ForegroundColor Green
    Write-Host "====================================" 
    
	$connStringNode = $appConfigXml.SelectNodes("//connectionStrings/add")
	foreach($node in $connStringNode){
		$connString = $node.connectionString -replace "data source=([^;]+);", "data source=$dbServer;"  
		$connString = $connString -replace "initial catalog=([^;]+);", "initial catalog=$dbName;" 
		$node.SetAttribute("connectionString", $connString)
	}
	
    Write-Host "Saving $appConfigPath" -ForegroundColor Green
    $appConfigXml.Save($appConfigPath)
	
	Write-Host "Calling migration..." -ForegroundColor Green
	pushd
	cd "$dbPackageDir\efdb"
	
	$dllFiles = Get-ChildItem -Filter "*.dll" | Where-Object{$_.name -notlike "EntityFramework*.dll" -and $_.name -notlike "Subscriptions.Common.dll" -and $_.name -notlike "SharedUtilities.dll"}
	if($dllFiles -is [system.array]){
		foreach($file in $dllFiles){
			& .\migrate.exe "$($file.Name)"  /startupConfigurationFile="app.config"
		}
	}else{
		& .\migrate.exe "$($dllFiles.Name)"  /startupConfigurationFile="app.config"
	}
	popd
}

Export-ModuleMember -Function DeployEfDatabase