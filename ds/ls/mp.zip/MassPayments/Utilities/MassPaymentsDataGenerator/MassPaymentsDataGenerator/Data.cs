﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using MassPaymentsDataGenerator.Domain.Entities;
using MassPaymentsDataGenerator.JsonObjects;

namespace MassPaymentsDataGenerator
{
    public static class Data
    {
        private static readonly Random rnd = new Random();
        private static readonly string[] Entities = { "Individual", "Company" };
        private static readonly string[] FirstNames = { "Ronan", "Faith", "Hayes", "Ora", "Allen", "Holly", "Sopoline", "Cheyenne", "Yoshi", "Stella", "Sonya", "Hadley", "Ulla", "Blaze", "Leigh", "Chanda", "Lareina", "Macon", "Virginia", "Wallace", "Cain", "Renee", "Ruby", "Shelly", "Kato", "Fleur", "Marah", "Shay", "Kaitlin", "Carl", "Nevada", "Ronan", "Heidi", "Galena", "Bernard", "Kylynn", "Keegan", "Ruby", "Alma", "Whilemina", "Giacomo", "Armand", "Knox", "Janna", "Willa", "Jameson", "Cheryl", "Dahlia", "Elizabeth", "Suki", "Rana", "Clare", "Brennan", "Penelope", "Shellie", "Upton", "Chiquita", "Bo", "Beatrice", "Ciaran", "Slade", "Hector", "Whilemina", "Mufutau", "Victor", "Warren", "Octavius", "Calvin", "Nehru", "Jonas", "Hayfa", "Ima", "Rae", "Blake", "John", "Kirsten", "Josephine", "Savannah", "Sophia", "Nomlanga", "Lillian", "Ignacia", "Illana", "Curran", "Cameran", "Rebekah", "Talon", "Carla", "Palmer", "Brock", "Kai", "Silas", "Aiko", "Tamekah", "Frances", "Kevin", "Stuart", "Tarik", "Kasper", "Montana" };
        private static readonly string[] MiddleNames = { "W", "M", "S", "I", "Z", "M", "B", "X", "U", "Y", "K", "G", "H", "I", "I", "S", "B", "A", "W", "Z", "J", "A", "U", "I", "B", "J", "W", "I", "R", "Y", "Z", "E", "F", "X", "L", "R", "C", "T", "C", "S", "A", "C", "A", "E", "H", "M", "Z", "H", "V", "Y", "U", "Y", "T", "Z", "P", "D", "P", "U", "O", "I", "C", "H", "Y", "S", "V", "M", "E", "S", "Z", "S", "M", "P", "S", "N", "K", "F", "I", "K", "V", "G", "S", "K", "J", "V", "R", "M", "N", "B", "S", "T", "V", "Q", "L", "U", "D", "M", "C", "W", "E", "T" };
        private static readonly string[] LastNames = { "Cabrera", "Sawyer", "Velazquez", "Dejesus", "Pate", "George", "Hines", "Dodson", "Wolfe", "Cote", "Norman", "Dotson", "Mcclain", "Hayden", "Cook", "Valdez", "Beck", "Snider", "Mack", "Klein", "Little", "Hughes", "Guy", "Diaz", "Sweeney", "Lucas", "Sanchez", "Puckett", "Langley", "Leblanc", "Case", "Humphrey", "Simon", "Brock", "Sanders", "Steele", "Graves", "Conrad", "Wong", "Torres", "Perez", "Rogers", "Dotson", "Mcfarland", "Andrews", "Ortega", "Wilkins", "Thompson", "Davis", "Cole", "Hill", "Holt", "Hutchinson", "Flores", "Ortiz", "Powers", "Hester", "Nelson", "Chase", "Cochran", "Spears", "Compton", "Blake", "Collins", "Aguilar", "Houston", "Kirby", "Quinn", "Soto", "Bray", "Molina", "Kinney", "Mayo", "Ochoa", "Benton", "Watson", "Frederick", "Brewer", "Booth", "Petty", "Robles", "Jacobson", "Lindsay", "Evans", "Copeland", "Castro", "Nelson", "Brown", "Good", "Byers", "Harmon", "Fulton", "Cervantes", "Bridges", "Mcdowell", "Frank", "Curry", "Perkins", "Hurst", "Bolton" };
        private static readonly string[] PhoneNumbers = { "+520-912-9865", "+428-320-7194", "+728-295-8377", "+410-329-5861", "+189-978-0686", "+472-195-0692", "+753-833-7426", "+916-707-7044", "+102-144-9421", "+802-184-0641", "+171-113-0226", "+708-940-7952", "+650-898-6360", "+623-608-5667", "+971-890-0349", "+465-843-3456", "+272-941-9256", "+672-586-1237", "+880-382-6833", "+131-789-9351", "+400-163-4692", "+442-176-1638", "+540-792-4413", "+329-984-4580", "+552-589-2915", "+701-121-8736", "+703-248-7923", "+872-823-5075", "+472-207-6856", "+224-588-0908", "+518-118-1408", "+903-913-0050", "+340-729-7057", "+329-695-9778", "+544-421-3150", "+833-881-7595", "+327-838-7937", "+852-311-1897", "+572-774-4319", "+906-814-1420", "+491-176-4087", "+863-909-8401", "+773-342-5490", "+682-278-7547", "+462-696-5956", "+246-513-9647", "+728-453-6928", "+540-668-5123", "+857-754-8434", "+441-403-8299", "+311-651-7184", "+957-596-1901", "+566-328-5800", "+579-414-6270", "+137-747-2907", "+799-592-0487", "+591-760-2854", "+436-546-2915", "+761-697-3503", "+531-798-4555", "+391-624-7067", "+913-618-4412", "+868-353-0671", "+114-506-4928", "+418-543-1815", "+641-637-0319", "+790-662-1081", "+691-621-8446", "+142-134-7936", "+832-615-0700", "+849-387-1043", "+733-966-5759", "+416-900-0398", "+526-388-9635", "+821-565-3114", "+700-166-2372", "+849-681-4360", "+852-838-5769", "+209-805-5692", "+158-977-6257", "+126-603-2900", "+715-730-8254", "+951-690-5926", "+908-920-3461", "+325-971-9279", "+585-636-3756", "+417-772-6132", "+138-897-2659", "+155-530-5227", "+358-598-8715", "+938-655-7412", "+909-976-5162", "+712-658-2496", "+845-843-6791", "+932-647-5950", "+457-885-6641", "+812-930-3101", "+908-656-3363", "+187-940-5547", "+738-540-4571" };
        private static readonly string[] Gender = { "Male", "Female" };
        private static readonly string[] BusinessNames = {"Natoque Penatibus Et Foundation", "Elit Dictum Corp.", "In Institute", "Parturient Montes Nascetur Foundation", "Nibh LLP", "Nulla PC", "Erat Sed Nunc PC", "Vestibulum Ante Corporation", "Ante Ipsum Primis Limited", "Egestas Duis Consulting", "Enim LLC", "Nibh Enim Limited", "Sit Amet Ante LLP", "Duis A Mi PC", "Eget Volutpat Ornare Ltd", "Vitae Orci Phasellus Associates", "Purus Corporation", "Feugiat Institute", "Magna A Tortor Institute", "Cursus Associates", "Justo Proin Consulting", "Non Feugiat Nec Inc.", "Non Leo Vivamus Limited", "Non LLC", "Risus Donec Egestas Corporation", "Ut PC", "Nulla Eu Limited", "Est Nunc PC", "Vel Arcu LLP", "Duis At Lacus Industries", "Placerat Corporation", "Consequat PC", "Hendrerit Donec Industries", "Eu PC", "Ullamcorper Foundation", "Penatibus Et Foundation", "Scelerisque Incorporated", "Odio LLP", "Nec Quam Curabitur Corporation", "Nulla Vulputate Foundation", "Cras Dolor Dolor Associates", "Maecenas Malesuada Inc.", "Egestas Corp.", "Elit Limited", "Malesuada Vel PC", "Purus Industries", "A Limited", "Cras Foundation", "Aliquam Vulputate Ullamcorper Foundation", "Dui Cum Limited", "Pede Industries", "Eu Euismod Ac Consulting", "Orci Ut Sagittis PC", "Consectetuer Ipsum Nunc Foundation", "Volutpat Industries", "Velit Sed Malesuada PC", "Nunc Sed LLP", "Felis Orci Adipiscing Consulting", "Adipiscing Fringilla Porttitor Consulting", "Pellentesque Sed Corp.", "Ligula Company", "Sapien Gravida PC", "Aliquam PC", "Nunc Mauris Incorporated", "Donec Foundation", "Odio Phasellus Corporation", "Eu Enim Etiam LLC", "Vulputate Velit Eu Industries", "Scelerisque Neque Sed Foundation", "Adipiscing Institute", "Nec Associates", "Eleifend Egestas Incorporated", "Id Libero LLC", "Fusce Aliquam Enim Institute", "Nunc Nulla Industries", "Sed Id Industries", "Pulvinar Ltd", "Magna Sed Eu Foundation", "Enim Ltd", "Nec Tempus LLC", "Risus Duis Incorporated", "Eu Elit Consulting", "Donec Consectetuer Mauris Incorporated", "Enim Sed Nulla LLC", "Dictum Magna Ut LLC", "Et Euismod Corp.", "Non Sollicitudin A Inc.", "Ultrices Corporation", "Ligula Aenean LLC", "Nonummy Fusce Foundation", "Sapien Cursus Incorporated", "Iaculis Aliquet Diam LLC", "Donec Porttitor Tellus LLP", "Nec Mauris Corporation", "Ante Ipsum Corp.", "Arcu Curabitur Ut Ltd", "Adipiscing LLP", "Egestas A Scelerisque LLC", "Vivamus Rhoncus Consulting", "In Corporation"};
        private static readonly string[] Emails = {"urna.Vivamus.molestie@ettristique.com", "Phasellus.ornare@odiosagittissemper.org", "risus.at@gravidaAliquamtincidunt.edu", "velit@molestiearcu.org", "posuere@diam.net", "natoque@Integersem.edu", "mauris.sagittis@Curabitur.org", "magnis.dis.parturient@tortordictum.co.uk", "tellus@parturient.co.uk", "volutpat.nunc@feugiat.org", "vestibulum.massa.rutrum@mollisDuis.ca", "urna.nec@vitaesodales.edu", "mus.Donec@massaInteger.org", "eget@atiaculis.net", "morbi.tristique.senectus@convalliserateget.edu", "tortor.Nunc.commodo@laoreetipsum.com", "eget.odio.Aliquam@Nunclectus.com", "nonummy.ipsum.non@pharetrautpharetra.net", "Quisque.ornare@sitamet.ca", "eget.ipsum@sedconsequat.edu", "id.libero@quam.co.uk", "non@Nullatincidunt.net", "gravida@tellus.net", "parturient.montes.nascetur@dolor.com", "tristique@lobortisClass.ca", "Suspendisse@tellus.edu", "Mauris@acurnaUt.net", "neque@adlitora.net", "arcu.Vestibulum.ante@duiFuscediam.ca", "ut.dolor.dapibus@semmagnanec.co.uk", "sapien@auctor.net", "Vivamus.sit.amet@mollis.com", "massa.non.ante@velturpis.org", "commodo.auctor.velit@orciPhasellusdapibus.com", "ante.dictum@Nullamnisl.com", "erat.Vivamus.nisi@sitametmetus.net", "natoque.penatibus.et@Vivamus.net", "lacus@semelit.com", "nec.quam.Curabitur@iaculisquis.net", "non.ante@Cras.org", "lectus@mi.ca", "sem.egestas@Sedetlibero.edu", "fermentum.arcu.Vestibulum@molestie.co.uk", "non@sedsemegestas.edu", "arcu.iaculis.enim@dictum.com", "ornare.sagittis@lectusjustoeu.org", "velit@ametmassa.net", "Suspendisse@ac.org", "consequat.lectus.sit@infaucibus.co.uk", "Etiam@nequeSed.edu", "velit.justo@egetdictumplacerat.net", "est.vitae.sodales@Aliquamornarelibero.ca", "Fusce@Nullam.net", "Morbi@ac.co.uk", "Sed.dictum.Proin@tellusidnunc.com", "metus@parturient.net", "diam@sitametorci.net", "tristique.pharetra@dis.edu", "eu.neque@egestas.edu", "Nam.interdum@vulputateveliteu.com", "ac.arcu@dapibusquamquis.org", "at.libero@Nullam.net", "felis.adipiscing.fringilla@sagittis.org", "quis.arcu@sedfacilisis.net", "Integer.tincidunt.aliquam@purus.ca", "Mauris.non@idmollis.com", "risus@nonummy.com", "augue.porttitor.interdum@augueeutempor.net", "Integer.eu.lacus@euerat.co.uk", "Phasellus.nulla.Integer@Integer.co.uk", "lacus@Nuncsollicitudincommodo.co.uk", "Vivamus.nisi@ligulatortordictum.org", "tellus.faucibus@Suspendisseac.edu", "mattis.semper@eratSednunc.co.uk", "ligula.Aliquam.erat@tellus.org", "ipsum.Curabitur@adipiscing.net", "ipsum.primis@idantedictum.net", "quam.vel.sapien@Phasellusfermentum.ca", "in.cursus@maurissitamet.ca", "nisi@Donec.org", "sit@erategetipsum.com", "Suspendisse@primis.edu", "auctor.non.feugiat@volutpat.org", "magna.Lorem.ipsum@lacusUt.ca", "nulla@etmagna.net", "eget.metus.In@diam.ca", "aliquet.nec@IntegerurnaVivamus.com", "consequat.auctor.nunc@metus.ca", "massa.Vestibulum.accumsan@Vivamuseuismod.co.uk", "massa@facilisismagnatellus.com", "eu.eros@lobortisquama.ca", "nisi.Cum.sociis@imperdietnec.ca", "ante@Cras.net", "erat.neque.non@risusInmi.edu", "lacinia.orci@sapien.net", "Suspendisse@disparturient.co.uk", "neque.sed@variusultricesmauris.ca", "congue.In@feugiatnec.ca", "Nulla.eget@estNunc.ca", "rhoncus.Nullam@intempus.ca"};
        private static readonly string[] Addresses = {"Ap #422-9000 Nec Street", "Ap #128-1670 In St.", "Ap #418-1968 Mauris Av.", "Ap #965-8469 Purus Street", "127-3422 In Rd.", "604-982 Enim St.", "4047 Aenean Street", "9626 Phasellus Street", "8561 Et Avenue", "9063 Pellentesque Rd.", "9422 Vitae, St.", "327-3086 Nunc. Av.", "Ap #407-6706 Luctus St.", "Ap #750-2016 Etiam Road", "216-6304 Egestas, Ave", "P.O. Box 630, 2518 Dis St.", "P.O. Box 969, 4070 Porttitor St.", "P.O. Box 565, 1882 Cras Rd.", "P.O. Box 821, 3867 Vel, Av.", "697-239 Ornare, Avenue", "P.O. Box 107, 277 Ornare Av.", "Ap #543-2479 Erat Av.", "Ap #167-173 Ac Road", "P.O. Box 222, 9809 Nec Rd.", "834-2645 Tristique Av.", "P.O. Box 573, 7844 Adipiscing Road", "6766 Sagittis. St.", "4286 Taciti Rd.", "Ap #211-9290 A Ave", "5993 Nulla. Avenue", "6758 Maecenas Road", "2461 Et St.", "7550 Et, Avenue", "Ap #147-929 Nec St.", "Ap #907-5676 Turpis. St.", "631-689 Tempor Avenue", "Ap #211-635 Eu St.", "291-5531 Porttitor Rd.", "P.O. Box 885, 3400 Nunc. Rd.", "8859 Gravida Street", "Ap #476-4629 Ipsum. St.", "P.O. Box 357, 9107 Elit Street", "573-1199 Lobortis St.", "586-3847 Pede. Ave", "4256 In Rd.", "P.O. Box 996, 3289 Tellus Rd.", "3693 Id Av.", "P.O. Box 885, 1111 Vitae Road", "568-365 Mauris. Av.", "Ap #192-2286 Est. St.", "732-5143 Ut Ave", "2375 Velit. Rd.", "P.O. Box 842, 7620 Mauris Rd.", "2864 Phasellus St.", "396-4516 Magna Street", "3662 Suspendisse St.", "866-8845 Eros Rd.", "Ap #659-6242 Proin Rd.", "P.O. Box 759, 4291 Aliquam St.", "P.O. Box 526, 5633 Sagittis Ave", "438-5795 Proin Road", "P.O. Box 419, 6536 Dignissim Ave", "Ap #752-5148 Vel Rd.", "513-6656 Proin Street", "336-4100 Quis Avenue", "Ap #135-4837 Pellentesque. Avenue", "721-6277 Est Road", "Ap #266-7330 Sed Avenue", "P.O. Box 725, 1922 Sit Av.", "355-6555 Tempor St.", "P.O. Box 787, 5262 Egestas Rd.", "8257 Aliquam, Avenue", "568-7171 Magna. Ave", "Ap #128-586 Integer Avenue", "P.O. Box 718, 7800 Vestibulum Ave", "104-3294 Nunc St.", "P.O. Box 989, 6510 Nulla Ave", "349-7816 Sapien Street", "Ap #780-8669 Faucibus. Road", "P.O. Box 510, 547 Ullamcorper. Rd.", "Ap #785-850 A Avenue", "P.O. Box 366, 3576 Sed, Rd.", "P.O. Box 302, 9708 Faucibus Street", "553-7998 Nullam Rd.", "Ap #889-2745 Consequat Rd.", "Ap #396-8488 Sem Street", "1851 Convallis Rd.", "Ap #961-145 Neque. Rd.", "P.O. Box 968, 3271 Mollis. Street", "8416 Augue Road", "4745 Neque Avenue", "8691 Nunc Rd.", "944-6173 Nunc Rd.", "8539 Mauris Ave", "1886 Pharetra, Avenue", "Ap #504-8354 Elit, Av.", "787-5771 Tristique St.", "P.O. Box 368, 5592 Dui. St.", "6032 Vel Rd.", "P.O. Box 227, 6578 Eros Avenue"};
        private static readonly string[] Cities = {"Port Hope", "Gorzów Wielkopolski", "Grand Falls", "Harlingen", "Albiano", "G�ppingen", "Swansea", "Port Coquitlam", "Lincoln", "Vancouver", "Williams Lake", "Haasdonk", "Norman", "Saintes", "Lille", "Township of Minden Hills", "Worthing", "Krishnanagar", "Navsari", "Melle", "Issime", "Tourinne", "Joliet", "Turrialba", "Grasse", "Kirriemuir", "Busso", "Bergen", "New Quay", "Hulshout", "Darlington", "Paraíso", "Schwedt", "Nieuwegein", "Motueka", "Thisnes", "Saint-Pierre", "Orange", "Pickering", "Poggio Berni", "Chippenham", "Saint-Remy", "Santa Luzia", "Spy", "Paraíso", "Hertsberge", "Bellante", "Béziers", "Metz", "Martello/Martell", "Kırıkhan", "Strongoli", "Lichfield", "Stintino", "Gonda", "Dhanbad", "Eernegem", "Esterzili", "Milnathort", "Villanovafranca", "Fernie", "Quinte West", "Bansberia", "Markkleeberg", "Memphis", "Bolton", "Lochranza", "Cochrane", "Richmond", "Houtave", "Kuurne", "Saint-Hilarion", "Radicofani", "Rock Springs", "New Orleans", "Montreuil", "Meeuwen", "Cottbus", "Laurencekirk", "Cannock", "Lake Cowichan", "Tielrode", "Völkermarkt", "Landenne", "Zelzate", "San Damiano al Colle", "Durg", "Zonhoven", "Hertford", "Vöcklabruck", "Maubeuge", "Spittal an der Drau", "Siedlce", "Fauglia", "Colomiers", "Vitrival", "Wimborne Minster", "Isle-aux-Coudres", "Fort Saskatchewan", "Grand-Manil"};
        private static readonly string[] Descriptions = {"et netus et malesuada fames", "diam luctus lobortis. Class aptent taciti sociosqu ad litora", "arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec enim.", "Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non,", "consectetuer mauris id sapien. Cras dolor dolor, tempus non,", "orci, adipiscing non, luctus sit amet, faucibus ut, nulla.", "sit amet diam eu", "magna. Sed eu eros. Nam consequat dolor vitae dolor. Donec", "nec, euismod in, dolor. Fusce feugiat. Lorem ipsum", "dolor, tempus non, lacinia at, iaculis quis, pede. Praesent", "risus, at fringilla purus mauris a nunc. In", "egestas, urna justo faucibus lectus, a sollicitudin orci sem eget", "blandit mattis. Cras eget", "nunc sed libero. Proin sed turpis nec", "Mauris molestie pharetra nibh. Aliquam", "eu enim. Etiam imperdiet dictum magna. Ut", "massa. Quisque porttitor eros nec tellus. Nunc lectus", "eget odio. Aliquam vulputate ullamcorper magna. Sed", "in magna. Phasellus dolor", "dolor, nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui.", "convallis, ante lectus convallis est, vitae sodales", "tempus, lorem fringilla ornare placerat, orci lacus", "dictum. Proin eget odio. Aliquam vulputate ullamcorper", "Aliquam ultrices iaculis odio. Nam interdum enim non nisi. Aenean", "vitae aliquam eros turpis non enim. Mauris quis turpis", "tristique pellentesque, tellus sem mollis dui, in", "adipiscing elit. Etiam laoreet,", "fringilla mi lacinia mattis.", "nibh. Donec est mauris, rhoncus id, mollis nec, cursus", "dictum augue malesuada malesuada.", "nascetur ridiculus mus. Donec dignissim magna a", "tempor erat neque non quam. Pellentesque habitant morbi", "augue ut lacus. Nulla tincidunt, neque vitae semper egestas,", "magna. Nam ligula elit,", "Nullam suscipit, est ac facilisis facilisis,", "erat semper rutrum. Fusce dolor quam, elementum at, egestas", "Sed nulla ante, iaculis nec,", "massa. Vestibulum accumsan neque et nunc. Quisque ornare", "nec mauris blandit mattis. Cras eget nisi dictum augue", "Vivamus nisi. Mauris nulla. Integer urna. Vivamus molestie", "amet nulla. Donec non justo.", "rhoncus id, mollis nec, cursus a, enim. Suspendisse aliquet,", "accumsan laoreet ipsum. Curabitur consequat, lectus sit amet", "lobortis ultrices. Vivamus rhoncus. Donec est.", "arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec", "rutrum magna. Cras convallis convallis dolor.", "Cras interdum. Nunc sollicitudin commodo", "Integer eu lacus. Quisque imperdiet, erat nonummy", "sed orci lobortis augue scelerisque mollis.", "pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod", "sociis natoque penatibus et magnis dis", "orci luctus et ultrices posuere cubilia Curae; Phasellus ornare.", "Donec tempor, est ac", "a mi fringilla mi lacinia mattis.", "semper egestas, urna justo faucibus lectus, a sollicitudin orci sem", "ac libero nec ligula", "ante bibendum ullamcorper. Duis cursus,", "inceptos hymenaeos. Mauris ut quam vel sapien imperdiet ornare. In", "diam at pretium aliquet,", "varius ultrices, mauris ipsum porta elit, a feugiat tellus lorem", "bibendum ullamcorper. Duis cursus, diam at pretium", "posuere vulputate, lacus. Cras interdum. Nunc sollicitudin", "vulputate ullamcorper magna. Sed eu eros. Nam", "dictum. Proin eget odio. Aliquam vulputate ullamcorper magna. Sed eu", "massa rutrum magna. Cras convallis convallis dolor.", "magna. Ut tincidunt orci quis lectus. Nullam", "imperdiet nec, leo. Morbi neque tellus, imperdiet non,", "litora torquent per conubia nostra, per inceptos hymenaeos. Mauris", "ut nisi a odio semper cursus.", "Praesent interdum ligula eu enim. Etiam imperdiet dictum", "arcu. Morbi sit amet massa. Quisque porttitor eros nec tellus.", "Etiam ligula tortor, dictum", "augue. Sed molestie. Sed id risus quis diam luctus", "ipsum primis in faucibus orci luctus et ultrices posuere", "pharetra, felis eget varius ultrices, mauris ipsum porta elit,", "odio a purus. Duis elementum, dui quis accumsan", "dictum sapien. Aenean massa. Integer vitae nibh. Donec", "amet, consectetuer adipiscing elit.", "enim. Curabitur massa. Vestibulum accumsan neque et", "fringilla mi lacinia mattis. Integer eu lacus.", "Duis sit amet diam eu dolor egestas rhoncus.", "tristique neque venenatis lacus. Etiam", "scelerisque dui. Suspendisse ac", "ac, feugiat non, lobortis quis, pede.", "gravida sagittis. Duis gravida. Praesent eu nulla at sem molestie", "eu erat semper rutrum. Fusce dolor quam,", "massa rutrum magna. Cras convallis convallis dolor.", "ante lectus convallis est, vitae sodales nisi magna sed dui.", "est arcu ac orci. Ut semper pretium", "dignissim lacus. Aliquam rutrum lorem ac risus. Morbi", "pede ac urna. Ut tincidunt vehicula risus. Nulla eget", "nonummy. Fusce fermentum fermentum", "sed, hendrerit a, arcu. Sed et", "sem semper erat, in consectetuer ipsum nunc id", "aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend", "ligula. Aenean gravida nunc", "nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim.", "Donec tempor, est ac mattis semper, dui", "ipsum ac mi eleifend", "vel, faucibus id, libero. Donec consectetuer mauris id sapien. Cras"};
        private static readonly string[] CurrencyCodes = {"AED", "AUD", "BHD", "BWP", "CAD", "CHF", "CNH", "CZK", "DKK", "EUR", "FJD", "GBP", "GHS", "GMD", "HKD", "HUF", "ILS", "INR", "ISK", "JOD", "JPY", "KES", "KWD", "LSL", "MAD", "MGA", "MUR", "MWK", "MYR", "MZN", "NAD", "NGN", "NOK", "NZD", "OMR", "PGK", "PHP", "PLN", "QAR", "SBD", "SEK", "SGD", "SZL", "THB", "TND", "TOP", "TRY", "UGX", "USD", "VUV", "WST", "XPF", "ZAR", "ZMW"};
        private static readonly string[] SettlementCurrencyCodes = {"USD", "CAD", "EUR", "AUD"};
        private static readonly string[] BICs = { "IRVTUS3NXXX", "WPACAU2SXXX", "SBZAZAJJXXX", "ROYCCAT2XXX", "BOFAHKHXXXX", "CEKOCZPPXXX", "DABADKKKXXX", "BBRUBEBBXXX", "BOSPFJFJXXX", "ABNAGB2LXXX" };
        private static readonly string[] BeneType = {"Individual", "Business"};
        private static readonly string[] BusinessRemittanceType = {"CCD", "CTX"};
        private static readonly string[] PaymentMethods = {"ACH", "WIRE"};

        public static string GetRandomString(int length)
        {
            System.Threading.Thread.Sleep(1);
            var random = new Random(Guid.NewGuid().GetHashCode());
            return new string(
                Enumerable.Repeat("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", length)
                          .Select(s => s[random.Next(s.Length)])
                          .ToArray());
        }

        public static string GetRandomUniqueString(int length, List<string> alreadyUsed)
        {
            var text = GetRandomString(length);
            while (alreadyUsed.Contains(text))
            {
                text = GetRandomString(length);
            }

            alreadyUsed.Add(text);

            return text;
        }

        public static string GetRandomText(int length)
        {
            System.Threading.Thread.Sleep(1);
            var random = new Random(Guid.NewGuid().GetHashCode());
            return new string(
                Enumerable.Repeat("ABCDEFGHIJKLMNOPQRSTUVWXYZ", length)
                          .Select(s => s[random.Next(s.Length)])
                          .ToArray());
        }

        public static int GetRandomInt(int min = 10000, int max = 99999, Random rand = null)
        {
            if (rand == null)
            {
                System.Threading.Thread.Sleep(1);
                rand = new Random(Guid.NewGuid().GetHashCode());
            }

            return rand.Next(min, max);
        }
        
        public static string GetRandomEntity()
        {
            return Entities[new Random().Next(0, 1)];
        }

        public static string GetRandomBeneType()
        {
            System.Threading.Thread.Sleep(1);
            return BeneType[rnd.Next(0, 2)];
        }

        public static string GetRandomBusinessRemittanceType()
        {
            return BusinessRemittanceType[new Random().Next(0, 2)];
        }

        public static string GetRandomPaymentMethod()
        {
            System.Threading.Thread.Sleep(1);
            return PaymentMethods[rnd.Next(0, 2)];
        }

        public static List<JsonPaymentBeneficiary> GetBeneficiariesFromFile(string fileName)
        {
            var beneficiaries = new List<JsonPaymentBeneficiary>();

            if (string.IsNullOrEmpty(fileName))
                return beneficiaries;

            var fileLines = File.ReadAllLines(fileName).ToList();

            if (fileLines.Count < 2)
                return beneficiaries;

            List<string> headers = null;
            foreach (var line in fileLines)
            {
                var beneDetails = line.TrimEnd().Split('\t').ToList();

                if (headers == null)
                {
                    //get header names            
                    headers = beneDetails; continue;
                }

                var columnCount = 0;
                var name = new Name();
                foreach (var detail in beneDetails)
                {
                    if (columnCount > headers.Count) break;
                    name.FirstName = headers[columnCount].ToUpper() == "FIRST NAME" ? 
                            string.IsNullOrEmpty(detail) ? string.Empty : detail : name.FirstName;
                    name.LastName = headers[columnCount].ToUpper() == "LAST NAME" ?
                            string.IsNullOrEmpty(detail) ? string.Empty : detail : name.LastName;
                    columnCount++;
                }

                var beneficiary = GetRandomPaymentBeneficiary(name);
                beneficiaries.Add(beneficiary);
            }

            return beneficiaries;
        }
        public static string GetRandomFirstName()
        {
            return FirstNames[new Random().Next(0, FirstNames.Length - 1)];
        }

        public static string GetRandomMiddleName()
        {
            return MiddleNames[new Random().Next(0, MiddleNames.Length - 1)];
        }

        public static string GetRandomLastName()
        {
            return LastNames[new Random().Next(0, LastNames.Length - 1)];
        }

        public static string GetRandomPhoneNumber()
        {
            return PhoneNumbers[new Random().Next(0, PhoneNumbers.Length - 1)];
        }

        public static string GetRandomDate(int minYear = 1910, int maxYear = 2015, bool includeTime = false)
        {
            var random = new Random();

            var now = DateTime.Now;

            return includeTime ?
                new DateTime(random.Next(minYear, maxYear), random.Next(1, 12), random.Next(1, 28), now.Hour, now.Minute, now.Second).ToString("s") + "Z" : 
                new DateTime(random.Next(minYear, maxYear), random.Next(1, 12), random.Next(1, 28)).ToString("yyyy-MM-dd");
        }

        public static string GetRandomGender()
        {
            return Gender[new Random().Next(0, 1)];
        }

        public static string GetRandomBusinessName()
        {
            return BusinessNames[new Random().Next(0, BusinessNames.Length - 1)];
        }

        public static string GetRandomEmail()
        {
            return Emails[new Random().Next(0, Emails.Length - 1)];
        }

        public static string GetRandomAddress()
        {
            return Addresses[new Random().Next(0, Addresses.Length - 1)];
        }

        public static string GetRandomCity()
        {
            return Cities[new Random().Next(0, Cities.Length - 1)];
        }

        public static string GetRandomDescription()
        {
            return Descriptions[new Random().Next(0, Descriptions.Length - 1)];
        }

        private static string GetRandomBIC()
        {
            return BICs[new Random().Next(0, BICs.Length - 1)];
        }

        public static string GetRandomCurrencyCode(string excluding = "")
        {
            return CurrencyCodes.Where(c => c != excluding).ToArray()[new Random().Next(0, CurrencyCodes.Length - 1)];
        }

        public static string GetRandomSettlementCurrencyCode()
        {
            return SettlementCurrencyCodes.ToArray()[new Random().Next(0, SettlementCurrencyCodes.Length - 1)];
        }

        public static string GetRandomItemFromList(List<string> items)
        {
            return items.ToArray()[new Random().Next(0, items.Count)];
        }
        
        public class CurrencyPair
        {
            public string SettlementCurrency;
            public string TradeCurrency;

            public override bool Equals(object obj)
            {
                var currencyPair = obj as CurrencyPair;
                return currencyPair.SettlementCurrency == SettlementCurrency && currencyPair.TradeCurrency == TradeCurrency;
            }
        }

        public static List<CurrencyPair> GetUniqueCurrencyPairs(int count)
        {
            var pairs = new List<CurrencyPair>();
            var rand = new Random();

            while (pairs.Count < count)
            {
                var currencyPair = new CurrencyPair
                {
                    SettlementCurrency = SettlementCurrencyCodes[rand.Next(0, SettlementCurrencyCodes.Count() - 1)],
                    TradeCurrency = CurrencyCodes[rand.Next(0, CurrencyCodes.Count() - 1)]
                };

                if (!pairs.Contains(currencyPair))
                    pairs.Add(currencyPair);
            }
            
            return pairs;
        }

        public static bool GetRandomBool(Random rand = null)
        {
            if (rand == null)
            {
                System.Threading.Thread.Sleep(1);
                rand = new Random();
            }
            return Convert.ToBoolean(rand.Next(2) == 0);
        }

        public static JsonAddress GetRandomJsonAddress()
        {
            return new JsonAddress
            {
                AddressLine1 = GetRandomAddress(),
                AddressLine2 = "",
                AddressLine3 = "",
                City = GetRandomCity(),
                StateOrPovince = "CA",
                ZipOrPostalCode = "12345",
                CountryCode = "US"
            };
        }

        public static JsonBeneficiaryIdentification GetRandomJsonIdentification()
        {
            return new JsonBeneficiaryIdentification
            {
                EntityType = GetRandomEntity(),
                FirstName = GetRandomFirstName(),
                MiddleName = GetRandomMiddleName(),
                LastName = GetRandomLastName(),
                PhoneNumber = GetRandomPhoneNumber(),
                CellNumber = GetRandomPhoneNumber(),
                DateOfBirth = GetRandomDate(),
                Gender = GetRandomGender(),
                BusinessName = GetRandomBusinessName(),
                BusinessRegistrationNumber = GetRandomInt().ToString(),
                BusinessRegistrationCountry = "US",
                BusinessRegistrationStateProv = "CA",
                BusinessContactRole = "CEO",
                Industry = "Finance",
                EmailAddress = GetRandomEmail()
            };
        }

        public static JsonBankAccount GetRandomBankAccount()
        {
            return new JsonBankAccount
            {
                ExternalAccountId = GetRandomString(10),
                VersionNumber = 1,
                ExternalAccountType = "BANK_ACCOUNT_CANADA",
                AccountPurpose = "SAVINGS",
                CurrencyCode = "USD",
                BankName = "Humungous Bank Inc.",
                BranchName = GetRandomInt().ToString(),
                BankAddress = GetRandomJsonAddress(),
                BankCode = GetRandomInt().ToString(),
                BranchCode = GetRandomInt().ToString(),
                AccountNumber = GetRandomInt().ToString(),
                DisplayName = "Humungous Bank",
                IntermediaryBankAccount = GetRandomIntermediaryAccount()
            };
        }

        public static JsonBeneficiaryBankAccount GetRandomBeneBankAccount()
        {
            return new JsonBeneficiaryBankAccount()
            {
                Id = GetRandomString(10),
                AccountType = "SAVINGS",
                BankName = "Humungous Bank Inc.",
                BranchName = GetRandomInt().ToString(),
                BankAddress = GetRandomJsonAddress(),
                BankCode = GetRandomBIC(),
                BankBranchCode = GetRandomInt().ToString(),
                AccountNumber = GetRandomInt().ToString(),
                IntermediaryBank = GetRandomBeneficiaryIntermediaryBankAccount(),
                VersionedOn = GetRandomDate(2015, DateTime.Now.Year, true)
            };
        }

        public static JsonPaymentBeneficiary GetRandomPaymentBeneficiary(Name name = null)
        {
            var beneficiary = GetRandomPaymentBeneficiary();

            if ((name != null && !string.IsNullOrEmpty(name.LastName) && string.IsNullOrEmpty(name.FirstName))||
                (name == null && beneficiary.Type == BeneType[1]))
            {
                beneficiary.Type = BeneType[1]; //Business type
                beneficiary.BusinessName = name != null ? name.LastName : beneficiary.BusinessName;
                beneficiary.LastName = string.Empty;
                beneficiary.MiddleName = string.Empty;
                beneficiary.FirstName = string.Empty;
                beneficiary.Gender = string.Empty;
                beneficiary.DateOfBirth = string.Empty;
            }
            else
            {
                beneficiary.Type = BeneType[0]; //Individual type
                beneficiary.LastName = name != null ? name.LastName : beneficiary.LastName;
                beneficiary.FirstName = name != null ? name.FirstName : beneficiary.FirstName;
                beneficiary.BusinessName = string.Empty;
                beneficiary.BusinessRegistrationCountry = string.Empty;
                beneficiary.BusinessRegistrationNumber = string.Empty;
                beneficiary.BusinessRegistrationStateProv = string.Empty;
                beneficiary.Industry = string.Empty;
            }
            
            return beneficiary;
        }


        private static JsonPaymentBeneficiary GetRandomPaymentBeneficiary()
        {
            return new JsonPaymentBeneficiary
            {
                Address = GetRandomJsonAddress(),
                BusinessName = GetRandomBusinessName(),
                BusinessRegistrationCountry = "CA",
                BusinessRegistrationNumber = GetRandomString(10),
                BusinessRegistrationStateProv = "BC",
                CellNumber = GetRandomPhoneNumber(),
                DateOfBirth = GetRandomDate(),
                EmailAddress = GetRandomString(10).ToLower() + "@" + GetRandomString(5).ToLower() + ".com",
                FirstName = GetRandomFirstName(),
                LastName = GetRandomLastName(),
                Gender = GetRandomGender(),
                Id = GetRandomString(5),
                Industry = GetRandomString(10),
                VersionedOn = GetRandomDate(2015, DateTime.Now.Year, true),
                MiddleName = GetRandomMiddleName(),
                PhoneNumber = GetRandomPhoneNumber(),
                Type = GetRandomBeneType()
            };
        }

        private static string GetRandomIBAN()
        {
            return GetRandomString(34);
        }

        private static JsonIntermediaryBankAccount GetRandomIntermediaryAccount()
        {
            return new JsonIntermediaryBankAccount()
            {
                BankCode = GetRandomBIC(),
                AccountNumber = GetRandomInt().ToString(),
                BankName = "Humungous Bank",
                BankAddress = GetRandomJsonAddress()
            };
        }

        private static JsonBeneficiaryIntermediaryBankAccount GetRandomBeneficiaryIntermediaryBankAccount()
        {
            return new JsonBeneficiaryIntermediaryBankAccount()
            {
                BankCode = GetRandomBIC(),
                AccountNumber = GetRandomInt().ToString(),
                BankName = "Humungous Bank",
                BankAddress = GetRandomJsonAddress()
            };
        }

        private static string GetRandomText()
        {
            return GetRandomString(200);
        }


        public static JsonPaymentDetail GetRandomPaymentDetail(string transferId, string bankBatchId, string paymentId)
        {
            return new JsonPaymentDetail
            {
                CustomerBeneId = GetRandomInt().ToString(),
                ExternalBeneId = GetRandomInt().ToString(),
                PaymentId = paymentId,
                CustomerReferenceNumber = GetRandomInt().ToString(),
                ExternalDescription = GetRandomDescription(),
                ExternalTransferId = string.IsNullOrEmpty(transferId) ? GetRandomInt().ToString() : transferId,
                WUBSBankBatchId = string.IsNullOrEmpty(bankBatchId) ? GetRandomInt().ToString() : bankBatchId,
                Amount = GetRandomInt(),
                Currency = GetRandomCurrencyCode(),
                BeneficiaryProfile = new JsonBeneficiaryProfile
                {
                    Address = GetRandomJsonAddress(),
                    Identification = GetRandomJsonIdentification(),
                    VersionNumber = 1
                },
                BankAccount = GetRandomBankAccount(),
                PaymentMethod = "BMO_CAD",
                RequestedReleaseDate = DateTime.Now.AddDays(2).ToString("yyyy-MM-dd"),
                SettlementCurrencyCode = GetRandomCurrencyCode(),
                FixedSettlementAmount = GetRandomBool(),
                InstructionCodeForBank = GetRandomText(),
                InstructionForBank = GetRandomString(209),
                PurposeOfPayment = GetRandomString(139),
                RemitterInformation1 = GetRandomString(100),
                RemitterInformation2 = GetRandomString(100),
            };
        }
    }
}
