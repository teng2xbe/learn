﻿using System;
using System.Collections.Generic;
using System.IO;
using MassPaymentsDataGenerator.JsonObjects;
using Newtonsoft.Json;
using static MassPaymentsDataGenerator.Data;

namespace MassPaymentsDataGenerator
{
    public static class DataGenerator
    {
        public static void GenerateBeneficiaryFile(int numberOfBeneficiaries, string clientProgramId)
        {
            var wallets = new JsonBeneficiariesContainer
            {
                Beneficiaries = new List<JsonBeneficiary>()
            };

            for (var i = 0; i < numberOfBeneficiaries; i++)
            {
                wallets.Beneficiaries.Add(
                    new JsonBeneficiary
                    {
                        ClientCustomerId = Data.GetRandomInt().ToString(),
                        WalletNumber = Data.GetRandomInt().ToString(),
                        ClientProgramId = string.IsNullOrEmpty(clientProgramId) ? Data.GetRandomInt().ToString() : clientProgramId,
                        ProgramId = Data.GetRandomInt().ToString(),
                        Profile = new JsonBeneficiaryProfile
                        {
                            VersionNumber = 1,
                            Identification = Data.GetRandomJsonIdentification(),
                            Address = Data.GetRandomJsonAddress(),
                        },
                        BankAccounts = new List<JsonBankAccount>
                        {
                            Data.GetRandomBankAccount()
                        }
                    }
                );
            }

            var json = JsonConvert.SerializeObject(wallets, Formatting.Indented);

            File.WriteAllText("Beneficiaries.json", json);
        }

        public static void GenerateClientBatchesFile(int batchCount, int paymentCount, string clientProgramId, string transferId, string bankBatchId)
        {
            var clientBatches = new JsonPaymentBatchContainer
            {
                PaymentBatches = new List<JsonPaymentBatch>()
            };

            var batchId = Data.GetRandomString(5);

            for (var i = 0; i < batchCount; i++)
            {
                var paymentDetails = new List<JsonPaymentDetail>();

                for (var j = 0; j < paymentCount; j++)
                {
                    paymentDetails.Add(Data.GetRandomPaymentDetail(transferId, bankBatchId, string.Format("{0}-{1}", batchId, j + 1)));
                }

                clientBatches.PaymentBatches.Add(
                    new JsonPaymentBatch
                    {
                        BatchId = batchId,
                        ClientBatchId = Data.GetRandomString(8) + ".json",
                        ClientProgramId = string.IsNullOrEmpty(clientProgramId) ? Data.GetRandomInt().ToString() : clientProgramId,
                        ProgramId = Data.GetRandomString(6).ToUpper(),
                        PaymentDetails = paymentDetails
                    }
                );
            }

            var json = JsonConvert.SerializeObject(clientBatches, Formatting.Indented);

            File.WriteAllText("ClientBatches.json", json);
        }

        public static void GeneratePendingTransfersFile(int paymentCount, string clientProgramId, string transferId, string bankBatchId)
        {
            var pendingTransfers = new JsonPaymentCashoutsContainer
            {
                PaymentCashouts = new List<JsonPaymentCashout>()
            };

            var batchId = Data.GetRandomString(5);
            var clientBatchId = Data.GetRandomString(8) + ".json";
            var programId = Data.GetRandomString(6).ToUpper();

            for (var i = 0; i < paymentCount; i++)
            {
                pendingTransfers.PaymentCashouts.Add(
                    new JsonPaymentCashout
                    {
                        OriginatingBatch = new JsonPaymentOriginatingBatch
                        {
                            BatchId = batchId,
                            ClientBatchId = clientBatchId,
                            ClientProgramId = clientProgramId,
                            ProgramId = programId
                        },
                        PaymentDetail = Data.GetRandomPaymentDetail(transferId, bankBatchId, string.Format("{0}-{1}", batchId, i + 1))
                    }
                );
            }

            var json = JsonConvert.SerializeObject(pendingTransfers, Formatting.Indented);

            File.WriteAllText("PendingTransfers.json", json);
        }

        public static void GenerateClientBatchesAndPendingTransferFile(int batchCount, int paymentCount, string clientProgramId, string transferId, string bankBatchId)
        {
            var clientBatches = new JsonPaymentBatchContainer
            {
                PaymentBatches = new List<JsonPaymentBatch>()
            };

            var pendingTransfers = new JsonPaymentCashoutsContainer
            {
                PaymentCashouts = new List<JsonPaymentCashout>()
            };

            for (var i = 0; i < batchCount; i++)
            {
                var batchId = Data.GetRandomString(5);
                var paymentDetails = new List<JsonPaymentDetail>();
                var clientBatchId = Data.GetRandomString(8) + ".json";
                var programId = Data.GetRandomString(6).ToUpper();

                if (string.IsNullOrEmpty(clientProgramId))
                    clientProgramId = Data.GetRandomInt().ToString();

                for (var j = 0; j < paymentCount; j++)
                {
                    var paymentDetail = Data.GetRandomPaymentDetail(transferId, bankBatchId, string.Format("{0}-{1}", batchId, j + 1));
                    paymentDetails.Add(paymentDetail);

                    pendingTransfers.PaymentCashouts.Add(
                        new JsonPaymentCashout
                        {
                            OriginatingBatch = new JsonPaymentOriginatingBatch
                            {
                                BatchId = batchId,
                                ClientBatchId = clientBatchId,
                                ClientProgramId = clientProgramId,
                                ProgramId = programId
                            },
                            PaymentDetail = paymentDetail
                        });
                }

                clientBatches.PaymentBatches.Add(
                    new JsonPaymentBatch
                    {
                        BatchId = batchId,
                        ClientBatchId = clientBatchId,
                        ClientProgramId = clientProgramId,
                        ProgramId = programId,
                        PaymentDetails = paymentDetails
                    });
            }

            var jsonPendingTransfers = JsonConvert.SerializeObject(pendingTransfers, Formatting.Indented);

            //payments in the clientBatch don't have transfer ids.
            foreach (var paymentBatch in clientBatches.PaymentBatches)
            {
                foreach (var paymentDetail in paymentBatch.PaymentDetails)
                {
                    paymentDetail.ExternalTransferId = "";
                }
            }

            var jsonClientBatches = JsonConvert.SerializeObject(clientBatches, Formatting.Indented);

            File.WriteAllText("ClientBatches.json", jsonClientBatches);
            File.WriteAllText("PendingTransfers.json", jsonPendingTransfers);
        }

        public static void GenerateQuotes(int count, string customerId)
        {                                                                               
            var quotedItems = new List<JsonQuoteItem>();

            try
            {
                var currencyPairs = Data.GetUniqueCurrencyPairs(count);
                var rand = new Random();
                var isAmountInSettlement = Data.GetRandomBool(rand);

                for (var i = 0; i < count; i++)
                {
                    quotedItems.Add(new JsonQuoteItem
                    {
                        Amount = Data.GetRandomInt(100, 999, rand),
                        IsAmountInSettlementCurrency = isAmountInSettlement,
                        SettlementCurrencyCode = currencyPairs[i].SettlementCurrency,
                        TradeCurrencyCode = currencyPairs[i].TradeCurrency
                    });
                }

                var quote = new JsonQuote
                {
                    PartnerAssignedCustomerId = string.IsNullOrEmpty(customerId) ? Data.GetRandomInt().ToString() : customerId,
                    PartnerReference = Data.GetRandomString(10),
                    QuoteRequestItems = quotedItems
                };

                var jsonQuotes = JsonConvert.SerializeObject(quote, Formatting.Indented);

                File.WriteAllText("Quotes.json", jsonQuotes);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void GenerateOrders(int orderCount, string quoteId, string quoteFileName)
        {
            var quoteFile = File.ReadAllText(quoteFileName);
            var quote = JsonConvert.DeserializeObject<JsonQuote>(quoteFile);
            var ordersToBook = new Dictionary<string, JsonOrder>();

            for (var i = 0; i < orderCount - 1; i++)
            {
                var randomIndex = Data.GetRandomInt(0, quote.QuoteRequestItems.Count - 1);
                var quotedItem = quote.QuoteRequestItems[randomIndex];
                var jsonItem = new JsonItem
                {
                    TradeCurrencyCode = quotedItem.TradeCurrencyCode,
                    Amount = quotedItem.Amount,
                    IsAmountInSettlementCurrency = quotedItem.IsAmountInSettlementCurrency
                };

                if (ordersToBook.ContainsKey(quotedItem.SettlementCurrencyCode))
                {
                    if (!ordersToBook[quotedItem.SettlementCurrencyCode].ItemsToBook.Exists(item => item.TradeCurrencyCode == jsonItem.TradeCurrencyCode))
                        ordersToBook[quotedItem.SettlementCurrencyCode].ItemsToBook.Add(jsonItem);
                }
                else
                {
                    ordersToBook.Add(quotedItem.SettlementCurrencyCode, new JsonOrder
                    {
                        SettlementCurrencyCode = quotedItem.SettlementCurrencyCode,
                        SettlementMethod = "Wire",
                        ItemsToBook = new List<JsonItem> { jsonItem }
                    });
                }
            }

            var orders = new JsonOrders
            {
                QuoteId = quoteId,
                PartnerAssignedCustomerId = quote.PartnerAssignedCustomerId,
                PartnerReference = Data.GetRandomString(10),
                OrdersToBook = new List<JsonOrder>(ordersToBook.Values)
            };

            var jsonOrders = JsonConvert.SerializeObject(orders, Formatting.Indented);

            File.WriteAllText("Orders.json", jsonOrders);
        }

        public static void GeneratePayments(int paymentsToSubmitCount, string customerId, 
                string customerCountryCode, long amount, List<string> currencies, string fileName)
        {
            var payments = new JsonPayments
            {
                PaymentsToProcess = new List<JsonPayment>()
            };

            var beneficiaries = Data.GetBeneficiariesFromFile(fileName);

            if (beneficiaries.Count > paymentsToSubmitCount)
                paymentsToSubmitCount = beneficiaries.Count;

            var paymentIds = new List<string>();

            for (var i = 0; i < paymentsToSubmitCount; i++)
            {
                payments.PaymentsToProcess.Add(GeneratePayment(customerId, customerCountryCode, amount, currencies, paymentIds,
                    beneficiaries.Count > i ? beneficiaries[i] : null ));
            }

            var jsonPayments = JsonConvert.SerializeObject(payments, Formatting.Indented);
            File.WriteAllText("Payments.json", jsonPayments);
        }

        private static JsonPayment GeneratePayment(string customerId, string customerCountryCode, long amount, List<string> currencies, List<string> paymentIds, 
            JsonPaymentBeneficiary beneficiary)
        {
            var bene = beneficiary != null ? beneficiary : Data.GetRandomPaymentBeneficiary();
            var remittanceType = "";
            var currencyCode = currencies.Count > 0 ? Data.GetRandomItemFromList(currencies) : Data.GetRandomSettlementCurrencyCode();
            var paymentMethod = Data.GetRandomPaymentMethod();
            List<JsonRemittance> remittanceData = null;

            if (bene.Type == "Business" && currencyCode == "USD" && paymentMethod == "ACH")
            {
                if (customerCountryCode == "US")
                {
                    remittanceType = Data.GetRandomBusinessRemittanceType();

                    if (remittanceType == "CTX")
                        remittanceData = new List<JsonRemittance> {new JsonRemittance {Reference = Data.GetRandomString(10)}};
                }
                else
                {
                    remittanceType = "IAT";
                }
            }
            else
            {
                remittanceType = "";
            }

            return new JsonPayment
            {
                BankAccount = Data.GetRandomBeneBankAccount(),
                Beneficiary = bene,
                InstructionCodeForBank = Data.GetRandomString(10),
                InstructionForBank = Data.GetRandomString(10),
                PartnerAssignedCustomerId = customerId,
                PartnerReference = Data.GetRandomString(5),
                PaymentId = Data.GetRandomUniqueString(7, paymentIds),
                PaymentMethod = paymentMethod,
                PurposeOfPayment = Data.GetRandomString(10),
                RemittanceData = remittanceData,
                RemittanceType = remittanceType,
                TradeAmount = amount > -1 ? amount : Data.GetRandomInt(),
                TradeCurrencyCode = currencyCode,
            };
        }
    }
}
