﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonOrder
    {
        [JsonProperty("settlementCurrency")]
        public string SettlementCurrencyCode { get; set; }

        [JsonProperty("settlementMethod")]
        public string SettlementMethod { get; set; }

        [JsonProperty("itemsToBook")]
        public List<JsonItem> ItemsToBook { get; set; }
    }
}
