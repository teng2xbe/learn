﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBeneficiaryIdentification
    {
        [JsonProperty("entityType")] 
        public string EntityType { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("middleName")]
        public string MiddleName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty("mobileNumber")]
        public string CellNumber { get; set; }

        [JsonProperty("dateOfBirth")]
        public string DateOfBirth { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("businessName")]
        public string BusinessName { get; set; }

        [JsonProperty("businessRegistrationNumber")]
        public string BusinessRegistrationNumber { get; set; }

        [JsonProperty("businessRegistrationCountry")]
        public string BusinessRegistrationCountry { get; set; }

        [JsonProperty("businessRegistrationStateProv")]
        public string BusinessRegistrationStateProv { get; set; }

        [JsonProperty("businessContactRole")]
        public string BusinessContactRole { get; set; }

        [JsonProperty("industry")]
        public string Industry { get; set; }

        [JsonProperty("emailAddress")]
        public string EmailAddress { get; set; }
    }
}
