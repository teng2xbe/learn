﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonPaymentCashout
    {
        [JsonProperty("originatingBatch")] 
        public JsonPaymentOriginatingBatch OriginatingBatch;

        [JsonProperty("paymentDetail")]
        public JsonPaymentDetail PaymentDetail;

    }
}
