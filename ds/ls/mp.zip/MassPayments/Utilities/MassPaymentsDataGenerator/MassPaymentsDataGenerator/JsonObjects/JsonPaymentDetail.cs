﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonPaymentDetail
    {
        [JsonProperty("clientCustomerId")]
        public string CustomerBeneId { get; set; }

        [JsonProperty("walletNumber")]
        public string ExternalBeneId { get; set; }

        [JsonProperty("paymentId")]
        public string PaymentId { get; set; }

        [JsonProperty("clientReferenceNumber")]
        public string CustomerReferenceNumber { get; set; }

        [JsonProperty("description")]
        public string ExternalDescription { get; set; }

        [JsonProperty("transferId")]
        public string ExternalTransferId { get; set; }
        
        [JsonProperty("bankBatchId")]
        public string WUBSBankBatchId { get; set; }

        [JsonProperty("amount")]
        public decimal Amount { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }

        [JsonProperty("profile")]
        public JsonBeneficiaryProfile BeneficiaryProfile { get; set; }

        [JsonProperty("bankAccount")]
        public JsonBankAccount BankAccount { get; set; }

        [JsonProperty("dispensationType")]
        public string PaymentMethod { get; set; }

        [JsonProperty("valueDate")]
        public string RequestedReleaseDate { get; set; }

        [JsonProperty("settlementCurrencyCode")]
        public string SettlementCurrencyCode { get; set; }

        [JsonProperty("fixedSettlementAmount")]
        public bool FixedSettlementAmount { get; set; }

        [JsonProperty("instructionCodeForBank")]
        public string InstructionCodeForBank { get; set; }

        [JsonProperty("instructionForBank")]
        public string InstructionForBank { get; set; }

        [JsonProperty("purposeOfPayment")]
        public string PurposeOfPayment { get; set; }

        [JsonProperty("remitterInformation1")]
        public string RemitterInformation1 { get; set; }

        [JsonProperty("remitterInformation2")]
        public string RemitterInformation2 { get; set; }    


    }
}
