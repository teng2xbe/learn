﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonOrders
    {
        [JsonProperty("customerId")]
        public string PartnerAssignedCustomerId { get; set; }

        [JsonProperty("quoteId")]
        public string QuoteId { get; set; }

        [JsonProperty("partnerReference")]
        public string PartnerReference { get; set; }

        [JsonProperty("ordersToBook")]
        public List<JsonOrder> OrdersToBook { get; set; }
    }
}
