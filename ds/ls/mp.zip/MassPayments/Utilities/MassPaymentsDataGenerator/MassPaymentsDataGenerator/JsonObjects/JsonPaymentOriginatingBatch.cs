﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonPaymentOriginatingBatch
    {
        [JsonProperty("batchId")]
        public string BatchId { get; set; }

        [JsonProperty("clientBatchId")]
        public string ClientBatchId { get; set; }

        [JsonProperty("clientProgramId")]
        public string ClientProgramId { get; set; }

        [JsonProperty("programId")]
        public string ProgramId { get; set; }
    }
}
