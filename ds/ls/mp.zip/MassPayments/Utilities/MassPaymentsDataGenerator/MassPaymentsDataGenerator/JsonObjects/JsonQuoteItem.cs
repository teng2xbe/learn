﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonQuoteItem
    {
        [JsonProperty("amount")]
        public long Amount { get; set; }

        [JsonProperty("isAmountSettlement")]
        public bool IsAmountInSettlementCurrency { get; set; }

        [JsonProperty("tradeCurrency")]
        public string TradeCurrencyCode { get; set; }

        [JsonProperty("settlementCurrency")]
        public string SettlementCurrencyCode { get; set; }
    }
}
