﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBeneficiary
    {
        [JsonProperty("clientCustomerId")]
        public string ClientCustomerId { get; set; }

        [JsonProperty("walletNumber")]
        public string WalletNumber { get; set; }

        [JsonProperty("programId")]
        public string ProgramId { get; set; }

        [JsonProperty("clientProgramId")]
        public string ClientProgramId { get; set; }

        [JsonProperty("profile")]
        public JsonBeneficiaryProfile Profile { get; set; }

        [JsonProperty("bankAccounts")]
        public List<JsonBankAccount> BankAccounts { get; set; }
    }
}
