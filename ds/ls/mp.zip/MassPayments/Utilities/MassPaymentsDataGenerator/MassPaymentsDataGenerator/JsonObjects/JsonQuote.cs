﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonQuote
    {
        [JsonProperty("customerId")]
        public string PartnerAssignedCustomerId { get; set; }

        [JsonProperty("partnerReference")]
        public string PartnerReference { get; set; }

        [JsonProperty("itemsToQuote")]
        public List<JsonQuoteItem> QuoteRequestItems { get; set; }
    }
}
