﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBankAccount
    {
        [JsonProperty("externalAccountId")]
        public string ExternalAccountId{ get; set; }

        [JsonProperty("versionNumber")]
        public int VersionNumber { get; set; }

        [JsonProperty("externalAccountType")]
        public string ExternalAccountType { get; set; }

        [JsonProperty("accountPurpose")]
        public string AccountPurpose { get; set; }

        [JsonProperty("currencyCode")]
        public string CurrencyCode { get; set; }

        [JsonProperty("bankName")]
        public string BankName { get; set; }

        [JsonProperty("branchName")]
        public string BranchName { get; set; }

        [JsonProperty("bankAddress")]
        public JsonAddress BankAddress { get; set; }

        [JsonProperty("bankCode")]
        public string BankCode { get; set; }

        [JsonProperty("branchCode")]
        public string BranchCode { get; set; }

        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("intermediaryBankAccount")]
        public JsonIntermediaryBankAccount IntermediaryBankAccount { get; set; }

    }
}
