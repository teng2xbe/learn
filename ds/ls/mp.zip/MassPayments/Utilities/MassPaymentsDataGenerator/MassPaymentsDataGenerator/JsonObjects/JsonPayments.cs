﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonPayments
    {
        [JsonProperty("payments")]
        public List<JsonPayment> PaymentsToProcess { get; set; }
    }
}
