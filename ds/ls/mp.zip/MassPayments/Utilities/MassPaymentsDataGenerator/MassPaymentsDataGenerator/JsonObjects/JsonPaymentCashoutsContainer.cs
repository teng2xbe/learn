﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonPaymentCashoutsContainer
    {
        [JsonProperty("pendingBankTransfers")]
        public List<JsonPaymentCashout> PaymentCashouts { get; set; } 
    }
}
