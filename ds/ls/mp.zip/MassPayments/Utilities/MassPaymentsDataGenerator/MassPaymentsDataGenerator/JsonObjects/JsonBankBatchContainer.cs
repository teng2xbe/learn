﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBankBatchContainer
    {
        [JsonProperty("transfers")]
        public List<JsonBankBatch> PaymentBatch;
    }
}
