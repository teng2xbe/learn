﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonItem
    {
        [JsonProperty("amount")]
        public long Amount { get; set; }

        [JsonProperty("tradeCurrency")]
        public string TradeCurrencyCode { get; set; }

        [JsonProperty("isAmountSettlement")]
        public bool IsAmountInSettlementCurrency { get; set; }
    }
}
