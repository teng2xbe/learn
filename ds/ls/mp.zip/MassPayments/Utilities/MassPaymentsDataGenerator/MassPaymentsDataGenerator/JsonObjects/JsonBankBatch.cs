﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBankBatch
    {
        [JsonProperty("clientTransferId")]
        public string PaymentReference { get; set; }

        [JsonProperty("transferId")]
        public string TransferId { get; set; }
    }
}
