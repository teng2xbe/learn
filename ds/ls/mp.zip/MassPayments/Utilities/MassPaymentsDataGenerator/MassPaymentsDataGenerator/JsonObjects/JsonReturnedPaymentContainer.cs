﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonReturnedPaymentContainer
    {
        [JsonProperty("returnedPaymentDetails")]
        public List<JsonPaymentDetail> PaymentDetails { get; set; } 
    }
}
