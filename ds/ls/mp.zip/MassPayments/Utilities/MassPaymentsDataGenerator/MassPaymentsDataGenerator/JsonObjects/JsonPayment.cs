﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonPayment
    {
        [JsonProperty("customerId")]
        public string PartnerAssignedCustomerId { get; set; }

        [JsonProperty("partnerReference")]
        public string PartnerReference { get; set; }

        [JsonProperty("paymentMethod")]
        public string PaymentMethod { get; set; }

        [JsonProperty("id")]
        public string PaymentId { get; set; }

        [JsonProperty("amount")]
        public long TradeAmount { get; set; }

        [JsonProperty("currencyCode")]
        public string TradeCurrencyCode { get; set; }

        [JsonProperty("beneficiary")]
        public JsonPaymentBeneficiary Beneficiary { get; set; }

        [JsonProperty("bankAccount")]
        public JsonBeneficiaryBankAccount BankAccount { get; set; }

        [JsonProperty("purposeOfPayment")]
        public string PurposeOfPayment { get; set; }

        [JsonProperty("instructionForBank")]
        public string InstructionForBank { get; set; }

        [JsonProperty("instructionCodeForBank")]
        public string InstructionCodeForBank { get; set; }

        [JsonProperty("remittanceType")]
        public string RemittanceType { get; set; }

        [JsonProperty("remittanceData")]
        public List<JsonRemittance> RemittanceData { get; set; }
    }
}
