﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonAddress
    {
        [JsonProperty("line1")]
        public string AddressLine1 { get; set; }

        [JsonProperty("line2")]
        public string AddressLine2 { get; set; }

        [JsonProperty("line3")]
        public string AddressLine3 { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("stateOrProv")]
        public string StateOrPovince { get; set; }

        [JsonProperty("zipOrPostal")]
        public string ZipOrPostalCode { get; set; }

        [JsonProperty("countryCode")]
        public string CountryCode { get; set; }
    }
}
