﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBeneficiaryBankAccount
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("versionedOn")]
        public string VersionedOn { get; set; }

        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("accountType")]
        public string AccountType { get; set; }

        [JsonProperty("bankName")]
        public string BankName { get; set; }

        [JsonProperty("bankBranchName")]
        public string BranchName { get; set; }

        [JsonProperty("bankCode")]
        public string BankCode { get; set; }

        [JsonProperty("bankBranchCode")]
        public string BankBranchCode { get; set; }

        [JsonProperty("address")]
        public JsonAddress BankAddress { get; set; }

        [JsonProperty("intermediaryBank")]
        public JsonBeneficiaryIntermediaryBankAccount IntermediaryBank { get; set; }
    }
}
