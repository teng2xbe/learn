﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonPaymentBatchContainer
    {
        [JsonProperty("clientBatches")]
        public List<JsonPaymentBatch> PaymentBatches;
    }
}
