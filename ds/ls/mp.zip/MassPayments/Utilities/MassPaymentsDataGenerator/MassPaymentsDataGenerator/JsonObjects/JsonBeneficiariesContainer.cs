﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBeneficiariesContainer
    {
        [JsonProperty("wallets")]
        public List<JsonBeneficiary> Beneficiaries;
    }
}
