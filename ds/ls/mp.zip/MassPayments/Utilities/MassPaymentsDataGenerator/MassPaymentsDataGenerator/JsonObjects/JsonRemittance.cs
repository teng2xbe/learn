﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonRemittance
    {
        [JsonProperty("ref")]
        public string Reference { get; set; }
    }
}
