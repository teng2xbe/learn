﻿using Newtonsoft.Json;

namespace MassPaymentsDataGenerator.JsonObjects
{
    public class JsonBeneficiaryProfile
    {
        [JsonProperty("versionNumber")]
        public int VersionNumber { get; set; }

        [JsonProperty("identification")]
        public JsonBeneficiaryIdentification Identification { get; set; }

        [JsonProperty("address")]
        public JsonAddress Address { get; set; }
    }
}
