﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MassPaymentsDataGenerator
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int batchCount;
            int paymentCount;
            string partnerAssignedCustomerId = "";
            string transferId = "";
            string bankBatchId = "";

            if (args.Length == 0)
                ShowUsage();

            switch (args[0].ToUpper())
            {
/*
                case "BENEFICIARY":
                case "B":
                    int beneCount;

                    if (args.Length < 2)
                        ShowUsage();

                    if (!int.TryParse(args[1], out beneCount))
                        ShowUsage();

                    if (args.Length >= 3)
                        partnerAssignedCustomerId = args[2];

                    DataGenerator.GenerateBeneficiaryFile(beneCount, partnerAssignedCustomerId);
                    break;
                case "CLIENTBATCH":
                case "C":
                    if (args.Length < 3)
                        ShowUsage();

                    if (!int.TryParse(args[1], out batchCount))
                        ShowUsage();

                    if (!int.TryParse(args[2], out paymentCount))
                        ShowUsage();

                    if (args.Length >= 4)
                        partnerAssignedCustomerId = args[3];

                    if (args.Length >= 5)
                        transferId = args[4];

                    if (args.Length >= 6)
                        bankBatchId = args[5];

                    DataGenerator.GenerateClientBatchesFile(batchCount, paymentCount, partnerAssignedCustomerId, transferId, bankBatchId);
                    break;
                case "PENDINGTANSFER":
                case "PT":
                    if (args.Length < 2)
                        ShowUsage();

                    if (!int.TryParse(args[1], out paymentCount))
                        ShowUsage();

                    if (args.Length >= 3)
                        partnerAssignedCustomerId = args[2];

                    if (args.Length >= 4)
                        transferId = args[3];

                    if (args.Length >= 5)
                        bankBatchId = args[4];

                    DataGenerator.GeneratePendingTransfersFile(paymentCount, partnerAssignedCustomerId, transferId, bankBatchId);
                    break;
                case "CLIENTBATCHANDPENDINGTRANSFER":
                case "CP":
                    if (args.Length < 3)
                        ShowUsage();

                    if (!int.TryParse(args[1], out batchCount))
                        ShowUsage();

                    if (!int.TryParse(args[2], out paymentCount))
                        ShowUsage();

                    if (args.Length >= 4)
                        partnerAssignedCustomerId = args[3];

                    if (args.Length >= 5)
                        transferId = args[4];

                    if (args.Length >= 6)
                        bankBatchId = args[5];

                    DataGenerator.GenerateClientBatchesAndPendingTransferFile(batchCount, paymentCount, partnerAssignedCustomerId, transferId, bankBatchId);
                    break;
*/
                case "QUOTES":
                case "Q":
                    if (args.Length < 3)
                        ShowUsage();

                    if (!int.TryParse(args[1], out batchCount))
                        ShowUsage();

                    if (args.Length >= 3)
                        partnerAssignedCustomerId = args[2];

                    DataGenerator.GenerateQuotes(batchCount, partnerAssignedCustomerId);
                    break;
                case "ORDERS":
                case "O":
                    var quoteFile = "Quotes.json";
                    var quoteId = "";

                    if (args.Length < 4)
                        ShowUsage();

                    if (!int.TryParse(args[1], out batchCount))
                        ShowUsage();

                    if (args.Length >= 3)
                        quoteId = args[2];

                    if (args.Length >= 4)
                        quoteFile = args[3];

                    DataGenerator.GenerateOrders(batchCount, quoteId, quoteFile);
                    break;
                case "PAYMENTS":
                case "P":
                    if (args.Length < 3)
                        ShowUsage();

                    string fileName = GetInputFile(args.ToList());
                    
                    int paymentsToProcessCount;
                    if (!int.TryParse(args[1], out paymentsToProcessCount))
                        ShowUsage();

                    partnerAssignedCustomerId = args[2];

                    var customerCountryCode = "US";
                    if (args.Length >= 4)
                        customerCountryCode = args[3];

                    var amount = -1;
                    if (args.Length >= 5 && !int.TryParse(args[4], out amount)) 
                        ShowUsage();

                    var currencies = new List<string>();
                    if (args.Length >= 6)
                    {
                        currencies = args[5].Split(',').ToList();

                        if (currencies.Count == 0)
                            ShowUsage();
                    }  

                    DataGenerator.GeneratePayments(paymentsToProcessCount, 
                            partnerAssignedCustomerId, customerCountryCode, amount, currencies, fileName);
                    break;
                default:
                    ShowUsage();
                    break;
            }            
        }

        private static string GetInputFile(List<string> args)
        {
            int argCount = 0;
            foreach (var arg in args)
            {
                if (arg.ToUpper() == "-DATAFILE")
                    return args[argCount + 1];

                argCount++;
            }

            return string.Empty;
        }

        private static void ShowUsage()
        {
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("*************************************************************************************************************************");
            Console.WriteLine("  Mass Payments Data Generator. Updated on July 12, 2016");
            Console.WriteLine("");
            Console.WriteLine("  Usages:");
/*
            Console.WriteLine("    MassPaymentsDataGenerator Beneficiary BatchCount PaymentCount [ClientProgramId] [TransferId] [BankBatchId]");
            Console.WriteLine("    MassPaymentsDataGenerator ClientBatch BatchCount PaymentCount [ClientProgramId] [TransferId] [BankBatchId]");
            Console.WriteLine("    MassPaymentsDataGenerator PendingTransfer BatchCount PaymentCount [ClientProgramId] [TransferId] [BankBatchId]");
            Console.WriteLine("    MassPaymentsDataGenerator ClientBatchAndPendingTransfer BatchCount PaymentCount [ClientProgramId] [TransferId] [BankBatchId]");
            */
            Console.WriteLine("    MassPaymentsDataGenerator Quotes QuoteCount ClientProgramId");
            Console.WriteLine("    MassPaymentsDataGenerator Orders OrderCount QuoteId QuoteFile");
            Console.WriteLine("    MassPaymentsDataGenerator Payments PaymentsToProcessCount CustomerId [CustomerCountryCode] [Amount] [Currencies] -DataFile [path and filename]");
            Console.WriteLine("");
//            Console.WriteLine("  ClientProgramId, TransferId & BankBatchId are optional and will be randomly generated if omitted.");
            Console.WriteLine("  If CustomerCountryCode is omitted for Payments, it defaults to US");
            Console.WriteLine("");
//            Console.WriteLine("  examples: MassPaymentsDataGenerator cp 1 1000 111 222 333");
            Console.WriteLine("            MassPaymentsDataGenerator quotes 10 customerId");
            Console.WriteLine("            MassPaymentsDataGenerator orders 10 customerId Quotes.json");
            Console.WriteLine("            MassPaymentsDataGenerator payments 15 customerId CA 100 CAD,USD,GBP");
            Console.WriteLine("            MassPaymentsDataGenerator payments 15 customerId CA 100 CAD,USD,GBP -dataFile payments-input.txt");
            Console.WriteLine("");
            Console.WriteLine("  When generating payments for Decouple Partner - replace 'payments' with 'paymentToProcess' in a generated file"); 
            Console.WriteLine("*************************************************************************************************************************");
            Console.WriteLine("");
            Console.WriteLine("");

            Environment.Exit(0);
        }
    }
}
