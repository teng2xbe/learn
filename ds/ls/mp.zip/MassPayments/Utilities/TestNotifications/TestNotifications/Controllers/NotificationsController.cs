﻿using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using System.Web.Http;

namespace TestNotifications.Controllers
{
    public class NotificationsController : ApiController
    {
        private static bool isServerDown;

        public void Put()
        {
            isServerDown = !isServerDown;

            var hubContext = GlobalHost.ConnectionManager.GetHubContext<NotificationsHub>();
            hubContext.Clients.All.udpateServerStatus(isServerDown);
        }

        public IHttpActionResult Post([FromBody] object message)
        {
            if (isServerDown)
                return NotFound();

            var securityToken = new AppSettingsReader().GetValue("SecurityToken", typeof (string)).ToString();

            if (!string.IsNullOrEmpty(securityToken) && 
                (Request.Headers.Authorization == null || securityToken != Request.Headers.Authorization.Parameter))
                return new Forbidden();

            var hubContext = GlobalHost.ConnectionManager.GetHubContext<NotificationsHub>();
            hubContext.Clients.All.addMessage(message.ToString());

            return Ok();
        }
    }

    public class Forbidden : IHttpActionResult
    {
        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            return Task.FromResult(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.Forbidden
            });
        }
    }
}