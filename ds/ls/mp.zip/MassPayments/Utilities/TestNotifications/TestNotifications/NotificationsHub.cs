﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace TestNotifications
{
    [HubName("notifications")]
    public class NotificationsHub : Hub
    {
    }
}