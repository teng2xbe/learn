﻿var notifications = [];

var filterNotifications = function () {
    $('#notifications').empty();

    for (var index in notifications) {
        if (notifications.hasOwnProperty(index)) {
            var filter = $('#filter').val();
            var notification = notifications[index];

            if (notification.indexOf(filter) !== -1) {
                $('#notifications').append('<div>' + notification + '</div>');
            }
        }
    }
}

var addMessage = function (notification) {
    notifications.push(notification);
    var filter = $('#filter').val();

    if (notification.indexOf(filter) !== -1) {
        $('#notifications').append('<div>' + notification + '</div>');
    }

    $('body').scrollTop($('body')[0].scrollHeight);
};

var udpateServerStatus = function (isServerDown) {
    if (isServerDown) {
        $('#serverStatus').text('Bring server back up');
        $('#serverStatus').css('color', '#f00');
    }
    else {
        $('#serverStatus').text('Simulate server outage');
        $('#serverStatus').css('color', '#0f0');
    }
};

var toggleServer = function() {
    $.ajax({
        url: '/notifications',
        type: 'PUT'
    });
};

$(function () {
    $.connection.hub.url = '/signalr';
    var messages = $.connection.notifications;

    messages.client.addMessage = addMessage;
    messages.client.udpateServerStatus = udpateServerStatus;

    $.connection.hub.start();

    $('#search').click(filterNotifications);

    $('#filter').keypress(function(e) {
        if (e.keyCode === 13)
            filterNotifications();
    });

    $('#serverStatus').click(toggleServer);

    $('#listeningOn').text('Listening on endpoint: ' + location.href.replace(/[^\/]*$/, '') + 'notifications');
});
