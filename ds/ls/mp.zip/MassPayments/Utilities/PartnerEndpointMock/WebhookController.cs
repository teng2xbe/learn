﻿using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace PartnerEnpointMock
{
    public class WebhookController : ApiController
    {
        public IHttpActionResult Post([FromBody] object obj)
        {
            Console.WriteLine(obj);
            return Ok();
        }

        public override Task<HttpResponseMessage> ExecuteAsync(HttpControllerContext controllerContext, CancellationToken cancellationToken)
        {
            var request = controllerContext.Request;
            Console.WriteLine($"{request.Headers}");

            return base.ExecuteAsync(controllerContext, cancellationToken);
        }
    }
}
