﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using MassPayServicesManager.Model;

namespace MassPayServicesManager.Manager
{
    public static class ServiceManager
    {
        public static void StartService(Service service)
        {
            var dllPath = service.ServicePath;
            var configPath = dllPath + ".config";
            var hostPath = Settings.Default.HostPath;

            UpdateConfigFileForSelfHosting(configPath);

            var process = new Process
            {
                StartInfo =
                {
                    FileName = hostPath,
                    Arguments = string.Format("/service:{0} /config:{1}", dllPath, configPath),
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                },
                EnableRaisingEvents = true,
            };

            process.Start();
            service.ProcessId = process.Id;
        }

        public static void StopService(Service service)
        {
            if (service.ProcessId == 0)
                return;

            Process.GetProcessById(service.ProcessId).Kill();
            service.ProcessId = 0;
        }

        //because of an issue in .net 4.5, we need to remove the listtenBacklog and maxConnections
        //attributes from the config files since we're running the tcp and mex bindings under the same port
        private static void UpdateConfigFileForSelfHosting(string configPath)
        {
            var fileMap = new ExeConfigurationFileMap
            {
                ExeConfigFilename = configPath
            };

            var config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

            var bindingsSection = config.GetSection("system.serviceModel/bindings") as BindingsSection;
            foreach (ConfigurationElement binding in bindingsSection.NetTcpBinding.Bindings)
            {
                binding.ElementInformation.Properties["listenBacklog"].Value = null;
                binding.ElementInformation.Properties["maxConnections"].Value = null;
            }

            config.Save(ConfigurationSaveMode.Modified);
        }
    }
}
