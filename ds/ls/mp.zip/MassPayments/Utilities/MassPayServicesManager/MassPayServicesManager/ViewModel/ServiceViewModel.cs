﻿using System.ComponentModel;
using System.Windows.Input;
using MassPayServicesManager.Manager;
using MassPayServicesManager.Model;

namespace MassPayServicesManager.ViewModel
{
    public class ServiceViewModel : INotifyPropertyChanged
    {
        public Service Service { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged(string propertyName)
        {
            // take a copy to prevent thread issues
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        
        public ServiceViewModel(Service service)
        {
            Service = service;
        }

        public string Name
        {
            get { return Service.Name; }
        }

        public int? ProcessId
        {
            get { return Service.ProcessId == 0 ? (int?) null : Service.ProcessId; }
        }

        public bool IsStarted
        {
            get { return Service.IsStarted; }
        }

        public ICommand ToggleServiceCommand
        {
            get
            {
                return new DelegateCommand
                {
                    CommandAction = ToggleService
                };
            }
        }

        public void StartService()
        {
            if (Service.IsStarted) return;

            ServiceManager.StartService(Service);
            UpdateServiceState();
        }

        public void StopService()
        {
            if (!Service.IsStarted) return;

            ServiceManager.StopService(Service);
            UpdateServiceState();
        }

        public void ToggleService()
        {
            if (Service.IsStarted)
                ServiceManager.StopService(Service);
            else
                ServiceManager.StartService(Service);

            UpdateServiceState();
        }

        private void UpdateServiceState()
        {
            Service.IsStarted = !Service.IsStarted;
            RaisePropertyChanged("IsStarted");
            RaisePropertyChanged("ProcessId");
        }
    }
}
