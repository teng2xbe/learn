﻿using System.Windows;
using System.Windows.Input;
using MassPayServicesManager.View;

namespace MassPayServicesManager.ViewModel
{
    public class NotifyIconViewModel
    {
        public ICommand ShowWindowCommand
        {
            get
            {
                return new DelegateCommand
                {
                    CommandAction = () => Application.Current.MainWindow.Show(),
                    CanExecuteFunc = () => Application.Current.MainWindow.IsVisible == false
                };
            }
        }

        public ICommand HideWindowCommand
        {
            get
            {
                return new DelegateCommand
                {
                    CommandAction = () => Application.Current.MainWindow.Hide(),
                    CanExecuteFunc = () => Application.Current.MainWindow.IsVisible == true
                };
            }
        }

        public ICommand ToggleWindowCommand 
        {
            get
            {
                return new DelegateCommand
                {
                    CommandAction = () =>
                    {
                        if (Application.Current.MainWindow.IsVisible)
                            Application.Current.MainWindow.Hide();
                        else
                            Application.Current.MainWindow.Show();
                    },
                    CanExecuteFunc = () => Application.Current.MainWindow != null
                };
            }
        }

        public ICommand ExitApplicationCommand
        {
            get
            {
                return new DelegateCommand { CommandAction = () => Application.Current.Shutdown() };
            }
        }
    }
}
