﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using MassPayServicesManager.Model;

namespace MassPayServicesManager.ViewModel
{
    public class ServicesManagerViewModel
    {
        public ObservableCollection<ServiceViewModel> Services { get; set; }

        public ServicesManagerViewModel()
        {
            Services = new ObservableCollection<ServiceViewModel>();

            foreach (var path in Settings.Default.ServicesPath)
            {
                var service = new Service(path);
                var serviceViewModel = new ServiceViewModel(service);
                Services.Add(serviceViewModel);
            }
        }

        private void StartAllServices()
        {
            foreach (var serviceViewModel in Services)
            {
                serviceViewModel.StartService();
            }
        }

        public ICommand StartAllServicesCommand
        {
            get
            {
                return new DelegateCommand
                {
                    CommandAction = StartAllServices,
                    CanExecuteFunc = () => Services.Any(serviceViewModel => !serviceViewModel.IsStarted)
                };
            }
        }

        private void StopAllServices()
        {
            foreach (var serviceViewModel in Services)
            {
                serviceViewModel.StopService();
            }
        }

        public ICommand StopAllServicesCommand
        {
            get
            {
                return new DelegateCommand
                {
                    CommandAction = StopAllServices,
                    CanExecuteFunc = () => Services.Any(serviceViewModel => serviceViewModel.IsStarted)
                };
            }
        }

        public void OnWindowClosing(object sender, CancelEventArgs e)
        {
            StopAllServices();
        }
    }
}
