﻿using System.IO;

namespace MassPayServicesManager.Model
{
    public class Service
    {
        public string Name { get; set; }
        public string ServicePath { get; set; }
        public int ProcessId { get; set; }
        public bool IsStarted { get; set; }

        public Service(string path)
        {
            Name = Path.GetFileNameWithoutExtension(path);
            ServicePath = path;
        }
    }
}
