﻿using System.Diagnostics;
using System.Windows;
using MassPayServicesManager.Manager;
using MassPayServicesManager.Model;

namespace MassPayServicesManager.View
{
    public partial class ServiceUserControl
    {
        private Process process;

        public ServiceUserControl()
        {
            InitializeComponent();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            ServiceManager.StartService(new Service(""));
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            process.Kill();
        }
    }
}
