﻿using System.Windows.Forms;
using MassPayServicesManager.ViewModel;

namespace MassPayServicesManager.View
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();

            var servicesManagerViewModel = new ServicesManagerViewModel();

            Closing += servicesManagerViewModel.OnWindowClosing;
            DataContext = servicesManagerViewModel;

            var listHeight = servicesManagerViewModel.Services.Count*38;
            ServiceList.Height = listHeight + 2;
            Height = listHeight + 90;
            Top = Screen.PrimaryScreen.WorkingArea.Bottom - Height;
            Left = Screen.PrimaryScreen.WorkingArea.Right - Width;
        }
    }
}
