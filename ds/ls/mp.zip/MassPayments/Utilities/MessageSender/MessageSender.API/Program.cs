﻿using System;

namespace MessageSender.API
{
    static class Program
    {
        static void Main(string[] args)
        {
            var startup = new Startup();
            startup.Start();
            Console.ReadKey();
            startup.Stop();
        }
    }
}