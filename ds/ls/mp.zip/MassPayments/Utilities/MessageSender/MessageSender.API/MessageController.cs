﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Newtonsoft.Json;
using NServiceBus;

namespace MessageSender.API
{
    public class MessageController : ApiController
    {
        private ISendOnlyBus Bus => BusFactory.BusInstance;

        public IHttpActionResult Get()
        {
            try
            {
                return Ok((from type in MessageTypesCache.GetAll() select type.Name).ToList());
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        public IHttpActionResult Get(string id)
        {
            try
            {
                var instance = Activator.CreateInstance(MessageTypesCache.Get(id));
                return Ok(JsonConvert.SerializeObject(instance));
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        public IHttpActionResult Put(string id, [FromBody] string template)
        {
            try
            {
                var message = JsonConvert.DeserializeObject(template, MessageTypesCache.Get(id));
                Bus.Send(message);

                return Ok();
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}", ex);
                return InternalServerError(ex);
            }
        }

        public IHttpActionResult Post(string id, [FromBody] string template)
        {
            try
            {
                var message = JsonConvert.DeserializeObject(template, MessageTypesCache.Get(id));
                Bus.Publish(message);

                return Ok();
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}", ex);
                return InternalServerError(ex);
            }
        }
    }
}
