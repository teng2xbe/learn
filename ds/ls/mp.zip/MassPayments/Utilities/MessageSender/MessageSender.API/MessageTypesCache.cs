﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MessageSender.API
{
    public static class MessageTypesCache
    {
        private static Dictionary<string, Type> messageTypes;

        private static Dictionary<string, Type> MessageTypes
        {
            get
            {
                if (messageTypes == null)
                    Initialize();
                return messageTypes;
            }
        }

        public static Type Get(string type)
        {
            Type result;
            if (!MessageTypes.TryGetValue(type, out result))
                throw new KeyNotFoundException($"Type {type} not found in cache.");
            return result;
        }

        public static List<Type> GetAll()
        {
            return MessageTypes.Values.ToList();
        }

        private static void Initialize()
        {
            var types = MassPayMessageTypes.Get();
            messageTypes = types.ToDictionary(k => k.Name, t => t);
        }        
    }

}
