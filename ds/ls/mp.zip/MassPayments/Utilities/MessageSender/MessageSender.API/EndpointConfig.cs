﻿using System.Configuration;
using NServiceBus;

namespace MessageSender.API
{
    public class EndpointConfig
    {

        public void Customize(BusConfiguration configuration)
        {
            configuration.UseTransport<SqlServerTransport>()
                .DefaultSchema("nsb");
            configuration.UsePersistence<NHibernatePersistence>();
            configuration.UseSerialization<JsonSerializer>();
            configuration.EndpointName(ConfigurationManager.AppSettings["BusEndpointName"]);
            //configuration.DoNotCreateQueues();
            configuration.Conventions()
                .DefiningCommandsAs(MassPayMessageTypes.IsMassPayCommandType)
                .DefiningEventsAs
                (t  =>  (
                    MassPayMessageTypes.IsMassPayEventType(t) || 
                    MassPayMessageTypes.IsPainEventType(t) ||
                    MassPayMessageTypes.IsExternalEventType(t))
                );

        }

    }

    public static class BusFactory
    {

        public static ISendOnlyBus BusInstance { get; private set; }

        public static void Init()
        {
            var configuration = new BusConfiguration();
            new EndpointConfig().Customize(configuration);

            BusInstance = Bus.CreateSendOnly(configuration);
        }
    }
}