﻿using System;
using System.Collections.Generic;
using System.Linq;
using Common.Contracts.MassPayments.Messages.Commands;
using Common.Contracts.MassPayments.Messages.Events;
using Common.Contracts.PAIN.Messages.Events;
using Common.Contracts.PAIN.Messages.External;
using Common.Contracts.Subscriptions.Messages.Events;

namespace MessageSender.API
{
    public static class MassPayMessageTypes
    {
        
        private static readonly Type MassPayCommands  = typeof(MassPaymentsCommand);
        private static readonly Type MassPayEvents = typeof(MassPaymentsEvent);
        private static readonly Type PainEvents = typeof(PainEvent);
        private static readonly Type SubscriptionEvents = typeof(SubscriptionEvent);
        private static readonly Type ExternalEvents = typeof(ExternalEvent);

        public static bool IsMassPayCommandType(Type type)
        {
            return type.IsClass && !type.IsAbstract && (type.IsSubclassOf(MassPayCommands));
        }

        public static bool IsMassPayEventType(Type type)
        {
            return type.IsClass && !type.IsAbstract && (type.IsSubclassOf(MassPayEvents));
        }

        public static bool IsPainEventType(Type type)
        {
            return type.IsClass && !type.IsAbstract && (type.IsSubclassOf(PainEvents));
        }

        public static bool IsSubscriptionEventType(Type type)
        {
            return type.IsClass && !type.IsAbstract && (type.IsSubclassOf(SubscriptionEvents));
        }

        public static bool IsExternalEventType(Type type)
        {
            return type.IsClass && !type.IsAbstract && (type.IsSubclassOf(ExternalEvents));
        }

        public static List<Type> Get()
        {
            var messageTypesCache = new List<Type>();

            messageTypesCache.AddRange(MassPayCommands.Assembly.GetTypes().Where(IsMassPayCommandType).ToList());
            messageTypesCache.AddRange(MassPayEvents.Assembly.GetTypes().Where(IsMassPayEventType).ToList());
            messageTypesCache.AddRange(PainEvents.Assembly.GetTypes().Where(IsPainEventType).ToList());
            messageTypesCache.AddRange(SubscriptionEvents.Assembly.GetTypes().Where(IsSubscriptionEventType).ToList());
            messageTypesCache.AddRange(ExternalEvents.Assembly.GetTypes().Where(IsExternalEventType).ToList());
            return messageTypesCache;
        }
    }
}
