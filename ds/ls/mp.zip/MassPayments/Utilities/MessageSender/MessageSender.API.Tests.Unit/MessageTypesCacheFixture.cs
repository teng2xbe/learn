﻿using System.Collections.Generic;
using Common.Contracts.MassPayments.Messages.Commands;
using Common.Contracts.MassPayments.Messages.Events;
using Common.Contracts.PAIN.Messages.Events;
using Common.Contracts.PAIN.Messages.External;
using Common.Contracts.Subscriptions.Messages.Events;
using NUnit.Framework;


namespace MessageSender.API.Tests.Unit
{
    [TestFixture]
    public class MessageTypesCacheFixture
    {
        [Test]
        public void Get_Commands_ReturnsCorrect()
        {
            var expected = new CreateWebhookCommand().GetType();
            var actual = MessageTypesCache.Get("CreateWebhookCommand");
            Assert.AreEqual(expected.FullName, actual.FullName);
        }

        [Test]
        public void Get_Events_ReturnsCorrect()
        {
            var expected = new PingRequestedEvent().GetType();
            var actual = MessageTypesCache.Get("PingRequestedEvent");
            Assert.AreEqual(expected.FullName, actual.FullName);
        }

        [Test]
        public void Get_PainEvents_ReturnsCorrect()
        {
            var expected = new PaymentReturnedByBrokerEvent().GetType();
            var actual = MessageTypesCache.Get("PaymentReturnedByBrokerEvent");
            Assert.AreEqual(expected.FullName, actual.FullName);
        }

        [Test]
        public void Get_SubscriptionEvents_ReturnsCorrect()
        {
            var expected = new NotificationPublishedToWebhookEvent().GetType();
            var actual = MessageTypesCache.Get("NotificationPublishedToWebhookEvent");
            Assert.AreEqual(expected.FullName, actual.FullName);
        }

        [Test]
        public void Get_ExternalEvents_ReturnsCorrect()
        {
            var expected = new PaymentReturnedEvent().GetType();
            var actual = MessageTypesCache.Get("PaymentReturnedEvent");
            Assert.AreEqual(expected.FullName, actual.FullName);
        }

        [Test]
        public void Get_ThrowsExceptionForInvalidMessageType()
        {
            Assert.Throws<KeyNotFoundException>(() => MessageTypesCache.Get("UnknownTypes"));
        }        
    }
}
