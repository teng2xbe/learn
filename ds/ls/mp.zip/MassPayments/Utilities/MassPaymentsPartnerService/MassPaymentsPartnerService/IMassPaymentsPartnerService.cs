﻿using System.IO;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace MassPaymentsPartnerService
{
    [ServiceContract]
    public interface IMassPaymentsPartnerService
    {
        [WebInvoke(Method = "GET",
            UriTemplate = "ping")]
        void Ping();

        [OperationContract]
        [WebInvoke(
        Method = "POST",
        BodyStyle = WebMessageBodyStyle.Bare,
        UriTemplate = "invoice")]
        void UploadInvoice(Stream data);
    }
}
