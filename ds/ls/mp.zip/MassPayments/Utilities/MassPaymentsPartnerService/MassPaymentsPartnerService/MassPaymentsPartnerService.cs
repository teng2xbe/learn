﻿using System;
using System.Configuration;
using System.IO;
using System.ServiceModel.Web;

namespace MassPaymentsPartnerService
{
    public class MassPaymentsPartnerService : IMassPaymentsPartnerService
    {
        public void Ping()
        {
            Console.WriteLine("Ping received.");
        }

        public void UploadInvoice(Stream data)
        {
            var headers = WebOperationContext.Current.IncomingRequest.Headers;
            var fileName = headers["fileName"];
            var outputPath = Convert.ToString(new AppSettingsReader().GetValue("OutputPath", typeof(string)));
            var outputFilePath = Path.Combine(outputPath, fileName);

            using (var writer = new FileStream(outputFilePath, FileMode.Create))
            {
                int readCount;
                var buffer = new byte[8192];
                while ((readCount = data.Read(buffer, 0, buffer.Length)) != 0)
                {
                    writer.Write(buffer, 0, readCount);
                }
            }

            Console.WriteLine("File received at {0}", Path.GetFullPath(outputFilePath));
        }
    }
}
