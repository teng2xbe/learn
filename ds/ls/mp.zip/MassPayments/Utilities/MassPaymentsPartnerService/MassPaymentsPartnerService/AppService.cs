﻿using System.ServiceProcess;

namespace MassPaymentsPartnerService
{
    public partial class AppService : ServiceBase
    {
        
    }
}
