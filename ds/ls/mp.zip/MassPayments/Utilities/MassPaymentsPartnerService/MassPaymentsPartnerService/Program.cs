﻿using System;
using System.ServiceModel;

namespace MassPaymentsPartnerService
{
    public static class Program
    {
        public static void Main()
        {
            using (ServiceHost serviceHost = new ServiceHost(typeof (MassPaymentsPartnerService)))
            {
                serviceHost.Open();

                Console.WriteLine("The service is ready.");
                Console.WriteLine("Press <ENTER> to terminate service.");
                Console.WriteLine();
                Console.ReadLine();
             }
        }
    }
}
