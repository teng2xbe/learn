import { Component } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';


@Component({
    selector: 'home',
    templateUrl: './home.component.html'
})
export class HomeComponent {
    public adapterStatuses : AdapterStatus[] = [];

    constructor(){
        this.adapterStatuses.push(
            new AdapterStatus(
                "https://localhost:7331/banking",
                "Banking Rest",
                "Expception thrown",
                false    
            )
        );
        this.adapterStatuses.push(
            new AdapterStatus(
                "https://localhost:7331/banking/IVR",
                "Banking IVR",
                "OK",
                true    
            )
        );
        this.adapterStatuses.push(
            new AdapterStatus(
                "https://localhost:7331/banking/LOS",
                "Banking LOS",
                "Exception unable to reach",
                false    
            )
        );

        console.log(this.adapterStatuses[0])
    }
}


export class AdapterStatus {
    adapterUrl : string;
    isActive : boolean;
    adapterName : string;
    adapterStatusDescription  : string;
    constructor(adapterUrl: string, adapterName : string,
        adapterStatusDescription: string, isActive : boolean){
            this.adapterName = adapterName;
            this.isActive = isActive;
            this.adapterStatusDescription = adapterStatusDescription;
            this.adapterUrl = adapterUrl;
    }

}