import { NgClass } from '@angular/common';
import { Component, Input } from '@angular/core';
import { AdapterStatus } from '../../home/home.component';

@Component({
  selector: 'adapter-status',
  templateUrl: './adapter-status.component.html',
  styleUrls: ['./adapter-status.component.css']
})
export class AdapterStatusComponent {
    @Input('adapter-status') adapterStatus : AdapterStatus;
    
    constructor() {
        console.log(this.adapterStatus);    
    }
}
