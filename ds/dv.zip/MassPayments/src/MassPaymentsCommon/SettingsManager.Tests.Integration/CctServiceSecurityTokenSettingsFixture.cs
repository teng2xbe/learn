﻿using System.Linq.Expressions;
using NUnit.Framework;
using Rhino.Mocks;
using SettingsManager.Interfaces;
using SettingsManager.Mappers.Interfaces;
using SettingsManager.Tests.Integration.Utilities;

namespace SettingsManager.Tests.Integration
{
    [TestFixture]
    public class CctServiceSecurityTokenSettingsFixture
    {
        [Test]
        public void Settings_LoadsAndCaches_Correctly()
        {
            var settingSource = MockRepository.GenerateMock<ICctServiceSecurityTokenMapper>();
            settingSource.Expect(s => s.GetActiveToken()).Return("abc").Repeat.Once();
            var settings = new CctServiceSecurityTokenSettings(settingSource);

            var token = settings.GetActiveSecurityToken();
            token = settings.GetActiveSecurityToken();
            token = settings.GetActiveSecurityToken();

            Assert.AreEqual("abc",token);
            settingSource.VerifyAllExpectations();
        }
    }
}
