﻿using NUnit.Framework;
using Rhino.Mocks;
using SettingsManager.Interfaces;
using SettingsManager.Tests.Integration.Utilities;

namespace SettingsManager.Tests.Integration
{
    [TestFixture]
    public class ValidationRulesSettings
    {
        private ValidationRuleSettings validationRules;

        [SetUp]
        public void SetUp()
        {
            var connectionString = ConnectionStrings.Get(Database.MassPayments.ToString());
            var settingsConfig = new SettingsConfig(connectionString, "MP.BusinessSettings");
            validationRules = new ValidationRuleSettings(settingsConfig);
        }
        
        [TearDown]
        public void TearDown()
        {
            validationRules = null;
        }

        [Test]
        public void ValidationRulesSettings_Caches_Correctly()
        {
            var settingSource = MockRepository.GenerateMock<ISettingSource>();
            settingSource.Expect(s => s.GetAllValidationRules()).Repeat.Times(1);

            var validationRules1 = new ValidationRuleSettings(settingSource);
            validationRules.GetStringValue("ValidationRule.Format.ExternalID"); 

            settingSource.VerifyAllExpectations();
        }

        [Test]
        public void GetStringValue_Correctly()
        {
            var value = validationRules.GetStringValue("ValidationRule.Format.ExternalID");
            Assert.IsNotNullOrEmpty(value);
        }

        [Test]
        public void GetStringValueWithDefault_Correctly()
        {
            var defaultValue = "blah";
            var value = validationRules.GetStringValue("ValidationRule.Format.ExternalID_TMP", defaultValue);
            Assert.AreEqual(defaultValue, value);
        }
    }
}
