﻿namespace SettingsManager.Tests.Integration.Utilities
{
    public enum Database
    {
        MassPayments,
        BI,
        Dispatcher,
        MPIQ
    }
}
