﻿using System.Configuration;

namespace SettingsManager.Tests.Integration.Utilities
{
    public class ConnectionStrings
    {
        public static string Get(string database)
        {
            return ConfigurationManager.ConnectionStrings[$"{database}.ConnectionString"].ConnectionString;
        }
    }
}
