﻿using NUnit.Framework;
using SettingsManager.Mappers;
using SettingsManager.Tests.Integration.Utilities;

namespace SettingsManager.Tests.Integration.Mappers
{
    [TestFixture]
    public class SettingsMapperFixture
    {
        [Test]
        public void GetMassPaymentsConfig_Works()
        {
            string connectionString = ConnectionStrings.Get(Database.MassPayments.ToString());
            var settingConfig = new SettingsConfig(connectionString, "MP.BusinessSettings");
            var mapper = new SettingsMapper(settingConfig);
            var settings = mapper.GetAllSettings();
            Assert.True(settings.Count > 0);

            var validationRules = mapper.GetAllValidationRules();
            Assert.True(validationRules.Count > 0);
        }
        
    }
}
