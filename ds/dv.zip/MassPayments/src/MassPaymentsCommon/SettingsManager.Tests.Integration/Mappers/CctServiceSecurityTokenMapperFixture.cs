﻿using NUnit.Framework;
using SettingsManager.Mappers;
using SettingsManager.Tests.Integration.Utilities;

namespace SettingsManager.Tests.Integration.Mappers
{
    [TestFixture]
    public class CctServiceSecurityTokenMapperFixture
    {
        [Test]
        public void GetToken_Works()
        {
            string connectionString = ConnectionStrings.Get(Database.MassPayments.ToString());
            var settingConfig = new CctServiceSecurityTokenConfig(connectionString, "MP.CctServiceSecurityToken");
            var mapper = new CctServiceSecurityTokenMapper(settingConfig);
            var token = mapper.GetActiveToken();
            Assert.IsNotNullOrEmpty(token);
        }
    }
}
