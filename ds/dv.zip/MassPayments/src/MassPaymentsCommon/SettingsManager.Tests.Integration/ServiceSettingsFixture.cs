﻿using NUnit.Framework;
using Rhino.Mocks;
using SettingsManager.Interfaces;
using SettingsManager.Tests.Integration.Utilities;

namespace SettingsManager.Tests.Integration
{
    [TestFixture]
    public class ServiceSettingsFixture
    {
        private ServiceSettings settings;

        [SetUp]
        public void SetUp()
        {
            var connectionString = ConnectionStrings.Get(Database.MassPayments.ToString());
            var settingsConfig = new SettingsConfig(connectionString, "MP.BusinessSettings");
            settings = new ServiceSettings(settingsConfig);
        }
        
        [TearDown]
        public void TearDown()
        {
            settings = null;
        }

        [Test]
        public void Settings_Caches_Correctly()
        {
            var settingSource = MockRepository.GenerateMock<ISettingSource>();
            settingSource.Expect(s => s.GetAllSettings()).Repeat.Times(1);

            var settings = new ServiceSettings(settingSource);
            settings.GetIntValue("IRIS.PollFrequencyInSeconds",1);
            settings.GetIntValue("IRIS.PollFrequencyInSeconds",1);

            settingSource.VerifyAllExpectations();
        }

        [Test]
        public void GetStringValue_Correctly()
        {
            var value = settings.GetStringValue("IRIS.PollFrequencyInSeconds");
            Assert.IsNotNullOrEmpty(value);
        }

        [Test]
        public void GetIntValue_Correctly()
        {
            var intValue = settings.GetIntValue("IRIS.PollFrequencyInSeconds");
            Assert.IsTrue(intValue > 0);
        }

        [Test]
        public void GetBooleanValue_Correctly()
        {
            var value = settings.GetBooleanValue("Invoice.EnableInvoiceXmlValidation");
            Assert.IsTrue(value);
        }

        [Test]
        public void GetStringValueWithDefault_Correctly()
        {
            var defaultValue = "blah";
            var value = settings.GetStringValue("RandOMKey", defaultValue);
            Assert.AreEqual(defaultValue, value);
        }

        [Test]
        public void GetIntValueWithDefault_Correctly()
        {

            var defaultValue = 12345;
            var intValue = settings.GetIntValue("RandomKey", defaultValue);
            Assert.AreEqual(defaultValue, intValue);
        }

        [Test]
        public void GetBooleanValueWithDefault_Correctly()
        {

            var defaultValue = true;
            var value = settings.GetBooleanValue("Invoice.EnableInvoiceXmlValidation", defaultValue);
            Assert.AreEqual(defaultValue, value);
        }
    }
}
