﻿namespace SettingsManager
{
    public class SettingsConfig
    {
        public SettingsConfig(string connectionString, string tableFullName)
        {
            Connectionstring = connectionString;
            TableFullName = tableFullName;
        }

        public SettingsConfig(string connectionString, string tableFullName, string keyColumnName, string valueColumnName)
        {
            Connectionstring = connectionString;
            TableFullName = tableFullName;
            this.keyColumnName = keyColumnName;
            this.valueColumnName = valueColumnName;
        }

        public string Connectionstring { get; set; }
        public string TableFullName { get; set; }
        
        private string keyColumnName;
        private string valueColumnName;

        public string KeyColumnName
        {
            get { return string.IsNullOrEmpty(keyColumnName) ? "Name" : keyColumnName; }
            set { keyColumnName = value; }
        }

        public string ValueColumnName
        {
            get { return string.IsNullOrEmpty(keyColumnName) ? "Value" : valueColumnName; }
            set { valueColumnName = value; }
        }
    }
}
