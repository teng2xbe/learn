﻿using System.Data.SqlClient;
using PetaPoco;
using SettingsManager.Mappers.Interfaces;

namespace SettingsManager.Mappers
{
    internal class CctServiceSecurityTokenMapper : ICctServiceSecurityTokenMapper
    {
        private CctServiceSecurityTokenConfig config;
        public CctServiceSecurityTokenMapper(CctServiceSecurityTokenConfig config)
        {
            this.config = config;
        }
        
        public string GetActiveToken()
        {
            using (var connection = new SqlConnection(config.Connectionstring))
            {
                connection.Open();

                var db = new PetaPoco.Database(connection);
                var sql = Sql.Builder
                    .Select($"Top 1 {config.TokenColumnName}")
                    .From($"{config.TableFullName}")
                    .Where($"{config.IsActiveColumnName} = 1");

                var tokens = db.Fetch<string>(sql);
                if (tokens == null || tokens.Count == 0)
                    return string.Empty;
                return tokens[0];
            }
        }
    }
}
