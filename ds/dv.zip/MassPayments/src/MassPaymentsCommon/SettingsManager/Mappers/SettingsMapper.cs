﻿using System.Collections.Generic;
using System.Data.SqlClient;
using PetaPoco;
using SettingsManager.Domain.Entities;
using SettingsManager.Mappers.Interfaces;

namespace SettingsManager.Mappers
{
    internal class SettingsMapper : ISettingsMapper
    {
        private SettingsConfig config;
        public SettingsMapper(SettingsConfig config)
        {
            this.config = config;
        }
        
        public List<SettingEntry> GetAllSettings()
        {
            using (var connection = new SqlConnection(config.Connectionstring))
            {
                connection.Open();

                var db = new PetaPoco.Database(connection);
                var sql = Sql.Builder
                    .Select($"{config.KeyColumnName} as SettingKey, {config.ValueColumnName} as SettingValue")
                    .From($"{config.TableFullName}");

                var settings = db.Fetch<SettingEntry>(sql) ?? new List<SettingEntry>();
                return settings;
            }
        }

        public List<ValidationRule> GetAllValidationRules()
        {
            using (var connection = new SqlConnection(config.Connectionstring))
            {
                connection.Open();

                var db = new PetaPoco.Database(connection);
                var sql = Sql.Builder
                    .Select($"{config.KeyColumnName} as ValidationRuleKey, {config.ValueColumnName} as ValidationRuleValue")
                    .From($"{config.TableFullName}")
                    .Where($"{config.KeyColumnName} like 'ValidationRule%'");

                var validationRules = db.Fetch<ValidationRule>(sql) ?? new List<ValidationRule>();
                return validationRules;
            }
        }
    }
}
