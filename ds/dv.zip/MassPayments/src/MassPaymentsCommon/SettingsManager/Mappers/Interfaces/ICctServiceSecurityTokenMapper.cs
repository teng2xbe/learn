﻿namespace SettingsManager.Mappers.Interfaces
{
    internal interface ICctServiceSecurityTokenMapper
    {
        string GetActiveToken();
    }
}
