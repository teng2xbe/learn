﻿using SettingsManager.Interfaces;

namespace SettingsManager.Mappers.Interfaces
{
    internal interface ISettingsMapper : ISettingSource
    {
    }
}
