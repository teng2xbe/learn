﻿using System;
using System.Collections.Generic;
using SettingsManager.Domain.Entities;
using SettingsManager.Interfaces;
using SettingsManager.Mappers;

namespace SettingsManager
{
    public class ServiceSettings : IServiceSettings
    {
        private Dictionary<string, string> cachedSettings;
        private List<SettingEntry> cachedSettingList; 
        private ISettingSource settingSource;

        public ServiceSettings(ISettingSource settingSource)
        {
            this.settingSource = settingSource;
            LoadValues();
        }

        public ServiceSettings(SettingsConfig config)
        {
            settingSource = new SettingsMapper(config);
            LoadValues();
        }
        
        public void LoadValues()
        {
            cachedSettings = new Dictionary<string, string>();
            cachedSettingList = settingSource.GetAllSettings();
            cachedSettingList.ForEach(s =>
            {
                //Don't trust the source to have unique keys
                if (cachedSettings.ContainsKey(s.SettingKey))
                    cachedSettings[s.SettingKey] = s.SettingValue;
                else
                    cachedSettings.Add(s.SettingKey, s.SettingValue);
            });
        }

        public List<SettingEntry> GetAllSetings()
        {
            if(cachedSettings == null)
                LoadValues();
            return cachedSettingList;
        }

        private string GetValue(string key)
        {
            string value;
            if (cachedSettings.TryGetValue(key, out value))
            {
                return value;
            }

            throw new KeyNotFoundException();
        }

        public bool GetBooleanValue(string key)
        {
            return Convert.ToBoolean(GetValue(key));
        }

        public int GetIntValue(string key)
        {
            return Convert.ToInt32(GetValue(key));
        }

        public string GetStringValue(string key)
        {
            return GetValue(key);
        }

        public bool GetBooleanValue(string key, bool defaultValue)
        {
            try
            {
                return GetBooleanValue(key);
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }

        public int GetIntValue(string key, int defaultValue)
        {
            try
            {
                return GetIntValue(key);
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }

        public string GetStringValue(string key, string defaultValue)
        {
            try
            {
                return GetStringValue(key);
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }
    }
}
