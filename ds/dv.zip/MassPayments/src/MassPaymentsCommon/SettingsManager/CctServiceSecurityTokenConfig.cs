﻿namespace SettingsManager
{
    public class CctServiceSecurityTokenConfig
    {
        public CctServiceSecurityTokenConfig(string connectionString, string tableFullName)
        {
            Connectionstring = connectionString;
            TableFullName = tableFullName;
        }

        public CctServiceSecurityTokenConfig(string connectionString, string tableFullName, string tokenColumnName, string isActiveColumnName)
        {
            Connectionstring = connectionString;
            TableFullName = tableFullName;
            this.tokenColumnName = tokenColumnName;
            this.isActiveColumnName = isActiveColumnName;
        }

        public string Connectionstring { get; set; }
        public string TableFullName { get; set; }
        
        private string tokenColumnName;
        private string isActiveColumnName;

        public string TokenColumnName
        {
            get { return string.IsNullOrEmpty(tokenColumnName) ? "SecurityToken" : tokenColumnName; }
            set { tokenColumnName = value; }
        }

        public string IsActiveColumnName
        {
            get { return string.IsNullOrEmpty(isActiveColumnName) ? "IsActive" : isActiveColumnName; }
            set { isActiveColumnName = value; }
        }
    }
}
