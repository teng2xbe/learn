﻿namespace SettingsManager.Domain.Entities
{
    public class ValidationRule
    {
        public string ValidationRuleKey { get; set; }
        public string ValidationRuleValue { get; set; }
    }
}
