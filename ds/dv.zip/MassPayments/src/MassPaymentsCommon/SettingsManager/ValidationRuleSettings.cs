﻿using System;
using System.Collections.Generic;
using SettingsManager.Domain.Entities;
using SettingsManager.Interfaces;
using SettingsManager.Mappers;

namespace SettingsManager
{
    public class ValidationRuleSettings : IValidationRuleSettings
    {
        private Dictionary<string, string> cachedValidationRules;
        private List<ValidationRule> cachedValidationRulesList;
        private ISettingSource settingSource;

        public ValidationRuleSettings(ISettingSource settingSource)
        {
            this.settingSource = settingSource;
            LoadValues();
        }

        public ValidationRuleSettings(SettingsConfig config)
        {
            settingSource = new SettingsMapper(config);
            LoadValues();
        }
        
        public void LoadValues()
        {
            cachedValidationRules = new Dictionary<string, string>();
            cachedValidationRulesList = settingSource.GetAllValidationRules();
            cachedValidationRulesList.ForEach(s =>
            {
                //Don't trust the source to have unique keys
                if (cachedValidationRules.ContainsKey(s.ValidationRuleKey))
                    cachedValidationRules[s.ValidationRuleValue] = s.ValidationRuleValue;
                else
                    cachedValidationRules.Add(s.ValidationRuleKey, s.ValidationRuleValue);
            });
        }

        public List<ValidationRule> GetValidationRules()
        {
            if (cachedValidationRules == null)
                LoadValues();
            return cachedValidationRulesList;
        }

        private string GetValue(string key)
        {
            string value;
            if (cachedValidationRules.TryGetValue(key, out value))
            {
                return value;
            }

            throw new KeyNotFoundException();
        }

        public bool GetBooleanValue(string key)
        {
            return Convert.ToBoolean(GetValue(key));
        }

        public int GetIntValue(string key)
        {
            return Convert.ToInt32(GetValue(key));
        }

        public string GetStringValue(string key)
        {
            return GetValue(key);
        }

        public bool GetBooleanValue(string key, bool defaultValue)
        {
            try
            {
                return GetBooleanValue(key);
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }

        public int GetIntValue(string key, int defaultValue)
        {
            try
            {
                return GetIntValue(key);
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }

        public string GetStringValue(string key, string defaultValue)
        {
            try
            {
                return GetStringValue(key);
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }
    }
}
