﻿using SettingsManager.Interfaces;
using SettingsManager.Mappers;
using SettingsManager.Mappers.Interfaces;

namespace SettingsManager
{
    public class CctServiceSecurityTokenSettings : ICctServiceSecurityTokenSettings
    {
        private string cachedToken = null; 
        private ICctServiceSecurityTokenMapper settingSource;

        internal CctServiceSecurityTokenSettings(ICctServiceSecurityTokenMapper settingSource)
        {
            this.settingSource = settingSource;
            GetActiveSecurityToken();
        }

        public CctServiceSecurityTokenSettings(CctServiceSecurityTokenConfig config)
        {
            settingSource = new CctServiceSecurityTokenMapper(config);
            GetActiveSecurityToken();
        }
        
        public string GetActiveSecurityToken()
        {
            if (cachedToken == null)
            {
                cachedToken = settingSource.GetActiveToken();
                return cachedToken;
            }

            return cachedToken;
        }
    }
}
