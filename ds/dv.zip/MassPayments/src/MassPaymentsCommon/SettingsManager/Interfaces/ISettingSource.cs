﻿using System.Collections.Generic;
using SettingsManager.Domain.Entities;

namespace SettingsManager.Interfaces
{
    public interface ISettingSource
    {
        List<SettingEntry> GetAllSettings();

        List<ValidationRule> GetAllValidationRules();
    }
}
