﻿using System.Collections.Generic;
using SettingsManager.Domain.Entities;

namespace SettingsManager.Interfaces
{
    public interface IServiceSettings
    {
        void LoadValues();
        List<SettingEntry> GetAllSetings(); 
        bool GetBooleanValue(string key);
        int GetIntValue(string key);
        string GetStringValue(string key);
        bool GetBooleanValue(string key, bool defaultValue);
        int GetIntValue(string key, int defaultValue);
        string GetStringValue(string key, string defaultValue);
    }
}
