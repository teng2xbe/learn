﻿using System.Collections.Generic;
using SettingsManager.Domain.Entities;

namespace SettingsManager.Interfaces
{
    public interface ICctServiceSecurityTokenSettings
    {
        string GetActiveSecurityToken();
    }
}
