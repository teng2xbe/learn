﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using MassPaymentsCommon.WCFContracts.Attributes.ValidationAttribute;
using MassPaymentsCommon.WCFContracts.Enums;
using NUnit.Framework;

namespace WCFContracts.Tests.Unit.Attributes.ValidationAttribute
{
    [TestFixture]
    public class IfImNotNullThenOtherPropertiesShouldNotBeNullAttributeFixture
    {
        [Test]
        public void ValidationWorks_PropertyHasNotDataMemberAttribute()
        {
            var testData = new TestDataWithNoDataMemberProperty
            {
                PropertyOne = "abc"
            };

            var attribute =
                TypeDescriptor.GetProperties(testData)
                    .Cast<PropertyDescriptor>()
                    .First(p => p.Name == nameof(testData.PropertyOne))
                    .Attributes.OfType<IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute>().First();

            var context = new ValidationContext(testData, null, null)
            {
                DisplayName = nameof(testData.PropertyOne),
                MemberName = nameof(testData.PropertyOne)
            };

            var result = attribute.GetValidationResult(testData.PropertyOne, context);
            Assert.AreEqual(result.ErrorMessage, ((int)ErrorCode.ConditionalField).ToString());
            Assert.AreEqual(result.MemberNames.ElementAt(0), nameof(testData.PropertyTwo));
        }

        [Test]
        public void ValidationWorks_PropertyHasDataMemberAttributeButNoName()
        {
            var testData = new TestDataWithDataMemberPropertyButNoName
            {
                PropertyOne = "abc"
            };

            var attribute =
                TypeDescriptor.GetProperties(testData)
                    .Cast<PropertyDescriptor>()
                    .First(p => p.Name == nameof(testData.PropertyOne))
                    .Attributes.OfType<IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute>().First();

            var context = new ValidationContext(testData, null, null)
            {
                DisplayName = nameof(testData.PropertyOne),
                MemberName = nameof(testData.PropertyOne)
            };

            var result = attribute.GetValidationResult(testData.PropertyOne, context);
            Assert.AreEqual(result.ErrorMessage, ((int)ErrorCode.ConditionalField).ToString());
            Assert.AreEqual(result.MemberNames.ElementAt(0), nameof(testData.PropertyTwo));
        }
        
        [Test]
        public void ValidationWorks_PropertyHasDataMemberAttributeAndName()
        {
            var testData = new TestDataWithDataMemberPropertyAndName
            {
                PropertyOne = "abc"
            };

            var attribute =
                TypeDescriptor.GetProperties(testData)
                    .Cast<PropertyDescriptor>()
                    .First(p => p.Name == nameof(testData.PropertyOne))
                    .Attributes.OfType<IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute>().First();

            var context = new ValidationContext(testData, null, null)
            {
                DisplayName = nameof(testData.PropertyOne),
                MemberName = nameof(testData.PropertyOne)
            };

            var result = attribute.GetValidationResult(testData.PropertyOne, context);
            Assert.AreEqual(result.ErrorMessage, ((int)ErrorCode.ConditionalField).ToString());
            Assert.AreEqual(result.MemberNames.ElementAt(0), "IHaveAName");
        }

        [Test]
        public void ValidationWorks_WhenRequirementAreMet()
        {
            var testData = new TestDataWithDataMemberPropertyAndName
            {
                PropertyOne = "abc",
                PropertyTwo = "edf"
            };

            var attribute =
                TypeDescriptor.GetProperties(testData)
                    .Cast<PropertyDescriptor>()
                    .First(p => p.Name == nameof(testData.PropertyOne))
                    .Attributes.OfType<IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute>().First();

            var context = new ValidationContext(testData, null, null)
            {
                DisplayName = nameof(testData.PropertyOne),
                MemberName = nameof(testData.PropertyOne)
            };

            var result = attribute.GetValidationResult(testData.PropertyOne, context);

            Assert.AreEqual(result, ValidationResult.Success);
        }

        [Test]
        public void ValidationWorks_ValidatesMultipleProperties()
        {
            var testData = new TestDataValidatesMultipleProperty
            {
                PropertyOne = "abc"
            };

            var attribute =
                TypeDescriptor.GetProperties(testData)
                    .Cast<PropertyDescriptor>()
                    .First(p => p.Name == nameof(testData.PropertyOne))
                    .Attributes.OfType<IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute>().First();

            var context = new ValidationContext(testData, null, null)
            {
                DisplayName = nameof(testData.PropertyOne),
                MemberName = nameof(testData.PropertyOne)
            };

            var result = attribute.GetValidationResult(testData.PropertyOne, context);
            Assert.AreEqual(result.ErrorMessage, ((int)ErrorCode.ConditionalField).ToString());
            Assert.AreEqual(result.MemberNames.ElementAt(0), "PropertyTwo");
            Assert.AreEqual(result.MemberNames.ElementAt(1), "PropertyThree");
        }

        [Test]
        public void ValidationWorks_WhenAttributeDoesNotSpecifyOtherProperties()
        {
            var testData = new TestDataDoesNotSpecifyPropertyToValidate
            {
                PropertyOne = "abc"
            };

            var attribute =
                TypeDescriptor.GetProperties(testData)
                    .Cast<PropertyDescriptor>()
                    .First(p => p.Name == nameof(testData.PropertyOne))
                    .Attributes.OfType<IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute>().First();

            var context = new ValidationContext(testData, null, null)
            {
                DisplayName = nameof(testData.PropertyOne),
                MemberName = nameof(testData.PropertyOne)
            };

            var result = attribute.GetValidationResult(testData.PropertyOne, context);

            Assert.AreEqual(result, ValidationResult.Success);
        }

        class TestDataWithNoDataMemberProperty
        {
            [IfImNotNullThenOtherPropertiesShouldNotBeNull(OtherNotNullPropertyNames = "PropertyTwo")]
            public string PropertyOne { get; set; }
            public string PropertyTwo { get; set; }
        }

        class TestDataWithDataMemberPropertyButNoName
        {
            [IfImNotNullThenOtherPropertiesShouldNotBeNull(OtherNotNullPropertyNames = "PropertyTwo")]
            public string PropertyOne { get; set; }

            [DataMember]
            public string PropertyTwo { get; set; }
        }

        class TestDataWithDataMemberPropertyAndName
        {
            [IfImNotNullThenOtherPropertiesShouldNotBeNull(OtherNotNullPropertyNames = "PropertyTwo")]
            public string PropertyOne { get; set; }

            [DataMember(Name = "IHaveAName")]
            public string PropertyTwo { get; set; }
        }

        class TestDataValidatesMultipleProperty
        {
            [IfImNotNullThenOtherPropertiesShouldNotBeNull(OtherNotNullPropertyNames = "PropertyTwo, PropertyThree")]
            public string PropertyOne { get; set; }
            public string PropertyTwo { get; set; }
            public string PropertyThree { get; set; }
        }


        class TestDataDoesNotSpecifyPropertyToValidate
        {
            [IfImNotNullThenOtherPropertiesShouldNotBeNull(OtherNotNullPropertyNames = "")]
            public string PropertyOne { get; set; }
            public string PropertyTwo { get; set; }
            public string PropertyThree { get; set; }
        }
    }
}
