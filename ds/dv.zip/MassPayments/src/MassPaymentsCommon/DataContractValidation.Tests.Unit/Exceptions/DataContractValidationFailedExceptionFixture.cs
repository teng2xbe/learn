﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataContractValidation.Exceptions;
using NUnit.Framework;

namespace DataContractValidation.Tests.Unit.Exceptions
{
    [TestFixture]
    public class DataContractValidationFailedExceptionFixture
    {
        [Test]
        public void Exception_ReturnsArgumentNullExceptionIfResultsAreNull()
        {
            Assert.Throws<ArgumentNullException>(() => new DataContractValidationFailedException(null));
        }

        [Test]
        public void Exception_ReturnsArgumentExceptionIfResultsAreEmpty()
        {
            Assert.Throws<ArgumentException>(() => new DataContractValidationFailedException(new List<ValidationResult>()));
        }

        [Test]
        public void Exception_SetsResultsIfAnyExist()
        {
            var results = new List<ValidationResult>
            {
                ValidationResult.Success
            };

            var exception = new DataContractValidationFailedException(results);

            Assert.AreEqual(1, exception.ValidationResults.Count);
            Assert.AreEqual(ValidationResult.Success, exception.ValidationResults[0]);
        }
    }
}
