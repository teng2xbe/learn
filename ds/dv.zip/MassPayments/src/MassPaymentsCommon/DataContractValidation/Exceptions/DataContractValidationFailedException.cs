﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace DataContractValidation.Exceptions
{
    public class DataContractValidationFailedException : Exception
    {
        public DataContractValidationFailedException(List<ValidationResult> results) : base("DataContract validation failed.")
        {
            if (results == null)
                throw new ArgumentNullException(nameof(results));

            if (!results.Any())
                throw new ArgumentException(nameof(results));

            ValidationResults = results;
        }

        public List<ValidationResult> ValidationResults { get; }
    }
}
