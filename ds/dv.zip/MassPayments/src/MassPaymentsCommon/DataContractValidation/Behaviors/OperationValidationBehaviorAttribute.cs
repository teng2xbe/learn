﻿using System;
using System.Collections.Generic;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using DataContractValidation.AttributeValidators;

namespace DataContractValidation.Behaviors
{
    [AttributeUsage(AttributeTargets.Method)]
    public class OperationValidationBehaviorAttribute : Attribute, IOperationBehavior
    {
        private readonly IEnumerable<IObjectValidator> validators;
        public OperationValidationBehaviorAttribute()
        {
            validators = new IObjectValidator[]
            {
                new DataAnnotationsObjectValidator()
            };
        }
        public void Validate(OperationDescription operationDescription)
        {
        }

        public void ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
        {
            dispatchOperation.ParameterInspectors.Add(new DataContractValidationInspector(validators));
        }

        public void ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation)
        {
        }

        public void AddBindingParameters(OperationDescription operationDescription, BindingParameterCollection bindingParameters)
        {
        }
    }
}
