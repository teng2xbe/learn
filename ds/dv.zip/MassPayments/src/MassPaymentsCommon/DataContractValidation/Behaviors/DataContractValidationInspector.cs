﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel.Dispatcher;
using DataContractValidation.AttributeValidators;
using DataContractValidation.Exceptions;

namespace DataContractValidation.Behaviors
{
    public class DataContractValidationInspector : IParameterInspector
    {
        private readonly IEnumerable<IObjectValidator> validators;
        public DataContractValidationInspector(IEnumerable<IObjectValidator> validators)
        {
            this.validators = validators;
        }

        public object BeforeCall(string operationName, object[] inputs)
        {
            var validationResults = new List<ValidationResult>();

            foreach (var input in inputs)
            {
                if (!IsDataContract(input))
                    continue;
                foreach (var validator in validators)
                {
                    var results = validator.Validate(input);
                    validationResults.AddRange(results);
                }
            }

            if (validationResults.Count > 0)
            {
                throw new DataContractValidationFailedException(validationResults);
            }

            return null;
        }

        public void AfterCall(string operationName, object[] outputs, object returnValue, object correlationState)
        {
        }

        private bool IsDataContract(object input)
        {
            return TypeDescriptor.GetAttributes(input).OfType<DataContractAttribute>().Any();
        }
    }
}
