﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using DataContractValidation.AttributeValidators;

namespace DataContractValidation.Behaviors
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ServiceValidationBehaviorAttribute : Attribute, IServiceBehavior
    {
        private readonly IParameterInspector dataContractValidationInspector;

        public ServiceValidationBehaviorAttribute()
        {
            var validators = new IObjectValidator[]
            {
                new DataAnnotationsObjectValidator(),
            };

            dataContractValidationInspector = new DataContractValidationInspector(validators);
        }

        public void AddBindingParameters(
            ServiceDescription serviceDescription,
            ServiceHostBase serviceHostBase,
            Collection<ServiceEndpoint> endpoints,
            BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
            var operations =
                from dispatcher in serviceHostBase.ChannelDispatchers.Cast<ChannelDispatcher>()
                from endpoint in dispatcher.Endpoints
                from operation in endpoint.DispatchRuntime.Operations
                select operation;

            foreach (var operation in operations)
            {
                operation.ParameterInspectors.Add(dataContractValidationInspector);
            }
        }

        public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
        }
    }
}
