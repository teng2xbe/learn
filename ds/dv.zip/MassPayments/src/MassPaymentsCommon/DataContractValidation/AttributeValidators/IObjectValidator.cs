﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DataContractValidation.AttributeValidators
{
    public interface IObjectValidator
    {
        IEnumerable<ValidationResult> Validate(object value);
    }
}
