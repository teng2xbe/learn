﻿using System;
using System.Configuration;

namespace SharedUtilities
{
    public static class Settings
    {
        private static object GetValue(string key, Type type)
        {
            if (ConfigurationManager.AppSettings[key] == null)
                throw new SettingsPropertyNotFoundException();

            return new AppSettingsReader().GetValue(key, type);
        }

        public static string GetStringValue(string key)
        {
            return GetValue(key, typeof (string)).ToString();
        }

        public static string GetStringValue(string key, string defaultValue)
        {
            try
            {
                return GetStringValue(key);
            }
            catch (SettingsPropertyNotFoundException)
            {
                return defaultValue;
            }
        }

        public static int GetIntValue(string key)
        {
            return Convert.ToInt32(GetValue(key, typeof (int)));
        }

        public static int GetIntValue(string key, int defaultValue)
        {
            try
            {
                return GetIntValue(key);
            }
            catch (InvalidOperationException)
            {
                return defaultValue;
            }
            catch (SettingsPropertyNotFoundException)
            {
                return defaultValue;
            }
        }

        public static bool GetBooleanValue(string key)
        {
            return Convert.ToBoolean(GetValue(key, typeof (bool)));
        }

        public static bool GetBooleanValue(string key, bool defaultValue)
        {
            try
            {
                return  GetBooleanValue(key);
            }
            catch (InvalidOperationException)
            {
                return defaultValue;
            }
            catch (SettingsPropertyNotFoundException)
            {
                return defaultValue;
            }
        }
    }
}
