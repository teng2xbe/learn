﻿using System.Diagnostics.CodeAnalysis;
using System.ServiceModel;

namespace SharedUtilities.Wcf
{
    [ExcludeFromCodeCoverage]
    public class ServiceHostWrapper<T> : IServiceHostWrapper<T>
    {
        private ServiceHost service;

        public void Start()
        {
            service = new ServiceHost(typeof(T));
            service.Open();
        }

        public void Stop()
        {
            if (service != null)
                service.Close();
        }
    }
}
