﻿namespace SharedUtilities.Wcf
{
    public interface IServiceHostWrapper<T>
    {
        void Start();
        void Stop();
    }
}
