﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPaymentsCommon.WCFContracts.Attributes.ValidationAttribute
{
    public class IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute : BaseValidationAttribute
    {
        public string OtherNotNullPropertyNames { get; set; }
        private ErrorCode errorCode { get; set; }

        public IfImNotNullThenOtherPropertiesShouldNotBeNullAttribute()
        {
            errorCode = ErrorCode.ConditionalField;
        }

        protected override ValidationResult IsValid(object input, ValidationContext validationContext)
        {
            if (input is string)
                if(string.IsNullOrEmpty(input as string))
                    return ValidationResult.Success;

            if(input == null)
                return ValidationResult.Success;

            var invalidProperties = new List<string>();
            foreach (var otherPropertyName in GetOtherPropertyNames())
            {
                if (!IsValidProperty(otherPropertyName, validationContext))
                {
                    invalidProperties.Add(GetParentObjectPropertyDataMemberName(otherPropertyName,validationContext));
                }
            }

            if (invalidProperties.Count > 0)
            {
                return AssembleValidationResult(errorCode, invalidProperties);
            }

            return ValidationResult.Success;
        }

        private bool IsValidProperty(string dependingPropertyName, ValidationContext validationContext)
        {
            try
            {
                var property = TypeDescriptor.GetProperties(validationContext.ObjectInstance).Cast<PropertyDescriptor>().FirstOrDefault(p => p.Name == dependingPropertyName);
                if (property != null)
                {
                    var dependingPropertyValue = property.GetValue(validationContext.ObjectInstance);
                    if (dependingPropertyValue == null)
                        return false;

                    if (dependingPropertyValue is string)
                        return !string.IsNullOrEmpty(dependingPropertyValue as string);
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private string GetParentObjectPropertyDataMemberName(string propertyName, ValidationContext validationContext)
        {
            var property = TypeDescriptor.GetProperties(validationContext.ObjectInstance).Cast<PropertyDescriptor>().FirstOrDefault(p => p.Name == propertyName);
            if (property == null)
                return propertyName;

            var dataMemberAttribute = property.Attributes.OfType<DataMemberAttribute>().FirstOrDefault();
            if(dataMemberAttribute == null)
                return propertyName;

            return string.IsNullOrEmpty(dataMemberAttribute.Name) ? propertyName : dataMemberAttribute.Name;
        }

        private IEnumerable<string> GetOtherPropertyNames()
        {
            return OtherNotNullPropertyNames.Split(',').Select(n => n.Trim());
        }
    }
}
