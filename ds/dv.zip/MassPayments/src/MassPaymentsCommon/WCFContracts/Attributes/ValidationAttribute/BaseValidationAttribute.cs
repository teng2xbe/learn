﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPaymentsCommon.WCFContracts.Attributes.ValidationAttribute
{
    public abstract class BaseValidationAttribute : System.ComponentModel.DataAnnotations.ValidationAttribute
    {
        //IMPORTANT: call this method to assemble validation result to make sure
        //the int value of errorCode is always submitted as string for ValidationResult.errorMessage field
        protected ValidationResult AssembleValidationResult(ErrorCode errorCode, List<string> invalidProperties)
        {
            if (invalidProperties == null || !invalidProperties.Any())
            {
                throw new ArgumentException(nameof(invalidProperties));
            }
            return new ValidationResult(((int)errorCode).ToString(), invalidProperties);
        }
    }
}
