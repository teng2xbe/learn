﻿using System;

namespace MassPaymentsCommon.WCFContracts.Attributes
{
    public class IgnoreRequiredPropertyAttribute : Attribute
    {
        public string Except { get; set; }
    }
}
