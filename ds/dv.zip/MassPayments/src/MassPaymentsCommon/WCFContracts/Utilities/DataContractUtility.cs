﻿using System;
using System.Linq;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.Utilities
{
    public static class DataContractUtility
    {
        public static string GetDataMemberAttributeNameValue(Type dataContractType, string dataContractPropertyName)
        {
            var dataMemberAttr = dataContractType
                    .GetProperty(dataContractPropertyName)
                    .GetCustomAttributes(typeof(DataMemberAttribute), false)
                    .FirstOrDefault();

            if (dataMemberAttr is DataMemberAttribute)
                return (dataMemberAttr as DataMemberAttribute).Name;
            return null;
        }
    }
}
