﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class BatchAggregateAmountsResultData
    {
        [DataMember(Name = "isFixedOnSettlement")]
        public bool IsFixedOnSettlement { get; set; }

        [DataMember(Name = "currency")]
        public string CurrencyCode { get; set; }

        [DataMember(Name = "settlementCurrency")]
        public string SettlementCurrencyCode { get; set; }

        [DataMember(Name = "amount", EmitDefaultValue = false)]
        public long Amount { get; set; }

        [DataMember(Name = "settlementAmount", EmitDefaultValue = false)]
        public long SettlementAmount { get; set; }
    }
}
