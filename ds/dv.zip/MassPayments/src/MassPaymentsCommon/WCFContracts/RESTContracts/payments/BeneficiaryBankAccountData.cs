﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using MassPaymentsCommon.WCFContracts.Attributes;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class BeneficiaryBankAccountData
    {
        [DataMember(Name = "id")]
        [Required(ErrorMessage = "bankAccount.id")]
        public string Id { get; set; }

        [DataMember(Name = "versionedOn")]
        [Required(ErrorMessage = "bankAccount.versionedOn")]
        public string VersionedOn { get; set; }

        [DataMember(Name = "accountNumber")]
        [Required(ErrorMessage = "bankAccount.accountNumber")]
        public string AccountNumber { get; set; }

        [DataMember(Name = "accountType")]
        public string AccountType { get; set; }

        [DataMember(Name = "bankName")]
        [Required(ErrorMessage = "bankAccount.bankName")]
        public string BankName { get; set; }

        [DataMember(Name = "bankBranchName")]
        public string BranchName { get; set; }

        [DataMember(Name = "bankCode")]
        [Required(ErrorMessage = "bankAccount.bankCode, bankBranchCode")]
        public string BankCode { get; set; }

        [DataMember(Name = "bankBranchCode")]
        [Required(ErrorMessage = "bankAccount.bankCode, bankBranchCode")]
        public string BankBranchCode { get; set; }

        [DataMember(Name = "address")]
        [Required(ErrorMessage = "bankAccount.address")]
        [IgnoreRequiredProperty(Except = "countryCode")]
        public AddressData BankAddress { get; set; }

        [DataMember(Name = "intermediaryBank")]
        public IntermediaryBankData IntermediaryBank { get; set; }
    }
}

