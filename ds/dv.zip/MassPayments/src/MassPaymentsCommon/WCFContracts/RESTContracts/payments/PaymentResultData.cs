﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class PaymentResultData
    {
        [DataMember(Name = "id")]
        public string Id { get; set; }

        [DataMember(Name = "status")]
        public string Status { get; set; }

        [DataMember(Name = "partnerReference")]
        public string PartnerReference { get; set; }

        [DataMember(Name = "amountReturned", EmitDefaultValue = false)]
        public decimal AmountReturned { get; set; }

        [DataMember(Name = "amountReturnedCurrency")]
        public string AmountReturnedCurrency { get; set; }

        [DataMember(Name = "paymentReference")]
        public string PaymentReference { get; set; }

        [DataMember(Name = "createdOn")]
        public string CreatedOnUtc { get; set; }

        [DataMember(Name = "lastUpdatedOn")]
        public string LastUpdatedOnUtc { get; set; }

        [DataMember(Name = "errorCode")]
        public string ErrorCode { get; set; }
    }
}
