﻿using System.Runtime.Serialization;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class IntermediaryBankData
    {
        [DataMember(Name = "bankName")]
        public string BankName { get; set; }

        [DataMember(Name = "bankCode")]
        public string BankCode { get; set; }

        [DataMember(Name = "accountNumber")]
        public string AccountNumber { get; set; }

        [DataMember(Name = "bankBranchCode")]
        public string BankBranchCode { get; set; }

        [DataMember(Name = "address")]
        public AddressData Address { get; set; }
    }
}
