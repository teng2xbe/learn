using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class SingleBatchPaymentResultData : SinglePaymentResultData
    {
        [DataMember(Name = "settlementAmount", Order = 12, EmitDefaultValue = false)]
        public long SettlementAmount { get; set; }

        [DataMember(Name = "settlementCurrencyCode", Order = 13) ]
        public string SettlementCurrencyCode { get; set; }

        [DataMember(Name = "isFixedAmountInSettlementCurrency", Order = 14)]
        public bool IsFixedAmountInSettlementCurrency { get; set; }
    }
}