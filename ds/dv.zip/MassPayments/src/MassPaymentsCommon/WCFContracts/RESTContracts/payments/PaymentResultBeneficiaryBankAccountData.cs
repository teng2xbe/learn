﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class PaymentResultBeneficiaryBankAccountData
    {
        [DataMember(Name = "id")]
        public string Id { get; set; }

        [DataMember(Name = "versionedOn")]
        public string VersionedOn { get; set; }

        [DataMember(Name = "accountNumber")]
        public string AccountNumber { get; set; }

        [DataMember(Name = "accountType")]
        public string AccountType { get; set; }

        [DataMember(Name = "bankName")]
        public string BankName { get; set; }

        [DataMember(Name = "bankBranchName")]
        public string BranchName { get; set; }

        [DataMember(Name = "bankCode")]
        public string BankCode { get; set; }

        [DataMember(Name = "bankBranchCode")]
        public string BankBranchCode { get; set; }

        [DataMember(Name = "address")]
        public AddressData BankAddress { get; set; }

        [DataMember(Name = "intermediaryBank")]
        public IntermediaryBankData IntermediaryBank { get; set; }
    }
}
