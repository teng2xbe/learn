﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class BatchedPaymentData
    {
        [DataMember(Name = "partnerReference")]
        public string PartnerReference { get; set; }

        [DataMember(Name = "paymentMethod")]
        [Required(ErrorMessage = "paymentMethod")]
        public string PaymentMethod { get; set; }

        [DataMember(Name = "id")]
        [Required(ErrorMessage = "id")]
        public string PaymentId { get; set; }

        [DataMember(Name = "paymentReference")]
        public string PaymentReference { get; set; }

        [DataMember(Name = "amount")]
        [Required]
        public long TradeAmount { get; set; }

        [DataMember(Name = "currencyCode")]
        [Required]
        public string TradeCurrencyCode { get; set; }

        [DataMember(Name = "settlementCurrencyCode")]
        public string SettlementCurrencyCode { get; set; }

        [DataMember(Name = "isFixedAmountInSettlementCurrency")]
        public string IsFixedAmountInSettlementCurrency { get; set; }

        [DataMember(Name = "beneficiary")]
        [Required(ErrorMessage = "beneficiary")]
        public BeneficiaryData Beneficiary { get; set; }

        [DataMember(Name = "bankAccount")]
        [Required(ErrorMessage = "bankAccount")]
        public BeneficiaryBankAccountData BankAccount { get; set; }

        [DataMember(Name = "purposeOfPayment")]
        public string PurposeOfPayment { get; set; }

        [DataMember(Name = "instructionForBank")]
        public string InstructionForBank { get; set; }

        [DataMember(Name = "instructionCodeForBank")]
        public string InstructionCodeForBank { get; set; }

        [DataMember(Name = "remittanceType")]
        public string RemittanceType { get; set; }

        [DataMember(Name = "remittanceData")]
        public List<RemittanceReferenceData> RemittanceData { get; set; }

        [DataMember(Name = "thirdPartyRemitter")]
        public ThirdPartyRemitterData ThirdPartyRemitterData { get; set; }
    }
}
