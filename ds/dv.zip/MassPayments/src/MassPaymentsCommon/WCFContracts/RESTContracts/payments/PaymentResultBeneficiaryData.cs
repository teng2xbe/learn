﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class PaymentResultBeneficiaryData
    {
        [DataMember(Name = "id")]
        public string Id { get; set; }

        [DataMember(Name = "versionedOn")]
        public string VersionedOn { get; set; }

        [DataMember(Name = "email")]
        public string EmailAddress { get; set; }

        [DataMember(Name = "type")]
        public string Type { get; set; }

        [DataMember(Name = "firstName")]
        public string FirstName { get; set; }

        [DataMember(Name = "middleName")]
        public string MiddleName { get; set; }

        [DataMember(Name = "lastName")]
        public string LastName { get; set; }

        [DataMember(Name = "phoneNumber")]
        public string PhoneNumber { get; set; }

        [DataMember(Name = "cellNumber")]
        public string CellNumber { get; set; }

        [DataMember(Name = "dateOfBirth")]
        public string DateOfBirth { get; set; }

        [DataMember(Name = "gender")]
        public string Gender { get; set; }

        [DataMember(Name = "businessName")]
        public string BusinessName { get; set; }

        [DataMember(Name = "businessRegistrationNumber")]
        public string BusinessRegistrationNumber { get; set; }

        [DataMember(Name = "businessRegistrationCountry")]
        public string BusinessRegistrationCountry { get; set; }

        [DataMember(Name = "businessRegistrationStateProv")]
        public string BusinessRegistrationStateProv { get; set; }

        [DataMember(Name = "industry")]
        public string Industry { get; set; }

        [DataMember(Name = "address")]
        public AddressData Address { get; set; }
    }
}
