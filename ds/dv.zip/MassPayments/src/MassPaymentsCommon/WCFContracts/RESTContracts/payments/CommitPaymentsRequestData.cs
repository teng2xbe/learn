﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class CommitPaymentsRequestData
    {
        [DataMember(Name = "paymentToProcess")]
        public List<UnbatchedPaymentData> PaymentsToProcess { get; set; }
    }
}
