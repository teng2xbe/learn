﻿using System.Runtime.Serialization;
using System.Collections.Generic;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class GetPaymentsRequestData
    {
        [DataMember(Name = "id")]
        public List<string> PaymentIds { get; set; }

        [DataMember(Name = "status")]
        public string StatusFilter { get; set; }

        [DataMember(Name = "sortBy")]
        public string SortBy { get; set; }
    }
}
