﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class CommitBatchPaymentsRequestData
    {
        [DataMember(Name = "payments")]
        public List<BatchedPaymentData> Payments { get; set; }
    }
}
