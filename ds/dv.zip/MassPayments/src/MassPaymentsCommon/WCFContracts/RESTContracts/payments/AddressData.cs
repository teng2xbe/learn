﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class AddressData
    {
        [DataMember(Name = "line1")]
        [Required(ErrorMessage = "address.line1")]
        public string AddressLine1 { get; set; }

        [DataMember(Name = "line2")]
        public string AddressLine2 { get; set; }

        [DataMember(Name = "line3")]
        public string AddressLine3 { get; set; }

        [DataMember(Name = "city")]
        [Required(ErrorMessage = "address.city")]
        public string City { get; set; }

        [DataMember(Name = "stateOrProv")]
        [Required(ErrorMessage = "address.stateOrProv")]
        public string StateOrPovince { get; set; }

        [DataMember(Name = "zipOrPostal")]
        [Required(ErrorMessage = "address.zipOrPostal")]
        public string ZipOrPostalCode { get; set; }

        [DataMember(Name = "countryCode")]
        [Required(ErrorMessage = "address.countryCode")]
        public string CountryCode { get; set; }
    }
}
