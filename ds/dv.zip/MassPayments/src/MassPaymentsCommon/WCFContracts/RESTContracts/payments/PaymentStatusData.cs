﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public enum PaymentStatusData
    {
        [EnumMember]
        NotAccepted,
        [EnumMember]
        Created,
        [EnumMember]
        Processing,
        [EnumMember]
        Funded,
        [EnumMember]
        Released,
        [EnumMember]
        Cancelled,
        [EnumMember]
        Rejected,
        [EnumMember]
        Returned,
        [EnumMember]
        NotFound,
        [EnumMember]
        Undefined
    }
}
