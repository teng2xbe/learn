﻿using System.Runtime.Serialization;
using System.Collections.Generic;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class GetPaymentsResultData
    {
        [DataMember(Name = "payments")]
        public List<PaymentResultData> PaymentItems { get; set; }
    }
}
