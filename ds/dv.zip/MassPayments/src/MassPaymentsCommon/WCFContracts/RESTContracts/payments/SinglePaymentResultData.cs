﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.payments
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    [KnownType(typeof(SingleBatchPaymentResultData))]
    public class SinglePaymentResultData
    {
        [DataMember(Name = "id", Order = 0)]
        public string PaymentId { get; set; }

        [DataMember(Name = "customerId", Order = 1)]
        public string PartnerAssignedCustomerId { get; set; }

        [DataMember(Name = "status", Order = 2)]
        public string Status { get; set; }

        [DataMember(Name = "errorCode", Order = 3)]
        public string ErrorCode { get; set; }

        [DataMember(Name = "partnerReference", Order = 4)]
        public string PartnerReference { get; set; }

        [DataMember(Name = "createdOn", Order = 5)]
        public string CreatedOnUTC { get; set; }

        [DataMember(Name = "lastUpdatedOn", Order = 6)]
        public string LastUpdatedOn { get; set; }

        [DataMember(Name = "paymentMethod", Order = 7)]
        public string PaymentMethod { get; set; }

        [DataMember(Name = "paymentReference", Order = 8)]
        public string PaymentReference { get; set; }
        
        [DataMember(Name = "paymentVersion", Order = 9)]
        public string PaymentVersionId { get; set; }

        [DataMember(Name = "amount", Order = 10, EmitDefaultValue = false)]
        public long TradeAmount { get; set; }

        [DataMember(Name = "currencyCode", Order = 11)]
        public string TradeCurrencyCode { get; set; }

        [DataMember(Name = "amountReturned", Order = 15, EmitDefaultValue = false)]
        public long ReturnAmount { get; set; }

        [DataMember(Name = "amountReturnedCurrency", Order = 16)]
        public string ReturnCurrencyCode { get; set; }

        [DataMember(Name = "beneficiary", Order = 200)]
        public PaymentResultBeneficiaryData Beneficiary { get; set; }

        [DataMember(Name = "bankAccount", Order = 300)]
        public PaymentResultBeneficiaryBankAccountData BankAccount { get; set; }

        [DataMember(Name = "purposeOfPayment", Order = 400)]
        public string PurposeOfPayment { get; set; }
        
        [DataMember(Name = "instructionForBank", Order = 401)]
        public string InstructionForBank { get; set; }

        [DataMember(Name = "instructionCodeForBank", Order = 402)]
        public string InstructionCodeForBank { get; set; }

        [DataMember(Name = "remittanceType", Order = 500)]
        public string RemittanceType { get; set; }

        [DataMember(Name = "remittanceData", Order = 501)]
        public List<RemittanceReferenceData> RemittanceData { get; set; }

        [DataMember(Name = "thirdPartyRemitter", Order = 503)]
        public ThirdPartyRemitterData ThirdPartyRemitterData { get; set; }

        [DataMember(Name = "updateErrorCode", Order = 600)]
        public string UpdateErrorCode { get; set; }

        [DataMember(Name = "updateErrorOn", Order = 601)]
        public string UpdateErrorOn { get; set; }        
    }
}
