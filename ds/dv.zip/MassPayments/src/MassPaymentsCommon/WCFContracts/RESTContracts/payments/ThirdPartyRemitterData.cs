﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class ThirdPartyRemitterData
    {
        [DataMember(Name = "id")]
        [Required]
        public string Id { get; set; }

        [DataMember(Name = "versionedOn")]
        [Required]
        public string VersionedOn { get; set; }

        [DataMember(Name = "type")]
        public string Type { get; set; }

        [DataMember(Name = "businessName")]
        [Required]
        public string BusinessName { get; set; }

        [DataMember(Name = "address")]
        public AddressData Address { get; set; }

        [DataMember(Name = "email")]
        public string Email { get; set; }

        [DataMember(Name = "phoneNumber")]
        public string PhoneNumber { get; set; }

        [DataMember(Name = "identificationType")]
        public string IdentificationType { get; set; }

        [DataMember(Name = "identification")]
        public string Identification { get; set; }

        [DataMember(Name = "industry")]
        public string Industry { get; set; }
    }
}
