﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class ClientBankAccountAddressData
    {
        [DataMember(Name = "line1")]
        public string AddressLine1 { get; set; }

        [DataMember(Name = "line2")]
        public string AddressLine2 { get; set; }

        [DataMember(Name = "line3")]
        public string AddressLine3 { get; set; }

        [DataMember(Name = "stateOrProv")]
        public string StateOrProvince { get; set; }

        [DataMember(Name = "city")]
        public string City { get; set; }

        [DataMember(Name = "zipOrPostal")]
        public string ZipOrPostalCode { get; set; }

        [DataMember(Name = "countryCode")]
        public string CountryCode { get; set; }
    }
}
