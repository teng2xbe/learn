﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.settings
{
    [DataContract]
    public class GetValidationRulesResultData
    {
        [DataMember]
        public List<GetValidationRuleResultData> ValidationRules { get; set; }
    }
}
