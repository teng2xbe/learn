﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.settings
{
    [DataContract]
    public class GetValidationRuleResultData
    {
        [DataMember]
        public string ValidationRuleKey { get; set; }

        [DataMember]
        public string ValidationRuleValue { get; set; }
    }
}
