﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.orders
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class CommitBatchRequestData
    {
        [DataMember(Name = "settlements")]
        public List<CommitBatchSettlementRequestData> Settlements { get; set; }
    }
}
