﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.orders
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class CommitBatchResultData
    {
        [DataMember(Name = "orders")]
        public List<CommitBatchOrderResultData> BookedOrders { get; set; }
    }
}
