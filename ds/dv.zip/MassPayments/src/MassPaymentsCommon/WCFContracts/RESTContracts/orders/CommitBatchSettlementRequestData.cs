﻿using System.Runtime.Serialization;
using MassPaymentsCommon.WCFContracts.Attributes.ValidationAttribute;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.orders
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class CommitBatchSettlementRequestData
    {
        [DataMember(Name = "settlementCurrency")]
        [IfImNotNullThenOtherPropertiesShouldNotBeNull(OtherNotNullPropertyNames = "SettlementMethod")]
        public string SettlementCurrencyCode { get; set; }

        [DataMember(Name = "settlementMethod")]
        [IfImNotNullThenOtherPropertiesShouldNotBeNull(OtherNotNullPropertyNames = "SettlementCurrencyCode")]
        public string SettlementMethod { get; set; }
    }
}
