﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.orders
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public enum OrderStatusData
    {
        [EnumMember]
        Committed,
        [EnumMember]
        Received,
        [EnumMember]
        Funded,
        [EnumMember]
        Cancelled,
        [EnumMember]
        NotFound
    }
}
