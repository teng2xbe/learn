﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.orders
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class BookFundingOrderRequestData
    {
        [DataMember(Name = "settlementCurrency")]
        [Required]
        public string SettlementCurrencyCode { get; set; }

        [DataMember(Name = "settlementMethod")]
        public string SettlementMethod { get; set; }

        [DataMember(Name = "itemsToBook")]
        public List<BookFundingOrderRequestItemData> ItemsToBook { get; set; }
    }
}
