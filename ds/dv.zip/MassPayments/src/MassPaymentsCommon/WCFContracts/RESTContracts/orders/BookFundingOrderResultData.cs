﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.orders
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class BookFundingOrderResultData
    {
        [DataMember(Name = "id")]
        public string OrderId { get; set; }

        [DataMember(Name = "settlementCurrency")]
        public string SettlementCurrencyCode { get; set; }

        [DataMember(Name = "status")]
        public string OrderStatus { get; set; }

        [DataMember(Name = "customerId")]
        public string PartnerAssignedCustomerId { get; set; }

        [DataMember(Name = "createdOn")]
        public string CreatedOn { get; set; }

        [DataMember(Name = "lastUpdatedOn")]
        public string LastUpdatedOn { get; set; }

        [DataMember(Name = "partnerReference")]
        public string PartnerReference { get; set; }
    }
}
