﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.orders
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class GetSingleOrderRequestData
    {
        [DataMember(Name = "id")]
        public string OrderId { get; set; }
    }
}
