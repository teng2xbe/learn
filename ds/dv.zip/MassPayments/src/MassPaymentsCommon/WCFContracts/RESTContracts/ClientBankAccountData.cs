﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class ClientBankAccountData
    {
        [DataMember(Name = "id")]
        public string Id { get; set; }

        [DataMember(Name = "status")]
        public string Status { get; set; }

        [DataMember(Name = "lastUpdatedOn")]
        public string LastUpdatedOn { get; set; }

        [DataMember(Name = "accountNumber")]
        public string AccountNumber { get; set; }

        [DataMember(Name = "accountType")]
        public string AccountType { get; set; }

        [DataMember(Name = "bankName")]
        public string BankName { get; set; }

        [DataMember(Name = "currency")]
        public string CurrencyCode { get; set; }

        [DataMember(Name = "routingCode")]
        public string RoutingCode { get; set; }

        [DataMember(Name = "swiftCode")]
        public string SwiftCode { get; set; }

        [DataMember(Name = "address")]
        public ClientBankAccountAddressData BankAddress { get; set; }

        [DataMember(Name = "accountHolderName")]
        public string AccountHolderName { get; set; }

        [DataMember(Name = "isDirectDebit")]
        public bool IsDirectDebit { get; set; }
    }
}

