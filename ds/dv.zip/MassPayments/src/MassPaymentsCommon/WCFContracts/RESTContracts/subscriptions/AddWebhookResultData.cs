﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.subscriptions
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class AddWebhookResultData
    {
        [DataMember]
        public string Id { get; set; }
    }
}
