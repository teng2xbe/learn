﻿using System;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.subscriptions
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class GetWebhookResultData
    {
        [DataMember(Name="id")]
        public string Id { get; set; }

        [DataMember(Name = "uri")]
        public string Uri { get; set; }

        [DataMember(Name = "isPrimary")]
        public bool IsPrimary { get; set; }

        [DataMember(Name = "createdOnUtc")]
        public DateTime CreatedOnUtc { get; set; }

        [DataMember(Name = "lastUpdatedOnUtc")]
        public DateTime UpdatedOnUtc { get; set; }

        [DataMember(Name = "lastEvent")]
        public PushedEventResultData LastPushedEvent { get; set; }

    }
}
