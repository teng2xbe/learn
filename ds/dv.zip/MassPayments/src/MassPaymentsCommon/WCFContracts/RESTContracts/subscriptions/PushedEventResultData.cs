﻿using System;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.subscriptions
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class PushedEventResultData
    {
        [DataMember(Name = "pushedOnUtc")]
        public DateTime PushedOnUtc { get; set; }

        [DataMember(Name = "eventType")]
        public string EventType { get; set; }
        
        [DataMember(Name = "status")]
        public string Status { get; set; }
    }
}
