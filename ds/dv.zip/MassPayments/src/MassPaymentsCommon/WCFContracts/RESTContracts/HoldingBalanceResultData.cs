﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class HoldingBalanceResultData
    {
        [DataMember(Name = "currency")]
        public string Currency { get; set; }

        [DataMember(Name = "available")]
        public long Available { get; set; }

        [DataMember(Name = "booked")]
        public long Booked { get; set; }
    }
}
