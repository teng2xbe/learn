﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class GetBatchResultData
    {
        [DataMember(Name = "id")]
        public string BatchId { get; set; }

        [DataMember(Name = "reference")]
        public string BatchReference { get; set; }

        [DataMember(Name = "createdOn")]
        public string CreatedOn { get; set; }

        [DataMember(Name = "lastUpdatedOn")]
        public string LastUpdatedOn { get; set; }

        [DataMember(Name = "numberOfReceivedPayments")]
        public int NumberofReceivedPayments { get; set; }

        [DataMember(Name = "numberOfAcceptedPayments")]
        public int NumberofAcceptedPayments { get; set; }

        [DataMember(Name = "aggregateAmounts")]
        public List<BatchAggregateAmountsResultData> AggregateAmounts { get; set; }
    }
}
