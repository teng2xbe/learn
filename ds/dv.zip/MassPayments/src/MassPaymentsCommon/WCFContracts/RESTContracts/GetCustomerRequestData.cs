﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class GetCustomerRequestData
    {
        [DataMember(Name = "id")]
        public string PartnerAssignedCustomerId { get; set; }
    }
}
