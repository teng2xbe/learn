﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.settings
{
    [DataContract]
    public class GetServiceSettingResultData
    {
        [DataMember]
        public string SettingKey { get; set; }

        [DataMember]
        public string SettingValue { get; set; }
    }
}
