﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.settings
{
    [DataContract]
    public class GetServiceSettingsResultData
    {
        [DataMember]
        public List<GetServiceSettingResultData> Settings { get; set; }
    }
}
