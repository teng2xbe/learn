﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.quotes
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class FundingQuoteResultItemData
    {
        [DataMember(Name = "tradeAmount")]
        public long TradeAmount { get; set; }

        [DataMember(Name = "settlementAmount")]
        public long SettlementAmount { get; set; }

        [DataMember(Name = "tradeCurrency")]
        public string TradeCurrencyCode { get; set; }

        [DataMember(Name = "settlementCurrency")]
        public string SettlementCurrencyCode { get; set; }

        [DataMember(Name = "isDirectRate")]
        public bool IsDirect;

        [DataMember(Name = "rate")]
        public decimal RateValue;

        [DataMember(Name = "rateInverted")]
        public decimal RateValueInverted;

        [DataMember(Name = "decimalsDirect")]
        public int NumberOfDecimalsDirect;

        [DataMember(Name = "decimalsIndirect")]
        public int NumberOfDecimalsIndirect;
    }
}