﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.quotes
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class FundingQuoteRequestData
    {
        [DataMember(Name = "customerId")]
        [Required]
        public string PartnerAssignedCustomerId { get; set; }

        [DataMember(Name = "partnerReference")]
        public string PartnerReference { get; set; }

        [DataMember(Name = "itemsToQuote")]
        public List<FundingQuoteRequestItemData> QuoteRequestItems { get; set; }
    }
}
