﻿using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.quotes
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class GetFundingQuoteRequestData
    {
        [DataMember(Name = "id")]
        public string QuoteId { get; set; }
    }
}
