﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.quotes
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class FundingQuoteResultData
    {
        [DataMember(Name = "id")]
        public string QuoteId { get; set; }

        [DataMember(Name = "customerId")]
        public string PartnerAssignedCustomerId { get; set; }

        [DataMember(Name = "partnerReference")]
        public string PartnerReference { get; set; }

        [DataMember(Name = "expirationIntervalInSec")]
        public int ExpirationIntervalInSeconds { get; set; }    
    
        [DataMember(Name = "createdOn")]
        public string CreatedOn { get; set; }

        [DataMember(Name = "status")]
        public string QuoteStatus { get; set; }
        
        [DataMember(Name = "lastUpdatedOn")]
        public string LastUpdatedOn { get; set; }

        [DataMember(Name = "quotedItems")]
        public List<FundingQuoteResultItemData> QuotedItems { get; set; }

    }
}