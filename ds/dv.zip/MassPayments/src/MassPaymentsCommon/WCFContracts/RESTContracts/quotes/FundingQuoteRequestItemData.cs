﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.quotes
{
    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class FundingQuoteRequestItemData
    {
        [DataMember(Name = "amount")]
        [Required]
        public long Amount { get; set; }

        [DataMember(Name = "isAmountSettlement")]
        public bool IsAmountInSettlementCurrency { get; set; }             

        [DataMember(Name = "tradeCurrency")]
        [Required]
        public string TradeCurrencyCode { get; set; }

        [DataMember(Name = "settlementCurrency")]
        [Required]
        public string SettlementCurrencyCode { get; set; }        
    }
}