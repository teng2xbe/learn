﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MassPaymentsCommon.WCFContracts.RESTContracts.quotes
{

    [DataContract(Namespace = "http://schemas.business.westernunion.com/2015/01/MassPayments/MassPayments")]
    public class FundingQuoteResultCollectionData
    {
        [DataMember(Name = "quotes")]
        public List<FundingQuoteResultData> QuoteDatas { get; set; }
    }
}
