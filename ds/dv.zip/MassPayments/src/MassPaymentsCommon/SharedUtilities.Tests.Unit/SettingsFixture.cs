﻿using System;
using System.Configuration;
using System.IO;
using NUnit.Framework;

namespace SharedUtilities.Tests.Unit
{
    [TestFixture]
    public class SettingsFixture
    {
        [Test]
        public void GetStringValue_ReturnsAString()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["TestSetting"].Value = "gorilla";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.AreEqual("gorilla", Settings.GetStringValue("TestSetting"));
        }

        [Test]
        public void GetStringValue_ReturnsDefaultValue()
        {
            Assert.AreEqual("gorilla", Settings.GetStringValue("DoesNotExist", "gorilla"));
        }

        [Test]
        public void GetStringValue_ThrowsForNonExistantKey()
        {
            Assert.Throws<SettingsPropertyNotFoundException>(() => Settings.GetStringValue("DoesNotExist"));
        }

        [Test]
        public void GetIntValue_ReturnsAnInt()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["TestSetting"].Value = "111";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.AreEqual(111, Settings.GetIntValue("TestSetting"));
        }

        [Test]
        public void GetIntValue_ThrowsForIncorrectValue()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["TestSetting"].Value = "notanint";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.Throws<InvalidOperationException>(() => Settings.GetIntValue("TestSetting"));
        }

        [Test]
        public void GetIntValue_ReturnsDefaultValueForIncorrectValue()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["TestSetting"].Value = "notanint";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.AreEqual(111, Settings.GetIntValue("TestSetting", 111));
        }

        [Test]
        public void GetIntValue_ReturnsDefaultValue()
        {
            Assert.AreEqual(111, Settings.GetIntValue("DoesNotExist", 111));
        }

        [Test]
        public void GetIntValue_ThrowsForNonExistantKey()
        {
            Assert.Throws<SettingsPropertyNotFoundException>(() => Settings.GetIntValue("DoesNotExist"));
        }

        [Test]
        public void GetBooleanValue_ReturnsABool()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["TestSetting"].Value = "false";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.IsFalse(Settings.GetBooleanValue("TestSetting"));
        }

        [Test]
        public void GetBooleanValue_ThrowsForIncorrectValue()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["TestSetting"].Value = "notabool";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.Throws<InvalidOperationException>(() => Settings.GetBooleanValue("TestSetting"));
        }

        [Test]
        public void GetBooleanValue_ReturnsDefaultValueForIncorrectValue()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["TestSetting"].Value = "notabool";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.IsFalse(Settings.GetBooleanValue("TestSetting", false));
        }

        [Test]
        public void GetBooleanValue_ReturnsDefaultValue()
        {
            Assert.IsFalse(Settings.GetBooleanValue("DoesNotExist", false));
        }

        [Test]
        public void GetBooleanValue_ThrowsForNonExistantKey()
        {
            Assert.Throws<SettingsPropertyNotFoundException>(() => Settings.GetBooleanValue("DoesNotExist"));
        }
    }
}
