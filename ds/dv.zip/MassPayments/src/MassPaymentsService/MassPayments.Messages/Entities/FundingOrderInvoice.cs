﻿namespace Common.Contracts.MassPayments.Messages.Entities
{
    public class FundingOrderInvoice
    {
        public string OrderIds { get; set; }
        public string InvoiceFileName { get; set; }
    }
}
