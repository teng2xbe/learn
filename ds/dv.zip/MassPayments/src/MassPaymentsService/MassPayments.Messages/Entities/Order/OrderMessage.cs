﻿namespace Common.Contracts.MassPayments.Messages.Entities.Order
{
    public class OrderMessage
    {
        public string Id { get; set; }
        public string PartnerAssignedCustomerId { get; set; }
        public string OrderStatus { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public string CreatedOnUtc { get; set; }
        public string LastUpdatedOnUtc { get; set; }
        public string ErrorCode { get; set; }
        public string PartnerReference { get; set; }
    }
}
