﻿using System;
using System.Collections.Generic;

namespace Common.Contracts.MassPayments.Messages.Entities
{
    public class PaymentDetail
    {
        public int PaymentId { get; set; }
        public string ScBearer { get; set; }
        public decimal Amount { get; set; }
        public int ClientId { get; set; }
        public DateTime? RequestedReleaseDate { get; set; }
        public string OutGoingConfirmation { get; set; }
        public string PartnerBankRefPrefix { get; set; }
        public string PaymentSource { get; set; }

        public string EndToEndId
        {
            get { return string.Format("{0}_{1}_{2}", PartnerBankRefPrefix, OutGoingConfirmation, PaymentId); }
        }

        public string IntermediaryBankCode { get; set; }
        public string IntermediaryBankAccountNumber { get; set; }
        public string IntermediaryBankName { get; set; }
        public string IntermediaryBankCity { get; set; }
        public string IntermediaryBankStateProvince { get; set; }
        public string IntermediaryBankZipOrPostalCode { get; set; }
        public string IntermediaryBankCountryCode { get; set; }
        public string IntermediaryBankAddressLine { get; set; }
        public string IntermediaryBankBranchCode { get; set; }

        public string BeneBankCode { get; set; }
        public string BeneBankName { get; set; }
        public string BeneBankCity { get; set; }
        public string BeneBankStateProvince { get; set; }
        public string BeneBankZipOrPostalCode { get; set; }
        public string BeneBankCountryCode { get; set; }
        public string BeneBankAddressLine { get; set; }
        public string BeneBankBranchCode { get; set; }

        public string BeneName { get; set; }
        public string BeneCity { get; set; }
        public string BeneCountryCode { get; set; }
        public string BeneStateProvince { get; set; }
        public string BeneZipOrPostalCode { get; set; }
        public string BeneAddressLine { get; set; }
        public string BenePhoneNumber { get; set; }
        public string BeneEmailAddress { get; set; }
        public string BeneAccountNumber { get; set; }
        public string BeneAccountName { get; set; }
        public string BeneAccountType { get; set; }
        public string InstructionCodeForBank { get; set; }
        public string InstructionInformation { get; set; }
        public string PurposeOfPayment { get; set; }
        public decimal ChargeAmount { get { return 0; } }
        public string ServiceLevelProprietory { get { return "CRED"; } }
        public string RemittanceInformation1 { get; set; }
        public string RemittanceInformation2 { get; set; }
        public List<string> RemittanceData { get; set; }
        public string RemittanceType { get; set; }
        public string BeneEntityType { get; set; }
        public string ThirdPartyRemitterId { get; set; }
        public string ThirdPartyRemitterBusinessName { get; set; }
        public string ThirdPartyRemitterAddressLine1 { get; set; }
        public string ThirdPartyRemitterAddressLine2 { get; set; }
        public string ThirdPartyRemitterAddressLine3 { get; set; }
        public string ThirdPartyRemitterCity { get; set; }
        public string ThirdPartyRemitterStateOrProv { get; set; }
        public string ThirdPartyRemitterZipOrPostal { get; set; }
        public string ThirdPartyRemitterCountryCode { get; set; }
    }
}
