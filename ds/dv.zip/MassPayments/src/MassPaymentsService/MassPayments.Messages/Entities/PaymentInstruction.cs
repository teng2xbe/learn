﻿using System.Collections.Generic;

namespace Common.Contracts.MassPayments.Messages.Entities
{
    public class PaymentInstruction
    {
        public string CurrencyCode { get; set; }
        public int CurrencyDecimalPlaces { get; set; }
        public string PaymentMethod { get; set; }
        public List<PaymentDetail> Payments { get; set; }
    }
}
