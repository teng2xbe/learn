using System;

namespace Common.Contracts.MassPayments.Messages.Entities.Payment
{
    public class Customer
    {
        public int Id { get; set; }
        public int Status { get; set; }
        public string Name { get; set; }
        public int TransactionSystemCustomerId { get; set; }
        public string NotificationEmails { get; set; }
        public int TransactionSystemId { get; set; }
        public int PartnerId { get; set; }
        public DateTime? TTLExpiration { get; set; }
        public string PartnerAssignedCustomerId { get; set; }
        public string TransactionSystemCustomerExternalId { get; set; }
        public string CountryCode { get; set; }
        public string SettlementCurrencyCode { get; set; }
    }
}
