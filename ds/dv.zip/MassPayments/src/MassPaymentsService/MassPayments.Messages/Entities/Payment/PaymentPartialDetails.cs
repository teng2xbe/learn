﻿namespace Common.Contracts.MassPayments.Messages.Entities.Payment
{
    public class PaymentPartialDetails
    {
        public string Id { get; set; }
        public string CustomerId { get; set; }
        public string Status { get; set; }
        public string PartnerReference { get; set; }
        public string PaymentReference { get; set; }
        public string CreatedOnUtc { get; set; }
        public string LastUpdatedOnUtc { get; set; }
        public string ErrorCode { get; set; }
        public string NotAcceptedReason { get; set; }   //Reason why a payment request failed
        public string UpdateErrorOnUtc { get; set; }
    }
}
