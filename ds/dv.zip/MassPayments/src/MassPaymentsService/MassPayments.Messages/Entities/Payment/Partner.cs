namespace Common.Contracts.MassPayments.Messages.Entities.Payment
{
    public class Partner
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string FilePrefix { get; set; }
        public string BankRefPrefix { get; set; }
        public bool Active { get; set; }
        public string CommonName { get; set; }
        public string Code { get; set; }
        public bool? ThirdPartyRemitterEnabled { get; set; }
        public int? PaymentModelId { get; set; }
        public string SecurityToken { get; set; }
        public int? InvoiceTypeId { get; set; }
    }
}
