﻿using System.ComponentModel;

namespace Common.Contracts.MassPayments.Messages.Enums
{
    public enum Application
    {
        [Description("MassPay")]
        MassPayments = 1
    }
}
