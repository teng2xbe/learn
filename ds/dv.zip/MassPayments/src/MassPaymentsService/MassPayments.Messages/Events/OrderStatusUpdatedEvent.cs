﻿using Common.Contracts.MassPayments.Messages.Entities.Order;

namespace Common.Contracts.MassPayments.Messages.Events
{
    public class OrderStatusUpdatedEvent : MassPaymentsEvent
    {
        public string orderNumber { get; set; }
        public OrderMessage Order { get; set; }
    }
}
