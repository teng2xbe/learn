﻿using Common.Contracts.MassPayments.Messages.Entities.Payment;

namespace Common.Contracts.MassPayments.Messages.Events
{
    public class PaymentStatusUpdatedEvent : MassPaymentsEvent
    {
        public PaymentPartialDetails PaymentPartialDetails { get; set; }
    }
}
