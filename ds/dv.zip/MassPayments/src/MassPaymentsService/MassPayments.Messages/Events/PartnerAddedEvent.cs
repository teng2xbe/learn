﻿namespace Common.Contracts.MassPayments.Messages.Events
{
    public class PartnerAddedEvent : MassPaymentsEvent
    {
    }
}
