﻿using Common.Contracts.MassPayments.Messages.Entities;

namespace Common.Contracts.MassPayments.Messages.Events
{
    public class FundingOrderInvoiceGeneratedEvent : MassPaymentsEvent
    {
        public FundingOrderInvoice Invoice { get; set;}
    }
}
