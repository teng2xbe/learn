﻿using Common.Contracts.MassPayments.Messages.Enums;

namespace Common.Contracts.MassPayments.Messages.Events
{
    public class MassPaymentsEvent
    {
        public string SubscriberCode { get; set; }
        public Application Application { get; set; }
    }
}
