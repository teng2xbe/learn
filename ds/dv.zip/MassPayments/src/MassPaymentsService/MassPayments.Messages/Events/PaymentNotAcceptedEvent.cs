﻿using System.Collections.Generic;
using Common.Contracts.MassPayments.Messages.Entities.Payment;

namespace Common.Contracts.MassPayments.Messages.Events
{
    public class PaymentNotAcceptedEvent : MassPaymentsEvent
    {
        public List<PaymentPartialDetails> NotAcceptedPayments { get; set; }

    }
}
