﻿using System;

namespace Common.Contracts.MassPayments.Messages.Commands
{
    public class DeleteWebhookCommand : MassPaymentsCommand
    {
        public Guid WebhookId { get; set; }
        public string SecurityToken { get; set; }
    }
}
