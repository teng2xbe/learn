﻿using System;

namespace Common.Contracts.MassPayments.Messages.Commands
{
    //A command for adding a subsciption entry for subscriber to receive OrderStatusChangedEvent
    public class AlterSubscriptionCommand : MassPaymentsCommand
    {
        public bool DoSubscribe { get; set; }   //Subscribe if true; Unsubscribe if false;
        public Type EventType { get; set; }
    }
}
