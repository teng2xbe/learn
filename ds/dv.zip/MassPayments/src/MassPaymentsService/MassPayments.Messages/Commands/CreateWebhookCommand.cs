﻿using System;

namespace Common.Contracts.MassPayments.Messages.Commands
{
    public class CreateWebhookCommand : MassPaymentsCommand
    {
        public Guid WebhookId { get; set; }
        public string Uri { get; set; }
        public bool IsPrimary { get; set; } 
        public DateTime RequestedOnUtc { get; set; }
        public string SecurityToken { get; set; }
    }
}
