﻿using Common.Contracts.MassPayments.Messages.Entities;

namespace Common.Contracts.MassPayments.Messages.Commands
{
    public class GeneratePainFileCommand : MassPaymentsCommand
    {
        public PaymentInstruction PaymentInstruction { get; set; }
    }
}
