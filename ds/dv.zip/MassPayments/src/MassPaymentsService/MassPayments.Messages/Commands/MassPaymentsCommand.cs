﻿using Common.Contracts.MassPayments.Messages.Enums;

namespace Common.Contracts.MassPayments.Messages.Commands
{
    public abstract class MassPaymentsCommand
    {
        public string SubscriberCode { get; set; }
        public Application Application { get; set; }
    }
}
