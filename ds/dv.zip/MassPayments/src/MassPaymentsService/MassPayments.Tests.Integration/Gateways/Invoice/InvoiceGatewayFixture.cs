﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using System.Xml.Schema;
using MassPayments.Gateways.Invoice;
using MassPayments.Gateways.Invoice.Entities;
using MassPayments.Managers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Gateways.Invoice
{
    [TestFixture]
    public class InvoiceGatewayFixture
    {
        [SetUp]
        public void SetUp()
        {   
            InvoiceGateway.Instance = MockRepository.GeneratePartialMock<InvoiceGateway>();
        }

        [TearDown]
        public void TearDown()
        {
            InvoiceGateway.Instance = null;
        }

        [Test]
        public void GetOutOfHoldingReportXml_ValidatesCorrectly()
        {
            var invoice = new AggregateInvoice();
            invoice.PrintHeader = GetPrintHeader();
            invoice.PrintHeader.OutputFileName = "blahFileName";
            invoice.OfficeDetail = GetOfficeDetail();
            invoice.ClientDetail = GetClientDetail();
            invoice.OrderHeader = GetOrderHeader();
            invoice.OrderDetails = GetOrderDetailsWithoutSettlementDetails();
            Assert.DoesNotThrow(() => ((InvoiceGateway)InvoiceGateway.Instance).GetOutOfHoldingReportXml(invoice, true));
        }

        [Test]
        public void GetOutOfHoldingReportXml_Throws_IfRequiredAttributeIsMissing()
        {
            var invoice = new AggregateInvoice();
            invoice.PrintHeader = GetPrintHeader();
            invoice.PrintHeader.OutputFileName = "blahFileName";
            invoice.OfficeDetail = GetOfficeDetail();
            invoice.ClientDetail = GetClientDetail();
            invoice.OrderHeader = new OrderHeader();
            invoice.OrderDetails = GetOrderDetailsWithoutSettlementDetails();
            Assert.Throws<XmlSchemaValidationException>(() => ((InvoiceGateway)InvoiceGateway.Instance).GetOutOfHoldingReportXml(invoice, true));
        }

        [Test]
        public void GetIncomingInvoiceXml_ValidatesCorrectly()
        {
            var invoice = new AggregateInvoice();
            invoice.PrintHeader = GetPrintHeader();
            invoice.OfficeDetail = GetOfficeDetail();
            invoice.ClientDetail = GetClientDetail();
            invoice.OrderHeader = GetOrderHeader();
            invoice.OrderDetails = GetOrderDetailsWitSettlementDetails();
            Assert.DoesNotThrow(() => ((InvoiceGateway)InvoiceGateway.Instance).GetIncomingInvoiceXml(invoice, true));
        }

        [Test]
        public void GetIncomingInvoiceXml_Throws_IfRequiredAttributeIsMissing()
        {
            var invoice = new AggregateInvoice();
            invoice.PrintHeader = GetPrintHeader();
            invoice.OfficeDetail = GetOfficeDetail();
            invoice.ClientDetail = GetClientDetail();
            invoice.OrderHeader = new OrderHeader();
            invoice.OrderDetails = GetOrderDetailsWitSettlementDetails();
            Assert.Throws<XmlSchemaValidationException>(() => ((InvoiceGateway)InvoiceGateway.Instance).GetIncomingInvoiceXml(invoice, true));
        }

        private List<OrderDetail> GetOrderDetailsWitSettlementDetails()
        {
            return new List<OrderDetail>() { new OrderDetail {ConfirmationNo = "test", ItemNo = 1,
                Items = new List<LineItem> {new LineItem { Description = "test", ItemNo = 1, Fee = 0, Rate = 0, SettlementAmount = 0, SettlementCurrency = "CAD", TradeAmount = 0, TradeCurrency = "USD"} },
                Product = "test",
                SettlementDetails = new SettlementDetails {SettlementMethod = "test",
                    OurBankDetails = new OurBankDetails
                    {
                        CreditBankDetails = new CreditBankDetails {CreditAccountId = "test", CreditAccountName = "test", CreditBankName = "test", CreditBankSwift = "test", CreditRoutingCode = "test"}
                    }
                }
            } };
        }

        private List<OrderDetail> GetOrderDetailsWithoutSettlementDetails()
        {
            return new List<OrderDetail>() { new OrderDetail {ConfirmationNo = "test", ItemNo = 1,
                Items = new List<LineItem> {new LineItem { Description = "test", ItemNo = 1, Fee = 0, Rate = 0, SettlementAmount = 0, SettlementCurrency = "CAD", TradeAmount = 0, TradeCurrency = "USD"} },
                Product = "test"
            } };
        }

        private OrderHeader GetOrderHeader()
        {
            return new OrderHeader {ConfirmationNo = "test", EntityName = "test", Language = "test", LicenseNo = "test", Number = 1, OrderCaptureSystem = "test", OrderDate = DateTime.Now, OrderInstructions = "test", OrderType = "test", ShortEntityName = "test"};
        }

        private ClientDetail GetClientDetail()
        {
            return new ClientDetail {ClientAccount = "123", ClientAddressLine1 = "123", ClientAddressLine2 = "123", ClientAddressLine3 = "", ClientCity = "test", ClientName = "test", ClientCountry = "test", ClientPostalCode = "20191", ClientProvince = "test", Contact = new ClientDetailContact {Name = "test", Type = "test"}, InvoiceType = "type3", PartnerCode = "test", ProcessCenter = "test"};
        }

        private OfficeDetail GetOfficeDetail()
        {
            return new OfficeDetail {Id = 1, MainOfficeFaxNumber = "1234", OfficeAddress = "test", OfficePhone = "123"};
        }

        private static PrintHeader GetPrintHeader()
        {
            return new PrintHeader {DateTimeGenerated = "2001-10-26T21:32:52", FileCopyConnector = "test"};
        }

        [Test]
        public void Validation_Throws_WithRandomXml()
        {
            var xmlDoc = new XDocument(new XElement("Blah"));
            Assert.Throws<XmlSchemaValidationException>(() => ((InvoiceGateway)InvoiceGateway.Instance).ValidateXml(xmlDoc, "Invoice.xsd"));
        }

        [Test]
        public void ValideXml_Throws_WithRandomXmlForOutOfHoldingReport()
        {
            var xmlDoc = new XDocument(new XElement("Blah"));
            Assert.Throws<XmlSchemaValidationException>(() => ((InvoiceGateway)InvoiceGateway.Instance).ValidateXml(xmlDoc, "OutOfHoldingReport.xsd"));
        }

    }
}
