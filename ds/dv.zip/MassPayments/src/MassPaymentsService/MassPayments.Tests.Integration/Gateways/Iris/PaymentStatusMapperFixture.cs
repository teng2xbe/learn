﻿using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.Gateways.Iris;
using MassPayments.Gateways.Iris.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Gateways.Iris
{
    [TestFixture]
    public class PaymentStatusMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void PaymentStatusInsertAndGet_Works()
        {
            var paymentStatusChange = new PaymentStatusChange
            {
                PaymentId = 1,
                Status = 0,
                UpdatedOnUtc = DateTime.UtcNow
            };

            Assert.DoesNotThrow( () => PaymentStatusMapper.Instance.InsertPaymentStatusChangesForTesting(paymentStatusChange));

            List<PaymentStatusChange> loadedChanges = null;

            Assert.DoesNotThrow( () => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.AreEqual(loadedChanges.Count, 1);
            Assert.AreEqual(loadedChanges[0].PaymentId, paymentStatusChange.PaymentId);
            Assert.AreEqual(loadedChanges[0].Status, paymentStatusChange.Status);
            Assert.AreEqual(loadedChanges[0].UpdatedOnUtc.ToLongDateString(), paymentStatusChange.UpdatedOnUtc.ToLongDateString());
        }

        [Test]
        public void PaymentStatusInsertAndMoveToArchive_Works()
        {
            var paymentStatusChange = new PaymentStatusChange
            {
                PaymentId = 1,
                Status = 0,
                UpdatedOnUtc = DateTime.UtcNow
            };

            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.InsertPaymentStatusChangesForTesting(paymentStatusChange));

            List<PaymentStatusChange> loadedChanges = null;
            List<PaymentStatusChange> loadedArchives = null;

            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.MovePaymentStatusChangeToArchive(loadedChanges[0].Id));
            Assert.DoesNotThrow(() => loadedArchives = PaymentStatusMapper.Instance.GetPaymentStatusChangesFromArchiveForTesting());
            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.AreEqual(loadedArchives.Count, 1);
            Assert.AreEqual(loadedChanges.Count, 0);
        }

        [Test]
        public void PaymentStatusInsertAndMoveToError_Works()
        {
            var paymentStatusChange = new PaymentStatusChange
            {
                PaymentId = 1,
                Status = 0,
                UpdatedOnUtc = DateTime.UtcNow
            };

            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.InsertPaymentStatusChangesForTesting(paymentStatusChange));

            List<PaymentStatusChange> loadedChanges = null;
            List<PaymentStatusChange> loadedErrors = null;

            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.MovePaymentStatusChangeToError(loadedChanges[0].Id, "blah"));
            Assert.DoesNotThrow(() => loadedErrors = PaymentStatusMapper.Instance.GetPaymentStatusChangesFromErrorForTesting());
            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.AreEqual(loadedErrors.Count, 1);
            Assert.AreEqual(loadedChanges.Count, 0);
        }

        [Test]
        public void PaymentStatusBulkInsertAndGet_Works()
        {
            var changes = new List<PaymentStatusChange>
            {
                new PaymentStatusChange
                {
                    PaymentId = 1,
                    Status = 0,
                    UpdatedOnUtc = DateTime.UtcNow
                },
                new PaymentStatusChange
                {
                    PaymentId = 2,
                    Status = 3,
                    UpdatedOnUtc = DateTime.UtcNow
                }
            };

            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.BulkInsertPaymentStatusChangesForTesting(changes));

            List<PaymentStatusChange> loadedChanges = null;

            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.AreEqual(loadedChanges.Count, 2);
            Assert.AreEqual(loadedChanges[0].PaymentId, changes[0].PaymentId);
            Assert.AreEqual(loadedChanges[0].Status, changes[0].Status);
            Assert.AreEqual(loadedChanges[0].UpdatedOnUtc.ToLongDateString(), changes[0].UpdatedOnUtc.ToLongDateString());
            Assert.AreEqual(loadedChanges[1].PaymentId, changes[1].PaymentId);
            Assert.AreEqual(loadedChanges[1].Status, changes[1].Status);
            Assert.AreEqual(loadedChanges[1].UpdatedOnUtc.ToLongDateString(), changes[1].UpdatedOnUtc.ToLongDateString());
        }

        [Test]
        public void PaymentStatusBulkInsertAndArchive_Works()
        {
            var changes = new List<PaymentStatusChange>
            {
                new PaymentStatusChange
                {
                    PaymentId = 1,
                    Status = 0,
                    UpdatedOnUtc = DateTime.UtcNow
                },
                new PaymentStatusChange
                {
                    PaymentId = 2,
                    Status = 3,
                    UpdatedOnUtc = DateTime.UtcNow
                }
            };

            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.BulkInsertPaymentStatusChangesForTesting(changes));
            List<PaymentStatusChange> loadedChanges = null;
            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.AreEqual(loadedChanges.Count, 2);
            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.MovePaymentStatusChangeToArchive(loadedChanges[0].Id));
            Assert.DoesNotThrow(() => PaymentStatusMapper.Instance.MovePaymentStatusChangeToArchive(loadedChanges[1].Id));
            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChanges());
            Assert.AreEqual(loadedChanges.Count, 0);
            Assert.DoesNotThrow(() => loadedChanges = PaymentStatusMapper.Instance.GetPaymentStatusChangesFromArchiveForTesting());
            Assert.AreEqual(loadedChanges.Count, 2);
            
            Assert.AreEqual(loadedChanges[0].PaymentId, changes[0].PaymentId);
            Assert.AreEqual(loadedChanges[0].Status, changes[0].Status);
            Assert.AreEqual(loadedChanges[0].UpdatedOnUtc.ToLongDateString(), changes[0].UpdatedOnUtc.ToLongDateString());
            Assert.AreEqual(loadedChanges[1].PaymentId, changes[1].PaymentId);
            Assert.AreEqual(loadedChanges[1].Status, changes[1].Status);
            Assert.AreEqual(loadedChanges[1].UpdatedOnUtc.ToLongDateString(), changes[1].UpdatedOnUtc.ToLongDateString());
        }
    }
}
