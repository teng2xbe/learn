﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers;
using MassPayments.Query.Mappers;
using MassPayments.Query.POCOs;
using MassPayments.Query.ValueObjects;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Query.Managers;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Query.Mappers
{
    [TestFixture]
    public class OrderQueryMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            CurrencyCache.Instance.Reinitialize();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "Concur" });

        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
        }

        [Test]
        public void GetOrders_AllOrdersAreReturned()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orders = OrderQueryMapper.Instance.GetOrders(partner, null, 10, new SortBy());
            
            Assert.IsNotNull(orders);
            Assert.AreEqual(3, orders.Count);
        }

        [Test]
        public void GetOrders_CanFilterBySingleOrderStatuses()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.OrderStatus = OrderStatus.Received;
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.OrderStatus = OrderStatus.Cancelled;
            var order3 = OrderHelper.Instance.CreateOrder(customer);
            order3.OrderStatus = OrderStatus.Funded;

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderStatuses = new List<OrderStatusFilter>
            {
                new OrderStatusFilter { OrderStatus = OrderStatusViewModel.Received }
            };

            var orders = OrderQueryMapper.Instance.GetOrders(partner, null, 10, new SortBy(), orderStatuses);

            Assert.AreEqual(1, orders.Count);
            AssertOrdersAreEqual(order1, orders[0]);
        }

        [Test]
        public void GetOrders_CanFilterMultipleOrdersBySingleOrderStatuses()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.OrderStatus = OrderStatus.Received;
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.OrderStatus = OrderStatus.Received;
            var order3 = OrderHelper.Instance.CreateOrder(customer);
            order3.OrderStatus = OrderStatus.Funded;

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderStatuses = new List<OrderStatusFilter>
            {
                new OrderStatusFilter { OrderStatus = OrderStatusViewModel.Received }
            };

            var orders = OrderQueryMapper.Instance.GetOrders(partner, null, 10, new SortBy(), orderStatuses);

            Assert.AreEqual(2, orders.Count);
        }
        
        [Test]
        [TestCase("CreatedOn")]
        [TestCase("createdon")]
        [TestCase("CreatedOnUTC")]
        [TestCase("createdonutc")]
        [TestCase("UpdatedOn")]
        [TestCase("updatedon")]
        [TestCase("UpdatedOnUTC")]
        [TestCase("updatedonutc")]
        [TestCase("LastUpdatedOn")]
        [TestCase("lastupdatedon")]
        [TestCase("LastUpdatedOnUTC")]
        [TestCase("lastupdatedonutc")]
        public void GetOrders_GetsAllOrdersWillSortAscending(string sortField)
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.CreatedOn = new DateTime(2003, 1, 1);
            order1.LastUpdatedOn = new DateTime(2003, 1, 1);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.CreatedOn = new DateTime(2003, 2, 2);
            order2.LastUpdatedOn = new DateTime(2003, 2, 2);
            var order3 = OrderHelper.Instance.CreateOrder(customer);
            order3.CreatedOn = new DateTime(2003, 3, 3);
            order3.LastUpdatedOn = new DateTime(2003, 3, 3);

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orders = OrderQueryMapper.Instance.GetOrders(partner, null, 10, new SortBy {SortField = sortField, Direction = SortDirection.ASC });

            Assert.AreEqual(3, orders.Count);
            AssertOrdersAreEqual(order1, orders[0]);
            AssertOrdersAreEqual(order2, orders[1]);
            AssertOrdersAreEqual(order3, orders[2]);
        }
        
        [Test]
        [TestCase("Id")]
        public void GetOrders_GetsAllOrdersWillSortAscendingById(string sortField)
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.ConfirmationNumber = "1111";
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.ConfirmationNumber = "2222";

            var orderList = new List<Order> { order1, order2 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orders = OrderQueryMapper.Instance.GetOrders(partner, null, 10, new SortBy { SortField = sortField, Direction = SortDirection.ASC });

            Assert.AreEqual(2, orders.Count);
            AssertOrdersAreEqual(order1, orders[0]);
            AssertOrdersAreEqual(order2, orders[1]);
        }

        [Test]
        public void GetOrders_ReturnsRecordsWithCorrectConfirmationNumbers()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.ConfirmationNumber = "2222";
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.ConfirmationNumber = "3333";

            var orderList = new List<Order> { order1, order2 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderNumbers = new List<string> { "2222"};
            var orders = OrderQueryMapper.Instance.GetOrders(partner, orderNumbers, 10, new SortBy {});

            Assert.AreEqual(1, orders.Count);
            AssertOrdersAreEqual(order1, orders[0]);
        }

        [Test]
        public void GetOrders_ReturnsRecordsWithCorrectConfirmationNumbersAndStatusFilter()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.ConfirmationNumber = "2222";
            order1.OrderStatus = OrderStatus.Committed;
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.ConfirmationNumber = "3333";
            order2.OrderStatus = OrderStatus.Received;
            var order3 = OrderHelper.Instance.CreateOrder(customer);
            order3.ConfirmationNumber = "4444";
            order3.OrderStatus = OrderStatus.Committed;

            var orderList = new List<Order> { order1, order2 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderStatuses = new List<OrderStatusFilter>
            {
                new OrderStatusFilter { OrderStatus = OrderStatusViewModel.Committed }
            };

            var orderNumbers = new List<string> { "2222", "3333" };
            var orders = OrderQueryMapper.Instance.GetOrders(partner, orderNumbers, 10, new SortBy { }, orderStatuses);

            Assert.AreEqual(1, orders.Count);
            AssertOrdersAreEqual(order1, orders[0]);
        }

        [Test]
        public void GetOrders_CanFilterByMultipleOrderStatuses()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.OrderId = 1;
            order1.OrderStatus = OrderStatus.Received;
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.OrderId = 2;
            order2.OrderStatus = OrderStatus.Cancelled;
            var order3 = OrderHelper.Instance.CreateOrder(customer);
            order3.OrderId = 3;
            order3.OrderStatus = OrderStatus.Funded;

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderStatuses = new List<OrderStatusFilter>
            {
                new OrderStatusFilter { OrderStatus = OrderStatusViewModel.Received },
                new OrderStatusFilter { OrderStatus = OrderStatusViewModel.Funded }
            };

            var orders = OrderQueryMapper.Instance.GetOrders(partner, null, 10, new SortBy(), orderStatuses);

            Assert.AreEqual(2, orders.Count);
            AssertOrdersAreEqual(order1, orders[0]);
            AssertOrdersAreEqual(order3, orders[1]);
        }
        
        private void AssertOrdersAreEqual(Order order, OrderViewModel orderViewModel)
        {
            Assert.AreEqual(order.OrderId, orderViewModel.OrderId);
        }
    }
}
