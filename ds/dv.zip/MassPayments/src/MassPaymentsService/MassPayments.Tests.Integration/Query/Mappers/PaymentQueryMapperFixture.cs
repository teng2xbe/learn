﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers;
using MassPayments.Query.Mappers;
using MassPayments.Query.POCOs;
using MassPayments.Query.ValueObjects;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.Exceptions;
using PaymentMapperCommand = MassPayments.Mappers.PaymentMapper;

namespace MassPayments.Tests.Integration.Query.Mappers
{
    [TestFixture]
    public class PaymentQueryMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void GetPayments_GetsAllPayments()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy());

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
            AssertPaymentAreEqual(payment2, payments[1]);
        }

        [Test]
        public void GetPayments_GetsAllPaymentsIncludingNotAccepted()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);

            paymentRequest.PaymentsToProcess[0].PartnerId = customer.PartnerId;
            paymentRequest.PaymentsToProcess[0].SetCustomer(customer);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("uh oh...");

            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "Good day to you sir!");
            var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            paymentRequest.PaymentsToProcess[0].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(paymentRequest.PaymentsToProcess);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy());

            Assert.AreEqual(3, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
            AssertPaymentAreEqual(payment2, payments[1]);
            Assert.AreEqual(paymentRequest.PaymentsToProcess[0].PaymentId, payments[2].ExternalId);
        }

        [Test]
        public void GetPayments_GetsNotAcceptedPaymentsByIdsFilter()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            
            paymentRequest.PaymentsToProcess[0].PartnerId = customer.PartnerId;
            paymentRequest.PaymentsToProcess[0].SetCustomer(customer);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("uh oh...");

            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "Good day to you sir!");
            var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            paymentRequest.PaymentsToProcess[0].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(paymentRequest.PaymentsToProcess);

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, new List<string> {paymentRequest.PaymentsToProcess[0].PaymentId}, 10, new SortBy());

            Assert.AreEqual(1, payments.Count);
            Assert.AreEqual(paymentRequest.PaymentsToProcess[0].PaymentId, payments[0].ExternalId);
        }

        [Test]
        [TestCase("Id")]
        [TestCase("id")]
        [TestCase("ExternalId")]
        [TestCase("externalid")]
        [TestCase("CreatedOn")]
        [TestCase("createdon")]
        [TestCase("CreatedOnUTC")]
        [TestCase("createdonutc")]
        [TestCase("UpdatedOn")]
        [TestCase("updatedon")]
        [TestCase("UpdatedOnUTC")]
        [TestCase("updatedonutc")]
        [TestCase("LastUpdatedOn")]
        [TestCase("lastupdatedon")]
        [TestCase("LastUpdatedOnUTC")]
        [TestCase("lastupdatedonutc")]
        public void GetPayments_GetsAllPaymentsWillSortAscending(string sortField)
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.CreatedOnUTC = new DateTime(2003, 3, 3);
            payment3.UpdatedOnUTC = new DateTime(2003, 3, 3);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.CreatedOnUTC = new DateTime(2001, 1, 1);
            payment1.UpdatedOnUTC = new DateTime(2001, 1, 1);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.CreatedOnUTC = new DateTime(2002, 2, 2);
            payment2.UpdatedOnUTC = new DateTime(2002, 2, 2);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy { SortField = sortField, Direction = SortDirection.ASC });

            Assert.AreEqual(3, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
            AssertPaymentAreEqual(payment2, payments[1]);
            AssertPaymentAreEqual(payment3, payments[2]);
        }

        [Test]
        [TestCase("Id")]
        [TestCase("id")]
        [TestCase("ExternalId")]
        [TestCase("externalid")]
        [TestCase("CreatedOn")]
        [TestCase("createdon")]
        [TestCase("CreatedOnUTC")]
        [TestCase("createdonutc")]
        [TestCase("UpdatedOn")]
        [TestCase("updatedon")]
        [TestCase("UpdatedOnUTC")]
        [TestCase("updatedonutc")]
        [TestCase("LastUpdatedOn")]
        [TestCase("lastupdatedon")]
        [TestCase("LastUpdatedOnUTC")]
        [TestCase("lastupdatedonutc")]
        public void GetPayments_GetsAllPaymentsWillSortDescending(string sortField)
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.CreatedOnUTC = new DateTime(2003, 3, 3);
            payment3.UpdatedOnUTC = new DateTime(2003, 3, 3);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.CreatedOnUTC = new DateTime(2001, 1, 1);
            payment1.UpdatedOnUTC = new DateTime(2001, 1, 1);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.CreatedOnUTC = new DateTime(2002, 2, 2);
            payment2.UpdatedOnUTC = new DateTime(2002, 2, 2);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy { SortField = sortField, Direction = SortDirection.DESC });

            Assert.AreEqual(3, payments.Count);
            AssertPaymentAreEqual(payment3, payments[0]);
            AssertPaymentAreEqual(payment2, payments[1]);
            AssertPaymentAreEqual(payment1, payments[2]);
        }

        [Test]
        public void GetPayments_WillThrowExceptionForInvalidSortField()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.CreatedOnUTC = new DateTime(2003, 3, 3);
            payment3.UpdatedOnUTC = new DateTime(2003, 3, 3);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.CreatedOnUTC = new DateTime(2001, 1, 1);
            payment1.UpdatedOnUTC = new DateTime(2001, 1, 1);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.CreatedOnUTC = new DateTime(2002, 2, 2);
            payment2.UpdatedOnUTC = new DateTime(2002, 2, 2);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            Assert.Throws<InvalidSortExpressionException>(() => PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy { SortField = "gorilla", Direction = SortDirection.DESC }));
        }

        [Test]
        public void GetPayments_ReturnsOnlyMaxRecords()
        {
            var maxRecords = 2;

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, maxRecords, new SortBy());

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
            AssertPaymentAreEqual(payment2, payments[1]);
        }

        [Test]
        public void GetPayments_CanFilterBySingleFundedDecoupledPaymentStatus()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment2);
            payment2.TransactionSystemOrderId = 222;
            payment2.TransactionSystemOrderNumber = "C222";
            payment2.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment2.Id, payment2.TransactionSystemOrderId, payment2.TransactionSystemOrderNumber);  //isFunded = true

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment3);
            payment3.TransactionSystemOrderId = 333;
            payment3.TransactionSystemOrderNumber = "C333";
            payment3.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment3.Id, payment3.TransactionSystemOrderId, payment3.TransactionSystemOrderNumber);  //isFunded = true

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.SanctionBlocked;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentStatuses = new List<DecoupledPaymentStatusFilter>
            {
                new DecoupledPaymentStatusFilter { IsFunded = true, PaymentStatus = PaymentStatus.SanctionCleared }
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment2, payments[0]);
            AssertPaymentAreEqual(payment3, payments[1]);
        }

        [Test]
        public void GetPayments_CanFilterBySingleFundedDecoupledPaymentStatusAndNotAcceptedPaymentExists()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment2);
            payment2.TransactionSystemOrderId = 222;
            payment2.TransactionSystemOrderNumber = "C222";
            payment2.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment2.Id, payment2.TransactionSystemOrderId, payment2.TransactionSystemOrderNumber);  //isFunded = true

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment3);
            payment3.TransactionSystemOrderId = 333;
            payment3.TransactionSystemOrderNumber = "C333";
            payment3.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment3.Id, payment3.TransactionSystemOrderId, payment3.TransactionSystemOrderNumber);  //isFunded = true

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.SanctionBlocked;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            //add not accepted payment to dataset
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);

            paymentRequest.PaymentsToProcess[0].PartnerId = customer.PartnerId;
            paymentRequest.PaymentsToProcess[0].SetCustomer(customer);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("uh oh...");

            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I am unnacceptable.");
            var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            paymentRequest.PaymentsToProcess[0].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(paymentRequest.PaymentsToProcess);

            var paymentStatuses = new List<DecoupledPaymentStatusFilter>
            {
                new DecoupledPaymentStatusFilter { IsFunded = true, PaymentStatus = PaymentStatus.SanctionCleared }
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment2, payments[0]);
            AssertPaymentAreEqual(payment3, payments[1]);
        }

        [Test]
        public void GetPayments_CanFilterBySingleCoupledPaymentStatus()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment2);
            payment2.TransactionSystemOrderId = 222;
            payment2.TransactionSystemOrderNumber = "C222";
            payment2.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment2.Id, payment2.TransactionSystemOrderId, payment2.TransactionSystemOrderNumber);  //isFunded = true

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment3);
            payment3.TransactionSystemOrderId = 333;
            payment3.TransactionSystemOrderNumber = "C333";
            payment3.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment3.Id, payment3.TransactionSystemOrderId, payment3.TransactionSystemOrderNumber);  //isFunded = true

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.SanctionBlocked;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentStatuses = new List<CoupledPaymentStatusFilter>
            {
                new CoupledPaymentStatusFilter { PaymentStatus = PaymentStatus.SanctionCleared }
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(customerBatch, null, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment2, payments[0]);
            AssertPaymentAreEqual(payment3, payments[1]);
        }

        [Test]
        public void ReturnPayments_InsertsAndMaps_Successfully()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var returnPayment = PaymentHelper.Instance.CreateReturnPayment(customer, customerBatch);
            returnPayment.PaymentStatus = PaymentStatus.Returned;
            returnPayment.ReturnAmount = new Money(Currency.CAD, 50.00m);
            returnPayment.RejectReason = "Return from Bank";

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(returnPayment));

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(new List<Payment> { returnPayment }));

            var paymentStatuses = new List<DecoupledPaymentStatusFilter>
            {
                new DecoupledPaymentStatusFilter { PaymentStatus = PaymentStatus.Returned }
            };

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(1, payments.Count);
            Assert.AreEqual(returnPayment.RejectReason, payments[0].Reason);
            Assert.AreEqual(returnPayment.ReturnAmount.Currency.Code, payments[0].ReturnCurrency);
            Assert.AreEqual(returnPayment.ReturnAmount.Amount, payments[0].ReturnAmount);
        }

        [Test]
        public void GetPayments_CanFilterBySingleUnFundedPaymentStatus()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment2);
            payment2.TransactionSystemOrderId = 222;
            payment2.TransactionSystemOrderNumber = "C222";
            payment2.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment2.Id, payment2.TransactionSystemOrderId, payment2.TransactionSystemOrderNumber);  //isFunded = true

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment3);
            payment3.TransactionSystemOrderId = 333;
            payment3.TransactionSystemOrderNumber = "C333";
            payment3.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment3.Id, payment3.TransactionSystemOrderId, payment3.TransactionSystemOrderNumber);  //isFunded = true

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.SanctionBlocked;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentStatuses = new List<DecoupledPaymentStatusFilter>
            {
                new DecoupledPaymentStatusFilter { IsFunded = false, PaymentStatus = PaymentStatus.Committed }
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(1, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
        }

        [Test]
        public void GetPayments_CanFilterByMultipleDecoupledPaymentStatuses()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapperCommand.Instance.InsertPayment(payment2);
            payment2.TransactionSystemOrderId = 222;
            payment2.TransactionSystemOrderNumber = "C222";
            payment2.IsFunded = true;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment2.Id, payment2.TransactionSystemOrderId, payment2.TransactionSystemOrderNumber);  //isFunded = true

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.SanctionBlocked;
            PaymentMapperCommand.Instance.InsertPayment(payment3);
            payment3.TransactionSystemOrderId = 333;
            payment3.TransactionSystemOrderNumber = "C333";
            payment3.IsFunded = false;
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment3.Id, payment3.TransactionSystemOrderId, payment3.TransactionSystemOrderNumber);  //isFunded = true

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.SanctionBlocked;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentStatuses = new List<DecoupledPaymentStatusFilter>
            {
                new DecoupledPaymentStatusFilter { IsFunded = true, PaymentStatus = PaymentStatus.Committed },
                new DecoupledPaymentStatusFilter { IsFunded = true, PaymentStatus = PaymentStatus.SanctionCleared },
                new DecoupledPaymentStatusFilter { IsFunded = false, PaymentStatus = PaymentStatus.SanctionBlocked }
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment2, payments[0]);
            AssertPaymentAreEqual(payment4, payments[1]);
        }

        [Test]
        public void GetPayments_CanFilterByMultipleCoupledPaymentStatuses()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.Created;
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.SanctionBlocked;
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.Cancelled;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentStatuses = new List<CoupledPaymentStatusFilter>
            {
                new CoupledPaymentStatusFilter { PaymentStatus = PaymentStatus.Committed },
                new CoupledPaymentStatusFilter { PaymentStatus = PaymentStatus.SanctionCleared },
                new CoupledPaymentStatusFilter { PaymentStatus = PaymentStatus.SanctionBlocked }
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(customerBatch, null, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
            AssertPaymentAreEqual(payment3, payments[1]);
        }

        [Test]
        public void GetPayments_ReturnsRecordsWithCorrectExternalPaymentIds()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var paymentIds = new List<string> { "2222", "3333" };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, paymentIds, 10, new SortBy());

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment2, payments[0]);
            AssertPaymentAreEqual(payment3, payments[1]);
        }

        [Test]
        public void GetPayments_ReturnsRecordsWithCorrectExternalPaymentIdsAndDecoupledStatusFilter()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.Created;
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentIds = new List<string> { "2222", "3333" };
            var paymentStatuses = new List<DecoupledPaymentStatusFilter>
            {
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.Committed}
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, paymentIds, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(1, payments.Count);
            AssertPaymentAreEqual(payment2, payments[0]);
        }

        [Test]
        public void GetPayments_ReturnsRecordsWithCorrectExternalPaymentIdsAndCoupledStatusFilter()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment3.PaymentStatus = PaymentStatus.Created;
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer, "4444", customerBatch);
            payment4.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentIds = new List<string> { "2222", "3333" };
            var paymentStatuses = new List<CoupledPaymentStatusFilter>
            {
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Committed}
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(customerBatch, paymentIds, 10, new SortBy(), paymentStatuses);

            Assert.AreEqual(1, payments.Count);
            AssertPaymentAreEqual(payment2, payments[0]);
        }

        [Test]
        public void GetPayments_ReturnsNoRecordsIfExternalIdsDontExist()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partner = new Partner { Id = customer.PartnerId };
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var paymentIds = new List<string> { "4444", "5555" };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, paymentIds, 10, new SortBy());

            Assert.AreEqual(0, payments.Count);
        }

        [Test]
        public void GetPayments_GetsPaymentsOnlyForSpecificBatch()
        {
            var customer1 = CustomerHelper.Instance.CreateCustomer();
            var customer2 = CustomerHelper.Instance.CreateCustomer();

            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer1, "1111", customerBatch1, customer1.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer1, "2222", customerBatch1, customer1.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer2, "3333", customerBatch2, customer2.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer2, "4444", customerBatch2, customer2.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var payments = PaymentQueryMapper.Instance.GetPayments(customerBatch1, null, 10, new SortBy());

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
            AssertPaymentAreEqual(payment2, payments[1]);
        }

        [Test]
        public void GetPayments_GetsNotAcceptedAndSuccessfulPaymentsOnlyForSpecificBatch()
        {
            var customer1 = CustomerHelper.Instance.CreateCustomer();
            var customer2 = CustomerHelper.Instance.CreateCustomer();

            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer1, "1111", customerBatch1, customer1.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer1, "2222", customerBatch1, customer1.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer2, "3333", customerBatch2, customer2.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer2, "4444", customerBatch2, customer2.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer1);

            paymentRequest.PaymentsToProcess[0].PartnerId = customer1.PartnerId;
            paymentRequest.PaymentsToProcess[0].SetCustomer(customer1);
            paymentRequest.PaymentsToProcess[0].SetCustomerBatchId(customerBatch1.Id);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("uh oh...");
            paymentRequest.BatchId = customerBatch1.Id;
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "Good day to you sir!");
            var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            paymentRequest.PaymentsToProcess[0].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(paymentRequest.PaymentsToProcess);

            var payments = PaymentQueryMapper.Instance.GetPayments(customerBatch1, null, 10, new SortBy());

            Assert.AreEqual(3, payments.Count);
            Assert.AreEqual(paymentRequest.PaymentsToProcess[0].PaymentId, payments[0].ExternalId);
            AssertPaymentAreEqual(payment1, payments[1]);
            AssertPaymentAreEqual(payment2, payments[2]);
        }

        [Test]
        public void GetPayments_GetsCreatedPaymentsFromNotAcceptedAndSuccessfulPaymentsOnlyForSpecificBatch()
        {
            var customer1 = CustomerHelper.Instance.CreateCustomer();
            var customer2 = CustomerHelper.Instance.CreateCustomer();

            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer1, "1111", customerBatch1, customer1.PartnerId);
            payment1.PaymentStatus = PaymentStatus.Created;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer1, "2222", customerBatch1, customer1.PartnerId);
            payment2.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer2, "3333", customerBatch2, customer2.PartnerId);
            payment3.PaymentStatus = PaymentStatus.Created;
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer2, "4444", customerBatch2, customer2.PartnerId);
            payment4.PaymentStatus = PaymentStatus.Committed;
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer1);

            paymentRequest.PaymentsToProcess[0].PartnerId = customer1.PartnerId;
            paymentRequest.PaymentsToProcess[0].SetCustomer(customer1);
            paymentRequest.PaymentsToProcess[0].SetCustomerBatchId(customerBatch1.Id);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("uh oh...");
            paymentRequest.BatchId = customerBatch1.Id;
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "Good day to you sir!");
            var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            paymentRequest.PaymentsToProcess[0].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(paymentRequest.PaymentsToProcess);

            var statusFilter = new List<CoupledPaymentStatusFilter> {new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Created}};
            var payments = PaymentQueryMapper.Instance.GetPayments(customerBatch1, null, 10, new SortBy(), statusFilter);

            Assert.AreEqual(1, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
        }

        [Test]
        public void GetPayments_GetsAcceptedAndNotAccpetedPaymentWhenThosePaymentsIdsWereSearchedFor()
        {
            var customer1 = CustomerHelper.Instance.CreateCustomer();
            var customer2 = CustomerHelper.Instance.CreateCustomer();

            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer1, "1111", customerBatch1, customer1.PartnerId);
            payment1.PaymentStatus = PaymentStatus.Created;
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer1);

            paymentRequest.PaymentsToProcess[0].PaymentId = "gorilla";
            paymentRequest.PaymentsToProcess[0].PartnerId = customer1.PartnerId;
            paymentRequest.PaymentsToProcess[0].SetCustomer(customer1);
            paymentRequest.PaymentsToProcess[0].SetCustomerBatchId(customerBatch1.Id);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("uh oh...");
            paymentRequest.BatchId = customerBatch1.Id;
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "Good day to you sir!");
            var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            paymentRequest.PaymentsToProcess[0].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(paymentRequest.PaymentsToProcess);

            var payments = PaymentQueryMapper.Instance.GetPayments(customerBatch1, new List<string> {"gorilla", "1111"}, 10, new SortBy());

            Assert.AreEqual(2, payments.Count);
            Assert.AreEqual("gorilla", payments[0].ExternalId);
            AssertPaymentAreEqual(payment1, payments[1]);
        }

        [Test]
        public void GetPayments_GetsPaymentsOnlyForSpecificPartner()
        {
            var customer1 = CustomerHelper.Instance.CreateCustomer();
            var customer2 = CustomerHelper.Instance.CreateCustomer();
            var partner = new Partner { Id = customer1.PartnerId };

            customer1.Id = 111;
            customer2.Id = 222;
            customer1.PartnerId = 1;
            customer2.PartnerId = 2;

            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer1, "1111", customerBatch1, customer1.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer1, "2222", customerBatch1, customer1.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer2, "3333", customerBatch2, customer2.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment3);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer2, "4444", customerBatch2, customer2.PartnerId);
            PaymentMapperCommand.Instance.InsertPayment(payment4);

            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy());

            Assert.AreEqual(2, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
            AssertPaymentAreEqual(payment2, payments[1]);
        }

        [Test]
        public void GetPayments_GetsPaymentsOnlyForSpecificPartnerWhenFilteredByPaymentStatus()
        {
            var customer1 = CustomerHelper.Instance.CreateCustomer();
            var customer2 = CustomerHelper.Instance.CreateCustomer();
            var partner = new Partner { Id = customer1.PartnerId };

            customer1.Id = 111;
            customer2.Id = 222;
            customer1.PartnerId = 1;
            customer2.PartnerId = 2;

            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer1, "1111", customerBatch1, customer1.PartnerId);
            payment1.PaymentStatus = PaymentStatus.Created;
            payment1.IsFunded = true;
            payment1.TransactionSystemOrderNumber = "p1111";
            PaymentMapperCommand.Instance.InsertPayment(payment1);
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment1.Id, payment1.TransactionSystemOrderId, payment1.TransactionSystemOrderNumber);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer1, "2222", customerBatch1, customer1.PartnerId);
            payment2.PaymentStatus = PaymentStatus.Committed;
            payment2.IsFunded = true;
            payment2.TransactionSystemOrderNumber = "p2222";
            PaymentMapperCommand.Instance.InsertPayment(payment2);
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment2.Id, payment2.TransactionSystemOrderId, payment2.TransactionSystemOrderNumber);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer2, "3333", customerBatch2, customer2.PartnerId);
            payment3.PaymentStatus = PaymentStatus.Created;
            payment3.IsFunded = true;
            payment3.TransactionSystemOrderNumber = "p3333";
            PaymentMapperCommand.Instance.InsertPayment(payment3);
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment3.Id, payment3.TransactionSystemOrderId, payment3.TransactionSystemOrderNumber);

            var payment4 = PaymentHelper.Instance.CreatePayment(customer2, "4444", customerBatch2, customer2.PartnerId);
            payment4.PaymentStatus = PaymentStatus.Committed;
            payment4.IsFunded = true;
            payment4.TransactionSystemOrderNumber = "p4444";
            PaymentMapperCommand.Instance.InsertPayment(payment4);
            PaymentMapperCommand.Instance.UpdatePaymentsConfirmationNo(payment4.Id, payment4.TransactionSystemOrderId, payment4.TransactionSystemOrderNumber);

            var statusFilter = new List<DecoupledPaymentStatusFilter>
            {
                new DecoupledPaymentStatusFilter { PaymentStatus = PaymentStatus.Created, IsFunded = false },
                new DecoupledPaymentStatusFilter  { PaymentStatus = PaymentStatus.Created, IsFunded = true }
            };
            var payments = PaymentQueryMapper.Instance.GetPayments(partner, null, 10, new SortBy(), statusFilter);

            Assert.AreEqual(1, payments.Count);
            AssertPaymentAreEqual(payment1, payments[0]);
        }

        private void AssertPaymentAreEqual(Payment payment, PaymentViewModel paymentViewModel)
        {
            Assert.AreEqual(payment.Id, paymentViewModel.Id);
            Assert.AreEqual(payment.CustomerBatchId, paymentViewModel.CustomerBatchId);
            Assert.AreEqual(payment.PaymentMethod, paymentViewModel.PaymentMethod);
            Assert.AreEqual(payment.PaymentStatus, paymentViewModel.PaymentStatus);
            Assert.AreEqual(payment.ExternalId, paymentViewModel.ExternalId);
            Assert.AreEqual(payment.AmountMoney.Amount, paymentViewModel.Amount);
            Assert.AreEqual(payment.AmountMoney.Currency.Code, paymentViewModel.Currency);
            Assert.AreEqual(payment.ExternalCustomerId, paymentViewModel.ExternalCustomerId);
            Assert.AreEqual(payment.Beneficiary.ExternalId, paymentViewModel.ExternalBeneId);
            Assert.AreEqual(payment.Beneficiary.Version, paymentViewModel.BeneVersion);
            Assert.AreEqual(payment.Beneficiary.CustomerBeneId, paymentViewModel.CustomerBeneId);
            Assert.AreEqual(payment.Beneficiary.VersionedOn, paymentViewModel.BeneVersionedOn);
            Assert.AreEqual(payment.Beneficiary.Identification.FirstName, paymentViewModel.BeneFirstName);
            Assert.AreEqual(payment.Beneficiary.Identification.MiddleName, paymentViewModel.BeneMiddleName);
            Assert.AreEqual(payment.Beneficiary.Identification.LastName, paymentViewModel.BeneLastName);
            Assert.AreEqual(payment.Beneficiary.Identification.PhoneNumber, paymentViewModel.BenePhoneNumber);
            Assert.AreEqual(payment.Beneficiary.Identification.CellNumber, paymentViewModel.BeneCellNumber);
            Assert.AreEqual(payment.Beneficiary.Identification.DateOfBirth, paymentViewModel.BeneDateOfBirth);
            Assert.AreEqual(payment.Beneficiary.Identification.Gender, paymentViewModel.BeneGender);
            Assert.AreEqual(payment.Beneficiary.Identification.EntityType, paymentViewModel.BeneEntityType);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessName, paymentViewModel.BeneBusinessName);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessRegistrationNumber, paymentViewModel.BeneBusinessRegistrationNumber);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessRegistrationCountry, paymentViewModel.BeneBusinessRegistrationCountry);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessRegistrationStateProv, paymentViewModel.BeneBusinessRegistrationStateProv);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessContactRole, paymentViewModel.BeneBusinessContactRole);
            Assert.AreEqual(payment.Beneficiary.Identification.Industry, paymentViewModel.BeneIndustry);
            Assert.AreEqual(payment.Beneficiary.Identification.EmailAddress, paymentViewModel.BeneEmailAddress);
            Assert.AreEqual(payment.Beneficiary.Address.AddressLine1, paymentViewModel.BeneAddressLine1);
            Assert.AreEqual(payment.Beneficiary.Address.AddressLine2, paymentViewModel.BeneAddressLine2);
            Assert.AreEqual(payment.Beneficiary.Address.AddressLine3, paymentViewModel.BeneAddressLine3);
            Assert.AreEqual(payment.Beneficiary.Address.City, paymentViewModel.BeneCity);
            Assert.AreEqual(payment.Beneficiary.Address.StateOrProvince, paymentViewModel.BeneStateOrProv);
            Assert.AreEqual(payment.Beneficiary.Address.ZipOrPostalCode, paymentViewModel.BeneZipOrPostal);
            Assert.AreEqual(payment.Beneficiary.Address.CountryCode, paymentViewModel.BeneCountryCode);
            Assert.AreEqual(payment.BankAccount.AccountNumber, paymentViewModel.BankAccountNumber);
            Assert.AreEqual(payment.BankAccount.ExternalAccountType, paymentViewModel.ExternalBankAccountType);
            Assert.AreEqual(payment.BankAccount.AccountPurpose, paymentViewModel.BankAccountPurpose);
            Assert.AreEqual(payment.BankAccount.BankName, paymentViewModel.BankName);
            Assert.AreEqual(payment.BankAccount.BranchName, paymentViewModel.BankBranchName);
            Assert.AreEqual(payment.BankAccount.BankCode, paymentViewModel.BankCode);
            Assert.AreEqual(payment.BankAccount.BranchCode, paymentViewModel.BankBranchCode);
            Assert.AreEqual(payment.BankAccount.DisplayName, paymentViewModel.ExternalBankAccountDisplayName);
            Assert.AreEqual(payment.BankAccount.BankAddress.AddressLine1, paymentViewModel.BankAddressLine1);
            Assert.AreEqual(payment.BankAccount.BankAddress.AddressLine2, paymentViewModel.BankAddressLine2);
            Assert.AreEqual(payment.BankAccount.BankAddress.AddressLine3, paymentViewModel.BankAddressLine3);
            Assert.AreEqual(payment.BankAccount.BankAddress.City, paymentViewModel.BankCity);
            Assert.AreEqual(payment.BankAccount.BankAddress.StateOrProvince, paymentViewModel.BankStateOrProv);
            Assert.AreEqual(payment.BankAccount.BankAddress.ZipOrPostalCode, paymentViewModel.BankZipOrPostal);
            Assert.AreEqual(payment.BankAccount.BankAddress.CountryCode, paymentViewModel.BankCountryCode);
            Assert.AreEqual(payment.BankAccount.ExternalId, paymentViewModel.ExternalBankAccountId);
            Assert.AreEqual(payment.BankAccount.Version, paymentViewModel.BankAccountVersion);
            Assert.AreEqual(payment.BankAccount.VersionedOn, paymentViewModel.BankAccountVersionedOn);
            Assert.That(payment.CreatedOnUTC, Is.EqualTo(paymentViewModel.CreatedOnUTC).Within(1).Seconds);
            Assert.That(payment.CreatedOnUTC, Is.EqualTo(paymentViewModel.UpdatedOnUTC).Within(1).Seconds);
            Assert.AreEqual(payment.TransactionSystemCustomerId, paymentViewModel.TransactionSystemCustomerId);
            Assert.AreEqual(payment.TransactionSystemId, paymentViewModel.TransactionSystemId);
            Assert.AreEqual(payment.PaymentSourceId, paymentViewModel.PartnerId);
            Assert.AreEqual(payment.TransactionSystemOrderId, paymentViewModel.TransactionSystemOrderId);
            Assert.AreEqual(payment.TransactionSystemOrderNumber, paymentViewModel.TransactionSystemOrderNumber);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderId, paymentViewModel.TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderNumber, paymentViewModel.TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(payment.RequestedReleaseDate, paymentViewModel.RequestedReleaseDate);
            Assert.AreEqual(payment.PaymentReference, paymentViewModel.PaymentReference);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankName, paymentViewModel.IntermediaryBankName);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankCode, paymentViewModel.IntermediaryBankCode);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.AddressLine1, paymentViewModel.IntermediaryBankAddressLine1);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.AddressLine2, paymentViewModel.IntermediaryBankAddressLine2);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.AddressLine3, paymentViewModel.IntermediaryBankAddressLine3);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.City, paymentViewModel.IntermediaryBankCity);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.StateOrProvince, paymentViewModel.IntermediaryBankStateOrProv);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.ZipOrPostalCode, paymentViewModel.IntermediaryBankZipOrPostal);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.CountryCode, paymentViewModel.IntermediaryBankCountryCode);
            Assert.AreEqual(payment.SettlementCurrencyCode, paymentViewModel.SettlementCurrency);
            Assert.AreEqual(payment.InstructionCodeForBank, paymentViewModel.InstructionCodeForBank);
            Assert.AreEqual(payment.InstructionForBank, paymentViewModel.InstructionForBank);
            Assert.AreEqual(payment.PurposeOfPayment, paymentViewModel.PurposeOfPayment);
            Assert.AreEqual(payment.PainFileGenerationStatus, paymentViewModel.PainFileGenerationStatus);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.AccountNumber, paymentViewModel.IntermediaryBankAccountNumber);
            Assert.AreEqual(payment.RemittanceType, paymentViewModel.RemittanceType);
            Assert.AreEqual(payment.BankAccount.BankAccountOwnerName, paymentViewModel.BankAccountOwnerName);
            Assert.AreEqual(payment.ThirdPartyRemitter.Id, paymentViewModel.ThirdPartyRemitterId);
            Assert.AreEqual(payment.ThirdPartyRemitter.Version, paymentViewModel.ThirdPartyRemitterVersion);
            Assert.AreEqual(payment.ThirdPartyRemitter.VersionedOn, paymentViewModel.ThirdPartyRemitterVersionedOn);
            Assert.AreEqual(payment.ThirdPartyRemitter.Type, paymentViewModel.ThirdPartyRemitterType);
            Assert.AreEqual(payment.ThirdPartyRemitter.BusinessName, paymentViewModel.ThirdPartyRemitterBusinessName);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine1, paymentViewModel.ThirdPartyRemitterAddressLine1);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine2, paymentViewModel.ThirdPartyRemitterAddressLine2);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine3, paymentViewModel.ThirdPartyRemitterAddressLine3);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.City, paymentViewModel.ThirdPartyRemitterCity);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.StateOrProvince, paymentViewModel.ThirdPartyRemitterStateOrProv);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.ZipOrPostalCode, paymentViewModel.ThirdPartyRemitterZipOrPostal);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.CountryCode, paymentViewModel.ThirdPartyRemitterCountryCode);
            Assert.AreEqual(payment.ThirdPartyRemitter.PhoneNumber, paymentViewModel.ThirdPartyRemitterPhoneNumber);
            Assert.AreEqual(payment.ThirdPartyRemitter.Email, paymentViewModel.ThirdPartyRemitterEmailAddress);
            Assert.AreEqual(payment.ThirdPartyRemitter.IdentificationType, paymentViewModel.ThirdPartyRemitterIdentificationType);
            Assert.AreEqual(payment.ThirdPartyRemitter.Identification, paymentViewModel.ThirdPartyRemitterIdentification);
            Assert.AreEqual(payment.ThirdPartyRemitter.Industry, paymentViewModel.ThirdPartyRemitterIndustry);
            Assert.AreEqual(payment.GPGProcessedUTC, paymentViewModel.GPGProcessedUTC);
            Assert.AreEqual(payment.IsFixedAmountInSettlementCurrency, paymentViewModel.IsFixedAmountInSettlementCurrency);
            Assert.AreEqual(payment.SettlementAmountMoney.Amount, paymentViewModel.SettlementAmount);
            Assert.AreEqual(payment.SanctionScanStatus, paymentViewModel.SanctionScanStatus);
            Assert.AreEqual(payment.SanctionScanStatusUpdatedOnUtc, paymentViewModel.SanctionScanStatusUpdatedOnUtc);
            Assert.AreEqual(payment.IsFunded, paymentViewModel.IsFunded);
            Assert.AreEqual(payment.PartnerReference, paymentViewModel.PartnerReference);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankBranchCode, paymentViewModel.IntermediaryBankBranchCode);
        }
    }
}
