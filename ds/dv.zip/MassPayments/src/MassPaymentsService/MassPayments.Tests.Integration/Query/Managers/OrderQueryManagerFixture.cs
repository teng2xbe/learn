﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers;
using MassPayments.Query.Mappers;
using MassPayments.Query.POCOs;
using MassPayments.Query.ValueObjects;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Query.Managers;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Query.Managers
{
    [TestFixture]
    public class OrderQueryManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            CurrencyCache.Instance.Reinitialize();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "Concur" });

        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
        }

        [Test]
        public void GetOrders_AllOrdersAreReturned()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));
            
            var orders = new OrderQueryManager().GetOrders(partner, null, new SortBy());

            Assert.IsNotNull(orders);
            Assert.AreEqual(3, orders.Count);
        }

        [Test]
        public void GetOrders_ReturnsOrdersNotFoundCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var partner = new Partner { Id = customer.PartnerId };

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.ConfirmationNumber = "2222";
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            order2.ConfirmationNumber = "3333";

            var orderList = new List<Order> { order1, order2 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderNumbers = new List<string> { "2222", "4444" };
            var orders = new OrderQueryManager().GetOrders(partner, orderNumbers, new SortBy());

            Assert.AreEqual(2, orders.Count);
            AssertOrdersAreEqual(order1, orders[0]);
            Assert.AreEqual(OrderStatus.NotFound, orders[1].OrderStatus);
        }

        private void AssertOrdersAreEqual(Order order, OrderViewModel orderViewModel)
        {
            Assert.AreEqual(order.OrderId, orderViewModel.OrderId);
        }
    }
}
