﻿//using System;
//using System.Transactions;
//using System.Xml.Serialization;
//using MassPayments.ActionHandlers;
//using MassPayments.Domain.Entities.ActionHandling;
//using MassPayments.Mappers;
//using NUnit.Framework;
//
//namespace MassPayments.Tests.Integration.ActionHandlers
//{
//    [TestFixture]
//    public class BaseActionHandlerFixture
//    {
//        private TransactionScope transactionScope;
//
//        [SetUp]
//        public void Setup()
//        {
//            transactionScope = new TransactionScope();
//        }
//
//        [TearDown]
//        public void TearDown()
//        {
//            if (transactionScope != null)
//                transactionScope.Dispose();
//        }
//
//        [Test]
//        public void ActionHandler_DoesNot_Throw_AndExecuteHandle()
//        {
//            var handlerInstance = new PartnerJsonFileHandler();
//            var mockActionObj = new Foo();
//            Assert.DoesNotThrow(() => handlerInstance.Handle("blahGuid", "blahHostName", () => { mockActionObj.Visit(); }));
//            Assert.AreEqual(1, mockActionObj.VisitedCount); //action executed;
//            var handler = ActionHandlerMapper.Instance.GetRegisteredHandlerByName(handlerInstance.GetType().FullName);
//            ActionHandlerLock insertedLock = null;
//            Assert.DoesNotThrow(() => insertedLock = ActionHandlerLockMapper.Instance.ObtainLock(handler.Id, "blahGuid", "blahHostName", 5));
//            Assert.IsNotNull(insertedLock);
//        }
//
//        [Test]
//        public void ActionHandler_DoesNotExecuteHandle_WhenHandlerIsLocked()
//        {
//            var registeredHandler = ActionHandlerMapper.Instance.GetRegisteredHandlerByName(typeof(PartnerJsonFileHandler).FullName);
//            var aLock = new ActionHandlerLock
//            {
//                HandlerGuid = "blahGuid",
//                HandlerId = registeredHandler.Id,
//                HostName = "blahHostName",
//                TimeToLiveUtc = DateTime.UtcNow.AddMinutes(1)
//            };
//
//            ActionHandlerLockMapper.Instance.InsertLock(aLock);
//
//            var handlerInstance = new PartnerJsonFileHandler();
//            var mockActionObj = new Foo();
//            Assert.DoesNotThrow(() => handlerInstance.Handle("blahGuid2", "blahHostName2",() => {mockActionObj.Visit(); }));
//            Assert.AreEqual(0, mockActionObj.VisitedCount); //action not executed due to locking;
//        }
//
//        [Test]
//        public void ActionHandler_DoesNotExecuteHandle_WhenHandlerNotRegistered()
//        {
//            var handlerInstance = new MockedActionHandler();
//            var mockActionObj = new Foo();
//            Assert.DoesNotThrow(() => handlerInstance.Handle("blahGuid", "blahHostName", () => { mockActionObj.Visit(); }));
//            Assert.AreEqual(0, mockActionObj.VisitedCount); //action not executed due to unregisterd handler;
//        }
//
//        [Test]
//        public void ActionHandler_BubbleUp_UnhandledExceptionFromAction()
//        {
//            var handlerInstance = new PartnerJsonFileHandler();
//            var mockActionObj = new Foo();
//            Assert.Throws<Exception>(() => handlerInstance.Handle("blahGuid", "blahHostName", () => { mockActionObj.ThrowException(); }));
//        }
//
//        private class Foo
//        {
//            public int VisitedCount;
//
//            internal Foo()
//            {
//                VisitedCount = 0;
//            }
//
//            internal void Visit()
//            {
//                VisitedCount ++;
//            }
//
//            internal void ThrowException()
//            {
//                throw new Exception();
//            }
//        }
//
//        private class MockedActionHandler : BaseActionHandler{}
//    }
//}
