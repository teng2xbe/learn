﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MassPayments.Tests.Integration
{
    public class TestHelper
    {
        public static bool AreDateTimesEqual(DateTime inMemoryDateTime, DateTime loadedFromDbDateTime)
        {
            //Have to compare like this because of SQL Server precision differences
            const int toleranceInSeconds = 1;
            return Math.Abs(inMemoryDateTime.Subtract(loadedFromDbDateTime).TotalSeconds) <= toleranceInSeconds;
        }
    }
}
