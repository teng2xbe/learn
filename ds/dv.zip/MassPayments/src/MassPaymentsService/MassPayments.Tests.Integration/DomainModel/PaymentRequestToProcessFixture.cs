﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers.Interfaces;
using MassPayments.Tests.Integration.Mappers.Helpers;
using MassPaymentsCommon.WCFContracts.Enums;
using NUnit.Framework;
using Rhino.Mocks;
using Address = MassPayments.Domain.Entities.PaymentRequest.Address;
using BankAccount = MassPayments.Domain.Entities.PaymentRequest.BankAccount;
using Beneficiary = MassPayments.Domain.Entities.PaymentRequest.Beneficiary;
using MassPayments.Publishers;

namespace MassPayments.Tests.Integration.DomainModel
{
    [TestFixture]
    public class PaymentRequestToProcessFixture
    {
        private TransactionScope transactionScope;
        private IPublisher<Payment, CustomerBatch, Customer> paymentStatusUpdatedpublisher;
        private IPublisher<List<PaymentRequest>> paymentNotAcceptedPublisher;
        private IPublisher<Payment, CustomerBatch> paymentUpdateFailedpublisher;

        [SetUp]
        public void SetUp()
        {
            transactionScope = new TransactionScope();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();

            paymentStatusUpdatedpublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentStatusUpdatedPublisher), paymentStatusUpdatedpublisher);

            paymentNotAcceptedPublisher = MockRepository.GenerateMock<IPublisher<List<PaymentRequest>>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentNotAcceptedPublisher), paymentNotAcceptedPublisher);

            paymentUpdateFailedpublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentUpdateFailedPublisher), paymentUpdateFailedpublisher);
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            paymentStatusUpdatedpublisher = null;
            paymentNotAcceptedPublisher = null;
            paymentUpdateFailedpublisher = null;
        }

        [Test]
        public void Process_Successfully()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

             var pr = new PaymentRequestToProcess()
            {
                Id = 2,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePaymentRequest("1", 0, 1, ""), CreatePaymentRequest("2", 1, 1, "") }
            };
           
            pr.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            pr.PaymentsToProcess[1].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;

            pr.Process();
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            var payments = PaymentMapper.Instance.GetPayments(pr.PartnerId, new List<string> { "1", "2" });
            Assert.AreEqual(2, payments.Count);

            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(pr.PaymentsToProcess[0].CustomerBatchId);
            Assert.AreEqual(customer.Id, customerBatch.CustomerId);
            Assert.AreEqual(pr.PaymentsToProcess[0].CustomerBatchId, customerBatch.Id);
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_InsertsNotAcceptedPaymentsLog_Successfully()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var pr = new PaymentRequestToProcess()
            {
                Id = 2,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePaymentRequest("1", 0, 1, "")}
            };

            pr.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            pr.PaymentsToProcess[0].Beneficiary.VersionedOn = "";
            pr.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(pr);
            pr.Process();

            var selectStatement = $"SELECT TOP 1 * FROM MP.NotAcceptedPaymentLog WHERE PaymentId = '{pr.PaymentsToProcess[0].PaymentId}' ORDER BY Id DESC";
            var prevAchiveId = 0;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(pr.PaymentsToProcess[0].PaymentId, Convert.ToString(reader["PaymentId"]));
                    prevAchiveId = Convert.ToInt32(reader["PaymentRequestArchiveDetailId"]);
                }
            }

            pr.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(pr);
            pr.Process();

            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(pr.PaymentsToProcess[0].PaymentId, Convert.ToString(reader["PaymentId"]));
                    Assert.AreNotEqual(prevAchiveId, Convert.ToInt32(reader["PaymentRequestArchiveDetailId"]));
                }
            }
        }

        [Test]
        public void Process_DeleteAcceptedPaymentsFromLog_Successfully()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var pr = new PaymentRequestToProcess()
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePaymentRequest("1", 0, 1, "") }
            };

            pr.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            var versionedOn = pr.PaymentsToProcess[0].Beneficiary.VersionedOn;
            pr.PaymentsToProcess[0].Beneficiary.VersionedOn = "";
            pr.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(pr);

            pr.Process();

            var selectStatement = string.Format("SELECT TOP 1 * FROM MP.NotAcceptedPaymentLog WHERE PaymentId = '{0}' ORDER BY Id DESC", pr.PaymentsToProcess[0].PaymentId);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(pr.PaymentsToProcess[0].PaymentId, Convert.ToString(reader["PaymentId"]));
                }
            }

            pr.PaymentsToProcess[0].Beneficiary.VersionedOn = versionedOn;
            pr.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(pr);
            pr.Process();

            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                Assert.IsEmpty(reader);
            }
        }

        [Test] 
        public void Process_WithBatchSuccessfully()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            customerBatch.Id = 103;
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var pr = new PaymentRequestToProcess ()
            {
                Id = 1,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePaymentRequest("1", 0, 1, ""), CreatePaymentRequest("2", 1, 1, "") }
            };
            pr.BatchId = customerBatch.Id;
            pr.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            pr.PaymentsToProcess[1].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            pr.PaymentsToProcess[0].ExternalBatchId = customerBatch.ExternalId;
            pr.PaymentsToProcess[1].ExternalBatchId = customerBatch.ExternalId;

            pr.Process();
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            var newCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(pr.BatchId);
            var updatedOnUTC = newCustomerBatch.UpdatedOnUTC;
            var payments = PaymentMapper.Instance.GetPayments(customer, new List<string> { "1", "2" });
            Assert.AreEqual(2, payments.Count);
            paymentStatusUpdatedpublisher.VerifyAllExpectations();

            newCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(pr.PaymentsToProcess[0].CustomerBatchId);
            Assert.AreEqual(customer.Id, newCustomerBatch.CustomerId);
            Assert.AreEqual(pr.PaymentsToProcess[0].CustomerBatchId, newCustomerBatch.Id);
            Assert.AreEqual(2, newCustomerBatch.TotalPaymentsReceived);
            Assert.AreEqual(2, newCustomerBatch.TotalPaymentsAccepted);
            Assert.AreEqual(updatedOnUTC, newCustomerBatch.UpdatedOnUTC);
            Assert.AreEqual(PaymentStatus.Created, payments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Created, payments[1].PaymentStatus);

            pr.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(pr);
            pr.Process();
            paymentUpdateFailedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything));
            newCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(pr.PaymentsToProcess[0].CustomerBatchId);
            Assert.AreEqual(4, newCustomerBatch.TotalPaymentsReceived);
            Assert.AreEqual(2, newCustomerBatch.TotalPaymentsAccepted); //2 failed
            Assert.AreEqual(updatedOnUTC, newCustomerBatch.UpdatedOnUTC);
        }

        [Test]
        public void Process_BothSamePaymentIdForEachPartner_Successfully()
        {
            var customer = CreateCustomer();
            customer.PartnerId = 1;
            customer.PartnerAssignedCustomerId = "BLEHBLEH";
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var pr = new PaymentRequestToProcess()
            {
                Id = 1,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePaymentRequest("1", 0, 1, "") }
            };

            pr.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;

            pr.Process();

            var payments = PaymentMapper.Instance.GetPayments(pr.PartnerId, new List<string> { "1" });
            Assert.AreEqual(1, payments.Count);
            Assert.AreEqual(PaymentStatus.Committed, payments[0].PaymentStatus);
            Assert.AreEqual(pr.PaymentsToProcess[0].PaymentId, payments[0].ExternalId);

            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(pr.PaymentsToProcess[0].CustomerBatchId);
            Assert.AreEqual(customer.Id, customerBatch.CustomerId);
            Assert.AreEqual(pr.PaymentsToProcess[0].CustomerBatchId, customerBatch.Id);
            
            var customer2 = CreateCustomer();
            customer2.PartnerId = 2;
            customer2.PartnerAssignedCustomerId = "BLUHBLUH";
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);

            var pToProcess = new PaymentRequestToProcess()
            {
                Id = 1,
                PartnerId = 2,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePaymentRequest("1", 0, 2, "") }
            };

            pToProcess.PaymentsToProcess[0].PartnerAssignedCustomerId = customer2.PartnerAssignedCustomerId;

            pToProcess.Process();
            var payments2 = PaymentMapper.Instance.GetPayments(pToProcess.PartnerId, new List<string> {"1" });
        }        

        [Test] 
        public void Process_Fails()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var paymentId1 = Guid.NewGuid().ToString();
            var paymentId2 = Guid.NewGuid().ToString();
            var paymentWithlongString = CreatePaymentRequest(paymentId2, 0, 1, "");
            var pr = new PaymentRequestToProcess()
            {
                Id = 1,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePaymentRequest(paymentId1, 0, 1, ""), paymentWithlongString}
            };
            
            pr.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            pr.PaymentsToProcess[1].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;

            //fake the exception
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            PaymentMapper.Instance.Expect(im => im.BulkInsertUpdatePayment(Arg<List<Payment>>.Is.Anything)).Throw(new Exception());

            pr.Process();

            paymentStatusUpdatedpublisher.AssertWasNotCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            
            //use actual mapper
            PaymentMapper.Instance = null;
            var payments = PaymentMapper.Instance.GetPayments(pr.PartnerId, new List<string> { paymentId2 });

            Assert.AreEqual(0, payments.Count);
            paymentStatusUpdatedpublisher.VerifyAllExpectations();

            var selectStatement = string.Format("SELECT TOP 1 * FROM MP.PaymentRequestArchiveDetail WHERE PaymentId = '{0}' ORDER BY Id DESC", paymentId2);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(paymentId2, Convert.ToString(reader["PaymentId"]));
                    Assert.AreEqual(0, Convert.ToInt32(reader["SuccessFlag"]));
                    Assert.AreEqual(((int)ErrorCode.GenericMassPaymentsServiceError).ToString(), Convert.ToString(reader["Message"]));
                }
            }
            selectStatement = string.Format("SELECT TOP 1 * FROM MP.PaymentRequestArchiveDetail WHERE PaymentId = '{0}' ORDER BY Id DESC", paymentId1);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(paymentId1, Convert.ToString(reader["PaymentId"]));
                    Assert.AreEqual(0, Convert.ToInt32(reader["SuccessFlag"]));
                    Assert.AreEqual(((int)ErrorCode.GenericMassPaymentsServiceError).ToString(), Convert.ToString(reader["Message"]));
                }
            }
        }

        [Test]
        public void ProcessCustomerInPaymentRequest_CallCorrectlyWhenBatchExists()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            customerBatch.Id = 123;
            var paymentRequests = new List<PaymentRequest>
            {
                CreatePaymentRequest("2", 1, 1, "")
            };

            paymentRequests[0].SetCustomer(customer);
            paymentRequests[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            paymentRequests[0].ExternalBatchId = "blah";

            var paymentRequestToProcess = new PaymentRequestToProcess();
            paymentRequestToProcess.CreatedOnUtc = DateTime.UtcNow;
            paymentRequestToProcess.BatchId = customerBatch.Id;
            PaymentRequestMapper.Instance = MockRepository.GenerateMock<IPaymentRequestMapper>();

            paymentRequestToProcess.ProcessCustomerInPaymentRequest(paymentRequests, "ACH", customerBatch);

            PaymentRequestMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance = null;
        }

        [Test]
        public void ProcessCustomerInPaymentRequest_MakeRequestAsFailed()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequests = new List<PaymentRequest>
            {
                CreatePaymentRequest("2", 1, 1, "")
            };

            paymentRequests[0].SetCustomer(new Customer {Id=123,PartnerAssignedCustomerId = "Test"});
            paymentRequests[0].ExternalBatchId = "blah";

            var paymentRequestToProcess = new PaymentRequestToProcess();
            paymentRequestToProcess.CreatedOnUtc = DateTime.UtcNow;

            paymentRequestToProcess.ProcessCustomerInPaymentRequest(paymentRequests, "ACH", customerBatch);

            Assert.True(paymentRequests[0].HasFailed);
        }

        [Test]
        public void ProcessCustomerInPaymentRequest_ThrowsExceptionWhenBatchNotFound()
        {
            var customer = CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequests = new List<PaymentRequest>
            {
                CreatePaymentRequest("2", 1, 1, "")
            };

            paymentRequests[0].SetCustomer(new Customer {Id = 123, PartnerAssignedCustomerId = "Test"});
            paymentRequests[0].ExternalBatchId = "blah";

            var paymentRequestToProcess = new PaymentRequestToProcess {CreatedOnUtc = DateTime.UtcNow};

            paymentRequestToProcess.ProcessCustomerInPaymentRequest(paymentRequests, "ACH", customerBatch);

            Assert.True(paymentRequests[0].HasFailed);
        }

        private Customer CreateCustomer()
        {
            return new Customer
            {
                Name = "BLEH",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1),
                PartnerAssignedCustomerId = "BLAHBLEH",
                CountryCode = "US",
                SettlementCurrency = Currency.USD
            };
            
        }

        private PaymentRequest CreatePaymentRequest(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            return new PaymentRequest
            {
                ItemIndex = itemIndex,
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerAssignedCustomerId = "BLAHBLAH",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "ach",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                FixedAmount = 100,
                CurrencyCode = "USD",
                RemittanceData = new List<RemittanceReference>
                    {
                        new RemittanceReference { Reference = "ref1" }, 
                        new RemittanceReference { Reference = "ref2" }
                    }
            };
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddress(),
                BankBranchCode = "br code",
                BankAccountOwnerName = "bank account code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                IntermediaryBank = CreateIntermediaryBank(),
                VersionedOn = "2016-05-23T00:00:00Z"
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

        private IntermediaryBank CreateIntermediaryBank()
        {
            return new IntermediaryBank
            {
                AccountNumber = "acct no",
                Address = CreateAddress(),
                BankCode = "bnk code",
                BankName = "bnk name"
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                PhoneNumber = "123",
                Type = "individual",
                VersionedOn = "2016-05-23T00:00:00Z"
            };
        }
    }
}
