﻿using System;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration
{
    [TestFixture]
    public class CustomerBatchCurrencyMapperFixture
    {

        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            PaymentRequestMapper.Instance = MockRepository.GenerateStub<IPaymentRequestMapper>();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now);
            ServiceCallContextManager.Instance.CurrentContext.Partner = new Partner { Id = 1 };
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentRequestMapper.Instance = null;

            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
            CurrencyCache.Instance = null;
        }

        [Test]
        public void InsertCustomerBatchCurrency_Works()
        {

            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1),
                SettlementCurrency = Currency.USD
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            Assert.DoesNotThrow(()=>CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(
                customerBatch.Id, 
                new Money(Currency.CAD, 100), 
                new Money(Currency.USD, 100), 
                new Money(Currency.USD, 0), 
                true));

            var aggregates =
                CustomerBatchCurrencyMapper.Instance.GetCustomerBatchCurrencyAggregatesByBatchId(customerBatch.Id);
            Assert.AreEqual(1, aggregates.Count);
            Assert.AreEqual(Currency.CAD.Code, aggregates[0].TotalPaymentsMoney.Currency.Code);
            Assert.AreEqual(100, aggregates[0].TotalPaymentsMoney.NonDecimalAmount);
            Assert.AreEqual(0, aggregates[0].TotalOrdersMoney.NonDecimalAmount);
            Assert.True(aggregates[0].CustomerBatchId != 0);

        }

    
    }
}
