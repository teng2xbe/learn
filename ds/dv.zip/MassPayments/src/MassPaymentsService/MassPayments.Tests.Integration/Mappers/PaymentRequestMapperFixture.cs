﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Utilities;
using MassPayments.Tests.Integration.Mappers.Helpers;
using Newtonsoft.Json;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Transactions;
using Address = MassPayments.Domain.Entities.PaymentRequest.Address;
using BankAccount = MassPayments.Domain.Entities.PaymentRequest.BankAccount;
using Beneficiary = MassPayments.Domain.Entities.PaymentRequest.Beneficiary;
using Partner = MassPayments.Domain.Entities.Partner;
using MassPayments.Infrastructure;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class PaymentRequestMapperFixture
    {
        private TransactionScope transactionScope;
        private DateTime timeStamp;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 1, Name = "HyperWallet" });

            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            ServiceCallContextManager.Instance = null;
            ValidationRules.Instance = null;

            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void InsertPaymentRequest_CanInsertCorrectly()
        {
            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePayment("2", 0) }
            };

            var paymentRequestId = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            var selectStatement = string.Format("SELECT * FROM MP.PaymentRequest WHERE Id = {0}", paymentRequestId);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(paymentRequestId, Convert.ToInt32(reader["Id"]));
                    AssertRequest(request, (PaymentRequestToProcess)JsonConvert.DeserializeObject(Convert.ToString(reader["JsonRequest"]), jsonSerializerSettings));
                    Assert.AreEqual(request.PaymentCount, Convert.ToInt32(reader["PaymentCount"]));
                }
            }
        }

        [Test]
        public void GetPaymentRequestForProcessing_CanGetCorrectly()
        {
            var payment2 = CreatePayment("2", 0);
            payment2.IsFixedAmountInSettlementCurrency = true;

            var request1 = new PaymentRequestToProcess
            {
                Id = 1,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { payment2 }
            };

            var request2 = new PaymentRequestToProcess
            {
                Id = 2,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow.AddMinutes(10),
                PaymentsToProcess = new List<PaymentRequest> { CreatePayment("3", 0), CreatePayment("4", 1) }
            };

            var request3 = new PaymentRequestToProcess
            {
                Id = 3,
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow.AddMinutes(20),
                PaymentsToProcess = new List<PaymentRequest> { CreatePayment("6", 0) }
            };

            PaymentRequestMapper.Instance.InsertPaymentRequest(request1);
            PaymentRequestMapper.Instance.InsertPaymentRequest(request2);
            PaymentRequestMapper.Instance.InsertPaymentRequest(request3);

            var result = PaymentRequestMapper.Instance.GetPaymentRequestForProcessing(2);

            Assert.AreEqual(2, result.Count);
            AssertRequest(request1, result[0]);
            AssertRequest(request2, result[1]);
            AssertPayment(request2.PaymentsToProcess[1], result[1].PaymentsToProcess[1]);
            Assert.IsTrue(result[0].PaymentsToProcess[0].IsFixedAmountInSettlementCurrency);
        }

        [Test]
        public void ArchivePaymentRequest_Correctly()
        {
            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePayment("2", 0) }
            };

            var paymentRequestId = PaymentRequestMapper.Instance.InsertPaymentRequest(request);
            var paymentRequest = PaymentRequestMapper.Instance.GetPaymentRequestForProcessing(1);

            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest[0], FileStatus.Processed, "success");

            var selectStatement = $"SELECT * FROM MP.PaymentRequestArchive WHERE Id = '{paymentRequest[0].Id}'";
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual((int)FileStatus.Processed, DbReadingUtility.NullableInt(reader["processStatus"]));
                    Assert.AreEqual("success", DbReadingUtility.NullableString(reader["statusMessage"]));
                    Assert.AreEqual(request.PaymentCount, DbReadingUtility.NullableInt(reader["paymentCount"]));
                }
            }

            var selectDetail = $"SELECT * FROM MP.PaymentRequestArchiveDetail WHERE PaymentRequestId = {paymentRequest[0].Id} AND PaymentId = '2'";
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectDetail, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(paymentRequest[0].Id, DbReadingUtility.NullableInt(reader["PaymentRequestId"]));
                    Assert.AreEqual("2", DbReadingUtility.NullableString(reader["PaymentId"]));
                }
            }

        }

        [Test]
        public void RemoveZombiePaymentRequest_Works()
        {
            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePayment("2", 0) }
            };

            var paymentRequestId = PaymentRequestMapper.Instance.InsertPaymentRequest(request);
            var insertIntoArchive = string.Format("INSERT INTO MP.PaymentRequestArchive (Id,CreatedOnUtc,PartnerId,JsonRequest,ProcessStatus,StatusMessage,ProcessedOnUtc) VALUES ({0}, '{1}', {2}, '{3}',{4},'{5}','{6}')", paymentRequestId, DateTime.Now, request.PartnerId, "Blah", 3, "BLah", DateTime.UtcNow);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(insertIntoArchive, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                command.ExecuteNonQuery();
            }

            var removedIds = PaymentRequestMapper.Instance.RemoveProcessedRequests(new List<PaymentRequestToProcess> { new PaymentRequestToProcess { Id = paymentRequestId } });
            Assert.AreEqual(1, removedIds.Count);
            Assert.AreEqual(paymentRequestId, removedIds[0]);
        }

        [Test]
        public void LogPaymentProcessing_Correctly()
        {
            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { CreatePayment("2", 0) }
            };

            var paymentRequestId = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            PaymentRequestMapper.Instance.LogPaymentRequestProcessing(paymentRequestId, string.Format("Started processing: {0}", paymentRequestId));

            var selectStatement = string.Format("SELECT * FROM MP.PaymentRequestProcessingLog WHERE PaymentRequestId = {0}", paymentRequestId);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(paymentRequestId, DbReadingUtility.NullableInt(reader["PaymentRequestId"]));
                    Assert.AreEqual(string.Format("Started processing: {0}", paymentRequestId), DbReadingUtility.NullableString(reader["Message"]));
                }
            }
        }

        [Test]
        public void InsertPaymentRequestCustomerBatch_CanInsertCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,

                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };

            var id1 = CustomerMapper.Instance.InsertCustomer(customer);
            customer.PartnerAssignedCustomerId = "EXT2";
            var id2 = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch1 = new CustomerBatch { CustomerId = id1, ExternalId = "External", ExternalCustomerId = "test", CreatedOnUTC = DateTime.UtcNow, BatchType = BatchType.PaymentRequest };
            var customerBatch2 = new CustomerBatch { CustomerId = id2, ExternalId = "External", ExternalCustomerId = "test", CreatedOnUTC = DateTime.UtcNow, BatchType = BatchType.PaymentRequest };

            var customerBatches = CustomerBatchMapper.Instance.InsertCustomerBatches(new List<CustomerBatch> { customerBatch1, customerBatch2 });

            var request = new PaymentRequestToProcess
            {
                PartnerId = ServiceCallContextManager.Instance.CurrentContext.Partner.Id,
                CreatedOnUtc = ServiceCallContextManager.Instance.CurrentContext.DateTime.ToUniversalTime(),
                PaymentsToProcess = new List<PaymentRequest> { CreatePayment("2", 0) }
            };

            var paymentRequestId = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(customerBatches.Select(i => i.Id).ToList(), paymentRequestId);

            var selectStatement = string.Format("SELECT * FROM MP.PaymentRequestCustomerBatch WHERE PaymentRequestId = {0}", paymentRequestId);
            var result = new List<int>();
            var resultRequestId = 0;
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    while (reader.Read())
                    {
                        result.Add(Convert.ToInt32(reader["CustomerBatchId"]));
                        resultRequestId = Convert.ToInt32(reader["PaymentRequestId"]);
                    }
                }
            }
            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.Contains(customerBatches[0].Id));
            Assert.IsTrue(result.Contains(customerBatches[1].Id));
            Assert.AreEqual(paymentRequestId, resultRequestId);
            Assert.AreNotEqual(0, resultRequestId);
        }

        [Test]
        public void GetFailedPaymentRequestByCustomerBatchAndPaymentId_ReturnsCorrectData()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);

            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I hate gorillas!");
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);

            var failedPaymentRequest = PaymentRequestMapper.Instance.GetFailedPaymentRequest(batch, paymentRequest.PaymentsToProcess[0].PaymentId);

            Assert.IsNotNull(failedPaymentRequest);
            Assert.AreEqual("oops", failedPaymentRequest.Message);
        }

        [Test]
        public void GetFailedPaymentRequestsByCustomerBatchAndPaymentId_ReturnsCorrectData()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);

            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I hate gorillas!");
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);

            var failedPaymentRequest = PaymentRequestMapper.Instance.GetFailedPaymentRequests(batch, new List<string> { paymentRequest.PaymentsToProcess[0].PaymentId });

            Assert.IsNotNull(failedPaymentRequest);
            Assert.AreEqual("oops", failedPaymentRequest[0].Message);
        }

        [Test]
        public void GetFailedPaymentRequestsByCustomerBatchAndPaymentId_ReturnsCorrectDataForMultipleIds()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            var extraPayment = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer).PaymentsToProcess[0];

            extraPayment.PaymentId = "222";
            paymentRequest.PaymentsToProcess.Add(extraPayment);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");
            paymentRequest.PaymentsToProcess[1].RecordFailedValidation("oops, I did it again!");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I hate gorillas!");
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);

            var failedPaymentRequest = PaymentRequestMapper.Instance.GetFailedPaymentRequests(batch, new List<string> { "111", "222" });

            Assert.IsNotNull(failedPaymentRequest);
            Assert.AreEqual(2, failedPaymentRequest.Count);
            Assert.AreEqual("oops", failedPaymentRequest[0].Message);
            Assert.AreEqual("oops, I did it again!", failedPaymentRequest[1].Message);
        }

        [Test]
        public void GetFailedPaymentRequestsByCustomerBatchAndPaymentId_ReturnsSingleFailedPaymentCorrectDataForMultipleIds()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            var extraPayment = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer).PaymentsToProcess[0];

            extraPayment.PaymentId = "222";
            paymentRequest.PaymentsToProcess.Add(extraPayment);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I hate gorillas!");
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);

            var failedPaymentRequest = PaymentRequestMapper.Instance.GetFailedPaymentRequests(batch, new List<string> { "111", "222" });

            Assert.IsNotNull(failedPaymentRequest);
            Assert.AreEqual(1, failedPaymentRequest.Count);
            Assert.AreEqual("oops", failedPaymentRequest[0].Message);
        }

        [Test]
        public void GetFailedPaymentRequests_ReturnsAllFailedPaymentRequests()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            var extraPayment = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer).PaymentsToProcess[0];

            extraPayment.PaymentId = "222";
            paymentRequest.PaymentsToProcess.Add(extraPayment);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");
            paymentRequest.PaymentsToProcess[1].RecordFailedValidation("oops, I did it again!");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I hate gorillas!");
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);

            const int maxRecords = 1000;
            var failedPaymentRequest = PaymentRequestMapper.Instance.GetFailedPaymentRequests(batch, maxRecords);

            Assert.IsNotNull(failedPaymentRequest);
            Assert.AreEqual(2, failedPaymentRequest.Count);
            Assert.AreEqual("oops", failedPaymentRequest[0].Message);
            Assert.AreEqual("oops, I did it again!", failedPaymentRequest[1].Message);
        }

        [Test]
        public void GetFailedPaymentRequests_ReturnsMaxNumberOfFailedPaymentRequests()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            var extraPayment1 = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer).PaymentsToProcess[0];
            var extraPayment2 = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer).PaymentsToProcess[0];

            extraPayment1.PaymentId = "222";
            extraPayment2.PaymentId = "333";
            paymentRequest.PaymentsToProcess.Add(extraPayment1);
            paymentRequest.PaymentsToProcess.Add(extraPayment2);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");
            paymentRequest.PaymentsToProcess[1].RecordFailedValidation("oops, I did it again!");
            paymentRequest.PaymentsToProcess[2].RecordFailedValidation("and again!");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I hate gorillas!");
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);

            const int maxRecords = 2;
            var failedPaymentRequest = PaymentRequestMapper.Instance.GetFailedPaymentRequests(batch, maxRecords);

            Assert.IsNotNull(failedPaymentRequest);
            Assert.AreEqual(2, failedPaymentRequest.Count);
            Assert.AreEqual("oops", failedPaymentRequest[0].Message);
            Assert.AreEqual("oops, I did it again!", failedPaymentRequest[1].Message);
        }

        [Test]
        public void GetFailedPaymentRequests_ReturnsAllFailedPaymentRequestsWhenOnlyOneHasFailed()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            var extraPayment = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer).PaymentsToProcess[0];

            extraPayment.PaymentId = "222";
            paymentRequest.PaymentsToProcess.Add(extraPayment);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "I hate gorillas!");
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);

            const int maxRecords = 1000;
            var failedPaymentRequest = PaymentRequestMapper.Instance.GetFailedPaymentRequests(batch, maxRecords);

            Assert.IsNotNull(failedPaymentRequest);
            Assert.AreEqual(1, failedPaymentRequest.Count);
            Assert.AreEqual("oops", failedPaymentRequest[0].Message);
        }

        [Test]
        public void LogNotAcceptedPayments_InsertsCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);                     
           
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("oops");

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest.Id);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.FailedToProcess, "I hate gorillas!");

            var failedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            failedPayments[0].SetCustomer(customer);
            failedPayments[0].PartnerId = 1234;

            PaymentRequestMapper.Instance.LogNotAcceptedPayments(failedPayments);

            var selectStatement = string.Format("SELECT * FROM MP.NotAcceptedPaymentLog WHERE PaymentId = {0}", failedPayments[0].PaymentId);
            var result = new List<PaymentRequest>();
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    while (reader.Read())
                    {
                        var retrievedPaymentRequest =  new PaymentRequest {
                            PaymentId = Convert.ToString(reader["PaymentId"]),
                            PartnerId = Convert.ToInt32(reader["PartnerId"]),
                            PaymentRequestArchiveDetailId = Convert.ToInt32(reader["PaymentRequestArchiveDetailId"])
                        };

                        retrievedPaymentRequest.SetCustomer(new Customer { Id = Convert.ToInt32(reader["CustomerId"]) });

                        result.Add(retrievedPaymentRequest);                        
                    }
                }
            }

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(customer.Id, result[0].Customer.Id);
            Assert.AreEqual(failedPayments[0].PartnerId, result[0].PartnerId);
            Assert.AreEqual(failedPayments[0].PaymentId, result[0].PaymentId);
            Assert.AreEqual(failedPayments[0].PaymentRequestArchiveDetailId, result[0].PaymentRequestArchiveDetailId);
        }

        [Test]
        public void LogNotAcceptedPayments_UpdatesCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest1 = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            var paymentRequest2 = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            

            paymentRequest1.PaymentsToProcess[0].RecordFailedValidation("oops");
            paymentRequest2.PaymentsToProcess = paymentRequest1.PaymentsToProcess;

            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest1.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest1);
            paymentRequest2.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest2);
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest1.Id);
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest2.Id);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest1, FileStatus.FailedToProcess, "I hate gorillas!");
            var failedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest1.Id);
            var prevPaymentRequestArchiveDetailId = failedPayments[0].PaymentRequestArchiveDetailId;
            failedPayments[0].SetCustomer(customer);
            failedPayments[0].PartnerId = 1234;

            //insert
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(failedPayments);

            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest2, FileStatus.FailedToProcess, "I hate gorillas!");
            failedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest2.Id);
            failedPayments[0].SetCustomer(customer);
            failedPayments[0].PartnerId = 1234;
            
            //update
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(failedPayments);

            var selectStatement = string.Format("SELECT * FROM MP.NotAcceptedPaymentLog WHERE PaymentId = {0}", failedPayments[0].PaymentId);
            var result = new List<PaymentRequest>();
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    while (reader.Read())
                    {
                        var retrievedPaymentRequest = new PaymentRequest
                        {
                            PaymentId = Convert.ToString(reader["PaymentId"]),
                            PartnerId = Convert.ToInt32(reader["PartnerId"]),
                            PaymentRequestArchiveDetailId = Convert.ToInt32(reader["PaymentRequestArchiveDetailId"])
                        };

                        retrievedPaymentRequest.SetCustomer(new Customer { Id = Convert.ToInt32(reader["CustomerId"]) });

                        result.Add(retrievedPaymentRequest);
                    }
                }
            }

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(customer.Id, result[0].Customer.Id);
            Assert.AreEqual(failedPayments[0].PartnerId, result[0].PartnerId);
            Assert.AreEqual(failedPayments[0].PaymentId, result[0].PaymentId);
            Assert.AreNotEqual(prevPaymentRequestArchiveDetailId, result[0].PaymentRequestArchiveDetailId);
            Assert.AreEqual(failedPayments[0].PaymentRequestArchiveDetailId, result[0].PaymentRequestArchiveDetailId);
        }

        [Test]
        public void DeleteAcceptedPaymentsFromLog_Correctly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest1 = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
                        
            paymentRequest1.PaymentsToProcess[0].RecordFailedValidation("oops");
            
            CustomerBatchMapper.Instance.InsertCustomerBatch(batch);
            paymentRequest1.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest1);
            PaymentRequestMapper.Instance.InsertPaymentRequestCustomerBatch(new List<int> { batch.Id }, paymentRequest1.Id);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest1, FileStatus.FailedToProcess, "I hate gorillas!");
            var failedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest1.Id);
            failedPayments[0].SetCustomer(customer);
            failedPayments[0].PartnerId = 1234;

            //insert
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(failedPayments);           

            //update
            PaymentRequestMapper.Instance.DeleteAcceptedPaymentsFromLog(failedPayments);

            var selectStatement = $"SELECT * FROM MP.NotAcceptedPaymentLog WHERE PaymentId = {failedPayments[0].PaymentId}";

            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                Assert.IsEmpty(reader);
            }            
        }

        [Test]
        public void DeleteAcceptedPaymentsFromLog_OnlyDeletesTheRecordWeRequested()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var paymentRequest = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer);
            var successfulPayment = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1234, customer).PaymentsToProcess[0];
            paymentRequest.PaymentsToProcess[0].PartnerId = customer.PartnerId;
            paymentRequest.PaymentsToProcess[0].SetCustomer(customer);
            paymentRequest.PaymentsToProcess[0].RecordFailedValidation("uh oh...");
            successfulPayment.PaymentId = "1111";
            successfulPayment.PartnerId = customer.PartnerId;
            successfulPayment.SetCustomer(customer);
            paymentRequest.PaymentsToProcess.Add(successfulPayment);

            paymentRequest.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(paymentRequest);
            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequest, FileStatus.Processed, "Good day to you sir!");
            var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(paymentRequest.Id);

            paymentRequest.PaymentsToProcess[0].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            paymentRequest.PaymentsToProcess[1].PaymentRequestArchiveDetailId = archivedPayments[0].PaymentRequestArchiveDetailId;
            PaymentRequestMapper.Instance.LogNotAcceptedPayments(paymentRequest.PaymentsToProcess);
            
            //update
            PaymentRequestMapper.Instance.DeleteAcceptedPaymentsFromLog(new List<PaymentRequest> {successfulPayment});

            var selectStatement = "SELECT * FROM MP.NotAcceptedPaymentLog";

            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                Assert.IsNotEmpty(reader);

                while (reader.Read())
                {
                    Assert.AreEqual(successfulPayment.PaymentId, Convert.ToString(reader["PaymentId"]));
                }
            }            
        }
        
        private void AssertRequest(PaymentRequestToProcess paymentRequestToProcessExpected, PaymentRequestToProcess paymentRequestToProcessActual)
        {
            Assert.AreEqual(paymentRequestToProcessExpected.PartnerId, paymentRequestToProcessActual.PartnerId);
            Assert.AreEqual(paymentRequestToProcessExpected.CreatedOnUtc, paymentRequestToProcessActual.CreatedOnUtc);
            if ((paymentRequestToProcessExpected.PaymentsToProcess != null) && (paymentRequestToProcessActual.PaymentsToProcess != null))
                AssertPayment(paymentRequestToProcessExpected.PaymentsToProcess[0], paymentRequestToProcessActual.PaymentsToProcess[0]);
        }

        private void AssertPayment(PaymentRequest paymentRequestExpected, PaymentRequest paymentRequestActual)
        {
            Assert.AreEqual(paymentRequestExpected.ItemIndex, paymentRequestActual.ItemIndex);
            Assert.AreEqual(paymentRequestExpected.PartnerAssignedCustomerId, paymentRequestActual.PartnerAssignedCustomerId);
            Assert.AreEqual(paymentRequestExpected.PartnerReference, paymentRequestActual.PartnerReference);
            Assert.AreEqual(paymentRequestExpected.PaymentMethod, paymentRequestActual.PaymentMethod);
            Assert.AreEqual(paymentRequestExpected.PaymentId, paymentRequestActual.PaymentId);
            Assert.AreEqual(paymentRequestExpected.FixedAmount, paymentRequestActual.FixedAmount);
            Assert.AreEqual(paymentRequestExpected.CurrencyCode, paymentRequestActual.CurrencyCode);
            Assert.AreEqual(paymentRequestExpected.PurposeOfPayment, paymentRequestActual.PurposeOfPayment);
            Assert.AreEqual(paymentRequestExpected.InstructionForBank, paymentRequestActual.InstructionForBank);
            Assert.AreEqual(paymentRequestExpected.InstructionCodeForBank, paymentRequestActual.InstructionCodeForBank);

            AssertBeneficiary(paymentRequestExpected.Beneficiary, paymentRequestActual.Beneficiary);
            AssertBankAccount(paymentRequestExpected.BankAccount, paymentRequestActual.BankAccount);
            AssertRemittanceReferences(paymentRequestExpected.RemittanceData, paymentRequestActual.RemittanceData);
        }

        private void AssertBeneficiary(Beneficiary beneficiaryExpected, Beneficiary beneficiaryActual)
        {
            Assert.AreEqual(beneficiaryExpected.Id, beneficiaryActual.Id);
            Assert.AreEqual(beneficiaryExpected.VersionedOn, beneficiaryActual.VersionedOn);
            Assert.AreEqual(beneficiaryExpected.EmailAddress, beneficiaryActual.EmailAddress);
            Assert.AreEqual(beneficiaryExpected.Type, beneficiaryActual.Type);
            Assert.AreEqual(beneficiaryExpected.FirstName, beneficiaryActual.FirstName);
            Assert.AreEqual(beneficiaryExpected.MiddleName, beneficiaryActual.MiddleName);
            Assert.AreEqual(beneficiaryExpected.LastName, beneficiaryActual.LastName);
            Assert.AreEqual(beneficiaryExpected.PhoneNumber, beneficiaryActual.PhoneNumber);
            Assert.AreEqual(beneficiaryExpected.CellNumber, beneficiaryActual.CellNumber);
            Assert.AreEqual(beneficiaryExpected.DateOfBirth, beneficiaryActual.DateOfBirth);
            Assert.AreEqual(beneficiaryExpected.Gender, beneficiaryActual.Gender);
            Assert.AreEqual(beneficiaryExpected.BusinessName, beneficiaryActual.BusinessName);
            Assert.AreEqual(beneficiaryExpected.BusinessRegistrationNumber, beneficiaryActual.BusinessRegistrationNumber);
            Assert.AreEqual(beneficiaryExpected.BusinessRegistrationCountry, beneficiaryActual.BusinessRegistrationCountry);
            Assert.AreEqual(beneficiaryExpected.BusinessRegistrationStateProv, beneficiaryActual.BusinessRegistrationStateProv);
            Assert.AreEqual(beneficiaryExpected.BusinessContactRole, beneficiaryActual.BusinessContactRole);
            Assert.AreEqual(beneficiaryExpected.Industry, beneficiaryActual.Industry);
            AssertAddress(beneficiaryExpected.Address, beneficiaryActual.Address);
        }

        private void AssertBankAccount(BankAccount bankAccountExpected, BankAccount bankAccountActual)
        {
            Assert.AreEqual(bankAccountExpected.Id, bankAccountActual.Id);
            Assert.AreEqual(bankAccountExpected.VersionedOn, bankAccountActual.VersionedOn);
            Assert.AreEqual(bankAccountExpected.AccountNumber, bankAccountActual.AccountNumber);
            Assert.AreEqual(bankAccountExpected.AccountType, bankAccountActual.AccountType);
            Assert.AreEqual(bankAccountExpected.BankName, bankAccountActual.BankName);
            Assert.AreEqual(bankAccountExpected.BranchName, bankAccountActual.BranchName);
            Assert.AreEqual(bankAccountExpected.BankCode, bankAccountActual.BankCode);
            Assert.AreEqual(bankAccountExpected.BankBranchCode, bankAccountActual.BankBranchCode);
            AssertAddress(bankAccountExpected.BankAddress, bankAccountActual.BankAddress);
            AssertIntermediaryBank(bankAccountExpected.IntermediaryBank, bankAccountActual.IntermediaryBank);
        }

        private void AssertAddress(Address addressExpected, Address addressActual)
        {
            Assert.AreEqual(addressExpected.AddressLine1, addressActual.AddressLine1);
            Assert.AreEqual(addressExpected.AddressLine2, addressActual.AddressLine2);
            Assert.AreEqual(addressExpected.AddressLine3, addressActual.AddressLine3);
            Assert.AreEqual(addressExpected.City, addressActual.City);
            Assert.AreEqual(addressExpected.StateOrPovince, addressActual.StateOrPovince);
            Assert.AreEqual(addressExpected.ZipOrPostalCode, addressActual.ZipOrPostalCode);
            Assert.AreEqual(addressExpected.CountryCode, addressActual.CountryCode);
        }

        private void AssertIntermediaryBank(IntermediaryBank intermediaryBankExpected, IntermediaryBank intermediaryBankActual)
        {
            Assert.AreEqual(intermediaryBankExpected.BankName, intermediaryBankActual.BankName);
            Assert.AreEqual(intermediaryBankExpected.BankCode, intermediaryBankActual.BankCode);
            Assert.AreEqual(intermediaryBankExpected.AccountNumber, intermediaryBankActual.AccountNumber);
            AssertAddress(intermediaryBankExpected.Address, intermediaryBankActual.Address);
        }

        private void AssertRemittanceReferences(List<RemittanceReference> referencesExpected, List<RemittanceReference> referencesActual)
        {
            if ((referencesExpected == null) || (referencesActual == null)) return;
            for (var i = 0; i < referencesActual.Count; i++)
            {
                AssertRemittanceReference(referencesExpected[i], referencesActual[i]);
            }
        }

        private void AssertRemittanceReference(RemittanceReference referenceExpected, RemittanceReference referenceActual)
        {
            if ((referenceExpected != null) && (referenceActual != null))
                Assert.AreEqual(referenceExpected.Reference, referenceActual.Reference);
        }

        private PaymentRequest CreatePayment(string externalPaymentId, int itemIndex)
        {
            return new PaymentRequest
            {
                ItemIndex = itemIndex,
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerAssignedCustomerId = "123",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "pymt mtd",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                FixedAmount = 100,
                CurrencyCode = "CAD",
                RemittanceData = new List<RemittanceReference>
                    {
                        new RemittanceReference { Reference = "ref1" },
                        new RemittanceReference { Reference = "ref2" }
                    },
                RemittanceType = "CTX"
            };
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "savings",
                BankAddress = CreateAddress(),
                BankBranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                IntermediaryBank = CreateIntermediaryBank(),
                VersionedOn = DateTime.UtcNow.ToString(),
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

        private IntermediaryBank CreateIntermediaryBank()
        {
            return new IntermediaryBank
            {
                AccountNumber = "acct no",
                Address = CreateAddress(),
                BankCode = "bnk code",
                BankName = "bnk name"
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                VersionedOn = DateTime.UtcNow.ToString(),
                PhoneNumber = "123",
                Type = "I/B"
            };
        }

        private static readonly JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
        {
            TypeNameHandling = TypeNameHandling.All,
            TypeNameAssemblyFormat = FormatterAssemblyStyle.Simple
        };
    }
}

