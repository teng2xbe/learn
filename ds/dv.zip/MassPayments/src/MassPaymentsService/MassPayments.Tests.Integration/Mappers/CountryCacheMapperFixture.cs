﻿using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class CountryCacheMapperFixture
    {
        [Test]
        public void AllTheCorrectCountriesAreThere()
        {
            var countries = CountryCacheMapper.Instance.GetCountriesRequiringRegionsList();

            Assert.AreEqual(4, countries.Count);
            Assert.IsTrue(countries.Contains("CA"));
            Assert.IsTrue(countries.Contains("US"));
            Assert.IsTrue(countries.Contains("MX"));
            Assert.IsTrue(countries.Contains("AU"));
        }
    }
}
