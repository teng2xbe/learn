﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class CustomerMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void GetCustomer_ReturnsCorrectData_AfterInsert()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(1);
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "BLAH",
                Status = CustomerStatus.Disabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                CountryCode = "ABC",
                SettlementCurrency = Currency.EUR
            };
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            Customer loadedCustomer = CustomerMapper.Instance.GetCustomer(customer.Id);

            Assert.AreEqual("Cats Meowingshire", loadedCustomer.Name);
            Assert.AreEqual(1, loadedCustomer.TransactionSystemCustomerId);
            Assert.AreEqual("BLAH", loadedCustomer.PartnerAssignedCustomerId);
            Assert.AreEqual(customer.Id, loadedCustomer.Id);
            Assert.AreEqual(CustomerStatus.Disabled, loadedCustomer.Status);
            Assert.AreEqual(customer.PartnerId, loadedCustomer.PartnerId);
            Assert.AreEqual(ttlExpiration, loadedCustomer.TTLExpiration);
            Assert.AreEqual("ABC", loadedCustomer.CountryCode);
            Assert.AreEqual(Currency.EUR, loadedCustomer.SettlementCurrency);
        }

        [Test]
        public void InsertCustomer_AcceptsNull_ForCountryCode()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(1);
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "BLAH",
                Status = CustomerStatus.Disabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                CountryCode = null
            };
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            Customer loadedCustomer = CustomerMapper.Instance.GetCustomer(customer.Id);

            Assert.AreEqual("Cats Meowingshire", loadedCustomer.Name);
            Assert.AreEqual(1, loadedCustomer.TransactionSystemCustomerId);
            Assert.AreEqual("BLAH", loadedCustomer.PartnerAssignedCustomerId);
            Assert.AreEqual(customer.Id, loadedCustomer.Id);
            Assert.AreEqual(CustomerStatus.Disabled, loadedCustomer.Status);
            Assert.AreEqual(customer.PartnerId, loadedCustomer.PartnerId);
            Assert.AreEqual(ttlExpiration, loadedCustomer.TTLExpiration);
            Assert.IsNull(loadedCustomer.CountryCode);
        }

        [Test]
        public void GetCustomerByPartner_ReturnsCorrectData_AfterInsert()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(1);
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Disabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                PartnerAssignedCustomerId = "RandomCustomerId",
                TransactionSystemCustomerExternalId = "CCTBLAH",
                CountryCode = "CA",
                SettlementCurrency = Currency.GBP
            };
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            Customer loadedCustomer = CustomerMapper.Instance.GetCustomerByPartner(new Partner {Id = 1}, customer.PartnerAssignedCustomerId);

            Assert.AreEqual("Cats Meowingshire", loadedCustomer.Name);
            Assert.AreEqual(1, loadedCustomer.TransactionSystemCustomerId);
            Assert.AreEqual(customer.Id, loadedCustomer.Id);
            Assert.AreEqual(CustomerStatus.Disabled, loadedCustomer.Status);
            Assert.AreEqual(customer.PartnerId, loadedCustomer.PartnerId);
            Assert.AreEqual(ttlExpiration, loadedCustomer.TTLExpiration);
            Assert.AreEqual(customer.PartnerAssignedCustomerId, loadedCustomer.PartnerAssignedCustomerId);
            Assert.AreEqual(customer.TransactionSystemCustomerExternalId,
                            loadedCustomer.TransactionSystemCustomerExternalId);
            Assert.AreEqual("CA", loadedCustomer.CountryCode);
            Assert.AreEqual(Currency.GBP, loadedCustomer.SettlementCurrency);

        }

        [Test]
        public void GetCustomersByPartnerAndCustomerIds_Works()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(1);
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Disabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                PartnerAssignedCustomerId = "RandomCustomerId",
                TransactionSystemCustomerExternalId = "CCTBLAH",
                CountryCode = "Meow",
                SettlementCurrency = Currency.AUD
            };
            var parterAssignedCustomerIds = new List<string> { "Id1", "Id2", "Id3" };
            customer.PartnerAssignedCustomerId = parterAssignedCustomerIds[0];
            var id1 = CustomerMapper.Instance.InsertCustomer(customer);
            customer.PartnerAssignedCustomerId = parterAssignedCustomerIds[1];
            var id2 = CustomerMapper.Instance.InsertCustomer(customer);
            customer.PartnerAssignedCustomerId = parterAssignedCustomerIds[2];
            var id3 = CustomerMapper.Instance.InsertCustomer(customer);

            var loadedCustomers = CustomerMapper.Instance.GetCustomersByPartnerAndCustomerIds(customer.PartnerId, parterAssignedCustomerIds);

            Assert.AreEqual(3, loadedCustomers.Count);

            Assert.IsTrue(loadedCustomers.Select(e => e.Id).Contains(id1));
            Assert.IsTrue(loadedCustomers.Select(e => e.Id).Contains(id2));
            Assert.IsTrue(loadedCustomers.Select(e => e.Id).Contains(id3));

            Assert.IsTrue(loadedCustomers.Select(e => e.PartnerAssignedCustomerId).Contains(parterAssignedCustomerIds[0]));
            Assert.IsTrue(loadedCustomers.Select(e => e.PartnerAssignedCustomerId).Contains(parterAssignedCustomerIds[1]));
            Assert.IsTrue(loadedCustomers.Select(e => e.PartnerAssignedCustomerId).Contains(parterAssignedCustomerIds[2]));
            Assert.IsFalse(loadedCustomers.Select(e => e.PartnerAssignedCustomerId).Contains("ID4"));
                        
            //common
            Assert.AreEqual("Cats Meowingshire", loadedCustomers[0].Name);
            Assert.AreEqual(1, loadedCustomers[0].TransactionSystemCustomerId);
            Assert.AreEqual(CustomerStatus.Disabled, loadedCustomers[0].Status);
            Assert.AreEqual(customer.PartnerId, loadedCustomers[0].PartnerId);
            Assert.AreEqual(ttlExpiration, loadedCustomers[0].TTLExpiration);
            Assert.AreEqual(customer.TransactionSystemCustomerExternalId, loadedCustomers[0].TransactionSystemCustomerExternalId);
            Assert.AreEqual("Meow", loadedCustomers[0].CountryCode);
            Assert.AreEqual(Currency.AUD, loadedCustomers[0].SettlementCurrency);
        }

        [Test]
        public void GetCustomer_LoadsMultipleEmailsCorrectly_AfterSavingCustomerWithMultipleEmails()
        {
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "BLAH",
                Status = CustomerStatus.Disabled,
                TransactionSystemId = 1,
                NotificationEmails = new List<string> { "email1@email.com", "email2@email.com", "email3@email.com" },
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            Customer loadedCustomer = CustomerMapper.Instance.GetCustomer(customer.Id);

            Assert.AreEqual(3, loadedCustomer.NotificationEmails.Count);
            Assert.AreEqual("email1@email.com", loadedCustomer.NotificationEmails[0]);
            Assert.AreEqual("email2@email.com", loadedCustomer.NotificationEmails[1]);
            Assert.AreEqual("email3@email.com", loadedCustomer.NotificationEmails[2]);
        }

        [Test]
        public void GetCustomerByTransactionSystemCustomerId_ReturnsCorrectData_AfterInsert()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(1);
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "BLAH",
                Status = CustomerStatus.Disabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                CountryCode = "CA",
                SettlementCurrency = Currency.EUR
            };
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            Customer loadedCustomer = CustomerMapper.Instance.GetCustomerByTransactionSystemCustomerId(customer.TransactionSystemCustomerId, customer.TransactionSystemId);

            Assert.AreEqual("Cats Meowingshire", loadedCustomer.Name);
            Assert.AreEqual(1, loadedCustomer.TransactionSystemCustomerId);
            Assert.AreEqual("BLAH", loadedCustomer.PartnerAssignedCustomerId);
            Assert.AreEqual(customer.Id, loadedCustomer.Id);
            Assert.AreEqual(CustomerStatus.Disabled, loadedCustomer.Status);
            Assert.AreEqual(customer.PartnerId, loadedCustomer.PartnerId);
            Assert.AreEqual(ttlExpiration, loadedCustomer.TTLExpiration);
            Assert.AreEqual("CA", loadedCustomer.CountryCode);
            Assert.AreEqual(Currency.EUR, loadedCustomer.SettlementCurrency);
        }

        [Test]
        public void UpdateCustomer_ReturnsCorrectData_AfterUpdate()
        {
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "BLAH",
                Status = CustomerStatus.Disabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now,
                CountryCode = "US",
                SettlementCurrency = Currency.AUD
            };

            var customerId = CustomerMapper.Instance.InsertCustomer(customer);

            var insertedCustomer = CustomerMapper.Instance.GetCustomer(customerId);
            Assert.AreEqual("US", insertedCustomer.CountryCode);
            
            DateTime ttlExpiration = DateTime.Today.AddHours(1);
            customer.TTLExpiration = ttlExpiration;
            customer.TransactionSystemCustomerExternalId = "CCTAccountID";
            customer.CountryCode = "CA";
            customer.SettlementCurrency = Currency.EUR;
            
            CustomerMapper.Instance.UpdateCustomer(customer);

            var loadedCustomer = CustomerMapper.Instance.GetCustomer(customer.Id);

            Assert.AreEqual("Cats Meowingshire", loadedCustomer.Name);
            Assert.AreEqual(1, loadedCustomer.TransactionSystemCustomerId);
            Assert.AreEqual("BLAH", loadedCustomer.PartnerAssignedCustomerId);
            Assert.AreEqual(customer.Id, loadedCustomer.Id);
            Assert.AreEqual(CustomerStatus.Disabled, loadedCustomer.Status);
            Assert.AreEqual(customer.PartnerId, loadedCustomer.PartnerId);
            Assert.AreEqual(ttlExpiration, loadedCustomer.TTLExpiration);
            Assert.AreEqual("CCTAccountID", loadedCustomer.TransactionSystemCustomerExternalId);
            Assert.AreEqual("CA", loadedCustomer.CountryCode);
            Assert.AreEqual(Currency.EUR, loadedCustomer.SettlementCurrency);
        }

    }
}
