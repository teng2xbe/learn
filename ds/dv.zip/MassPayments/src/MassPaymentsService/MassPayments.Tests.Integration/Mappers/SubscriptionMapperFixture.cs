﻿using System;
using System.Transactions;
using MassPayments.Domain.Entities.Subscription;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class SubscriptionMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void InsertAndGetApiSubscription_Works()
        {
            var subscription = SubscriptionHelper.Instance.GetApiChannelSubscription(SubscriptionType.FundingStatus);
            SubscriptionMapper.Instance.InsertSubscription(subscription);
            var loadedSubscriptions = SubscriptionMapper.Instance.GetSubScriptionsByType(SubscriptionType.FundingStatus);
            Assert.AreEqual(1, loadedSubscriptions.Count);
            Assert.AreEqual(SubscriptionType.FundingStatus, loadedSubscriptions[0].SubscriptionType);
        }

        [Test]
        public void InsertAndGetApiSubscriptionByPartner_Works()
        {
            var subscription = SubscriptionHelper.Instance.GetApiChannelSubscription(SubscriptionType.FundingStatus);
            SubscriptionMapper.Instance.InsertSubscription(subscription);
            var loadedSubscriptions = SubscriptionMapper.Instance.GetSubScriptionsByTypeAndPartner(SubscriptionType.FundingStatus, subscription.PartnerId);
            Assert.AreEqual(1, loadedSubscriptions.Count);
            Assert.AreEqual(SubscriptionType.FundingStatus, loadedSubscriptions[0].SubscriptionType);
        }

        [Test]
        public void InsertAndGetFileiSubscription_Works()
        {
            var subscription = SubscriptionHelper.Instance.GetFileChannelSubscription(SubscriptionType.FundingStatus);
            SubscriptionMapper.Instance.InsertSubscription(subscription);
            var loadedSubscriptions = SubscriptionMapper.Instance.GetSubScriptionsByType(SubscriptionType.FundingStatus);
            Assert.AreEqual(1, loadedSubscriptions.Count);
            Assert.AreEqual(SubscriptionType.FundingStatus, loadedSubscriptions[0].SubscriptionType);
        }

        [Test]
        public void InsertAndGetEmailSubscription_Works()
        {
            var subscription = SubscriptionHelper.Instance.GetEmailChannelSubscription(SubscriptionType.FundingStatus);
            SubscriptionMapper.Instance.InsertSubscription(subscription);
            var loadedSubscriptions = SubscriptionMapper.Instance.GetSubScriptionsByType(SubscriptionType.FundingStatus);
            Assert.AreEqual(1, loadedSubscriptions.Count);
            Assert.AreEqual(SubscriptionType.FundingStatus, loadedSubscriptions[0].SubscriptionType);
        }

        [Test]
        public void InsertSubscriptionEventAndGet_Works()
        {
            var subscription = SubscriptionHelper.Instance.GetApiChannelSubscription(SubscriptionType.Invoice);
            SubscriptionMapper.Instance.InsertSubscription(subscription);
           
            var jsonEventArgs = "Blah";

            var subscriptionEvent = new SubscriptionEvent
            {
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated,
                JsonEventArguments = jsonEventArgs,
                CreatedOnUtc = DateTime.UtcNow
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent);
            SubscriptionEvent loadedEvent = null;
            Assert.DoesNotThrow(() => loadedEvent = SubscriptionMapper.Instance.GetSubscriptionEventById(subscriptionEvent.Id));
            Assert.True(loadedEvent.SubscriptionEventType == SubscriptionEventType.InvoiceGenerated);
            Assert.True(loadedEvent.Id > 0);
            Assert.True(loadedEvent.JsonEventArguments == jsonEventArgs);

        }
    }
}
