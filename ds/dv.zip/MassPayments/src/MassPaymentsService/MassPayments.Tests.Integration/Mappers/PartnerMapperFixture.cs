﻿using System.Linq;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class PartnerMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void GetPartnerByName_ReturnsProperData()
        {
            Partner partner = PartnerMapper.Instance.GetPartnerByName("HyperWallet");

            Assert.AreEqual(1, partner.Id);
            Assert.AreEqual("HyperWallet", partner.Name);
        }

        [Test]
        public void GetPartnerByName_Throws_ForNonExistingName()
        {
            Assert.Throws<InvalidPartnerNameException>(() => PartnerMapper.Instance.GetPartnerByName("Neko McMeow"));
        }

        [Test]
        public void GetPartnerIdByPrefix_ReturnsProperId()
        {
            var partner = PartnerMapper.Instance.GetPartnerByFilePrefix("HPWL");

            Assert.AreEqual(1, partner.Id);            
        }

        [Test]
        public void GetPartnerIdByCode_ReturnsProperId()
        {
            var partner = PartnerMapper.Instance.GetPartnerByCode("HyperWallet");

            Assert.AreEqual(1, partner.Id);
        }

        [Test]
        public void GetPartnerIdById_ReturnsProperCode()
        {
            var partner = PartnerMapper.Instance.GetPartnerById(1);
            Assert.AreEqual("HyperWallet", partner.Name);
        }

        [Test]
        public void GetPartnerIdByCode_Throws_ForNonExistingCode()
        {
            Assert.Throws<InvalidPartnerCodeException>(() => PartnerMapper.Instance.GetPartnerByCode("NONE"));
        }

        [Test]
        public void GetPartnerById_ReturnsProperInvoiceType()
        {
            var partner = PartnerMapper.Instance.GetPartnerById(1);
            Assert.AreEqual(1, partner.InvoiceTypeId);
            Assert.AreEqual("HyperWallet", partner.Code);
        }

        [Test]
        public void GetPartnerById_Returns_NotEnabledFor3rdPartyRemitter()
        {
            var partner = PartnerMapper.Instance.GetPartnerById(1);
            Assert.IsFalse(partner.IsThirdPartyRemitterEnabled);
        }

        [Test]
        public void GetPartnerById_Returns_CorrectPaymentModelForConcur()
        {
            var partner = PartnerMapper.Instance.GetPartnerById(2);
            Assert.AreEqual(PaymentModel.Decoupled, partner.PaymentModel);
        }

        [Test]
        public void GetPartners_ReturnsAll()
        {
            var partners = PartnerMapper.Instance.GetPartnersDictionary();

            Assert.AreEqual(3, partners.Count);
            var partner = partners.First(i => i.Key == 1).Value;
            Assert.AreEqual("HyperWallet", partner.Code);
            partner = partners.First(i => i.Key == 2).Value;
            Assert.AreEqual("Concur", partner.Code);
            partner = partners.First(i => i.Key == 3).Value;
            Assert.AreEqual("WUBSVTEST", partner.Code);
        }
    }
}
