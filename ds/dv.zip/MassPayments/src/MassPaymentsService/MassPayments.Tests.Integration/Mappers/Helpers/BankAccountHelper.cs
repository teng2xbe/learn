﻿using System;
using System.Data;
using System.Data.SqlClient;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Persistence.Enums;
using MassPayments.Mappers.Utilities;
using MassPayments.Providers.StorageProvider;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public static class BankAccountHelper
    {
        public static BankAccount GetBankAccount(string accountExternalId)
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.BI);
            var selectStatement = string.Format("SELECT * FROM DeltaMPS.BankAccount WHERE BankAccountID = '{0}'", accountExternalId);

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    if (reader.Read())
                        return GetBankAccountFromDataReader(reader);
                }
            }

            return null;
        }

        public static string GetBankAccountPartner(string accountExternalId)
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.BI);
            var selectStatement = string.Format("SELECT * FROM DeltaMPS.BankAccount WHERE BankAccountID = '{0}'", accountExternalId);

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    if (reader.Read())
                        return DbReadingUtility.NullableString(reader["PartnerCode"]);
                }
            }

            return null;
        }

        private static BankAccount GetBankAccountFromDataReader(SqlDataReader reader)
        {
            var bankAddress = new Address
            {
                AddressLine1 = DbReadingUtility.NullableString(reader["AddressLine1"]),
                AddressLine2 = DbReadingUtility.NullableString(reader["AddressLine2"]),
                AddressLine3 = DbReadingUtility.NullableString(reader["AddressLine3"]),
                City = DbReadingUtility.NullableString(reader["BankCity"]),
                StateOrProvince = DbReadingUtility.NullableString(reader["StateOrProv"]),
                ZipOrPostalCode = DbReadingUtility.NullableString(reader["ZipOrPostal"]),
                CountryCode = DbReadingUtility.NullableString(reader["CountryCode"])
            };

            var bankAccount = new BankAccount
            {
                Version = DbReadingUtility.NullableBigInt(reader["VersionNo"]),
                BeneficiaryId = DbReadingUtility.NullableString(reader["BeneficiaryID"]),
                ExternalId = DbReadingUtility.NullableString(reader["BankAccountID"]),
                AccountNumber = DbReadingUtility.NullableString(reader["AccountNumber"]),
                ExternalAccountType = DbReadingUtility.NullableString(reader["AccountType"]),
                AccountPurpose = DbReadingUtility.NullableString(reader["AccountPurpose"]),
                BankName = DbReadingUtility.NullableString(reader["BankName"]),
                BranchName = DbReadingUtility.NullableString(reader["BranchName"]),
                BankAddress = bankAddress,
                BankCode = DbReadingUtility.NullableString(reader["BankCode"]),
                BranchCode = DbReadingUtility.NullableString(reader["BranchCode"])
            };
            return bankAccount;
        }
    }
}
