﻿using System;
using System.Data;
using System.Data.SqlClient;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Persistence.Enums;
using MassPayments.Providers.StorageProvider;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public static class ThirdPartyRemitterHelper
    {
        public static ThirdPartyRemitter GetThirdPartyRemitter(string id)
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.BI);
            var selectStatement = string.Format("SELECT * FROM DeltaMPS.ThirdPartyRemitter WHERE ThirdPartyRemitterId = '{0}'", id);

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    if (reader.Read())
                        return GetThirdPartyRemitterFromDataReader(reader);
                }
            }

            return null;
        }

        private static ThirdPartyRemitter GetThirdPartyRemitterFromDataReader(SqlDataReader reader)
        {
            return new ThirdPartyRemitter
            {
                Id = Convert.ToString(reader["ThirdPartyRemitterId"]),
                Version = Convert.ToInt64(reader["VersionNo"]),
                VersionedOn = Convert.ToString(reader["LastUpdatedUTC"]),
                BusinessName = Convert.ToString(reader["BusinessName"]),
                Address = new Address
                {
                    AddressLine1 = Convert.ToString(reader["AddressLine1"]),
                    AddressLine2 = Convert.ToString(reader["AddressLine2"]),
                    AddressLine3 = Convert.ToString(reader["AddressLine3"]),
                    City = Convert.ToString(reader["City"]),
                    StateOrProvince= Convert.ToString(reader["StateOrProv"]),
                    ZipOrPostalCode= Convert.ToString(reader["ZipOrPostal"]),
                    CountryCode = Convert.ToString(reader["CountryCode"])
                },
                PhoneNumber=  Convert.ToString(reader["PhoneNumber"]),
                Email = Convert.ToString(reader["EmailAddress"]),
                Type = Convert.ToString(reader["Type"]),
                IdentificationType = Convert.ToString(reader["IdentificationType"]), 
                Identification = Convert.ToString(reader["Identification"]),
                Industry = Convert.ToString(reader["Industry"])
            };
        }

        public static string GetThirdPartyRemitterPartnerCode(string thirdPartyRemitterId)
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.BI);
            var selectStatement = string.Format("SELECT * FROM DeltaMPS.ThirdPartyRemitter WHERE ThirdPartyRemitterId = '{0}'", thirdPartyRemitterId);

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    if (reader.Read())
                        return Convert.ToString(reader["PartnerCode"]);
                }
            }

            return null;
        }

        public static int GetThirdPartyRemitterCustomerId(string thirdPartyRemitterId)
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.BI);
            var selectStatement = string.Format("SELECT * FROM DeltaMPS.ThirdPartyRemitter WHERE ThirdPartyRemitterId = '{0}'", thirdPartyRemitterId);

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    if (reader.Read())
                        return Convert.ToInt32(reader["CustomerId"]);
                }
            }

            return 0;
        }
    }
}
