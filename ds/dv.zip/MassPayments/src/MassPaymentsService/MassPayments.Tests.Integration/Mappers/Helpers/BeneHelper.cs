﻿using System;
using System.Data;
using System.Data.SqlClient;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Persistence.Enums;
using MassPayments.Providers.StorageProvider;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public static class BeneHelper
    {
        public static Beneficiary GetBeneficiary(string beneficiaryExternalId)
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.BI);
            var selectStatement = string.Format("SELECT * FROM DeltaMPS.Beneficiary WHERE BeneficiaryID = '{0}'", beneficiaryExternalId);

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    if (reader.Read())
                        return GetBeneficiaryFromDataReader(reader);
                }
            }

            return null;
        }

        public static string GetBeneficiaryPartnerCode(string beneficiaryExternalId)
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.BI);
            var selectStatement = string.Format("SELECT * FROM DeltaMPS.Beneficiary WHERE BeneficiaryID = '{0}'", beneficiaryExternalId);

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    if (reader.Read())
                        return Convert.ToString(reader["PartnerCode"]);
                }
            }

            return null;
        }

        private static Beneficiary GetBeneficiaryFromDataReader(SqlDataReader reader)
        {
            var beneIdentification = new Identification
            {
                FirstName = Convert.ToString(reader["FirstName"]),
                MiddleName = Convert.ToString(reader["MiddleName"]),
                LastName = Convert.ToString(reader["LastName"]),
                PhoneNumber = Convert.ToString(reader["Phone"]),
                CellNumber = Convert.ToString(reader["MobilePhone"]),
                DateOfBirth = Convert.ToString(reader["DateOfBirth"]),
                EntityType = Convert.ToString(reader["EntityType"]),
                BusinessName = Convert.ToString(reader["BusinessName"]),
                BusinessRegistrationNumber = Convert.ToString(reader["BusinessRegistrationNumber"]),
                BusinessRegistrationCountry = Convert.ToString(reader["BusinessRegistrationCountry"]),
                BusinessRegistrationStateProv = Convert.ToString(reader["BusinessRegistrationStatProv"]),
                BusinessContactRole = Convert.ToString(reader["BusinessContactRole"]),
                Industry = Convert.ToString(reader["Industry"]),
                EmailAddress = Convert.ToString(reader["Email"])
            };

            var beneAddress = new Address
            {
                AddressLine1 = Convert.ToString(reader["Address1"]),
                AddressLine2 = Convert.ToString(reader["Address2"]),
                AddressLine3 = Convert.ToString(reader["Address3"]),
                City = Convert.ToString(reader["City"]),
                StateOrProvince = Convert.ToString(reader["StateOrProv"]),
                ZipOrPostalCode = Convert.ToString(reader["ZipOrPostal"]),
                CountryCode = Convert.ToString(reader["CountryCode"])
            };

            var beneficiary = new Beneficiary
            {
                ExternalId = Convert.ToString(reader["BeneficiaryID"]),
                CustomerBeneId = Convert.ToString(reader["CustomerID"]),
                Version = Convert.ToInt64(reader["VersionNo"]),
                WUBSExternalCustomerId = Convert.ToString(reader["CustomerSourceSystemID"]),
                Address = beneAddress,
                Identification = beneIdentification
            };

            return beneficiary;
        }
    }
}
