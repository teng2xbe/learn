﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public class CustomerHelper
    {
        private static CustomerHelper instance;
        
        public static CustomerHelper Instance
        {
            get{return instance ?? (instance = new CustomerHelper());}
            set { instance = value; }
        }

        private readonly Random randomSeed;

        private CustomerHelper()
        {
            randomSeed = new Random(Guid.NewGuid().GetHashCode());
        }
    
        private string GetRandomString()
        {
            return randomSeed.Next(1, 100000).ToString();
        }

        private int GetRandomInt()
        {
            return randomSeed.Next(1, 100000);
        }

        public Customer CreateCustomer()
        {
            var externalId = GetRandomString();
            var customer = new Customer
            {
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = GetRandomInt(),
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1),
                PartnerAssignedCustomerId = externalId,
                TransactionSystemCustomerExternalId = "MEOW"
            };
            return customer;
        }

        public Beneficiary CreateBeneficiary(Customer customer)
        {
            var beneIdentification = new Identification
            {
                FirstName = "Test1",
                MiddleName = "Test2",
                LastName = "Test3",
                PhoneNumber = "6041231234",
                CellNumber = "6041231234",
                DateOfBirth = "2004-09-11",
                Gender = "M",
                EntityType = "INDIVIDUAL",
                BusinessName = "Test4",
                BusinessRegistrationNumber = "Test5",
                BusinessRegistrationCountry = "Test6",
                BusinessRegistrationStateProv = "Test7",
                BusinessContactRole = "Test8",
                Industry = "Test9",
                EmailAddress = "Test10"
            };

            var beneAddress = new Address
            {
                City = "Vancouver",
                StateOrProvince = "BC",
                ZipOrPostalCode = "1W1W1W",
                CountryCode = "CA",
                AddressLine1 = "Test11",
                AddressLine2 = "Test12",
                AddressLine3 = "Test13"
            };

            var bene = new Beneficiary
            {
                ExternalId = GetRandomString(),
                Version = GetRandomInt(),
                VersionedOn = DateTime.Now.ToString(),
                CustomerBeneId= GetRandomString(),
                WUBSExternalCustomerId = customer.PartnerAssignedCustomerId,
                Identification = beneIdentification,
                Address = beneAddress
            };

            return bene;
        }

        public BankAccount CreateBankAccount(Beneficiary beneficiary)
        {
            var bankAddress = new Address
            {
                City = "Vancouver",
                StateOrProvince = "BC",
                ZipOrPostalCode = "1W1W1W",
                CountryCode = "CA",
                AddressLine1 = "Test11",
                AddressLine2 = "Test12",
                AddressLine3 = "Test13"
            };

            var bankAccount = new BankAccount
            {
                Version = GetRandomInt(),
                VersionedOn = DateTime.Now.ToString(),
                ExternalId = GetRandomString(),
                BeneficiaryId = beneficiary.ExternalId,
                AccountNumber = "12345678",
                ExternalAccountType = "BANK_ACCOUNT_CANADA",
                AccountPurpose = "Saving",
                BankName = "BMO",
                BranchName = "Metrotown Branch",
                BankAddress = bankAddress,
                BankCode = "001",
                BranchCode = "23456",
                DisplayName = "910002222",
                CurrencyCode = "CAD",
                BankAccountOwnerName = "owner name",
                IntermediaryBankAccount = new IntermediaryBankAccount
                {
                    AccountNumber = "12345",
                    BankCode = "123124",
                    BankAddress = bankAddress,
                    BankName = "Test Name",
                    BankBranchCode = "12345"
                }
            };

            return bankAccount;
        }
    }
}
