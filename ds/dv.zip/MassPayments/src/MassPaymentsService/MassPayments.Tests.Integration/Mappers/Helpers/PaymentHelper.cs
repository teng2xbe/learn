﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public class PaymentHelper
    {
        private static PaymentHelper instance;
        
        public static PaymentHelper Instance
        {
            get { return instance ?? (instance = new PaymentHelper()); }
            set { instance = value; }
        }

        private Random randomSeed;

        private PaymentHelper()
        {
            randomSeed = new Random(Guid.NewGuid().GetHashCode());
        }
    
        public string GetRandomString()
        {
            return randomSeed.Next(1, 100000).ToString();
        }

        private int GetRandomInt()
        {
            return randomSeed.Next(1, 100000);
        }

        public Payment CreatePayment(Customer customer, string externalId, CustomerBatch customerBatch, int paymentSourceId = 1)
        {
            var bene = CustomerHelper.Instance.CreateBeneficiary(customer);
            return new Payment(externalId, customerBatch.ExternalCustomerId)
            {
                CustomerBatchId = customerBatch.Id,
                AmountMoney = new Money(Currency.JPY, 100.00m),
                Beneficiary = bene,
                BankAccount = CustomerHelper.Instance.CreateBankAccount(bene),
                PaymentMethod = PaymentMethod.Draft,
                PaymentStatus = PaymentStatus.Created,
                TransactionSystemCustomerId = customer.TransactionSystemCustomerId,
                TransactionSystemId = customer.TransactionSystemId,
                CreatedOnUTC = DateTime.UtcNow.AddDays(-20),
                RequestedReleaseDate = DateTime.Today,
                PaymentSourceId = paymentSourceId,
                RemittanceType = RemittanceType.CTX,
                RemittanceData = new List<string> { GetRandomString(), GetRandomString() },
                ThirdPartyRemitter = CreateThirdPartyRemitter(),
                PaymentReference = "TestReference",
                SettlementAmountMoney = new Money(Currency.USD, 0)
            };
        }

        public Payment CreatePayment(Customer customer, CustomerBatch customerBatch)
        {
            return CreatePayment(customer, GetRandomString(), customerBatch);
        }

        public ReturnedPayment CreateReturnPayment(Customer customer, CustomerBatch customerBatch)
        {
            var bene = CustomerHelper.Instance.CreateBeneficiary(customer);
            return new ReturnedPayment(GetRandomString(), customerBatch.ExternalCustomerId)
            {
                CustomerBatchId = customerBatch.Id,
                AmountMoney = new Money(Currency.CAD, 100.00m),
                Beneficiary = bene,
                BankAccount = CustomerHelper.Instance.CreateBankAccount(bene),
                PaymentMethod = PaymentMethod.Draft,
                PaymentStatus = PaymentStatus.Returned,
                TransactionSystemCustomerId = customer.TransactionSystemCustomerId,
                TransactionSystemId = customer.TransactionSystemId,
                CreatedOnUTC = DateTime.UtcNow.AddDays(-20),
                RequestedReleaseDate = DateTime.Today,
                PaymentSourceId = 1,
                RemittanceType = RemittanceType.CTX,
                RemittanceData = new List<string> { GetRandomString(), GetRandomString() },
                ThirdPartyRemitter = CreateThirdPartyRemitter(),
                PaymentReference = "TestReference",
                SettlementAmountMoney = new Money(Currency.USD, 0)
            };
        }
        private ThirdPartyRemitter CreateThirdPartyRemitter()
        {
            return new ThirdPartyRemitter
            {
                Id = "Test01",
                Version = GetRandomInt(),
                VersionedOn = DateTime.Now.ToString(),
                Type = "Test03",
                BusinessName = "Test04",
                Address = new Address
                    {
                        City = "Vancouver",
                        StateOrProvince = "BC",
                        ZipOrPostalCode = "1W1W1W",
                        CountryCode = "CA",
                        AddressLine1 = "Test10",
                        AddressLine2 = "Test11",
                        AddressLine3 = "Test12"
                    },
                Email = "Test05",
                PhoneNumber = "Test06",
                IdentificationType = "Test07",
                Identification = "Test08",
                Industry = "Test09"
            };
        }
    }
}
