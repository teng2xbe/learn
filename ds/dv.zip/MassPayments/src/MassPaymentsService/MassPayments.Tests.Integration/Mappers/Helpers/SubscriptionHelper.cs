﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public class SubscriptionHelper
    {
        private static object singletonLock = new object();
        private static SubscriptionHelper instance;
        
        public static SubscriptionHelper Instance
        {
            get {
                if (instance == null)
                {
                    lock (singletonLock)
                    {
                        if (instance == null)
                        {
                            instance = new SubscriptionHelper();
                        }
                    }
                }
                return instance;
            }
            set { instance = value; }
        }

        private Random randomSeed;

        private SubscriptionHelper()
        {
            randomSeed = new Random(Guid.NewGuid().GetHashCode());
        }

        public string GetRandomString()
        {
            return randomSeed.Next(1, 100000).ToString();
        }

        public ApiChannelSubscription GetApiChannelSubscription(SubscriptionType type)
        {
            return new ApiChannelSubscription
            {
                PartnerId = 1,
                SubscriptionType = type,
                Endpoint = GetRandomString(),
                Certificate = GetRandomString(),
                BodyTemplate = GetRandomString()
            };
        }

        public EmailChannelSubscription GetEmailChannelSubscription(SubscriptionType type)
        {
            return new EmailChannelSubscription
            {
                PartnerId = 1,
                SubscriptionType = type,
                Recipient = GetRandomString()
            };
        }

        public FileChannelSubscription GetFileChannelSubscription(SubscriptionType type)
        {
            return new FileChannelSubscription
            {
                PartnerId = 1,
                SubscriptionType = type
            };
        }
    }
}
