﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.OperationContexts;


namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public class OrderHelper
    {
        private static OrderHelper instance;
        
        public static OrderHelper Instance
        {
            get { return instance ?? (instance = new OrderHelper()); }
            set { instance = value; }
        }

        private Random randomSeed;

        private OrderHelper()
        {
            randomSeed = new Random(Guid.NewGuid().GetHashCode());
        }
    
        public string GetRandomString()
        {
            return randomSeed.Next(1, 100000).ToString();
        }
        private int GetRandomInt()
        {
            return randomSeed.Next(1, 100000);
        }
        public Order CreateOrder(Customer customer)
        {
            var orderId = GetRandomInt();
            var settlementCurrencyCode = "USD";

            return new Order
                {
                    ConfirmationNumber = GetRandomString(),
                    OrderId = orderId,
                    OrderStatus = OrderStatus.Committed,
                    PartnerId = 1,
                    QuoteRequestId = GetRandomInt(),
                    TransactionSystemCustomerId = customer.TransactionSystemCustomerId,
                    TransactionSystemQuoteId = GetRandomInt(),
                    CustomerId = customer.Id,
                    CreatedOn = ServiceCallContextManager.Instance.CurrentContext.DateTime.ToUniversalTime(),
                    LastUpdatedOn = ServiceCallContextManager.Instance.CurrentContext.DateTime.ToUniversalTime(),
                    PartnerReference = "OrderRef1",
                    OrderItems = new List<OrderItem>()
                    {
                        new OrderItem()
                        {
                            OrderId = orderId,
                            SettlementCurrencyCode = settlementCurrencyCode,
                            TargetCurrencyCode = "AUD",
                            Amount = 120.00m
                        },
                        new OrderItem()
                        {
                            OrderId = orderId,
                            SettlementCurrencyCode = settlementCurrencyCode,
                            TargetCurrencyCode = "GBP",
                            Amount = 110.00m
                        }
                        
                    }
                    
                };
                
        }

        

    }
}
