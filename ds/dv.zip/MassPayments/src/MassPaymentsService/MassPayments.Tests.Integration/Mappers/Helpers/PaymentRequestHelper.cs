﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Publishers.Interfaces;
using Address = MassPayments.Domain.Entities.PaymentRequest.Address;
using BankAccount = MassPayments.Domain.Entities.PaymentRequest.BankAccount;
using Beneficiary = MassPayments.Domain.Entities.PaymentRequest.Beneficiary;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public class PaymentRequestHelper
    {
        private static PaymentRequestHelper instance;

        public static PaymentRequestHelper Instance
        {
            get { return instance ?? (instance = new PaymentRequestHelper()); }
            set { instance = value; }
        }
        
        public PaymentRequestToProcess CreatePaymentRequestToProcess(int partnerId, Customer customer) => new PaymentRequestToProcess
        {
            PartnerId = partnerId,
            CreatedOnUtc = DateTime.Now,
            PaymentsToProcess = new List<PaymentRequest>
            {
                CreatePaymentRequest(customer)
            }
        };

        public PaymentRequest CreatePaymentRequest(Customer customer)
        {
            return new PaymentRequest
            {
                PaymentId = "111",
                PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId,
                PartnerReference = "",
                ExternalBatchId = "",
                PaymentMethod = "WIRE",
                FixedAmount = 10,
                CurrencyCode = "JPY",
                Beneficiary = new Beneficiary()
                {
                    Id = "222",
                    VersionedOn = "2015-08-23T00:00:00Z",
                    EmailAddress = "",
                    Type = "Business",
                    FirstName = "Fred",
                    MiddleName = "H",
                    LastName = "Flintstone",
                    PhoneNumber = "",
                    CellNumber = "",
                    DateOfBirth = "",
                    Gender = "",
                    BusinessName = "abc",
                    BusinessRegistrationNumber = "",
                    BusinessRegistrationCountry = "",
                    BusinessRegistrationStateProv = "",
                    Industry = "",
                    Address = new Address
                    {
                        AddressLine1 = "abc",
                        AddressLine2 = "",
                        AddressLine3 = "",
                        City = "aaaa",
                        StateOrPovince = "CC",
                        ZipOrPostalCode = "23423",
                        CountryCode = "DD"
                    }
                },
                BankAccount = new BankAccount
                {
                    Id = "333",
                    VersionedOn = "2015-08-23T00:00:00Z",
                    AccountNumber = "34234",
                    AccountType = "",
                    BankName = "aefase fase fasef",
                    BranchName = "",
                    BankCode = "sfserfsef",
                    BankBranchCode = "23423",
                    BankAddress = new Address
                    {
                        AddressLine1 = "23423 2342",
                        AddressLine2 = "",
                        AddressLine3 = "",
                        City = "asfasefa",
                        StateOrPovince = "cc",
                        ZipOrPostalCode = "df",
                        CountryCode = "sf"
                    },
                    IntermediaryBank = new IntermediaryBank
                    {
                        AccountNumber = "",
                        Address = new Address
                        {
                            AddressLine1 = "",
                            AddressLine2 = "",
                            AddressLine3 = "",
                            City = "",
                            StateOrPovince = "",
                            ZipOrPostalCode = "",
                            CountryCode = ""
                        },
                        BankBranchCode = "",
                        BankCode = "",
                        BankName = ""
                    }
                },
                PurposeOfPayment = "",
                InstructionForBank = "",
                InstructionCodeForBank = "",
                RemittanceType = "",
                RemittanceData = null
            };
        }
    }
}
