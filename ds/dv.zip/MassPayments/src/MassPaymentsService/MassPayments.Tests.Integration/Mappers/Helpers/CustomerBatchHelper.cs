﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Integration.Mappers.Helpers
{
    public class CustomerBatchHelper
    {
        private static CustomerBatchHelper instance;
        
        public static CustomerBatchHelper Instance
        {
            get { return instance ?? (instance = new CustomerBatchHelper()); }
            set { instance = value; }
        }

        private Random randomSeed;

        private CustomerBatchHelper()
        {
            randomSeed = new Random(Guid.NewGuid().GetHashCode());
        }
    
        public string GetRandomString()
        {
            return randomSeed.Next(1, 100000).ToString();
        }
        private int GetRandomInt()
        {
            return randomSeed.Next(1, 100000);
        }
        public CustomerBatch CreateCustomerBatch(Customer customer)
        {
            return new CustomerBatch
            {
                ExternalId = GetRandomString(),
                CustomerId = customer.Id,
                BatchReference = GetRandomString(),
                CreatedOnUTC = DateTime.UtcNow.AddDays(-20),
                ExternalCustomerId = customer.PartnerAssignedCustomerId,
                BatchType = BatchType.ApiBatch
            };
        }
    }
}
