﻿using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class RemittanceTypeCacheMapperFixture
    {
        [Test]
        public void AllTheCorrectRemittanceTypeAreThere()
        {
            var remittanceTypes = RemittanceTypeCacheMapper.Instance.GetRemittanceTypeDictionary();

            Assert.AreEqual(4, remittanceTypes.Count);
        }
    }
}
