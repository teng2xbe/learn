﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class BIMapperFixture
    {
        [Test, Explicit]
        public void InsertBankAccount_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerId = CustomerMapper.Instance.InsertCustomer(customer);
            customer.Id = customerId;
            var partnerCode = "abc";

            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);

            BIMapper.Instance.InsertBeneficiary(beneficiary, partnerCode, customer.TransactionSystemId, customer.TransactionSystemCustomerId, DateTime.UtcNow);

            var bankAccount = CustomerHelper.Instance.CreateBankAccount(beneficiary);

            BIMapper.Instance.InsertBankAccount(bankAccount, partnerCode, DateTime.UtcNow, customer.TransactionSystemCustomerId, customer.TransactionSystemId);

            var loadedBankAccount = BankAccountHelper.GetBankAccount(bankAccount.ExternalId);

            Assert.AreEqual(loadedBankAccount.ExternalId, bankAccount.ExternalId);

            var loadedPartner = BankAccountHelper.GetBankAccountPartner(bankAccount.ExternalId);
            Assert.AreEqual(partnerCode, loadedPartner);
        }

        [Test, Explicit]
        public void UpdateBankAccount_AndReload_ReturnCorrectValue()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var partnerCode = "abc";

            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            BIMapper.Instance.InsertBeneficiary(beneficiary, partnerCode,customer.TransactionSystemId,customer.TransactionSystemCustomerId, DateTime.UtcNow);

            var bankAccount = CustomerHelper.Instance.CreateBankAccount(beneficiary);
            BIMapper.Instance.InsertBankAccount(bankAccount, partnerCode, DateTime.UtcNow, customer.TransactionSystemCustomerId, customer.TransactionSystemId);

            var bankAddress = new Address
            {
                City = "Vancouver1",
                StateOrProvince = "BC1",
                ZipOrPostalCode = "1W1W1B",
                CountryCode = "USA",
                AddressLine1 = "Test112",
                AddressLine2 = "Test123",
                AddressLine3 = "Test134"
            };

            bankAccount.ExternalId = "100";
            bankAccount.Version = 67;
            bankAccount.AccountNumber = "123456781";
            bankAccount.ExternalAccountType = "BANK_ACCOUNT_CANADA1";
            bankAccount.AccountPurpose = "Saving1";
            bankAccount.BankName = "BMO1";
            bankAccount.BranchName = "Metrotown Branch1";
            bankAccount.BankAddress = bankAddress;
            bankAccount.BankCode = "0011";
            bankAccount.BranchCode = "234561";
            bankAccount.DisplayName = "9100022221";
            bankAccount.BankAddress = bankAddress;

            BIMapper.Instance.InsertBankAccount(bankAccount, partnerCode, DateTime.UtcNow, customer.TransactionSystemCustomerId, customer.TransactionSystemId);

            var loadedBankAccount = BankAccountHelper.GetBankAccount(bankAccount.ExternalId);
            ValidateBankAccount(bankAccount, loadedBankAccount);

            var loadedPartner = BankAccountHelper.GetBankAccountPartner(bankAccount.ExternalId);
            Assert.AreEqual(partnerCode, loadedPartner);
        }
         [Test, Explicit]
        public void GetBeneficiary_ReturnsCorrectData_AfterInsert()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var bene = CustomerHelper.Instance.CreateBeneficiary(customer);

            Assert.DoesNotThrow(() => BIMapper.Instance.InsertBeneficiary(bene,"test", customer.TransactionSystemId, customer.TransactionSystemCustomerId,DateTime.UtcNow));

            var loadedBene = BeneHelper.GetBeneficiary(bene.ExternalId);
            ValidateBeneficiary(bene, loadedBene);
            var loadedPartnerCode = BeneHelper.GetBeneficiaryPartnerCode(bene.ExternalId);
            Assert.AreEqual("test", loadedPartnerCode);
        }

        [Test, Explicit]
        public void InsertBeneficiaryVersion_AllFieldsAreUpdated()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var bene = CustomerHelper.Instance.CreateBeneficiary(customer);
            BIMapper.Instance.InsertBeneficiary(bene,"test", customer.TransactionSystemId, customer.TransactionSystemCustomerId, DateTime.UtcNow);

            bene.Version = bene.Version + 1;
            bene.ExternalId = "1000";
            bene.Address = new Address
            {
                AddressLine1 = "Test115",
                AddressLine2 = "Test125",
                AddressLine3 = "Test135",
                City = "Vancouverererer",
                StateOrProvince = "BCD",
                ZipOrPostalCode = "1W1W1W21",
                CountryCode = "USD",
            };
            bene.Identification = new Identification
            {
                FirstName = "Test123",
                MiddleName = "Test123",
                LastName = "Test123",
                PhoneNumber = "6041231234123",
                CellNumber = "6041231234123",
                DateOfBirth = "1980-06-10",
                Gender = "F",
                EntityType = "INDIVIDUAL",
                BusinessName = "Test45",
                BusinessRegistrationNumber = "Test55",
                BusinessRegistrationCountry = "Test65",
                BusinessRegistrationStateProv = "Test75",
                BusinessContactRole = "Test85",
                Industry = "Test95",
                EmailAddress = "Test105",
            };

            BIMapper.Instance.InsertBeneficiary(bene,"test", customer.TransactionSystemId, customer.TransactionSystemCustomerId, DateTime.UtcNow);
            var loadedNewBene = BeneHelper.GetBeneficiary(bene.ExternalId);
            ValidateBeneficiary(bene, loadedNewBene);
            var loadedPartnerCode = BeneHelper.GetBeneficiaryPartnerCode(bene.ExternalId);
            Assert.AreEqual("test", loadedPartnerCode);
        }

        [Test, Explicit]
        public void InsertThirdPartyRemitter_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var thirdParty = new ThirdPartyRemitter
            {
                Address = new Address
                {
                    AddressLine1 = "Test115",
                    AddressLine2 = "Test125",
                    AddressLine3 = "Test135",
                    City = "Vancouverererer",
                    StateOrProvince = "BCD",
                    ZipOrPostalCode = "1W1W1W21",
                    CountryCode = "CA",
                },
                BusinessName = "testBusinessName",
                VersionedOn = DateTime.Now.ToString(),
                Email = "testEmail",
                Id = "testId",
                Identification = "testIdentification",
                Industry = "testIndustry",
                IdentificationType = "testIdentificationType",
                PhoneNumber = "testPhoneNumber",
                Type = "testType",
                Version = 1
            };
            var partnerCode = "test";
            var customerId = 1234;
            BIMapper.Instance.InsertThirdPartyRemitter(thirdParty, partnerCode, customerId, DateTime.UtcNow, customer.TransactionSystemId);

            var loadedThirdPartyRemitter = ThirdPartyRemitterHelper.GetThirdPartyRemitter(thirdParty.Id);
            ValidateThirdPartyRemitter(thirdParty, loadedThirdPartyRemitter);
            var loadedPartnerCode = ThirdPartyRemitterHelper.GetThirdPartyRemitterPartnerCode(thirdParty.Id);
            Assert.AreEqual(partnerCode, loadedPartnerCode);
            var loadedCustomer = ThirdPartyRemitterHelper.GetThirdPartyRemitterCustomerId(thirdParty.Id);
            Assert.AreEqual(customerId, loadedCustomer);
        }

        private void ValidateThirdPartyRemitter(ThirdPartyRemitter expected, ThirdPartyRemitter target)
        {
            Assert.AreEqual(expected.BusinessName, target.BusinessName);
            Assert.AreEqual(expected.Version, target.Version);
            Assert.AreEqual(expected.Email, target.Email);
            Assert.AreEqual(expected.Id, target.Id);
            Assert.AreEqual(expected.Identification, target.Identification);
            Assert.AreEqual(expected.Industry, target.Industry);
            Assert.AreEqual(expected.IdentificationType, target.IdentificationType);
            Assert.AreEqual(expected.PhoneNumber, target.PhoneNumber);
            Assert.AreEqual(expected.Type, target.Type);
            Assert.AreEqual(expected.Address.AddressLine1, target.Address.AddressLine1);
            Assert.AreEqual(expected.Address.AddressLine2, target.Address.AddressLine2);
            Assert.AreEqual(expected.Address.AddressLine3, target.Address.AddressLine3);
            Assert.AreEqual(expected.Address.City, target.Address.City);
            Assert.AreEqual(expected.Address.StateOrProvince, target.Address.StateOrProvince);
            Assert.AreEqual(expected.Address.CountryCode, target.Address.CountryCode);
            Assert.AreEqual(expected.Address.ZipOrPostalCode, target.Address.ZipOrPostalCode);
        }

        private void ValidateBeneficiary(Beneficiary expected, Beneficiary target)
        {
            Assert.AreEqual(expected.ExternalId, target.ExternalId);
            Assert.AreEqual(expected.Version, target.Version);
            Assert.AreEqual(expected.Identification == null, target.Identification == null);
            Assert.AreEqual(expected.Address == null, target.Address == null);

            if (expected.Identification != null)
            {
                Assert.AreEqual(expected.Identification.FirstName, target.Identification.FirstName);
                Assert.AreEqual(expected.Identification.LastName, target.Identification.LastName);
                Assert.AreEqual(expected.Identification.MiddleName, target.Identification.MiddleName);
                Assert.AreEqual(expected.Identification.PhoneNumber, target.Identification.PhoneNumber);
                Assert.AreEqual(expected.Identification.CellNumber, target.Identification.CellNumber);
                Assert.AreEqual(DateTime.Parse(expected.Identification.DateOfBirth).Date, DateTime.Parse(target.Identification.DateOfBirth).Date);
                Assert.AreEqual(expected.Identification.EntityType, target.Identification.EntityType);
                Assert.AreEqual(expected.Identification.BusinessName, target.Identification.BusinessName);
                Assert.AreEqual(expected.Identification.BusinessRegistrationNumber, target.Identification.BusinessRegistrationNumber);
                Assert.AreEqual(expected.Identification.BusinessRegistrationCountry, target.Identification.BusinessRegistrationCountry);
                Assert.AreEqual(expected.Identification.BusinessRegistrationStateProv, target.Identification.BusinessRegistrationStateProv);
                Assert.AreEqual(expected.Identification.BusinessContactRole, target.Identification.BusinessContactRole);
                Assert.AreEqual(expected.Identification.Industry, target.Identification.Industry);
                Assert.AreEqual(expected.Identification.EmailAddress, target.Identification.EmailAddress);
            }

            if (expected.Address != null)
            {
                Assert.AreEqual(expected.Address.AddressLine1, target.Address.AddressLine1);
                Assert.AreEqual(expected.Address.AddressLine2, target.Address.AddressLine2);
                Assert.AreEqual(expected.Address.AddressLine3, target.Address.AddressLine3);
                Assert.AreEqual(expected.Address.City, target.Address.City);
                Assert.AreEqual(expected.Address.StateOrProvince, target.Address.StateOrProvince);
                Assert.AreEqual(expected.Address.ZipOrPostalCode, target.Address.ZipOrPostalCode);
                Assert.AreEqual(expected.Address.CountryCode, target.Address.CountryCode);
            }
        }
        private void ValidateBankAccount(BankAccount expected, BankAccount target)
        {
            Assert.AreEqual(expected.Version, target.Version);
            Assert.AreEqual(expected.ExternalId, target.ExternalId);
            Assert.AreEqual(expected.AccountNumber, target.AccountNumber);
            Assert.AreEqual(expected.ExternalAccountType, target.ExternalAccountType);
            Assert.AreEqual(expected.AccountPurpose, target.AccountPurpose);
            Assert.AreEqual(expected.BankName, target.BankName);
            Assert.AreEqual(expected.BranchName, target.BranchName);
            Assert.AreEqual(expected.BankCode, target.BankCode);
            Assert.AreEqual(expected.BranchCode, target.BranchCode);

            Assert.AreEqual(expected.BankAddress != null, target.BankAddress != null);

            if (expected.BankAddress != null)
            {
                Assert.AreEqual(expected.BankAddress.City, target.BankAddress.City);
                Assert.AreEqual(expected.BankAddress.StateOrProvince, target.BankAddress.StateOrProvince);
                Assert.AreEqual(expected.BankAddress.ZipOrPostalCode, target.BankAddress.ZipOrPostalCode);
                Assert.AreEqual(expected.BankAddress.CountryCode, target.BankAddress.CountryCode);
                Assert.AreEqual(expected.BankAddress.AddressLine1, target.BankAddress.AddressLine1);
                Assert.AreEqual(expected.BankAddress.AddressLine2, target.BankAddress.AddressLine2);
                Assert.AreEqual(expected.BankAddress.AddressLine3, target.BankAddress.AddressLine3);
            }
        }
    }
}
