﻿using System.Transactions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class PaymentsRejectedMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void InsertPaymentsRejected_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(loadedPayment));
        }
    }
}
