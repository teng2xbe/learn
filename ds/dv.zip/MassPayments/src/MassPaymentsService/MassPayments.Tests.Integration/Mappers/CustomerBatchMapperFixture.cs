﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;
using MassPayments.Infrastructure;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class CustomerBatchMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            PaymentRequestMapper.Instance = MockRepository.GenerateStub<IPaymentRequestMapper>();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now);
            ServiceCallContextManager.Instance.CurrentContext.Partner = new Partner {Id = 1};
            CurrencyCache.Instance.Reinitialize();

            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            PaymentRequestMapper.Instance = null;
            ValidationRules.Instance = null;

            if (transactionScope != null)
                transactionScope.Dispose();
            ServiceCallContextManager.Instance = null;
            CurrencyCache.Instance = null;
        }

        [Test]
        public void GetCustomerBatch_LoadsDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,

                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatch savedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.Id);

            Assert.AreEqual(customerBatch.Id, savedCustomerBatch.Id);
            Assert.AreEqual("External", savedCustomerBatch.ExternalId);
            Assert.AreEqual(customer.Id, savedCustomerBatch.CustomerId);
            Assert.AreEqual(DateTime.UtcNow.Date, savedCustomerBatch.CreatedOnUTC.Date);
            Assert.AreEqual("test", savedCustomerBatch.ExternalCustomerId, "expected value is what save with the batch not what customer might has");
            Assert.AreEqual(BatchType.FileBatch, savedCustomerBatch.BatchType);
        }

        [Test]
        public void GetCustomerBatchByExternalId_LoadsDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatch savedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatchByExternalId(customerBatch.ExternalId, customer.PartnerId);

            Assert.AreEqual(customerBatch.Id, savedCustomerBatch.Id);
            Assert.AreEqual("External", savedCustomerBatch.ExternalId);
            Assert.AreEqual(customer.Id, savedCustomerBatch.CustomerId);
            Assert.AreEqual(DateTime.UtcNow.Date, savedCustomerBatch.CreatedOnUTC.Date);
            Assert.AreEqual("test", savedCustomerBatch.ExternalCustomerId);
            Assert.AreEqual(BatchType.FileBatch, savedCustomerBatch.BatchType);
        }

        [Test]
        public void GetCustomerBatchByExternalId_ThrowsCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            Assert.Throws<ArgumentException>(() => CustomerBatchMapper.Instance.GetCustomerBatchByExternalId(customerBatch.ExternalId, 2));
            Assert.Throws<ArgumentException>(() => CustomerBatchMapper.Instance.GetCustomerBatchByExternalId("randomText", 1));
        }
        
        [Test]
        public void GetCustomerBatchByQuoteId_LoadsDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem {TransactionSystemQuoteId = 11, TradeMoney = new Money(Currency.CAD, 111), SettlementMoney = new Money(Currency.USD, 112), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customerBatch.ExternalId, customer.Id, "testPartnerReference", true, "", 100, DateTime.UtcNow, QuoteRequestStatus.Created);

            CustomerBatchMapper.Instance.UpdateCustomerBatchActiveQuoteRequestId(quoteRequestId, customerBatch.ExternalId, customer.Id);

            CustomerBatch savedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatchByQuoteId(quoteRequestId);

            Assert.AreEqual(customerBatch.Id, savedCustomerBatch.Id);
            Assert.AreEqual("External", savedCustomerBatch.ExternalId);
            Assert.AreEqual(customer.Id, savedCustomerBatch.CustomerId);
            Assert.AreEqual(DateTime.UtcNow.Date, savedCustomerBatch.CreatedOnUTC.Date);
            Assert.AreEqual("test", savedCustomerBatch.ExternalCustomerId);
            Assert.AreEqual(BatchType.FileBatch, savedCustomerBatch.BatchType);
        }

        [Test]
        public void GetCustomerBatchByQuoteId_ThrowsCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem {TransactionSystemQuoteId = 11, TradeMoney = new Money(Currency.CAD, 111), SettlementMoney = new Money(Currency.USD, 112), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customerBatch.ExternalId, customer.Id, "testPartnerReference", true, "", 100, DateTime.UtcNow, QuoteRequestStatus.Created);

            CustomerBatchMapper.Instance.UpdateCustomerBatchActiveQuoteRequestId(quoteRequestId, customerBatch.ExternalId, customer.Id);
            
            Assert.Throws<ArgumentException>(() => CustomerBatchMapper.Instance.GetCustomerBatchByQuoteId(quoteRequestId + 1));
        }

        [Test]
        public void GetCustomerBatchByCustomerAndBatchId_LoadsDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatch savedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.CustomerId,customerBatch.ExternalId);

            Assert.AreEqual(customerBatch.Id, savedCustomerBatch.Id);
            Assert.AreEqual("External", savedCustomerBatch.ExternalId);
            Assert.AreEqual(customer.Id, savedCustomerBatch.CustomerId);
            Assert.AreEqual(DateTime.UtcNow.Date, savedCustomerBatch.CreatedOnUTC.Date);
            Assert.AreEqual("test", savedCustomerBatch.ExternalCustomerId);
            Assert.AreEqual(BatchType.FileBatch, savedCustomerBatch.BatchType);
        }

        [Test]
        public void GetCustomerBatchByCustomerAndBatchId_ThrowsExceptionforApiBatchTypeNoExternalId()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = null, ExternalCustomerId = "test", BatchType = BatchType.ApiBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            Assert.Throws<MissingDataException>(() => CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.Id));
        }

        [Test]
        public void GetCustomerBatchByCustomerAndBatchId_ThrowsExceptionforFileBatchTypeNoExternalId()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = null, ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            Assert.Throws<MissingDataException>(() => CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.Id));
        }

        [Test]
        public void IsNewCustomerBatch_Works()
        {
            Assert.IsTrue(CustomerBatchMapper.Instance.IsNewCustomerBatch(new CustomerBatch{CustomerId = 123,ExternalId = "123"}));

            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch};
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatch savedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.CustomerId, customerBatch.ExternalId);

            Assert.AreEqual(customerBatch.Id, savedCustomerBatch.Id);
            Assert.AreEqual("External", savedCustomerBatch.ExternalId);
            Assert.AreEqual(customer.Id, savedCustomerBatch.CustomerId);
            Assert.AreEqual(DateTime.UtcNow.Date, savedCustomerBatch.CreatedOnUTC.Date);

            Assert.IsFalse(CustomerBatchMapper.Instance.IsNewCustomerBatch(savedCustomerBatch));
            Assert.AreEqual("test", savedCustomerBatch.ExternalCustomerId);
            Assert.AreEqual(BatchType.FileBatch, savedCustomerBatch.BatchType);
        }

        [Test]
        public void GetBatchFile_LoadsDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Meow",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var file = new File {Data = new byte[] {0x22, 0x33, 0x44}, Status = FileStatus.Pending, FileNameWithExtension = "test.json"};
            FileMapper.Instance.InsertFile(file);

            var customerBatch = new CustomerBatch {CustomerId = customer.Id, ExternalId = "Blah"};
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var batchFile = new BatchFile {CustomerBatchId = customerBatch.Id, FileId = file.Id};
            CustomerBatchMapper.Instance.SaveBatchFile(batchFile);

            BatchFile savedBatchFile = CustomerBatchMapper.Instance.GetBatchFile(batchFile.Id);

            Assert.AreEqual(batchFile.Id, savedBatchFile.Id);
            Assert.AreEqual(customerBatch.Id, savedBatchFile.CustomerBatchId);
            Assert.AreEqual(file.Id, savedBatchFile.FileId);
        }
        
        [Test]
        public void CustomerBatch_Update_Works()
        {
            var file = new File { Data = new byte[] { 0x22, 0x33, 0x44 }, Status = FileStatus.Processed, FileNameWithExtension = "xmlInvoice_123" };
            FileMapper.Instance.InsertFile(file);

            var customer = new Customer
            {
                Name = "Meow",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);            

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "Blah" , BatchType = BatchType.FileBatch};
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            customerBatch = CustomerBatchMapper.Instance.GetCustomerBatchByExternalId(customerBatch.ExternalId, customer.PartnerId);

            customerBatch.ExternalCustomerId = "Blah updated";
            customerBatch.BatchReference = "Blah File Name";
            CustomerBatchMapper.Instance.UpdateCustomerBatch(customerBatch);

            var loadedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.Id);
            Assert.AreEqual("Blah updated", loadedCustomerBatch.ExternalCustomerId);
            Assert.AreEqual(customerBatch.BatchReference, loadedCustomerBatch.BatchReference);
        }

        [Test]
        public void UpdateCustomerBatchStatus_UpdateStatus_Works()
        {
            var file = new File { Data = new byte[] { 0x22, 0x33, 0x44 }, Status = FileStatus.Processed, FileNameWithExtension = "xmlInvoice_123" };
            FileMapper.Instance.InsertFile(file);

            var customer = new Customer
            {
                Name = "Meow",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "Blah", BatchType = BatchType.ApiBatch, BatchStatus = CustomerBatchStatus.Created};
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            customerBatch = CustomerBatchMapper.Instance.GetCustomerBatchByExternalId(customerBatch.ExternalId, customer.PartnerId);

            customerBatch.BatchStatus = CustomerBatchStatus.Committed;
            CustomerBatchMapper.Instance.UpdateCustomerBatchStatus(customerBatch);

            var loadedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.Id);
            Assert.AreEqual(CustomerBatchStatus.Committed, loadedCustomerBatch.BatchStatus);
        }

        [Test]
        public void GetBatchByCustomerBatchAndFileId_Works()
        {
            var customer = new Customer
            {
                Name = "Meow",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var file = new File { Data = new byte[] { 0x22, 0x33, 0x44 }, Status = FileStatus.Pending, FileNameWithExtension = "test.json" };
            FileMapper.Instance.InsertFile(file);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "Blah" };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var batchFile = new BatchFile { CustomerBatchId = customerBatch.Id, FileId = file.Id };
            CustomerBatchMapper.Instance.SaveBatchFile(batchFile);

            BatchFile savedBatchFile = CustomerBatchMapper.Instance.GetBatchFileByCustomerBatchAndFile(customerBatch.Id, file.Id);

            Assert.AreEqual(batchFile.Id, savedBatchFile.Id);
            Assert.AreEqual(customerBatch.Id, savedBatchFile.CustomerBatchId);
            Assert.AreEqual(file.Id, savedBatchFile.FileId);
        }

        [Test]
        public void IsNewBatchFile_Works()
        {
            var customer = new Customer
            {
                Name = "Meow",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var file = new File { Data = new byte[] { 0x22, 0x33, 0x44 }, Status = FileStatus.Pending, FileNameWithExtension = "test.json" };
            FileMapper.Instance.InsertFile(file);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "Blah" };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var batchFile = new BatchFile { CustomerBatchId = customerBatch.Id, FileId = file.Id };
            CustomerBatchMapper.Instance.SaveBatchFile(batchFile);

            Assert.IsFalse(CustomerBatchMapper.Instance.IsNewBatchFile(batchFile));
        }

        [Test]
        public void IsNewBatchFile_Works_WithNewBatchFile()
        {
            var batchFile = new BatchFile { CustomerBatchId =123, FileId = 456};
            
            Assert.IsTrue(CustomerBatchMapper.Instance.IsNewBatchFile(batchFile));
        }

        [Test]
        public void InsertCustomerBatches_Works()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,

                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            var id1 = CustomerMapper.Instance.InsertCustomer(customer);
            var customer2 = customer;
            customer2.PartnerAssignedCustomerId = "EXT2";
            var id2 = CustomerMapper.Instance.InsertCustomer(customer2);

            var requestId = 123;
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything)).Return(requestId);

            var customerBatches = new List<CustomerBatch>
            {
                new CustomerBatch{CustomerId = id1, CreatedOnUTC = DateTime.UtcNow, BatchReference = requestId.ToString(), ExternalCustomerId = "something between 20 and 38", BatchType = BatchType.PaymentRequest}, 
                new CustomerBatch{CustomerId = id2, CreatedOnUTC = DateTime.UtcNow, BatchReference = requestId.ToString(), ExternalCustomerId = "ext2", BatchType = BatchType.PaymentRequest}
            };
            var batches = CustomerBatchMapper.Instance.InsertCustomerBatches(customerBatches);            

            Assert.AreEqual(2, batches.Count);
            Assert.AreEqual(requestId.ToString(), batches[0].BatchReference);
            Assert.IsTrue(batches.Select(u=>u.CustomerId).Contains(id1));
            Assert.IsTrue(batches.Select(u => u.CustomerId).Contains(id2));
            Assert.AreEqual(BatchType.PaymentRequest, batches[0].BatchType);
            Assert.AreEqual(BatchType.PaymentRequest, batches[1].BatchType);
            Assert.AreEqual("something between 20 and 38", batches[0].ExternalCustomerId);
            Assert.AreEqual("ext2", batches[1].ExternalCustomerId);
        }

        [Test]
        public void CheckFundingOrderExistsForCustomerBatch_ReturnsFalseIfOrderNotExists()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,

                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            var id1 = CustomerMapper.Instance.InsertCustomer(customer);
            var customer2 = customer;
            customer2.PartnerAssignedCustomerId = "EXT2";
            var id2 = CustomerMapper.Instance.InsertCustomer(customer2);

            var requestId = 123;
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything)).Return(requestId);

            var customerBatches = new List<CustomerBatch>
            {
                new CustomerBatch{CustomerId = id1, ExternalId = "batch1", CreatedOnUTC = DateTime.UtcNow, BatchReference = requestId.ToString(), ExternalCustomerId = "ext1", BatchType = BatchType.PaymentRequest}, 
                new CustomerBatch{CustomerId = id2, ExternalId = "batch2", CreatedOnUTC = DateTime.UtcNow, BatchReference = requestId.ToString(), ExternalCustomerId = "ext2", BatchType = BatchType.PaymentRequest}
            };
            var batches = CustomerBatchMapper.Instance.InsertCustomerBatches(customerBatches);

            var result = OrderMapper.Instance.CheckFundingOrderExistsForCustomerBatch(batches[0].ExternalId);
            Assert.AreEqual(false, result);
        }


        [Test]
        public void UpdateCustomerBatchTotalPaymentsProcessed_Works()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,

                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            var id1 = CustomerMapper.Instance.InsertCustomer(customer);
            var customer2 = customer;
            customer2.PartnerAssignedCustomerId = "EXT2";
            var id2 = CustomerMapper.Instance.InsertCustomer(customer2);

            var requestId = 123;
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything)).Return(requestId);

            var customerBatches = new List<CustomerBatch>
            {
                new CustomerBatch{CustomerId = id1, CreatedOnUTC = DateTime.UtcNow, BatchReference = requestId.ToString(), ExternalCustomerId = "ext1", BatchType = BatchType.PaymentRequest, ExternalId =  "BatchExt1"}, 
            };
            
            var batches = CustomerBatchMapper.Instance.InsertCustomerBatches(customerBatches);

            batches[0].TotalPaymentsReceived = 3;
            batches[0].TotalPaymentsAccepted = 2;

            CustomerBatchMapper.Instance.UpdateCustomerBatchTotalPaymentsProcessed(batches[0]);

            var updatedUpload = CustomerBatchMapper.Instance.GetCustomerBatchByExternalId(batches[0].ExternalId, customer.PartnerId);

            Assert.AreEqual(batches[0].TotalPaymentsReceived, updatedUpload.TotalPaymentsReceived);
            Assert.AreEqual(batches[0].TotalPaymentsAccepted, updatedUpload.TotalPaymentsAccepted);
        }

        [Test]
        public void Update_ActiveQuoteRequestId_Works()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem {TransactionSystemQuoteId = 11, TradeMoney = new Money(Currency.CAD, 111), SettlementMoney = new Money(Currency.USD, 112), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customerBatch.ExternalId, customer.Id, "testPartnerReference", true, "", 100, DateTime.UtcNow, QuoteRequestStatus.Created);

            CustomerBatchMapper.Instance.UpdateCustomerBatchActiveQuoteRequestId(quoteRequestId,customerBatch.ExternalId, customer.Id);

            CustomerBatch loadedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.Id);

            Assert.AreEqual(quoteRequestId, loadedCustomerBatch.ActiveQuoteRequestId);
        }

        [Test]
        public void Update_ActiveQuoteRequestId_NullQuote_Works()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatchMapper.Instance.UpdateCustomerBatchActiveQuoteRequestId(null, customerBatch.ExternalId, customer.Id);

            CustomerBatch loadedCustomerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch.Id);

            Assert.AreEqual(0, loadedCustomerBatch.ActiveQuoteRequestId);
        }

        [Test]
        public void GetBatchAmounts_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.CAD, 1.02m);
            payment.SettlementAmountMoney = new Money(Currency.USD, 0);
            payment.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment);


            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(Currency.CAD, 0.89m);
            payment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            payment1.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment1);


            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.AmountMoney = new Money(Currency.AUD, 0m);
            payment2.SettlementAmountMoney = new Money(Currency.USD, 1.23m);
            payment2.IsFixedAmountInSettlementCurrency = true;
            PaymentMapper.Instance.InsertPayment(payment2);


            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.AmountMoney = new Money(Currency.AUD, 0);
            payment3.SettlementAmountMoney = new Money(Currency.USD, 3.45m);
            payment3.IsFixedAmountInSettlementCurrency = true;
            PaymentMapper.Instance.InsertPayment(payment3);

            var amounts = CustomerBatchMapper.Instance.GetCustomerBatchAmounts(customerBatch);

            Assert.AreEqual(2, amounts.Count);
            Assert.AreEqual(payment.AmountMoney.Amount + payment1.AmountMoney.Amount, 
                amounts.First(a => a.Money.Currency.Code == payment.AmountMoney.Currency.Code 
                && a.SettlementMoney.Currency.Code == payment.SettlementAmountMoney.Currency.Code 
                && a.IsFixedAmountInSettlementCurrency == payment.IsFixedAmountInSettlementCurrency).Money.Amount);
            Assert.AreEqual(payment2.SettlementAmountMoney.Amount + payment3.SettlementAmountMoney.Amount, 
                amounts.First(a => a.Money.Currency.Code == payment2.AmountMoney.Currency.Code
                && a.SettlementMoney.Currency.Code == payment2.SettlementAmountMoney.Currency.Code
                && a.IsFixedAmountInSettlementCurrency == payment2.IsFixedAmountInSettlementCurrency).SettlementMoney.Amount);
        }

        [Test]
        public void GetBatchAmounts_DoesNotIncludeCanceledPayment()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.CAD, 1.02m);
            payment.SettlementAmountMoney = new Money(Currency.USD, 2.34m);
            payment.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(Currency.CAD, 10000.00m);
            payment1.SettlementAmountMoney = new Money(Currency.USD, 100.00m);
            payment1.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment1);
            payment1.PaymentStatus = PaymentStatus.Cancelled;
            PaymentMapper.Instance.UpdatePaymentStatus(payment1.Id, PaymentStatus.Cancelled);

            var amounts = CustomerBatchMapper.Instance.GetCustomerBatchAmounts(customerBatch);

            //only first payment amount is used for calculation
            Assert.AreEqual(payment.AmountMoney.Amount, amounts[0].Money.Amount);   
            Assert.AreEqual(payment.SettlementAmountMoney.Amount, amounts[0].SettlementMoney.Amount);
        }
    }
}