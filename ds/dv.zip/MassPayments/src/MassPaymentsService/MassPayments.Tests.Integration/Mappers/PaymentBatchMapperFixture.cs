﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using MassPayments.Infrastructure;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class PaymentBatchMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void CanInsertNewPaymentBatch()
        {
            var paymentIds = new List<int> {1, 2, 3, 4};
            var batchId = PaymentBatchMapper.Instance.InsertPaymentBatch(paymentIds);
            var selectStatement = string.Format("SELECT * FROM MP.PaymentBankBatch WHERE Id = {0}", batchId);

            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(Convert.ToString(reader["PaymentIds"]), "1,2,3,4");
                }
            }
        }

        [Test]
        public void CanUpdatePaymentBatchWithFileName()
        {
            var paymentIds = new List<int> { 1, 2, 3, 4 };
            var batchId = PaymentBatchMapper.Instance.InsertPaymentBatch(paymentIds);
            var fileName = string.Format("BatchFile_{0}_THEDATE", batchId);
            var selectStatement = string.Format("SELECT * FROM MP.PaymentBankBatch WHERE Id = {0}", batchId);

            PaymentBatchMapper.Instance.UpdatePaymentBatch(batchId, fileName, 1234);

            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(Convert.ToString(reader["FileName"]), fileName);
                    Assert.AreEqual(Convert.ToInt32(reader["BankBatchScheduleId"]), 1234);
                }
            }
        }
    }
}
