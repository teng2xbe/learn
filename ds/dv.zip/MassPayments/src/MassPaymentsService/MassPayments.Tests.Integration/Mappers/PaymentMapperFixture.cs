﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Persistence.Enums;
using MassPayments.Mappers;
using MassPayments.Providers.StorageProvider;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Transactions;
using BankAccount = MassPayments.Domain.Entities.BankAccount;
using ThirdPartyRemitter = MassPayments.Domain.Entities.ThirdPartyRemitter;
using System.Threading;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class PaymentMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void InsertPayment_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.TransactionSystemIncomingOrderId = 123;
            payment.TransactionSystemIncomingOrderNumber = "Test";
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual(loadedPayment.PaymentStatus, PaymentStatus.Created);
            ValidatePayment(payment, loadedPayment);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderId, loadedPayment.TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderNumber, loadedPayment.TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(PainFileGenerationStatus.NullStatus, loadedPayment.PainFileGenerationStatus);
            Assert.IsFalse((bool)loadedPayment.IsFixedAmountInSettlementCurrency);
        }

        [Test]
        public void InsertPayment_IsFixedAmountInSettlementCurrencyIsTrue_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.TransactionSystemIncomingOrderId = 123;
            payment.TransactionSystemIncomingOrderNumber = "Test";
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual(loadedPayment.PaymentStatus, PaymentStatus.Created);
            ValidatePayment(payment, loadedPayment);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderId, loadedPayment.TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderNumber, loadedPayment.TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(PainFileGenerationStatus.NullStatus, loadedPayment.PainFileGenerationStatus);
        }

        [Test]
        public void InsertPayment_Works_WithoutThirdPArtyRemitter()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.TransactionSystemIncomingOrderId = 123;
            payment.TransactionSystemIncomingOrderNumber = "Test";
            payment.ThirdPartyRemitter = null;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual(loadedPayment.PaymentStatus, PaymentStatus.Created);
            ValidatePayment(payment, loadedPayment);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderId, loadedPayment.TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderNumber, loadedPayment.TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(PainFileGenerationStatus.NullStatus, loadedPayment.PainFileGenerationStatus);
        }

        [Test]
        public void InsertPayment_Works_WithLastUpdatedOnNotSet()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.TransactionSystemIncomingOrderId = 123;
            payment.TransactionSystemIncomingOrderNumber = "Test";
            payment.Beneficiary.VersionedOn = null;
            payment.BankAccount.VersionedOn = null;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual(loadedPayment.PaymentStatus, PaymentStatus.Created);
            ValidatePayment(payment, loadedPayment);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderId, loadedPayment.TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderNumber, loadedPayment.TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(PainFileGenerationStatus.NullStatus, loadedPayment.PainFileGenerationStatus);
        }

        [Test]
        public void InsertPayment_Supports_LargeIds()
        {
            const string largeId_34 = "1234-1234-1234-1234-1234-1234-1234";

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, "2222" + largeId_34, customerBatch);
            payment.TransactionSystemIncomingOrderId = 123;
            payment.TransactionSystemIncomingOrderNumber = "Test";
            payment.Beneficiary.ExternalId = "4444" + largeId_34;
            payment.BankAccount.ExternalId = "5555" + largeId_34;
            payment.Beneficiary.Version = long.MaxValue - 2;
            payment.BankAccount.Version = long.MaxValue - 1000;
            payment.ThirdPartyRemitter.Version = long.MaxValue - 101;
            Assert.IsTrue(payment.ExternalId.Length >= 38);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual(loadedPayment.PaymentStatus, PaymentStatus.Created);
            ValidatePayment(payment, loadedPayment);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderId, loadedPayment.TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderNumber, loadedPayment.TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(PainFileGenerationStatus.NullStatus, loadedPayment.PainFileGenerationStatus);
        }

        [Test]
        public void InsertPayment_WithSpecialCharacters_AndExceedsLimit_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.TransactionSystemIncomingOrderId = 123;
            payment.TransactionSystemIncomingOrderNumber = "Test";
            payment.Beneficiary.Address.AddressLine1 = "901 N VETERANS' BLVD (\"I\" ROAD12345123123)";
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual("901 N VETERANS' BLVD (\"I\" ROAD12345", loadedPayment.Beneficiary.Address.AddressLine1);
        }

        [Test]
        public void InsertNullAsPaymentMethod_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentMethod = null;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual(loadedPayment.PaymentStatus, PaymentStatus.Created);
            ValidatePayment(payment, loadedPayment);
        }

        [Test]
        public void UpdateBatchPaymentToCashoutPayment_UpdateFieldsCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);

            payment.AmountMoney = new Money(Currency.CAD, 100.00m);
            payment.PaymentMethod = PaymentMethod.Draft;
            payment.Beneficiary = beneficiary;
            payment.BankAccount = CustomerHelper.Instance.CreateBankAccount(beneficiary);
            payment.PaymentStatus = PaymentStatus.Committed;

            Assert.DoesNotThrow(() => PaymentMapper.Instance.UpdateBatchPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId);

            ValidatePayment(payment, loadedPayment[0]);
        }

        [Test]
        public void GetUnsentPaymentIds_WillOnlyGetUnsentPaymentIds()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.PaymentStatus = PaymentStatus.Committed;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.PaymentStatus = PaymentStatus.Sent;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment3));

            var paymentIds = PaymentMapper.Instance.GetPaymentIds(PaymentStatus.Committed);
            var loadedPayment1 = PaymentMapper.Instance.GetPayments(payment1.ExternalId, payment1.PaymentSourceId)[0];
            var loadedPayment2 = PaymentMapper.Instance.GetPayments(payment2.ExternalId, payment2.PaymentSourceId)[0];

            Assert.AreEqual(paymentIds.Count, 2);
            Assert.AreEqual(paymentIds[0], loadedPayment1.Id);
            Assert.AreEqual(paymentIds[1], loadedPayment2.Id);
        }

        [Test]
        public void GetUnsentPayments_WillOnlyGetUnsentPaymentIds()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.PaymentStatus = PaymentStatus.Committed;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.PaymentStatus = PaymentStatus.Sent;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment3));

            var paymentsDic = PaymentMapper.Instance.GetPaymentIdsAndPartnerCodesByStatus(PaymentStatus.Committed);
            var loadedPayment1 = PaymentMapper.Instance.GetPayments(payment1.ExternalId, payment1.PaymentSourceId)[0];
            var loadedPayment2 = PaymentMapper.Instance.GetPayments(payment2.ExternalId, payment2.PaymentSourceId)[0];

            Assert.AreEqual(paymentsDic["HyperWallet"].Count, 2);
            Assert.AreEqual(paymentsDic["HyperWallet"][0], loadedPayment1.Id);
            Assert.AreEqual(paymentsDic["HyperWallet"][1], loadedPayment2.Id);
        }

        [Test]
        public void UpdatePaymentStatuses_WillUpdateEachPaymentStatus()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment3));

            var paymentIds = new List<int> { payment1.Id, payment2.Id, payment3.Id };
            var paymentStatuses = new List<PaymentStatus> { PaymentStatus.SanctionBlocked, PaymentStatus.SanctionCleared, PaymentStatus.Committed };

            PaymentMapper.Instance.UpdatePaymentStatuses(paymentIds, paymentStatuses);

            var loadedPayment1 = PaymentMapper.Instance.GetPayments(payment1.ExternalId, payment1.PaymentSourceId)[0];
            var loadedPayment2 = PaymentMapper.Instance.GetPayments(payment2.ExternalId, payment2.PaymentSourceId)[0];
            var loadedPayment3 = PaymentMapper.Instance.GetPayments(payment3.ExternalId, payment3.PaymentSourceId)[0];

            Assert.AreEqual(loadedPayment1.PaymentStatus, PaymentStatus.SanctionBlocked);
            Assert.AreEqual(loadedPayment2.PaymentStatus, PaymentStatus.SanctionCleared);
            Assert.AreEqual(loadedPayment3.PaymentStatus, PaymentStatus.Committed);

            var paymentStatusHistories1 = PaymentMapper.Instance.GetPaymentStatusHistoryById(loadedPayment1.Id);

            Assert.AreEqual(1, paymentStatusHistories1.Count);
            Assert.AreEqual(PaymentStatus.SanctionBlocked, paymentStatusHistories1[0].PaymentStatus);

            var paymentStatusHistories2 = PaymentMapper.Instance.GetPaymentStatusHistoryById(loadedPayment2.Id);

            Assert.AreEqual(1, paymentStatusHistories2.Count);
            Assert.AreEqual(PaymentStatus.SanctionCleared, paymentStatusHistories2[0].PaymentStatus);

            var paymentStatusHistories3 = PaymentMapper.Instance.GetPaymentStatusHistoryById(loadedPayment3.Id);

            Assert.AreEqual(1, paymentStatusHistories3.Count);
            Assert.AreEqual(PaymentStatus.Committed, paymentStatusHistories3[0].PaymentStatus);
        }

        [Test]
        public void GetPaymentStatuses_WillUpdateEachPaymentStatus()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.SanctionBlocked;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.PaymentStatus = PaymentStatus.Committed;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment3));

            var paymentidList = new List<string> { payment1.ExternalId, payment2.ExternalId, payment3.ExternalId };

            var loadedPayments = PaymentMapper.Instance.GetPayments(customer.PartnerId, paymentidList);

            Assert.AreEqual(loadedPayments[0].PaymentStatus, PaymentStatus.SanctionBlocked);
            Assert.AreEqual(loadedPayments[1].PaymentStatus, PaymentStatus.SanctionCleared);
            Assert.AreEqual(loadedPayments[2].PaymentStatus, PaymentStatus.Committed);
        }

        [Test]
        public void UpdatePaymentStatuses_WithEmptyListsDoesNotThrowExceptions()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var paymentIds = new List<int>();
            var paymentStatuses = new List<PaymentStatus>();

            Assert.DoesNotThrow(() => PaymentMapper.Instance.UpdatePaymentStatuses(paymentIds, paymentStatuses));
        }

        [Test]
        public void UpdatePaymentStatuses_WithGPGProcessedDate()
        {
            var gpgProcessedDate = DateTime.Today;
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Released;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.PaymentStatus = PaymentStatus.Released;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.PaymentStatus = PaymentStatus.Released;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment3));

            var paymentidList = new List<int> { payment1.Id, payment2.Id, payment3.Id };
            var paymentStatusList = new List<PaymentStatus> { payment1.PaymentStatus, payment2.PaymentStatus, payment3.PaymentStatus };
            var paymentGPGProcessed = new List<DateTime> { gpgProcessedDate, gpgProcessedDate, gpgProcessedDate };

            PaymentMapper.Instance.UpdatePaymentStatuses(paymentidList, paymentStatusList, paymentGPGProcessed);

            var loadedPayments = PaymentMapper.Instance.GetPayments(paymentidList);

            Assert.AreEqual(gpgProcessedDate, loadedPayments[0].GPGProcessedUTC);
            Assert.AreEqual(gpgProcessedDate, loadedPayments[0].GPGProcessedUTC);
            Assert.AreEqual(gpgProcessedDate, loadedPayments[0].GPGProcessedUTC);
        }

        [Test]
        public void UpdatePaymentStatuses_WithListsOfDifferentLenghtsWillThrowException()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var paymentIds = new List<int> { payment1.Id };
            var paymentStatuses = new List<PaymentStatus>();

            Assert.Throws<InvalidPaymentStatusListException>(() => PaymentMapper.Instance.UpdatePaymentStatuses(paymentIds, paymentStatuses));
        }

        [Test]
        public void InsertPayment_AndUpdateConfirmationWorks()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));
            const string confirmationNo = "N12345";
            const int orderId = 123;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.UpdatePaymentsConfirmationNo(payment.Id, orderId, confirmationNo));

            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            Assert.AreEqual(loadedPayment.TransactionSystemOrderNumber, confirmationNo);
            Assert.AreEqual(loadedPayment.TransactionSystemOrderId, orderId);
            ValidatePayment(payment, loadedPayment);
        }

        [Test]
        public void GetPaymentStatusHistory_Works_AfterInsert()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment);


            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentStatusHistory(payment.Id, payment.PaymentStatus));
            var paymentStatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment.Id);
            Assert.AreEqual(1, paymentStatusHistories.Count);
            Assert.AreEqual(PaymentStatus.Created, paymentStatusHistories[0].PaymentStatus);
        }

        [Test]
        public void GetPaymentStatusHistory_Works_AfterBulkInsert()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment1);
            
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentStatusHistories(new List<Payment> {payment, payment1}));

            var paymentStatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment.Id);
            Assert.AreEqual(1, paymentStatusHistories.Count);
            Assert.AreEqual(PaymentStatus.Created, paymentStatusHistories[0].PaymentStatus);

            var paymentStatusHistories1 = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment1.Id);
            Assert.AreEqual(1, paymentStatusHistories1.Count);
            Assert.AreEqual(PaymentStatus.Created, paymentStatusHistories1[0].PaymentStatus);
        }

        [Test]
        public void GetPaymentIntervals_Works()
        {
            List<PaymentInterval> intervals = null;
            Assert.DoesNotThrow(() => intervals = PaymentMapper.Instance.GetPaymentIntervals());
            Assert.NotNull(intervals);
            Assert.True(intervals[0].Id > 0);
        }

        [Test]
        public void GetPaymentInterval_Works()
        {
            PaymentInterval interval = null;
            Assert.DoesNotThrow(() => interval = PaymentMapper.Instance.GetPaymentInterval(new Currency("USD"), PaymentMethod.ACH));
            Assert.NotNull(interval);
        }

        [Test]
        public void InsertPaymentScheduleError_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var paymentScheduleError = new PaymentScheduleError
            {
                FailedTimeUTC = DateTime.UtcNow,
                Message = "test message",
                NextRetryTimeUTC = DateTime.UtcNow.AddMinutes(10),
                PaymentIntervalId = 1,
                Status = PaymentScheduleStatus.Failed,
                CustomerId = customer.Id
            };

            PaymentMapper.Instance.InsertPaymentScheduleError(paymentScheduleError);
            Assert.True(paymentScheduleError.Id > 0);
        }

        [Test]
        public void GetPaymentScheduleError_ByPaymentIntervalIdAndStatus_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var paymentScheduleError = new PaymentScheduleError
            {
                FailedTimeUTC = DateTime.UtcNow,
                Message = "test message",
                NextRetryTimeUTC = DateTime.UtcNow.AddMinutes(10),
                PaymentIntervalId = 1,
                Status = PaymentScheduleStatus.Failed,
                CustomerId = customer.Id
            };

            PaymentMapper.Instance.InsertPaymentScheduleError(paymentScheduleError);
            Assert.True(paymentScheduleError.Id > 0);

            var loadedPaymentScheduleError =
                PaymentMapper.Instance.GetPaymentScheduleErrorByPaymentIntervalAndStatus(
                    paymentScheduleError.PaymentIntervalId, paymentScheduleError.Status, customer.Id);

            Assert.AreEqual(paymentScheduleError.FailedTimeUTC.ToShortTimeString(), loadedPaymentScheduleError.FailedTimeUTC.ToShortTimeString());
            Assert.AreEqual(paymentScheduleError.Message, loadedPaymentScheduleError.Message);
            Assert.AreEqual(paymentScheduleError.NextRetryTimeUTC.ToShortTimeString(), loadedPaymentScheduleError.NextRetryTimeUTC.ToShortTimeString());
            Assert.AreEqual(paymentScheduleError.PaymentIntervalId, loadedPaymentScheduleError.PaymentIntervalId);
            Assert.AreEqual(paymentScheduleError.Status, loadedPaymentScheduleError.Status);
            Assert.AreEqual(paymentScheduleError.CustomerId, loadedPaymentScheduleError.CustomerId);
        }

        [Test]
        public void GetSanctionClearedPaymentsForCustomer_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var customer1 = CustomerHelper.Instance.CreateCustomer();
            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.SanctionCleared;
            payment.AmountMoney = new Money(Currency.CAD, 0);
            payment.PaymentMethod = PaymentMethod.ACH;
            PaymentMapper.Instance.InsertPayment(payment);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer1, customerBatch);
            payment1.PaymentStatus = PaymentStatus.SanctionCleared;
            payment1.AmountMoney = new Money(Currency.CAD, 0);
            payment1.PaymentMethod = PaymentMethod.ACH;
            PaymentMapper.Instance.InsertPayment(payment1);

            var payments = PaymentMapper.Instance.GetSanctionClearedPaymentsForCustomer(new Currency("CAD"), PaymentMethod.ACH, customer.Id);
            Assert.AreEqual(1, payments.Count);
            ValidatePayment(payment, payments[0]);
        }

        [Test]
        public void UpdatePaymentScheduleError_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var paymentScheduleError = new PaymentScheduleError
            {
                FailedTimeUTC = DateTime.UtcNow,
                Message = "test message",
                NextRetryTimeUTC = DateTime.UtcNow.AddMinutes(10),
                PaymentIntervalId = 1,
                Status = PaymentScheduleStatus.Failed,
                CustomerId = customer.Id
            };

            PaymentMapper.Instance.InsertPaymentScheduleError(paymentScheduleError);
            Assert.True(paymentScheduleError.Id > 0);

            paymentScheduleError.Message = "123";
            paymentScheduleError.Status = PaymentScheduleStatus.MaxRetryFailed;
            paymentScheduleError.NextRetryTimeUTC = DateTime.UtcNow.AddMinutes(20);
            paymentScheduleError.FailedTimeUTC = DateTime.UtcNow.AddMinutes(20);
            paymentScheduleError.Count = 10000;
            PaymentMapper.Instance.UpdatePaymentScheduleError(paymentScheduleError);

            PaymentScheduleError loadedSchedule = null;
            Assert.DoesNotThrow(() => loadedSchedule = PaymentMapper.Instance.GetPaymentScheduleErrorByPaymentIntervalAndStatus(1, PaymentScheduleStatus.MaxRetryFailed, customer.Id));

            Assert.AreEqual(paymentScheduleError.Message, loadedSchedule.Message);
            Assert.AreEqual(paymentScheduleError.Status, loadedSchedule.Status);
            Assert.AreEqual(paymentScheduleError.NextRetryTimeUTC.ToShortTimeString(), loadedSchedule.NextRetryTimeUTC.ToShortTimeString());
            Assert.AreEqual(paymentScheduleError.FailedTimeUTC.ToShortTimeString(), loadedSchedule.FailedTimeUTC.ToShortTimeString());
            Assert.AreEqual(paymentScheduleError.Count, loadedSchedule.Count);

            Assert.Throws<ArgumentException>(
                () => PaymentMapper.Instance.GetPaymentScheduleErrorByPaymentIntervalAndStatus(
                    1, PaymentScheduleStatus.Failed, customer.Id));

        }

        [Test]
        public void GetPaymentExteranlIdsByIdsAndPaymentState_WorksForCreatedState()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment3));

            var paymentIds = new List<string> { payment1.ExternalId, payment3.ExternalId };

            var actual = PaymentMapper.Instance.GetPaymentExternalIdsByIdsAndPaymentState(customer.PartnerId, paymentIds, (int)PaymentStatus.Created);

            Assert.AreEqual(2, actual.Count);
            Assert.IsTrue(actual.Contains(payment1.ExternalId));
            Assert.IsTrue(actual.Contains(payment3.ExternalId));
            Assert.IsTrue(!actual.Contains(payment2.ExternalId));
        }

        [Test]
        public void GetPaymentExteranlIdsByIdsAndPaymentState_Works_ForCommitedState()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.PaymentStatus = PaymentStatus.Committed;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.PaymentStatus = PaymentStatus.Created;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.PaymentStatus = PaymentStatus.SanctionCleared;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment3));

            var paymentIds = new List<string> { payment1.ExternalId, payment2.ExternalId, payment3.ExternalId };

            var actual = PaymentMapper.Instance.GetPaymentExternalIdsByIdsAndPaymentState(customer.PartnerId, paymentIds, (int)PaymentStatus.Committed);

            Assert.AreEqual(2, actual.Count);
            Assert.IsTrue(actual.Contains(payment1.ExternalId));
            Assert.IsTrue(actual.Contains(payment3.ExternalId));
            Assert.IsTrue(!actual.Contains(payment2.ExternalId));
        }

        [Test]
        public void BatchInsertUpdatePayment_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(payment1.AmountMoney.Currency, 777);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "ref2a", "ref2b" };

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.UpdatedOnUTC = DateTime.UtcNow;
            payment3.RemittanceData = new List<string> { "ref3a", "ref3b", "ref3c" };

            payment2.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment2);

            var payments = new List<Payment> { payment1, payment2, payment3 };

            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);

            var actualPayments = PaymentMapper.Instance.GetPayments(customer.PartnerId, payments.Select(q => q.ExternalId).ToList());

            Assert.AreEqual(3, actualPayments.Count);

            Assert.AreEqual(payment1.RemittanceData.Count, actualPayments.First(i => i.ExternalId == payment1.ExternalId).RemittanceData.Count);
            Assert.AreEqual(payment2.RemittanceData.Count, actualPayments.First(i => i.ExternalId == payment2.ExternalId).RemittanceData.Count);
            Assert.AreEqual(payment3.RemittanceData.Count, actualPayments.First(i => i.ExternalId == payment3.ExternalId).RemittanceData.Count);
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment1.ExternalId));
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment2.ExternalId));
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment3.ExternalId));
            Assert.AreEqual(actualPayments[0].PaymentReference, payment1.PaymentReference);
        }

        [Test]
        public void BatchInsertUpdatePayment_Works_ForSamePaymentId_But_Different_Partner()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.PartnerId = 1;
            customer.PartnerAssignedCustomerId = "BLEHBLEH";
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(payment1.AmountMoney.Currency, 777);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.PaymentSourceId = customer.PartnerId;

            var customer2 = CustomerHelper.Instance.CreateCustomer();
            customer2.PartnerId = 2;
            customer2.PartnerAssignedCustomerId = "BLUHBLUH";
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);
            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer2, customerBatch2);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "blah remit1" };
            payment2.PaymentSourceId = customer2.PartnerId;

            var payments = new List<Payment> { payment1, payment2 };

            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);

            var actualPayments = PaymentMapper.Instance.GetPayments(customer.PartnerId, payments.Select(q => q.ExternalId).ToList());
            Assert.AreEqual(1, actualPayments.Count);
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment1.ExternalId));
            var actualPayments2 = PaymentMapper.Instance.GetPayments(customer2.PartnerId, payments.Select(q => q.ExternalId).ToList());
            Assert.AreEqual(1, actualPayments2.Count);
            Assert.IsTrue(actualPayments2.Select(i => i.ExternalId).Contains(payment2.ExternalId));
        }

        [Test]
        public void BatchInsertUpdatePayment_Works_For_DecimalAmounts()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(payment.AmountMoney.Currency, 777);
            payment.UpdatedOnUTC = DateTime.UtcNow;

            var payments = new List<Payment> { payment };

            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);
            var actualPayments = PaymentMapper.Instance.GetPayments(customer.PartnerId, payments.Select(q => q.ExternalId).ToList());

            Assert.AreEqual(payment.AmountMoney.Amount, actualPayments[0].AmountMoney.Amount);
        }

        [Test]
        public void BatchInsertUpdatePayment_Works_For_OptionalFields()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.BankAccount = new BankAccount();

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "blah remit1" };

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.UpdatedOnUTC = DateTime.UtcNow;
            payment3.RemittanceType = RemittanceType.Undefined;
            payment3.RemittanceData = new List<string> { "blah remit3" };

            payment2.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment2);

            var payments = new List<Payment> { payment1, payment2, payment3 };

            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);

            var actualPayments = PaymentMapper.Instance.GetPayments(customer.PartnerId, payments.Select(q => q.ExternalId).ToList());

            Assert.AreEqual(3, actualPayments.Count);
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment1.ExternalId));
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment2.ExternalId));
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment3.ExternalId));
        }

        [Test]
        public void BatchInsertUpdatePayment_DoesNotThrow()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.CreatedOnUTC = DateTime.UtcNow;
            payment1.UpdatedOnUTC = DateTime.UtcNow;

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.CreatedOnUTC = DateTime.UtcNow;
            payment2.UpdatedOnUTC = DateTime.UtcNow;

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.CreatedOnUTC = DateTime.UtcNow;
            payment3.UpdatedOnUTC = DateTime.UtcNow;


            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            payment2.PaymentStatus = PaymentStatus.Committed;
            var payments = new List<Payment> { payment1, payment2, payment3 };

            Assert.DoesNotThrow(() => PaymentMapper.Instance.BulkInsertUpdatePayment(payments));

        }

        [Test]
        public void UpdatePainFileGenerationStatuses_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var loadedPayment1 = PaymentMapper.Instance.GetPayments(payment1.ExternalId, payment1.PaymentSourceId)[0];
            var loadedPayment2 = PaymentMapper.Instance.GetPayments(payment2.ExternalId, payment2.PaymentSourceId)[0];

            Assert.AreEqual(PainFileGenerationStatus.NullStatus, loadedPayment1.PainFileGenerationStatus);
            Assert.AreEqual(PainFileGenerationStatus.NullStatus, loadedPayment2.PainFileGenerationStatus);

            var paymentIds = new List<int> { loadedPayment1.Id, loadedPayment2.Id };
            var isSuccessful = true;
            PaymentMapper.Instance.UpdatePainGenerationStatusForPayment(paymentIds, isSuccessful);

            loadedPayment1 = PaymentMapper.Instance.GetPayments(payment1.ExternalId, payment1.PaymentSourceId)[0];
            loadedPayment2 = PaymentMapper.Instance.GetPayments(payment2.ExternalId, payment2.PaymentSourceId)[0];

            Assert.AreEqual(PainFileGenerationStatus.Sent, loadedPayment1.PainFileGenerationStatus);
            Assert.AreEqual(PainFileGenerationStatus.Sent, loadedPayment2.PainFileGenerationStatus);

            isSuccessful = false;
            PaymentMapper.Instance.UpdatePainGenerationStatusForPayment(paymentIds, isSuccessful);

            loadedPayment1 = PaymentMapper.Instance.GetPayments(payment1.ExternalId, payment1.PaymentSourceId)[0];
            loadedPayment2 = PaymentMapper.Instance.GetPayments(payment2.ExternalId, payment2.PaymentSourceId)[0];

            Assert.AreEqual(PainFileGenerationStatus.FailedToSend, loadedPayment1.PainFileGenerationStatus);
            Assert.AreEqual(PainFileGenerationStatus.FailedToSend, loadedPayment2.PainFileGenerationStatus);

        }

        [Test]
        public void GetByCurrencyAndOrStatus_ReturnExpectedPayments_WhenBothParametersAreSubmitted()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var paymentCADCleared = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentCADCleared.PaymentStatus = PaymentStatus.SanctionCleared;
            paymentCADCleared.AmountMoney = new Money(Currency.CAD, 10);
            paymentCADCleared.PaymentMethod = PaymentMethod.ACH;
            PaymentMapper.Instance.InsertPayment(paymentCADCleared);

            var paymentCADCommitted = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentCADCommitted.PaymentStatus = PaymentStatus.Committed;
            paymentCADCommitted.AmountMoney = new Money(Currency.CAD, 20);
            paymentCADCommitted.PaymentMethod = PaymentMethod.Wire;
            PaymentMapper.Instance.InsertPayment(paymentCADCommitted);

            var paymentAUDCommitted = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentAUDCommitted.PaymentStatus = PaymentStatus.Committed;
            paymentAUDCommitted.AmountMoney = new Money(Currency.AUD, 30);
            paymentAUDCommitted.PaymentMethod = PaymentMethod.Wire;
            PaymentMapper.Instance.InsertPayment(paymentAUDCommitted);

            var payment2CADCleared = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2CADCleared.PaymentStatus = PaymentStatus.SanctionCleared;
            payment2CADCleared.AmountMoney = new Money(Currency.CAD, 40);
            payment2CADCleared.PaymentMethod = PaymentMethod.ACH;
            PaymentMapper.Instance.InsertPayment(payment2CADCleared);


            var payments = PaymentMapper.Instance.GetPayments(Currency.CAD, PaymentStatus.SanctionCleared);
            Assert.AreEqual(2, payments.Count);
            Assert.AreEqual(paymentCADCleared.Id, payments[0].Id);
            Assert.AreEqual(Currency.CAD, payments[0].AmountMoney.Currency);
            Assert.AreEqual(PaymentStatus.SanctionCleared, payments[0].PaymentStatus);

            Assert.AreEqual(payment2CADCleared.Id, payments[1].Id);
            Assert.AreEqual(Currency.CAD, payments[1].AmountMoney.Currency);
            Assert.AreEqual(PaymentStatus.SanctionCleared, payments[1].PaymentStatus);


        }

        [Test]
        public void GetByCurrencyAndOrStatus_ReturnExpectedPaymentsInDefaultOrder_WhenOnlyCurrencySubmitted()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var paymentCADCleared = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentCADCleared.PaymentStatus = PaymentStatus.SanctionCleared;
            paymentCADCleared.AmountMoney = new Money(Currency.CAD, 10);
            paymentCADCleared.PaymentMethod = PaymentMethod.ACH;
            PaymentMapper.Instance.InsertPayment(paymentCADCleared);

            var paymentCADCommitted = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentCADCommitted.PaymentStatus = PaymentStatus.Committed;
            paymentCADCommitted.AmountMoney = new Money(Currency.CAD, 20);
            paymentCADCommitted.PaymentMethod = PaymentMethod.Wire;
            PaymentMapper.Instance.InsertPayment(paymentCADCommitted);

            var paymentAUDCommitted = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentAUDCommitted.PaymentStatus = PaymentStatus.Committed;
            paymentAUDCommitted.AmountMoney = new Money(Currency.AUD, 30);
            paymentAUDCommitted.PaymentMethod = PaymentMethod.Wire;
            PaymentMapper.Instance.InsertPayment(paymentAUDCommitted);

            var payments = PaymentMapper.Instance.GetPayments(Currency.CAD, PaymentStatus.Undefined);
            Assert.AreEqual(2, payments.Count);
            Assert.AreEqual(paymentCADCleared.Id, payments[0].Id);
            Assert.AreEqual(Currency.CAD, payments[0].AmountMoney.Currency);
            Assert.AreEqual(PaymentStatus.SanctionCleared, payments[0].PaymentStatus);

            Assert.AreEqual(paymentCADCommitted.Id, payments[1].Id);
            Assert.AreEqual(Currency.CAD, payments[1].AmountMoney.Currency);
            Assert.AreEqual(PaymentStatus.Committed, payments[1].PaymentStatus);

        }

        [Test]
        public void GetByCurrencyAndOrStatus_ReturnExpectedPaymentsInDefaultOrder_WhenOnlyStatusSubmitted()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var paymentCADCleared = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentCADCleared.PaymentStatus = PaymentStatus.SanctionCleared;
            paymentCADCleared.AmountMoney = new Money(Currency.CAD, 10);
            paymentCADCleared.PaymentMethod = PaymentMethod.ACH;
            PaymentMapper.Instance.InsertPayment(paymentCADCleared);

            var paymentCADCommitted = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentCADCommitted.PaymentStatus = PaymentStatus.Committed;
            paymentCADCommitted.AmountMoney = new Money(Currency.CAD, 20);
            paymentCADCommitted.PaymentMethod = PaymentMethod.Wire;
            PaymentMapper.Instance.InsertPayment(paymentCADCommitted);

            var paymentAUDCommitted = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentAUDCommitted.PaymentStatus = PaymentStatus.Committed;
            paymentAUDCommitted.AmountMoney = new Money(Currency.AUD, 30);
            paymentAUDCommitted.PaymentMethod = PaymentMethod.Wire;
            PaymentMapper.Instance.InsertPayment(paymentAUDCommitted);

            var payments = PaymentMapper.Instance.GetPayments(Currency.Null, PaymentStatus.Committed);
            Assert.AreEqual(2, payments.Count);
            Assert.AreEqual(paymentCADCommitted.Id, payments[0].Id);
            Assert.AreEqual(Currency.CAD, payments[0].AmountMoney.Currency);
            Assert.AreEqual(PaymentStatus.Committed, payments[0].PaymentStatus);

            Assert.AreEqual(paymentAUDCommitted.Id, payments[1].Id);
            Assert.AreEqual(Currency.AUD, payments[1].AmountMoney.Currency);
            Assert.AreEqual(PaymentStatus.Committed, payments[1].PaymentStatus);
        }

        [Test]
        public void GetPaymentsByPaymentIds_Returns_Payments()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var paymentIds = new List<int>();

            var payment = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment);
            paymentIds.Add(PaymentMapper.Instance.GetPayment(customer.PartnerId, payment.ExternalId).Id);

            payment = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment);
            paymentIds.Add(PaymentMapper.Instance.GetPayment(customer.PartnerId, payment.ExternalId).Id);

            payment = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment.PaymentStatus = PaymentStatus.Sent;
            PaymentMapper.Instance.InsertPayment(payment);
            paymentIds.Add(PaymentMapper.Instance.GetPayment(customer.PartnerId, payment.ExternalId).Id);

            var payments = PaymentMapper.Instance.GetPayments(paymentIds);
            Assert.AreEqual(3, payments.Count);
            Assert.AreEqual(1, payments.Count(i => i.ExternalId == "1111"));
            Assert.AreEqual(1, payments.Count(i => i.ExternalId == "2222"));
            Assert.AreEqual(1, payments.Count(i => i.ExternalId == "3333"));
        }

        [Test]
        public void UpdatePaymentsAmount_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.IsFixedAmountInSettlementCurrency = true;
            payment.AmountMoney = new Money(payment.AmountMoney.Currency, 0);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));
            Assert.AreEqual(0, payment.AmountMoney.Amount);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.IsFixedAmountInSettlementCurrency = false;
            payment1.SettlementAmountMoney = new Money(payment1.SettlementAmountMoney.Currency, 0);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));
            Assert.AreEqual(0, payment1.SettlementAmountMoney.Amount);

            payment.AmountMoney = new Money(payment.AmountMoney.Currency, 100.12m);
            payment1.SettlementAmountMoney = new Money(payment.SettlementAmountMoney.Currency, 100.12m);
            PaymentMapper.Instance.UpdatePaymentsAmount(new List<Payment> { payment, payment1 });
            var loadedPayment = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId)[0];
            var loadedPayment1 = PaymentMapper.Instance.GetPayments(payment1.ExternalId, payment1.PaymentSourceId)[0];
            Assert.AreEqual(payment.AmountMoney.Amount, loadedPayment.AmountMoney.Amount);
            Assert.AreEqual(payment1.SettlementAmountMoney.Amount, loadedPayment1.SettlementAmountMoney.Amount);
        }

        [Test]
        public void GetPaymentsByCustomerBatchId_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(customerBatch, 5);
            Assert.AreEqual(1, loadedPayments.Count);
        }

        [Test]
        public void GetPaymentByCustomerBatchId_ReturnsCorrectPaymentsWhenSamePaymentIdExistsMoreThanOnce()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.Cancelled;
            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);
            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch1);
            PaymentMapper.Instance.InsertPayment(payment3);

            var returnedPayments = PaymentMapper.Instance.GetPayments(customerBatch, 10);

            Assert.AreEqual(2, returnedPayments.Count);
            ValidatePayment(payment1, returnedPayments[0]);
            ValidatePayment(payment2, returnedPayments[1]);
        }

        [Test]
        public void GetPaymentByCustomerBatchIdNoLimit_ReturnsCorrectPaymentsWhenSamePaymentIdExistsMoreThanOnce()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.Cancelled;
            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);
            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch1);
            PaymentMapper.Instance.InsertPayment(payment3);

            var returnedPayments = PaymentMapper.Instance.GetPayments(customerBatch);

            Assert.AreEqual(2, returnedPayments.Count);
            ValidatePayment(payment1, returnedPayments[0]);
            ValidatePayment(payment2, returnedPayments[1]);
        }

        [Test]
        public void GetPaymentsByCustomerBatchId_NoLimit_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var loadedPayments = PaymentMapper.Instance.GetPayments(customerBatch);
            Assert.AreEqual(3, loadedPayments.Count);
        }

        [Test]
        public void GetAcceptedPaymentsByCustomerBatchId_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayments = PaymentMapper.Instance.GetAcceptedPaymentsByCustomerBatchId(customerBatch.Id);
            Assert.AreEqual(1, loadedPayments.Count);
        }

        [Test]
        public void GetActivePaymentByCustomerBatchId_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var loadedPayment = PaymentMapper.Instance.GetActiveBatchPayment(customerBatch, payment.ExternalId);
            Assert.IsNotNull(loadedPayment);
        }

        [Test]
        public void GetActivePaymentByCustomerBatchId_ReturnsNullIfPaymentNotFound()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var loadedPayment = PaymentMapper.Instance.GetActiveBatchPayment(customerBatch, "test");
            Assert.IsNull(loadedPayment);
        }

        [Test]
        public void UpdatePaymentStatusesAndSanctionScanStatuses_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));
            payment.PaymentStatus = PaymentStatus.SanctionCleared;
            payment.SanctionScanStatus = PaymentSanctionScanStatus.Unblock;

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));
            payment1.PaymentStatus = PaymentStatus.Committed;

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));
            payment2.PaymentStatus = PaymentStatus.Committed;
            payment2.SanctionScanStatus = PaymentSanctionScanStatus.Block;
            PaymentMapper.Instance.UpdatePaymentStatuses(new List<Payment> { payment2 });
            payment2 = PaymentMapper.Instance.GetPayment(payment2.PaymentSourceId, payment2.ExternalId);

            PaymentMapper.Instance.UpdatePaymentStatuses(new List<Payment> { payment, payment1, payment2 });
            var utcNow = DateTime.UtcNow;
            var loadedPayments = PaymentMapper.Instance.GetPayments(customerBatch, 5);

            //paymentStatus and SanctionScanStatus are all updated correctly
            Assert.AreEqual(PaymentStatus.SanctionCleared, loadedPayments[0].PaymentStatus);
            Assert.AreEqual(PaymentSanctionScanStatus.Unblock, loadedPayments[0].SanctionScanStatus);
            Assert.IsNotNull(loadedPayments[0].SanctionScanStatusUpdatedOnUtc);
            Assert.AreEqual(loadedPayments[0].SanctionScanStatusUpdatedOnUtc.Value.Day, utcNow.Day);

            //sanctionScanStatus and updatedOn remain null when sanctionScanStatus was not submitted
            Assert.AreEqual(PaymentStatus.Committed, loadedPayments[1].PaymentStatus);
            Assert.AreEqual(null, loadedPayments[1].SanctionScanStatus);
            Assert.AreEqual(null, loadedPayments[1].SanctionScanStatusUpdatedOnUtc);

            //sanctionScanStatus and updatedOn remain unchanged when same sanctionScanStatus was submitted
            Assert.AreEqual(PaymentStatus.Committed, loadedPayments[2].PaymentStatus);
            Assert.AreEqual(payment2.SanctionScanStatus, loadedPayments[2].SanctionScanStatus);
            Assert.AreEqual(payment2.SanctionScanStatusUpdatedOnUtc, loadedPayments[2].SanctionScanStatusUpdatedOnUtc);
        }

        [Test]
        public void UpdatePaymentStatusesAndSanctionScanStatuses_DoesNotSanctionStatusAndTimestamp_WhenNotSet()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment1));
            payment1.PaymentStatus = PaymentStatus.Committed;

            PaymentMapper.Instance.UpdatePaymentStatuses(new List<Payment> { payment1 });
            var loadedPayments = PaymentMapper.Instance.GetPayments(customerBatch, 5);

            //sanctionScanStatus and updatedOn remain null when sanctionScanStatus was not submitted
            Assert.AreEqual(PaymentStatus.Committed, loadedPayments[0].PaymentStatus);
            Assert.AreEqual(null, loadedPayments[0].SanctionScanStatus);
            Assert.AreEqual(null, loadedPayments[0].SanctionScanStatusUpdatedOnUtc);
        }

        [Test]
        public void GetByCurrencyAndOrStatus_CorrectAmountWhenSettlementAmountIsNull()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var paymentCADCleared = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            paymentCADCleared.PaymentStatus = PaymentStatus.SanctionCleared;
            paymentCADCleared.AmountMoney = new Money(Currency.CAD, 10);
            paymentCADCleared.SettlementAmountMoney = new Money(Currency.AUD, 20);
            paymentCADCleared.PaymentMethod = PaymentMethod.ACH;
            PaymentMapper.Instance.InsertPayment(paymentCADCleared);

            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.MassPayments);
            using (var connection = new SqlConnection(connectionString))
            using (var command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = $"update [MP].[Payment] set SettlementAmount = NULL where id = { paymentCADCleared.Id }";
                command.ExecuteNonQuery();
            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.GetPayments(Currency.CAD, PaymentStatus.SanctionCleared));
        }

        [Test]
        public void GetPaymentByCustomerBatchIdAndPaymentId_ReturnsCorrectResults()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            PaymentMapper.Instance.InsertPayment(payment);

            var returnedPayment = PaymentMapper.Instance.GetPayment(customerBatch, payment.ExternalId);

            ValidatePayment(payment, returnedPayment);
        }

        [Test]
        public void GetPaymentByCustomerBatchIdAndPaymentId_ReturnsNullWhenWrongBatchIdIsUsed()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            PaymentMapper.Instance.InsertPayment(payment);

            customerBatch.Id++;
            var returnedPayment = PaymentMapper.Instance.GetPayment(customerBatch, payment.ExternalId);

            Assert.IsNull(returnedPayment);
        }

        [Test]
        public void GetPaymentByCustomerBatchIdAndPaymentId_ReturnsNullWhenWrongPaymentIdIsUsed()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            PaymentMapper.Instance.InsertPayment(payment);

            var returnedPayment = PaymentMapper.Instance.GetPayment(customerBatch, payment.ExternalId + "gorilla");

            Assert.IsNull(returnedPayment);
        }

        [Test]
        public void GetPaymentByCustomerBatchIdAndPaymentIds_ReturnsAllPaymentsRequested()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);

            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var returnedPayments = PaymentMapper.Instance.GetPayments(customerBatch, new List<string> { "111", "222" });

            Assert.AreEqual(2, returnedPayments.Count);
            ValidatePayment(payment1, returnedPayments[0]);
            ValidatePayment(payment2, returnedPayments[1]);
        }

        [Test]
        public void GetPaymentByCustomerBatchIdAndPaymentIds_ReturnsCorrectPaymentsWhenSamePaymentIdExistsMoreThanOnce()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);
            payment2.PaymentStatus = PaymentStatus.Cancelled;
            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);
            var payment3 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch1);
            PaymentMapper.Instance.InsertPayment(payment3);

            var returnedPayments = PaymentMapper.Instance.GetPayments(customerBatch, new List<string> { "111", "222" });

            Assert.AreEqual(2, returnedPayments.Count);
            ValidatePayment(payment1, returnedPayments[0]);
            ValidatePayment(payment2, returnedPayments[1]);
        }

        [Test]
        public void GetPaymentByCustomerBatchIdAndPaymentIds_ReturnsSinglePayment()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);

            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var returnedPayments = PaymentMapper.Instance.GetPayments(customerBatch, new List<string> { "111" });

            Assert.AreEqual(1, returnedPayments.Count);
            ValidatePayment(payment1, returnedPayments[0]);
        }

        private void ValidatePayment(Payment expected, Payment target)
        {
            Assert.AreEqual(expected.AmountMoney.Amount, target.AmountMoney.Amount);
            Assert.AreEqual(expected.SettlementAmountMoney.Amount, target.SettlementAmountMoney.Amount);
            Assert.AreEqual(expected.ExternalId, target.ExternalId);
            Assert.AreEqual(expected.AmountMoney.Currency.Code, target.AmountMoney.Currency.Code);
            Assert.AreEqual(expected.SettlementAmountMoney.Currency.Code, target.SettlementAmountMoney.Currency.Code);
            Assert.AreEqual(expected.PaymentMethod, target.PaymentMethod);
            Assert.AreEqual(expected.ExternalId, target.ExternalId);

            Assert.AreEqual(expected.PaymentMethod, target.PaymentMethod);
            Assert.AreEqual(expected.PaymentSourceId, target.PaymentSourceId);
            Assert.AreEqual(expected.TransactionSystemCustomerId, target.TransactionSystemCustomerId);
            Assert.AreEqual(expected.TransactionSystemId, target.TransactionSystemId);
            Assert.AreEqual(expected.CreatedOnUTC.ToShortTimeString(), target.CreatedOnUTC.ToShortTimeString());
            Assert.AreEqual(expected.CreatedOnUTC.Date, target.CreatedOnUTC.Date);
            Assert.AreEqual(expected.RequestedReleaseDate.Value.Date, target.RequestedReleaseDate.Value.Date);
            var beneficiary = target.Beneficiary;
            var paymentBene = expected.Beneficiary;
            if (paymentBene != null)
            {
                Assert.AreEqual(paymentBene.ExternalId, beneficiary.ExternalId);
                Assert.AreEqual(paymentBene.CustomerBeneId, beneficiary.CustomerBeneId);
                Assert.AreEqual(paymentBene.Version, beneficiary.Version);
                Assert.AreEqual(paymentBene.VersionedOn, beneficiary.VersionedOn);

                var targetIdentification = beneficiary.Identification;
                var paymentIdentification = expected.Beneficiary.Identification;
                if (paymentIdentification != null)
                {
                    Assert.AreEqual(paymentIdentification.FirstName, targetIdentification.FirstName);
                    Assert.AreEqual(paymentIdentification.MiddleName, targetIdentification.MiddleName);
                    Assert.AreEqual(paymentIdentification.LastName, targetIdentification.LastName);
                    Assert.AreEqual(paymentIdentification.PhoneNumber, targetIdentification.PhoneNumber);
                    Assert.AreEqual(paymentIdentification.CellNumber, targetIdentification.CellNumber);
                    Assert.AreEqual(paymentIdentification.DateOfBirth, targetIdentification.DateOfBirth);
                    Assert.AreEqual(paymentIdentification.Gender, targetIdentification.Gender);
                    Assert.AreEqual(paymentIdentification.EntityType, targetIdentification.EntityType);
                    Assert.AreEqual(paymentIdentification.BusinessName, targetIdentification.BusinessName);
                    Assert.AreEqual(paymentIdentification.BusinessRegistrationNumber, targetIdentification.BusinessRegistrationNumber);
                    Assert.AreEqual(paymentIdentification.BusinessRegistrationCountry, targetIdentification.BusinessRegistrationCountry);
                    Assert.AreEqual(paymentIdentification.BusinessRegistrationStateProv, targetIdentification.BusinessRegistrationStateProv);
                    Assert.AreEqual(paymentIdentification.BusinessContactRole, targetIdentification.BusinessContactRole);
                    Assert.AreEqual(paymentIdentification.Industry, targetIdentification.Industry);
                    Assert.AreEqual(paymentIdentification.EmailAddress, targetIdentification.EmailAddress);
                }

                var targetBeneAddress = beneficiary.Address;
                var paymentBeneAddress = expected.Beneficiary.Address;
                if (targetBeneAddress != null)
                {
                    Assert.AreEqual(paymentBeneAddress.AddressLine1, targetBeneAddress.AddressLine1);
                    Assert.AreEqual(paymentBeneAddress.AddressLine2, targetBeneAddress.AddressLine2);
                    Assert.AreEqual(paymentBeneAddress.AddressLine3, targetBeneAddress.AddressLine3);
                    Assert.AreEqual(paymentBeneAddress.City, targetBeneAddress.City);
                    Assert.AreEqual(paymentBeneAddress.StateOrProvince, targetBeneAddress.StateOrProvince);
                    Assert.AreEqual(paymentBeneAddress.ZipOrPostalCode, targetBeneAddress.ZipOrPostalCode);
                    Assert.AreEqual(paymentBeneAddress.CountryCode, targetBeneAddress.CountryCode);
                }
            }

            var targetBankAccount = target.BankAccount;
            var paymentBankAccount = expected.BankAccount;
            if (targetBankAccount != null)
            {
                Assert.AreEqual(paymentBankAccount.Version, targetBankAccount.Version);
                Assert.AreEqual(paymentBankAccount.VersionedOn, paymentBankAccount.VersionedOn);
                Assert.AreEqual(paymentBankAccount.ExternalId, targetBankAccount.ExternalId);
                Assert.AreEqual(paymentBankAccount.AccountNumber, targetBankAccount.AccountNumber);
                Assert.AreEqual(paymentBankAccount.ExternalAccountType, targetBankAccount.ExternalAccountType);
                Assert.AreEqual(paymentBankAccount.AccountPurpose, targetBankAccount.AccountPurpose);
                Assert.AreEqual(paymentBankAccount.BankName, targetBankAccount.BankName);
                Assert.AreEqual(paymentBankAccount.BranchName, targetBankAccount.BranchName);
                Assert.AreEqual(paymentBankAccount.BankCode, targetBankAccount.BankCode);
                Assert.AreEqual(paymentBankAccount.BranchCode, targetBankAccount.BranchCode);
                Assert.AreEqual(paymentBankAccount.DisplayName, targetBankAccount.DisplayName);
                Assert.AreEqual(paymentBankAccount.BankAccountOwnerName, targetBankAccount.BankAccountOwnerName);

                var targetBankAddress = targetBankAccount.BankAddress;
                var paymentBankAddress = expected.BankAccount.BankAddress;
                if (targetBankAddress != null)
                {
                    Assert.AreEqual(paymentBankAddress.AddressLine1, targetBankAddress.AddressLine1);
                    Assert.AreEqual(paymentBankAddress.AddressLine2, targetBankAddress.AddressLine2);
                    Assert.AreEqual(paymentBankAddress.AddressLine3, targetBankAddress.AddressLine3);
                    Assert.AreEqual(paymentBankAddress.City, targetBankAddress.City);
                    Assert.AreEqual(paymentBankAddress.StateOrProvince, targetBankAddress.StateOrProvince);
                    Assert.AreEqual(paymentBankAddress.ZipOrPostalCode, targetBankAddress.ZipOrPostalCode);
                    Assert.AreEqual(paymentBankAddress.CountryCode, targetBankAddress.CountryCode);
                }

                var targetIntermediaryBank = targetBankAccount.IntermediaryBankAccount;
                var IntermediaryBank = expected.BankAccount.IntermediaryBankAccount;

                if (targetIntermediaryBank != null)
                {
                    Assert.AreEqual(IntermediaryBank.BankCode, targetIntermediaryBank.BankCode);
                    Assert.AreEqual(IntermediaryBank.BankName, targetIntermediaryBank.BankName);
                    Assert.AreEqual(IntermediaryBank.AccountNumber, targetIntermediaryBank.AccountNumber);
                    Assert.AreEqual(IntermediaryBank.BankBranchCode, targetIntermediaryBank.BankBranchCode);
                    Assert.AreEqual(IntermediaryBank.BankAddress.AddressLine1, targetIntermediaryBank.BankAddress.AddressLine1);
                    Assert.AreEqual(IntermediaryBank.BankAddress.AddressLine2, targetIntermediaryBank.BankAddress.AddressLine2);
                    Assert.AreEqual(IntermediaryBank.BankAddress.AddressLine3, targetIntermediaryBank.BankAddress.AddressLine3);
                    Assert.AreEqual(IntermediaryBank.BankAddress.City, targetIntermediaryBank.BankAddress.City);
                    Assert.AreEqual(IntermediaryBank.BankAddress.CountryCode, targetIntermediaryBank.BankAddress.CountryCode);
                    Assert.AreEqual(IntermediaryBank.BankAddress.ZipOrPostalCode, targetIntermediaryBank.BankAddress.ZipOrPostalCode);
                }
            }

            ValidateRemittance(expected.RemittanceData, target.RemittanceData);
            ValidateThirdPartyRemitter(expected.ThirdPartyRemitter, target.ThirdPartyRemitter);
        }

        [Test]
        public void PaymentUpdateHistoryInsert_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest>()
            };

            request.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(new PaymentUpdateHistory
            {
                ErrorCode = "1234",
                PaymentId = payment.Id,
                PaymentRequestId = request.Id
            }));
        }

        [Test]
        public void PaymentUpdateHistoryGet_ReturnsLatestHistory()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest>()
            };

            request.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            var earlyHistory = new PaymentUpdateHistory
            {
                ErrorCode = "1234",
                PaymentId = payment.Id,
                PaymentRequestId = request.Id,
                UpdatedOnUtc = DateTime.Now.AddDays(-1)
            };
            var lateHistory = new PaymentUpdateHistory
            {
                ErrorCode = "5678",
                PaymentId = payment.Id,
                PaymentRequestId = request.Id,
                UpdatedOnUtc = DateTime.Now
            };

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(earlyHistory));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(lateHistory));

            var loadedHistory = PaymentMapper.Instance.GetPaymentUpdateHistoryByPaymentIdForTesting(payment.Id);
            Assert.AreEqual(lateHistory.ErrorCode, loadedHistory.ErrorCode);
        }

        [Test]
        public void PaymentUpdateHistoryGet_AllowsNullInErrorCode()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest>()
            };

            request.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            var lateHistory = new PaymentUpdateHistory
            {
                PaymentId = payment.Id,
                PaymentRequestId = request.Id,
                UpdatedOnUtc = DateTime.Now
            };

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(lateHistory));

            var loadedHistory = PaymentMapper.Instance.GetPaymentUpdateHistoryByPaymentIdForTesting(payment.Id);
            Assert.AreEqual(null, loadedHistory.ErrorCode);
        }

        [Test]
        public void PaymentUpdateHistoryGet_ThrowsIfNotFound()
        {
            Assert.Throws<ArgumentException>(() => PaymentMapper.Instance.GetPaymentUpdateHistoryByPaymentIdForTesting(123));
        }

        [Test]
        public void GetPayment_LoadsLastUpdateError_Correctly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.SanctionCleared;
            payment.SanctionScanStatus = PaymentSanctionScanStatus.Unblock;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest>()
            };

            request.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            var earlyHistory = new PaymentUpdateHistory
            {
                ErrorCode = "1234",
                PaymentId = payment.Id,
                PaymentRequestId = request.Id,
                UpdatedOnUtc = DateTime.Now.AddDays(-1)
            };
            var lateHistory = new PaymentUpdateHistory
            {
                ErrorCode = "5678",
                PaymentId = payment.Id,
                PaymentRequestId = request.Id,
                UpdatedOnUtc = DateTime.Now
            };

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(earlyHistory));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(lateHistory));

            var loadedHistory1 = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId);
            var loadedHistory2 = PaymentMapper.Instance.GetPayments(payment.AmountMoney.Currency, payment.PaymentStatus);
            var loadedHistory3 = PaymentMapper.Instance.GetPayments(payment.PaymentSourceId, new List<string> { payment.ExternalId });
            var loadedHistory4 = PaymentMapper.Instance.GetPayments(new List<int> { payment.Id });
            var loadedHistory6 = PaymentMapper.Instance.GetPayments(customerBatch, 5);
            var loadedHistory7 = PaymentMapper.Instance.GetSanctionClearedPaymentsForCustomer(payment.AmountMoney.Currency, payment.PaymentMethod.Value, customer.Id);
            var loadedHistory8 = PaymentMapper.Instance.GetPayment(payment.ExternalId, payment.PaymentSourceId, payment.PaymentStatus);
            var loadedHistory9 = PaymentMapper.Instance.GetPayment(payment.PaymentSourceId, payment.ExternalId);
            var loadedHistory10 = PaymentMapper.Instance.GetPayment(customerBatch, payment.ExternalId);
            var loadedHistory11 = PaymentMapper.Instance.GetAcceptedPaymentsByCustomerBatchId(customerBatch.Id);

            AssertLoadedLastUpdateError(lateHistory, loadedHistory1[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory1.Count);   //Make sure only 1 payment update history is returned. 
            AssertLoadedLastUpdateError(lateHistory, loadedHistory2[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory2.Count);
            AssertLoadedLastUpdateError(lateHistory, loadedHistory3[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory3.Count);
            AssertLoadedLastUpdateError(lateHistory, loadedHistory4[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory4.Count);
            AssertLoadedLastUpdateError(lateHistory, loadedHistory6[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory6.Count);
            AssertLoadedLastUpdateError(lateHistory, loadedHistory7[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory7.Count);

            AssertLoadedLastUpdateError(lateHistory, loadedHistory8.LastUpdateError);
            AssertLoadedLastUpdateError(lateHistory, loadedHistory9.LastUpdateError);

            AssertLoadedLastUpdateError(lateHistory, loadedHistory10.LastUpdateError);
            AssertLoadedLastUpdateError(lateHistory, loadedHistory11[0].LastUpdateError);

            Assert.AreEqual(1, loadedHistory11.Count);
        }

        [Test]
        public void GetPayment_LoadsPaymentsWithNoLastUpdateError_Correctly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.SanctionCleared;
            payment.SanctionScanStatus = PaymentSanctionScanStatus.Unblock;
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment));

            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest>()
            };

            request.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            var loadedHistory1 = PaymentMapper.Instance.GetPayments(payment.ExternalId, payment.PaymentSourceId);
            var loadedHistory2 = PaymentMapper.Instance.GetPayments(payment.AmountMoney.Currency, payment.PaymentStatus);
            var loadedHistory3 = PaymentMapper.Instance.GetPayments(payment.PaymentSourceId, new List<string> { payment.ExternalId });
            var loadedHistory4 = PaymentMapper.Instance.GetPayments(new List<int> { payment.Id });
            var loadedHistory6 = PaymentMapper.Instance.GetPayments(customerBatch, 5);
            var loadedHistory7 = PaymentMapper.Instance.GetSanctionClearedPaymentsForCustomer(payment.AmountMoney.Currency, payment.PaymentMethod.Value, customer.Id);
            var loadedHistory8 = PaymentMapper.Instance.GetPayment(payment.ExternalId, payment.PaymentSourceId, payment.PaymentStatus);
            var loadedHistory9 = PaymentMapper.Instance.GetPayment(payment.PaymentSourceId, payment.ExternalId);
            var loadedHistory10 = PaymentMapper.Instance.GetPayment(customerBatch, payment.ExternalId);
            var loadedHistory11 = PaymentMapper.Instance.GetAcceptedPaymentsByCustomerBatchId(customerBatch.Id);

            Assert.IsNull(loadedHistory1[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory1.Count);   //Make sure only 1 payment update history is returned. 
            Assert.IsNull(loadedHistory2[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory2.Count);
            Assert.IsNull(loadedHistory3[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory3.Count);
            Assert.IsNull(loadedHistory4[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory4.Count);
            Assert.IsNull(loadedHistory6[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory6.Count);
            Assert.IsNull(loadedHistory7[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory7.Count);
            Assert.IsNull(loadedHistory8.LastUpdateError);
            Assert.IsNull(loadedHistory9.LastUpdateError);
            Assert.IsNull(loadedHistory10.LastUpdateError);
            Assert.IsNull(loadedHistory11[0].LastUpdateError);
            Assert.AreEqual(1, loadedHistory11.Count);
        }

        [Test]
        public void GetPaymentsByCustomerIdAndPaymentIds_ReturnsCorrectResults()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            PaymentMapper.Instance.InsertPayment(payment);

            var returnedPayments = PaymentMapper.Instance.GetPayments(customer, new List<string> { payment.ExternalId });
            Assert.AreEqual(1, returnedPayments.Count);
            ValidatePayment(payment, returnedPayments[0]);
        }

        [Test]
        public void GetPaymentsByCustomerIdAndPaymentIds_ReturnsNothingWhenWrongCustomerIsUsed()
        {
            var customer1 = CustomerHelper.Instance.CreateCustomer();
            var customer2 = CustomerHelper.Instance.CreateCustomer();
            customer1.Id = CustomerMapper.Instance.InsertCustomer(customer1);
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer1);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment = PaymentHelper.Instance.CreatePayment(customer1, customerBatch);
            PaymentMapper.Instance.InsertPayment(payment);

            var returnedPayment = PaymentMapper.Instance.GetPayments(customer2, new List<string> { payment.ExternalId });

            Assert.AreEqual(0, returnedPayment.Count);
        }

        [Test]
        public void GetPaymentsByCustomerIdAndPaymentId_ReturnsNothingWhenWrongPaymentIdIsUsed()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            PaymentMapper.Instance.InsertPayment(payment);

            var returnedPayment = PaymentMapper.Instance.GetPayments(customer, new List<string> { payment.ExternalId + "gorilla" });

            Assert.AreEqual(0, returnedPayment.Count);
        }

        [Test]
        public void GetPaymentsByCustomerIdAndPaymentIds_ReturnsAllPaymentsRequested()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);

            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var returnedPayments = PaymentMapper.Instance.GetPayments(customer, new List<string> { "111", "222" });

            Assert.AreEqual(2, returnedPayments.Count);
            ValidatePayment(payment1, returnedPayments[0]);
            ValidatePayment(payment2, returnedPayments[1]);
        }

        [Test, Description("Add payments with same Id in two batches for two different customers but only payment belonging to customer passed should be returned")]
        public void GetPaymentsByCustomerIdAndPaymentIds_ReturnsPaymentsCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var customer2 = CustomerHelper.Instance.CreateCustomer();
            customer2.Id = CustomerMapper.Instance.InsertCustomer(customer2);
            var customerBatch2 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer2);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch2);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer2, "111", customerBatch2);

            payment1.PaymentReference += "Batch123";
            payment2.PaymentReference += "Batch12311";

            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var returnedPaymentsForCust1 = PaymentMapper.Instance.GetPayments(customer, new List<string> { "111" });
            var returnedPaymentsForCust2 = PaymentMapper.Instance.GetPayments(customer2, new List<string> { "111" });

            Assert.AreEqual(1, returnedPaymentsForCust1.Count);
            Assert.AreEqual(1, returnedPaymentsForCust2.Count);
            ValidatePayment(payment1, returnedPaymentsForCust1[0]);
            ValidatePayment(payment2, returnedPaymentsForCust2[0]);
        }
        [Test]
        public void BatchPaymentBulkInsert_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.PartnerAssignedCustomerId = "432-41234-41234";
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(payment1.AmountMoney.Currency, 777);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "ref2a", "ref2b" };

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.UpdatedOnUTC = DateTime.UtcNow;
            payment3.RemittanceData = new List<string> { "ref3a", "ref3b", "ref3c" };

            var paymentsList = new List<Payment> { payment1, payment2, payment3 };

            PaymentMapper.Instance.PaymentBulkInsert(paymentsList);

            var actualPayments = PaymentMapper.Instance.GetPayments(customer, paymentsList.Select(q => q.ExternalId).ToList());

            Assert.AreEqual(3, actualPayments.Count);

            Assert.AreEqual(payment1.RemittanceData.Count, actualPayments.First(i => i.ExternalId == payment1.ExternalId).RemittanceData.Count);
            Assert.AreEqual(payment2.RemittanceData.Count, actualPayments.First(i => i.ExternalId == payment2.ExternalId).RemittanceData.Count);
            Assert.AreEqual(payment3.RemittanceData.Count, actualPayments.First(i => i.ExternalId == payment3.ExternalId).RemittanceData.Count);
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment1.ExternalId));
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment2.ExternalId));
            Assert.IsTrue(actualPayments.Select(i => i.ExternalId).Contains(payment3.ExternalId));
            Assert.AreEqual(actualPayments[0].PaymentReference, payment1.PaymentReference);
            Assert.AreEqual("432-41234-41234", actualPayments[0].ExternalCustomerId);
            Assert.AreEqual("432-41234-41234", actualPayments[1].ExternalCustomerId);
            Assert.AreEqual("432-41234-41234", actualPayments[2].ExternalCustomerId);
        }

        [Test]
        public void BulkInsertPaymentAmountAdjustmentHistory_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(payment.AmountMoney.Currency, 777);
            payment.UpdatedOnUTC = DateTime.UtcNow;
            payment.RemittanceData = new List<string> { "ref1a" };

            PaymentMapper.Instance.InsertPayment(payment);

            var histories = new List<PaymentAmountAdjustmentHistory>
            {
                new PaymentAmountAdjustmentHistory
                {
                    PaymentId = payment.Id,
                    OldAmount = 1m,
                    NewAmount = 2m,
                    UpdatedOnUtc = DateTime.UtcNow
                },
                new PaymentAmountAdjustmentHistory
                {
                    PaymentId = payment.Id,
                    OldSettlementAmount = 3m,
                    NewSettlementAmount = 4m,
                    UpdatedOnUtc = DateTime.UtcNow
                }
            };

            PaymentMapper.Instance.BulkInsertPaymentAmountAdjustmentHistory(histories);
            var loadedHistories = PaymentMapper.Instance.GetPaymentAmountAdjustmentHistoryForTesting(payment.Id);
            Assert.AreEqual(histories.Count, loadedHistories.Count);
            Assert.AreEqual(histories[0].OldAmount, loadedHistories[0].OldAmount);
            Assert.AreEqual(histories[0].NewAmount, loadedHistories[0].NewAmount);
            Assert.AreEqual(histories[0].OldSettlementAmount, loadedHistories[0].OldSettlementAmount);
            Assert.AreEqual(histories[0].NewSettlementAmount, loadedHistories[0].NewSettlementAmount);
            Assert.AreEqual(histories[1].OldAmount, loadedHistories[1].OldAmount);
            Assert.AreEqual(histories[1].NewAmount, loadedHistories[1].NewAmount);
            Assert.AreEqual(histories[1].OldSettlementAmount, loadedHistories[1].OldSettlementAmount);
            Assert.AreEqual(histories[1].NewSettlementAmount, loadedHistories[1].NewSettlementAmount);
        }

        [Test]
        public void InsertPaymentsRejected_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(newPayment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);

            foreach (var payment in loadedPayments)
            {
                payment.PaymentStatus = PaymentStatus.Rejected;
            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(loadedPayments));
        }


        [Test]
        public void InsertPaymentValidationLog_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(newPayment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);

            foreach (var payment in loadedPayments)
            {
                payment.PaymentStatus = PaymentStatus.Rejected;
                var log = new PaymentValidationLog
                {
                    PaymentId = payment.Id,
                    ExternalPaymentId = payment.ExternalId,
                    CustomerBatchId = payment.CustomerBatchId,
                    ExternalCustomerId = payment.ExternalCustomerId,
                    ErrorCode = "1234",
                    ErrorMessage = "test",
                    StackTrace = "test stack trace"
                };
                Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentValidationLog(log));
            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(loadedPayments));
        }

        [Test]
        public void InsertReturnedPayments_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(newPayment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);
            var returnedPayments = new List<Payment>();

            foreach (var payment in loadedPayments)
            {
                returnedPayments.Add(new ReturnedPayment(payment.Id)
                {
                    PaymentStatus = PaymentStatus.Returned,
                    ReturnAmount = payment.AmountMoney,
                    RejectReason = "Returned by Bank",
                    UserName = "TIBCO User"
                });
            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertReturnedPayments(returnedPayments));
        }

        [Test]
        public void InsertReturnedPayments_EntryIsNotDuplicated()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(newPayment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);
            var returnedPayments = new List<Payment>();

            foreach (var payment in loadedPayments)
            {
                returnedPayments.Add(new ReturnedPayment(payment.Id)
                {
                    PaymentStatus = PaymentStatus.Returned,
                    ReturnAmount = payment.AmountMoney,
                    RejectReason = "Returned by Bank",
                    UserName = "TIBCO User"
                });
            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertReturnedPayments(returnedPayments));
            returnedPayments[0].RejectReason = "Resubmitted";

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertReturnedPayments(returnedPayments));
            var selectStatement = $"SELECT * FROM MP.PaymentsRejected WHERE PaymentId = '{loadedPayments[0].Id}'";
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    var i = 0;
                    while (reader.Read())
                    {
                        Assert.AreEqual(returnedPayments[0].RejectReason, Convert.ToString(reader["Reason"]));
                        i++;
                    }

                    Assert.AreEqual(1, i);
                }
            }
        }

        [Test]
        public void InsertUpdateReturnedPaymentStatusinHistory_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(newPayment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);
            var returnedPayments = new List<Payment>();

            foreach (var payment in loadedPayments)
            {
                returnedPayments.Add(new ReturnedPayment(payment.Id)
                {
                    PaymentStatus = PaymentStatus.Returned,
                    ReturnAmount = payment.AmountMoney,
                    RejectReason = "Returned by Bank",
                    UserName = "TIBCO User"
                });
            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertUpdateReturnedPaymentStatusinHistory(returnedPayments));
        }

        [Test]
        public void InsertUpdateReturnedPaymentStatusinHistory_IsUpdated()
        {
            DateTime createdONUTC = DateTime.MinValue;
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(newPayment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);
            var returnedPayments = new List<Payment>();

            foreach (var payment in loadedPayments)
            {
                returnedPayments.Add(new ReturnedPayment(payment.Id)
                {
                    PaymentStatus = PaymentStatus.Returned,
                    ReturnAmount = payment.AmountMoney,
                    RejectReason = "Returned by Bank",
                    UserName = "TIBCO User"
                });
            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertUpdateReturnedPaymentStatusinHistory(returnedPayments));
            var selectStatement = $"SELECT * FROM MP.PaymentStatusHistory WHERE PaymentId = '{returnedPayments[0].Id}'";
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    while (reader.Read())
                    {
                        createdONUTC = Convert.ToDateTime(reader["CreatedOnUTC"]);
                        Assert.AreEqual(createdONUTC.TimeOfDay, Convert.ToDateTime(reader["UpdatedOnUTC"]).TimeOfDay);
                    }
                    
                }
            }

            Thread.Sleep(1000);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertUpdateReturnedPaymentStatusinHistory(returnedPayments));
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    var i = 0;
                    while (reader.Read())
                    {
                        Assert.AreNotEqual(createdONUTC, Convert.ToDateTime(reader["UpdatedOnUTC"]));
                        i++;
                    }

                    Assert.AreEqual(1, i);
                }
            }
        }

        [Test]
        public void ReturnPayments_InsertsAndMaps_Successfully()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var returnPayment = PaymentHelper.Instance.CreateReturnPayment(customer, customerBatch);
            returnPayment.PaymentStatus = PaymentStatus.Returned;
            returnPayment.ReturnAmount = new Money(Currency.CAD, 50.00m);
            returnPayment.RejectReason = "Return from Bank";
            returnPayment.UserName = "blah";

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(returnPayment));

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(new List<Payment> {returnPayment}));

            var payments = PaymentMapper.Instance.GetPayments(returnPayment.ExternalId, returnPayment.PaymentSourceId);

            Assert.AreEqual(1, payments.Count);
            Assert.IsInstanceOf<ReturnedPayment>(payments[0]);
            Assert.AreEqual("Return from Bank", payments[0].RejectReason);
            Assert.AreEqual(PaymentStatus.Returned, payments[0].PaymentStatus);
            Assert.AreEqual(Currency.CAD, ((ReturnedPayment)payments[0]).ReturnAmount.Currency);
            Assert.AreEqual(50.00m, ((ReturnedPayment)payments[0]).ReturnAmount.Amount);
        }

        [Test]
        public void GetPayments_Works_ForRejected_Decoupled()
        {
            var timestamp = DateTime.UtcNow;
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(newPayment));

            var loadedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);
            foreach (var payment in loadedPayments)
            {
                payment.RejectReason = "rejected for testing";
                payment.PaymentStatus = PaymentStatus.Rejected;
                payment.GPGProcessedUTC = timestamp;

            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.UpdatePaymentStatuses(loadedPayments.Select(rp => rp.Id).ToList(), loadedPayments.Select(rp => rp.PaymentStatus).ToList(),
                                loadedPayments.Select(rp => (DateTime)rp.GPGProcessedUTC).ToList()));

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(loadedPayments));

            var rejectedPayments = PaymentMapper.Instance.GetPayments(newPayment.ExternalId, newPayment.PaymentSourceId);

            Assert.AreEqual(1, rejectedPayments.Count);
            Assert.AreEqual("rejected for testing", rejectedPayments[0].RejectReason);
            Assert.AreEqual(PaymentStatus.Rejected, rejectedPayments[0].PaymentStatus);
            //sql time does not match .NET time
            //            Assert.AreEqual(timestamp, rejectedPayments[0].GPGProcessedUTC);

        }

        [Test]
        public void GetPayments_Works_ForRejected_Coupled()
        {
            var timestamp = DateTime.UtcNow;
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            customerBatch.BatchType = BatchType.ApiBatch;
            customerBatch.ExternalId = "Batch123";
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);

            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            var loadedPayments = PaymentMapper.Instance.GetPayments(customerBatch, new List<string> { "111", "222" });

            foreach (var payment in loadedPayments)
            {
                payment.RejectReason = "rejected for testing " + payment.Id;
                payment.PaymentStatus = PaymentStatus.Rejected;
                payment.GPGProcessedUTC = timestamp;

            }

            Assert.DoesNotThrow(() => PaymentMapper.Instance.UpdatePaymentStatuses(loadedPayments.Select(rp => rp.Id).ToList(), loadedPayments.Select(rp => rp.PaymentStatus).ToList(),
                                loadedPayments.Select(rp => (DateTime)rp.GPGProcessedUTC).ToList()));

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(loadedPayments));

            var rejectedPayments = PaymentMapper.Instance.GetPayments(customerBatch, new List<string> { "111", "222" });

            Assert.AreEqual(2, rejectedPayments.Count);
            Assert.AreEqual("rejected for testing " + rejectedPayments[0].Id, rejectedPayments[0].RejectReason);
            Assert.AreEqual(PaymentStatus.Rejected, rejectedPayments[0].PaymentStatus);
            Assert.AreEqual("rejected for testing " + +rejectedPayments[1].Id, rejectedPayments[1].RejectReason);
            Assert.AreEqual(PaymentStatus.Rejected, rejectedPayments[1].PaymentStatus);
            //sql time does not match .NET time
            //            Assert.AreEqual(timestamp, rejectedPayments[0].GPGProcessedUTC);

        }

        [Test]
        public void UpdatePaymentStatusesAndIncomingOrderInfo_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);

            PaymentMapper.Instance.InsertPayment(payment1);
            PaymentMapper.Instance.InsertPayment(payment2);

            payment1.PaymentStatus = PaymentStatus.Committed;
            payment1.TransactionSystemIncomingOrderId = 123;
            payment1.TransactionSystemIncomingOrderNumber = "Payment1Cfrm";
            payment2.PaymentStatus = PaymentStatus.Committed;
            payment2.TransactionSystemIncomingOrderId = 456;
            payment2.TransactionSystemIncomingOrderNumber = "Payment2Cfrm";

            PaymentMapper.Instance.UpdatePaymentStatusesAndIncomingOrderInfo(new List<Payment> { payment1, payment2 });

            var loadedPayments = PaymentMapper.Instance.GetPayments(customerBatch);
            Assert.AreEqual(2, loadedPayments.Count);
            Assert.AreEqual(payment1.PaymentStatus, loadedPayments[0].PaymentStatus);
            Assert.AreEqual(payment1.TransactionSystemIncomingOrderId, loadedPayments[0].TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment1.TransactionSystemIncomingOrderNumber, loadedPayments[0].TransactionSystemIncomingOrderNumber);

            Assert.AreEqual(payment2.PaymentStatus, loadedPayments[1].PaymentStatus);
            Assert.AreEqual(payment2.TransactionSystemIncomingOrderId, loadedPayments[1].TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment2.TransactionSystemIncomingOrderNumber, loadedPayments[1].TransactionSystemIncomingOrderNumber);
        }

        [Test]
        public void GetPaymentsByPaymentSource_PaymentStatusFilterWorks()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment);

            payment = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment);

            payment = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment.PaymentStatus = PaymentStatus.Sent;
            PaymentMapper.Instance.InsertPayment(payment);

            var payments = PaymentMapper.Instance.GetPayments(customer.PartnerId, 10, PaymentStatus.Created);

            Assert.AreEqual(2, payments.Count);
            Assert.AreEqual("3333", payments[0].ExternalId);
            Assert.AreEqual("2222", payments[1].ExternalId);
        }

        [Test]
        public void GetPaymentsByPaymentSource_PaymentStatusFilterIsUndefinedReturnsEverything()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, "3333", customerBatch);
            payment.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapper.Instance.InsertPayment(payment);

            payment = PaymentHelper.Instance.CreatePayment(customer, "2222", customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment);

            payment = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment.PaymentStatus = PaymentStatus.Sent;
            PaymentMapper.Instance.InsertPayment(payment);

            var payments = PaymentMapper.Instance.GetPayments(customer.PartnerId, 10);

            Assert.AreEqual(3, payments.Count);
            Assert.AreEqual("3333", payments[0].ExternalId);
            Assert.AreEqual("2222", payments[1].ExternalId);
            Assert.AreEqual("1111", payments[2].ExternalId);
        }
        
        [Test]
        public void GetPayments_PopulatesPaymentObject()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, "1111", customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            payment.CreatedOnUTC = new DateTime(2001, 2, 2);
            payment.UpdatedOnUTC = new DateTime(2001, 2, 2);
            PaymentMapper.Instance.InsertPayment(payment);

            var earlyHistory = new PaymentUpdateHistory
            {
                ErrorCode = "1234",
                PaymentId = payment.Id,
                PaymentRequestId = 1234,
                UpdatedOnUtc = DateTime.Now.AddDays(-1)
            };
            var lateHistory = new PaymentUpdateHistory
            {
                ErrorCode = "5678",
                PaymentId = payment.Id,
                PaymentRequestId = 1234,
                UpdatedOnUtc = DateTime.Now
            };

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(earlyHistory));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(lateHistory));

            var sortByField = "ExternalId";
            var payments = PaymentMapper.Instance.GetPayments(customer.PartnerId, 10, PaymentStatus.Created, sortByField);

            Assert.AreEqual(1, payments.Count);
            Assert.AreEqual("1111", payments[0].ExternalId);
        }

        [Test]
        public void UpdatePaymentStatus_Works_AndInsertPaymentUpdateHistory()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            payment.TransactionSystemIncomingOrderId = 123;
            payment.TransactionSystemIncomingOrderNumber = "Test";
            PaymentMapper.Instance.InsertPayment(payment);

            var paymentStatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment.Id);
            Assert.AreEqual(0, paymentStatusHistories.Count);

            PaymentMapper.Instance.UpdatePaymentStatus(payment.Id, PaymentStatus.Committed);
            var loadedPayment = PaymentMapper.Instance.GetPayment(customerBatch, payment.ExternalId);
            Assert.AreEqual(PaymentStatus.Committed, loadedPayment.PaymentStatus);
            paymentStatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment.Id);
            Assert.AreEqual(1, paymentStatusHistories.Count);
        }

        private void AssertLoadedLastUpdateError(PaymentUpdateHistory expectedHistory, PaymentUpdateHistory loadedHistory)
        {
            Assert.AreEqual(expectedHistory.ErrorCode, loadedHistory.ErrorCode);    //make sure the latest is returned
            Assert.AreEqual(expectedHistory.PaymentId, loadedHistory.PaymentId);   //make sure fields were populated
            Assert.AreEqual(expectedHistory.UpdatedOnUtc.ToLongTimeString(), loadedHistory.UpdatedOnUtc.ToLongTimeString());
            Assert.AreEqual(expectedHistory.PaymentRequestId, loadedHistory.PaymentRequestId);
        }

        private void ValidateRemittance(List<string> expected, List<string> actual)
        {
            Assert.AreEqual(expected.Count, actual.Count);
            Assert.AreEqual(0, expected.Except(actual).Count());
        }

        private void ValidateThirdPartyRemitter(ThirdPartyRemitter expected, ThirdPartyRemitter actual)
        {

            if (expected == null)
            {
                Assert.IsNullOrEmpty(actual.Id);
                return;
            }

            Assert.AreEqual(expected.Id, actual.Id);
            Assert.AreEqual(expected.Version, actual.Version);
            Assert.AreEqual(expected.VersionedOn, actual.VersionedOn);
            Assert.AreEqual(expected.Type, actual.Type);
            Assert.AreEqual(expected.BusinessName, actual.BusinessName);
            if (expected.Address != null && actual.Address != null)
            {
                Assert.AreEqual(expected.Address.AddressLine1, actual.Address.AddressLine1);
                Assert.AreEqual(expected.Address.AddressLine2, actual.Address.AddressLine2);
                Assert.AreEqual(expected.Address.AddressLine3, actual.Address.AddressLine3);
                Assert.AreEqual(expected.Address.City, actual.Address.City);
                Assert.AreEqual(expected.Address.StateOrProvince, actual.Address.StateOrProvince);
                Assert.AreEqual(expected.Address.ZipOrPostalCode, actual.Address.ZipOrPostalCode);
                Assert.AreEqual(expected.Address.CountryCode, actual.Address.CountryCode);
            }
            Assert.AreEqual(expected.Email, actual.Email);
            Assert.AreEqual(expected.PhoneNumber, actual.PhoneNumber);
            Assert.AreEqual(expected.IdentificationType, actual.IdentificationType);
            Assert.AreEqual(expected.Identification, actual.Identification);
            Assert.AreEqual(expected.Industry, actual.Industry);
        }
    }
}

