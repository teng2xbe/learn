﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Infrastructure.Persistence.Enums;
using MassPayments.Providers.StorageProvider;

namespace MassPayments.Tests.Integration.Mappers
{

    [TestFixture]
    public class OutOfHoldingOrderMapperFixture
    {
        private TransactionScope transactionScope;
        private DateTime timeStamp;
        private string MassPayConnectionString => DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.MassPayments);

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 1, Name = "HyperWallet" });
        }

        [TearDown]
        public void TearDown()
        {
            ServiceCallContextManager.Instance = null;
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void InsertOutOfHoldingOrder_CanInsertCorrectly()
        {
            var bookOutHoldingOrderResult = new BookOutgoingOrderResult
            {
                OrderId = 1234,
                ConfirmationNumber = "NTR12324343"
            };
            var customer = CustomerHelper.Instance.CreateCustomer();
            CustomerMapper.Instance.InsertCustomer(customer);

            OutOfHoldingMapper.Instance.InsertOutOfHoldingOrder(customer,bookOutHoldingOrderResult);

            var selectStatement =
                $"SELECT * FROM MP.OutofHoldingOrder WHERE TransactionSystemOrderId = {bookOutHoldingOrderResult.OrderId}";
            using (var connection = new SqlConnection(MassPayConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(bookOutHoldingOrderResult.ConfirmationNumber, reader["TransactionSystemOrderNumber"]);
                    Assert.AreEqual(customer.PartnerId, Convert.ToInt32(reader["PartnerId"]));
                    Assert.AreEqual(customer.Id, Convert.ToInt32(reader["CustomerId"]));
                }
            }
        }

        [Test]
        public void InsertOutOfHoldingOrderItem_CanInsertCorrectly()
        {
            var aggregateOrder = new AggregatedPayment
            {
                Currency = Currency.USD,
                Total = 10000,
            };

            var bookOutHoldingOrderResult = new BookOutgoingOrderResult
            {
                OrderId = 1234,
                ConfirmationNumber = "NTR12324343"
            };
            var customer = CustomerHelper.Instance.CreateCustomer();
            CustomerMapper.Instance.InsertCustomer(customer);

            OutOfHoldingMapper.Instance.InsertOutOfHoldingOrderItem(aggregateOrder, bookOutHoldingOrderResult);

            var selectStatement =
                $"SELECT * FROM MP.OutofHoldingOrderItem WHERE TransactionSystemOrderId = {bookOutHoldingOrderResult.OrderId}";
            using (var connection = new SqlConnection(MassPayConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(aggregateOrder.Currency.Code, reader["TradeCurrency"]);
                    Assert.AreEqual(aggregateOrder.Currency.Code, reader["SettlementCurrency"]);
                    Assert.AreEqual(aggregateOrder.Total, Convert.ToDecimal(reader["Amount"]));
                }
            }
        }

        [Test]
        public void GetOutOfHoldingOrderCustomers_GetCorrectCustomers()
        {
            var bookOutHoldingOrderResult = new BookOutgoingOrderResult
            {
                OrderId = 1234,
                ConfirmationNumber = "NTR12324343"
            };
            var customer = CustomerHelper.Instance.CreateCustomer();
            CustomerMapper.Instance.InsertCustomer(customer);

            OutOfHoldingMapper.Instance.InsertOutOfHoldingOrder(customer, bookOutHoldingOrderResult);

            var customerIds = OutOfHoldingMapper.Instance.GetOutOfHoldingOrderCustomers(customer.PartnerId);

            Assert.AreEqual(customer.Id, customerIds[0]);
        }

        [Test]
        public void GetOutOfHoldingOrders_GetCorrectOrder()
        {
            var bookOutHoldingOrderResult = new BookOutgoingOrderResult
            {
                OrderId = 1234,
                ConfirmationNumber = "NTR12324343"
            };
            var customer = CustomerHelper.Instance.CreateCustomer();
            CustomerMapper.Instance.InsertCustomer(customer);

            OutOfHoldingMapper.Instance.InsertOutOfHoldingOrder(customer, bookOutHoldingOrderResult);

            var orders = OutOfHoldingMapper.Instance.GetOutOfHoldingOrders(customer.PartnerId, customer.Id);

            Assert.AreEqual(orders.Count, 1);
            Assert.AreEqual(bookOutHoldingOrderResult.OrderId, orders[0].Id);
            Assert.AreEqual(bookOutHoldingOrderResult.ConfirmationNumber, orders[0].OrderNumber);
        }
    }
}
