﻿using System.Transactions;
using MassPayments.Domain.Entities.Subscription;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class SubscriptionLogMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void InsertLog_Works()
        {
            var log = new SubscriptionLog
            {
                Purpose = SubscriptionLogPurpose.Request,
                ApiChannelSubscriptionId = 1,
                Message = "Test Message"
            };

            SubscriptionLogMapper.Instance.Insert(log);
        }
    }
}
