﻿using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class OrderMapperFixture
    {
        private TransactionScope transactionScope;
        private DateTime timeStamp;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });
        }

        [TearDown]
        public void TearDown()
        {
            ServiceCallContextManager.Instance = null;
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void GetOrdersByOrderNumbers_ReturnsOrderInCommittedStatusAfterInsert()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> {order1, order2, order3};
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderNumbers = new List<string> { order1.ConfirmationNumber,order2.ConfirmationNumber,order3.ConfirmationNumber };

            var orders = OrderMapper.Instance.GetOrdersByOrderNumbers(orderNumbers);

            Assert.AreEqual(orders[0].OrderStatus, OrderStatus.Committed);
            Assert.AreEqual(orders[1].OrderStatus, OrderStatus.Committed);
            Assert.AreEqual(orders[2].OrderStatus, OrderStatus.Committed);
        }

        [Test]
        public void GetOrdersByStatus_ReturnsCommittedOrdersCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orders = OrderMapper.Instance.GetOrdersByStatus(OrderStatus.Committed);

            Assert.AreEqual(orders[0].OrderStatus, OrderStatus.Committed);
            Assert.AreEqual(orders[1].OrderStatus, OrderStatus.Committed);
            Assert.AreEqual(orders[2].OrderStatus, OrderStatus.Committed);
        }
        
        [Test]
        public void GetOrdersByOrderNumbers_ReturnsCorrectStatusAfterUpdate()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrderStatus(orderList));

            order1.OrderStatus = OrderStatus.Funded;
            order2.OrderStatus = OrderStatus.Received;
            order3.OrderStatus = OrderStatus.Cancelled;
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));

            var orderNumbers = new List<string> { order1.ConfirmationNumber, order2.ConfirmationNumber, order3.ConfirmationNumber };

            var orders = OrderMapper.Instance.GetOrdersByOrderNumbers(orderNumbers);

            Assert.AreEqual(orders[0].OrderStatus, OrderStatus.Funded);
            Assert.AreEqual(orders[1].OrderStatus, OrderStatus.Received);
            Assert.AreEqual(orders[2].OrderStatus, OrderStatus.Cancelled);
        }

        [Test, Explicit("The mapper is no longer setting default datetime, whoever calling it should make sure datetime is set properly")]
        public void GetOrdersByOrderNumbers_ReturnsCorrectStatusAfterUpdate_WhenUpdatedTimeStampIsNotValid()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.LastUpdatedOn = DateTime.MinValue;
            var orderList = new List<Order> { order1 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrderStatus(orderList));
        }

        [Test]
        public void GetOrdersByPartnerId_ReturnsAllOrders()
        {
            var partnerId = 1;
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);
            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));


            var orders = OrderMapper.Instance.GetOrdersByPartnerId(partnerId);
            Assert.AreEqual(3, orders.Count);
        }

        [Test]
        public void GetOrdersByOrderNumbers_ReturnsBatchDetails()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch1 = new CustomerBatch
            {
                CustomerId = customer.Id,
                ExternalId = "Batch001",
                BatchReference = "BatchFile001"
            };

            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.AUD, 120),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 1111
                },
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.GBP, 110),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 2222
                }

            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customerBatch1.ExternalId, customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            QuoteMapper.Instance.InsertQuoteToOrderRelationship(quoteRequestId, new List<int> { 1111, 2222 }, TransactionSystem.CCT);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);
            
            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.QuoteRequestId = quoteRequestId;
            order1.OrderId = 1111;
            var orderList = new List<Order> { order1 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));
            QuoteMapper.Instance.UpdateQuoteToOrderRelationship(quoteRequestId, orderList);
            var orderNumbers = new List<string> { order1.ConfirmationNumber};

            var orders = OrderMapper.Instance.GetOrdersByOrderNumbers(orderNumbers);

            Assert.AreEqual(orders[0].CustomerBatchExternalId, customerBatch1.ExternalId);
        }
        
        [Test]
        public void GetOrderByBatchIdAndCurrency_ReturnsOrder()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch1 = new CustomerBatch
            {
                CustomerId = customer.Id,
                ExternalId = "Batch001",
                BatchReference = "BatchFile001"
            };

            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.AUD, 120),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 1111
                },
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.GBP, 110),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 2222
                }

            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, null, customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            QuoteMapper.Instance.InsertQuoteToOrderRelationship(quoteRequestId, new List<int> { 1111, 2222 }, TransactionSystem.CCT);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);
            CustomerBatchMapper.Instance.UpdateCustomerBatchActiveQuoteRequestId(quoteRequestId, customerBatch1.ExternalId, customerBatch1.CustomerId);


            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.QuoteRequestId = quoteRequestId;
            order1.OrderId = 1111;
            var orderList = new List<Order> { order1 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));
            QuoteMapper.Instance.UpdateQuoteToOrderRelationship(quoteRequestId, orderList);

            var order = OrderMapper.Instance.GetOrderByBatchIdAndCurrency(customerBatch1.Id, "USD");

            Assert.IsNotNull(order);
            Assert.AreEqual(1111, order.OrderId);
        }

        [Test]
        public void GetOrder_Returns_CorrectOrder()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1};
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrderStatus(orderList));

            var orderNumber = order1.ConfirmationNumber;
            var orders = OrderMapper.Instance.GetOrder(orderNumber);
            Assert.IsTrue(orders.ConfirmationNumber == order1.ConfirmationNumber);
        }

        [Test]
        public void GetOrder_WithNoOrderId_DoesnNotThrowException()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrderStatus(orderList));

            string orderNumber = string.Empty;
            Assert.DoesNotThrow(() => OrderMapper.Instance.GetOrder(orderNumber));
        }

        [Test]
        public void UpdateOrderStatus_DoesNotSetCreatedOnAndLastUpdatedOnIfAlreadySet()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var createOnDate = new DateTime(1971, 02, 26, 2, 3, 4);
            var lastUpdatedOnDate = new DateTime(2001, 05, 30, 5, 6, 7);
            var order = OrderHelper.Instance.CreateOrder(customer);
            order.CreatedOn = createOnDate;
            order.LastUpdatedOn = lastUpdatedOnDate;
            var orderList = new List<Order> { order };

            OrderMapper.Instance.UpdateOrders(orderList);
            var retrievedOrder = OrderMapper.Instance.GetOrder(order.ConfirmationNumber);
            
            Assert.AreEqual(createOnDate, retrievedOrder.CreatedOn);
            Assert.AreEqual(lastUpdatedOnDate, retrievedOrder.LastUpdatedOn);
        }

        [Test]
        public void GetOrdersByQuoteRequest_Returns_OrdersWithOrWithoutAssignedCustomer()
        {

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.AUD, 120),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 1111
                },
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.GBP, 110),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 2222
                }

            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, "TTTT", customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            QuoteMapper.Instance.InsertQuoteToOrderRelationship(quoteRequestId, new List<int> { 1111, 2222 }, TransactionSystem.CCT);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);

            var orders = OrderMapper.Instance.GetOrdersByQuoteRequest(quoteRequestId);

            Assert.AreEqual(2, orders.Count);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.QuoteRequestId = quoteRequestId;
            order1.OrderId = 1111;
            var orderList = new List<Order> { order1 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));
            QuoteMapper.Instance.UpdateQuoteToOrderRelationship(quoteRequestId, orderList);

            var orders2 = OrderMapper.Instance.GetOrdersByQuoteRequest(quoteRequestId);

            Assert.AreEqual(2, orders2.Count);

        }

        [Test]
        public void GetOrdersByQuoteRequest_Returns_OrdersWithBatchReferenceWhenAvailable()
        {

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch
            {
                CustomerId = customer.Id,
                ExternalId = "Batch001",
                BatchReference = "BatchFile001"
            };

            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.AUD, 120),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 1111
                },
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.USD, 0),
                    TradeMoney = new Money(Currency.GBP, 110),
                    TransactionSystemQuoteId = 1234,
                    OrderId = 2222
                }

            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customerBatch.ExternalId, customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            QuoteMapper.Instance.InsertQuoteToOrderRelationship(quoteRequestId, new List<int> { 1111, 2222 }, TransactionSystem.CCT);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);

            CustomerBatchMapper.Instance.UpdateCustomerBatchActiveQuoteRequestId(quoteRequestId, customerBatch.ExternalId, customer.Id); 

            var orders = OrderMapper.Instance.GetOrdersByQuoteRequest(quoteRequestId);

            Assert.AreEqual(2, orders.Count);
            Assert.AreEqual(customerBatch.ExternalId, orders[0].CustomerBatchExternalId);
            Assert.AreEqual(customerBatch.ExternalId, orders[1].CustomerBatchExternalId);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            order1.QuoteRequestId = quoteRequestId;
            order1.OrderId = 1111;
            var orderList = new List<Order> { order1 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));
            QuoteMapper.Instance.UpdateQuoteToOrderRelationship(quoteRequestId, orderList);

            var orders2 = OrderMapper.Instance.GetOrdersByQuoteRequest(quoteRequestId);

            Assert.AreEqual(2, orders2.Count);
            Assert.AreEqual(customerBatch.ExternalId, orders[0].CustomerBatchExternalId);
            Assert.AreEqual(customerBatch.ExternalId, orders[1].CustomerBatchExternalId);

        }

    }
}
