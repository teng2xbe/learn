﻿using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class CustomerBatchCurrencyMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            PaymentRequestMapper.Instance = MockRepository.GenerateStub<IPaymentRequestMapper>();
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentRequestMapper.Instance = null;

            if (transactionScope != null)
                transactionScope.Dispose();
            CurrencyCache.Instance = null;
        }

        [Test]
        public void InsertCustomerBatchCurrency_InsertsDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id, new Money(Currency.USD, 1.1m), new Money(Currency.CAD, 0m),new Money(Currency.CAD,0),true);
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id, new Money(Currency.USD, 0m), new Money(Currency.CAD, 1.1m), new Money(Currency.CAD, 0), true);


            List<CustomerBatchCurrencyAggregates> savedCustomerBatchCurrency = CustomerBatchCurrencyMapper.Instance.GetCustomerBatchCurrencyAggregatesByBatchId(customerBatch.Id);

            Assert.AreEqual(1, savedCustomerBatchCurrency.Count);
            Assert.AreEqual("USD", savedCustomerBatchCurrency[0].TotalPaymentsMoney.Currency.Code);
            Assert.AreEqual(110, savedCustomerBatchCurrency[0].TotalPaymentsMoney.NonDecimalAmount);
            Assert.AreEqual(110, savedCustomerBatchCurrency[0].TotalPaymentsSettlementMoney.NonDecimalAmount);
        }

        [Test]
        public void GetCustomerBatchCurrencyAggregatesByBatchId_LoadsDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                new Money(Currency.USD, 100),
                new Money(Currency.CAD, 100),
                new Money(Currency.USD, 0),
                true);
            List<CustomerBatchCurrencyAggregates> savedCustomerBatchCurrency = CustomerBatchCurrencyMapper.Instance.GetCustomerBatchCurrencyAggregatesByBatchId(customerBatch.Id);

            Assert.AreEqual(1, savedCustomerBatchCurrency.Count);
            Assert.AreEqual("USD", savedCustomerBatchCurrency[0].TotalPaymentsMoney.Currency.Code);
            Assert.AreEqual(100, savedCustomerBatchCurrency[0].TotalPaymentsMoney.NonDecimalAmount);
        }

        [Test]
        public void GetCustomerBatchCurrencyAggregatesByBatchId_AggregatesCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                new Money(Currency.USD, 100),
                new Money(Currency.CAD, 100),
                new Money(Currency.CAD, 0),
                true);

            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                new Money(Currency.USD, 200),
                new Money(Currency.CAD, 100),
                new Money(Currency.USD, 0),
                true);

            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                new Money(Currency.CAD, 50),
                new Money(Currency.GBP, 100),
                new Money(Currency.GBP, 0),
                true);

            List<CustomerBatchCurrencyAggregates> savedCustomerBatchCurrency = CustomerBatchCurrencyMapper.Instance.GetCustomerBatchCurrencyAggregatesByBatchId(customerBatch.Id);

            Assert.AreEqual(2, savedCustomerBatchCurrency.Count);
            Assert.AreEqual("USD", savedCustomerBatchCurrency[0].TotalPaymentsMoney.Currency.Code);
            Assert.AreEqual("CAD", savedCustomerBatchCurrency[1].TotalPaymentsMoney.Currency.Code);
            Assert.AreEqual(300, savedCustomerBatchCurrency[0].TotalPaymentsMoney.NonDecimalAmount);
            Assert.AreEqual(50, savedCustomerBatchCurrency[1].TotalPaymentsMoney.NonDecimalAmount);
        }

        [Test]
        public void DeletePaymentCustomerBatchCurrency_DeletesDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id, new Money(Currency.USD, 100), new Money(Currency.CAD, 100), new Money(Currency.CAD, 0), true);
            CustomerBatchCurrencyMapper.Instance.DeletePaymentCustomerBatchCurrency(customerBatch.Id, new Money(Currency.USD, 20), new Money(Currency.CAD, 20), new Money(Currency.CAD, 0), true);
            List<CustomerBatchCurrencyAggregates> savedCustomerBatchCurrency = CustomerBatchCurrencyMapper.Instance.GetCustomerBatchCurrencyAggregatesByBatchId(customerBatch.Id);

            Assert.AreEqual(1, savedCustomerBatchCurrency.Count);
            Assert.AreEqual("USD", savedCustomerBatchCurrency[0].TotalPaymentsMoney.Currency.Code);
            Assert.AreEqual(80, savedCustomerBatchCurrency[0].TotalPaymentsMoney.NonDecimalAmount);
        }

        [Test]
        public void DeleteCustomerBatchCurrency_DeletesDataCorrectly()
        {
            var customer = new Customer
            {
                Name = "Kittens McGraw",
                Status = CustomerStatus.Enabled,
                PartnerAssignedCustomerId = "EXT",
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatch { CustomerId = customer.Id, ExternalId = "External", ExternalCustomerId = "test", BatchType = BatchType.FileBatch };
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id, new Money(Currency.USD, 100), new Money(Currency.CAD, 100), new Money(Currency.CAD, 0), true);
            CustomerBatchCurrencyMapper.Instance.DeleteCustomerBatchCurrency(customerBatch.Id, new Money(Currency.USD, 20), new Money(Currency.CAD, 20));
            List<CustomerBatchCurrencyAggregates> savedCustomerBatchCurrency = CustomerBatchCurrencyMapper.Instance.GetCustomerBatchCurrencyAggregatesByBatchId(customerBatch.Id);

            Assert.AreEqual(savedCustomerBatchCurrency.Count, 0);
        }

    }
}