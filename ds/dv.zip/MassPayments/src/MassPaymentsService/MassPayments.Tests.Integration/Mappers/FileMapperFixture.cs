﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class FileMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void GetFile_LoadsDataCorrectly()
        {
            var file = new File { Data = new byte[] { 0x22, 0x33, 0x44 }, Status = FileStatus.Pending, FileNameWithExtension = "test.json" };
            FileMapper.Instance.InsertFile(file);

            Assert.AreNotEqual(0, file.Id);
            Assert.AreEqual(DateTime.Now.ToUniversalTime().Date, file.CreatedOnUTC.Date);

            File savedFile = FileMapper.Instance.GetFile(file.Id);

            Assert.AreEqual(file.Id, savedFile.Id);
            Assert.AreEqual("test.json", savedFile.FileNameWithExtension);
            Assert.AreEqual(FileStatus.Pending, savedFile.Status);
            Assert.AreEqual(DateTime.Now.ToUniversalTime().Date, savedFile.CreatedOnUTC.Date);
            Assert.AreEqual(DateTime.MinValue, savedFile.UpdatedOnUTC);

            Assert.AreEqual(3, savedFile.Data.Length);
            Assert.AreEqual(0x22, savedFile.Data[0]);
            Assert.AreEqual(0x33, savedFile.Data[1]);
            Assert.AreEqual(0x44, savedFile.Data[2]);
        }

        [Test]
        public void File_UpdatesStatusCorrectly()
        {
            var file = new File { Data = new byte[] { 0x22, 0x33, 0x44 }, Status = FileStatus.Pending, FileNameWithExtension = "test1.json" };
            FileMapper.Instance.InsertFile(file);
            var createdFile = FileMapper.Instance.GetFile(file.Id);

            FileMapper.Instance.UpdateFileStatus(file.Id, FileStatus.Processed);

            var updatedFile = FileMapper.Instance.GetFile(file.Id);

            Assert.AreEqual(FileStatus.Processed, updatedFile.Status);
            Assert.AreEqual(createdFile.CreatedOnUTC, updatedFile.CreatedOnUTC);
            Assert.AreEqual(DateTime.Now.ToUniversalTime().Date, updatedFile.UpdatedOnUTC.Date);
        }

        [Test]
        public void LogFileParsingError_SavesDataCorrectly()
        {
            var file = new File { Data = new byte[] { 0x22, 0x33, 0x44 }, Status = FileStatus.Pending, FileNameWithExtension = "test1.json" };
            FileMapper.Instance.InsertFile(file);

            FileMapper.Instance.LogProcessingError(file.Id, file.FileNameWithExtension, "blah", new Exception("exception message"));

            var selectStatement = string.Format("SELECT * FROM MP.ProcessingError WHERE SourceId = {0}", file.Id);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(Convert.ToInt32(reader["SourceId"]), file.Id);
                    Assert.AreEqual(Convert.ToString(reader["Source"]), file.FileNameWithExtension);
                    Assert.AreEqual(Convert.ToString(reader["ErrorMessage"]), "blah");
                    Assert.AreEqual(Convert.ToString(reader["StackTrace"]), "System.Exception: exception message");
                }
            }
        }

        [Test]
        public void FileProcessing_Inserts_Correctly()
        {
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes("blah"),
                FileNameWithExtension = "123",
                Status = FileStatus.Pending
            };
            FileMapper.Instance.InsertFile(file);
            Assert.DoesNotThrow(() => FileMapper.Instance.LogProcessingInfo(file.Id, "blah"));
            Assert.True(FileMapper.Instance.GetProcessingInfoForTesting() == 1);
        }

        [Test]
        public void LogProcessingError_DoesNotThrow_ForNulls()
        {
            Assert.DoesNotThrow(() => FileMapper.Instance.LogProcessingError(0, null, null, null));
        }

        [Test]
        public void FileProcessing_Inserts_FailsWithInvalidFileId()
        {
            Assert.Throws<SqlException>(() => FileMapper.Instance.LogProcessingInfo(123, "blah"));
        }
    }
}
