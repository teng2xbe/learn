﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class QuoteMapperFixture
    {
        private TransactionScope transactionScope;
        private DateTime timeStamp;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner {Id = 1, Name = "HyperWallet"});
        }

        [TearDown]
        public void TearDown()
        {
            ServiceCallContextManager.Instance = null;
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void CanInsertNewQuoteRequest()
        {
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem {TransactionSystemQuoteId = 11, TradeMoney = new Money(Currency.CAD, 111), SettlementMoney = new Money(Currency.USD, 112), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
                new QuotedItem {TransactionSystemQuoteId = 22, TradeMoney = new Money(Currency.GBP, 222), SettlementMoney = new Money(Currency.JPY, 223), IsDirect = true, NumberOfDecimalsDirect = 0, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
                new QuotedItem {TransactionSystemQuoteId = 33, TradeMoney = new Money(Currency.USD, 333), SettlementMoney = new Money(Currency.CAD, 334), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m}
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, null, 1, "testPartnerReference", true, "", 100, DateTime.UtcNow, QuoteRequestStatus.Created);

            var selectStatement = string.Format("SELECT * FROM MP.QuoteRequest WHERE Id = {0}", quoteRequestId);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    Assert.IsTrue(reader.Read());
                    Assert.AreEqual(quoteRequestId, Convert.ToInt32(reader["Id"]));
                    Assert.AreEqual(100, Convert.ToInt32(reader["DurationInSec"]));
                    Assert.AreEqual(1, Convert.ToInt32(reader["CustomerId"]));
                    Assert.AreEqual("", Convert.ToString(reader["CustomerBatchExternalId"]));
                    Assert.AreEqual(true, Convert.ToBoolean(reader["IsSuccessful"]));
                    Assert.AreEqual((int)QuoteRequestStatus.Created, Convert.ToInt32(reader["Status"]));
                    Assert.AreEqual("testPartnerReference", Convert.ToString(reader["PartnerReference"]));
                }
            }

            var selectStatement2 = string.Format("SELECT * FROM MP.MPSQuoteTransactionSystemQuote WHERE QuoteRequestId = {0}", quoteRequestId);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement2, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    var index = 0;

                    while (reader.Read())
                    {
                        Assert.AreEqual(Convert.ToInt32(reader["QuoteRequestId"]), quoteRequestId);
                        Assert.AreEqual(Convert.ToInt32(reader["TransactionSystemQuoteId"]), quotedItems[index].TransactionSystemQuoteId);
                        Assert.AreEqual(Convert.ToString(reader["TradeCurrencyCode"]), quotedItems[index].TradeMoney.Currency.Code);
                        Assert.AreEqual(Convert.ToString(reader["SettlementCurrencyCode"]), quotedItems[index].SettlementMoney.Currency.Code);
                        Assert.AreEqual(Convert.ToBoolean(reader["IsDirectRate"]), quotedItems[index].IsDirect);
                        Assert.AreEqual(Convert.ToDecimal(reader["Rate"]), quotedItems[index].RateValue);
                        Assert.AreEqual(Convert.ToDecimal(reader["RateInverted"]), quotedItems[index].RateValueInverted);
                        Assert.AreEqual(Convert.ToInt32(reader["DecimalsDirect"]), quotedItems[index].NumberOfDecimalsDirect);
                        Assert.AreEqual(Convert.ToInt32(reader["DecimalsIndirect"]), quotedItems[index].NumberOfDecimalsIndirect);
                        Assert.AreEqual(Convert.ToDecimal(reader["TradeAmount"]), quotedItems[index].TradeMoney.Amount);
                        Assert.AreEqual(Convert.ToDecimal(reader["SettlementAmount"]), quotedItems[index].SettlementMoney.Amount);
                        index++;
                    }

                    Assert.AreEqual(3, index);
                }
            }
        }

        [Test]
        public void CanGetQuoteRequest()
        {
            var dateTimeUtcNow = timeStamp.ToUniversalTime();
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem {TransactionSystemQuoteId = 11, TradeMoney = new Money(Currency.CAD, 111), SettlementMoney = new Money(Currency.USD, 112), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
                new QuotedItem {TransactionSystemQuoteId = 22, TradeMoney = new Money(Currency.GBP, 222), SettlementMoney = new Money(Currency.JPY, 223), IsDirect = true, NumberOfDecimalsDirect = 0, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
                new QuotedItem {TransactionSystemQuoteId = 33, TradeMoney = new Money(Currency.USD, 333), SettlementMoney = new Money(Currency.CAD, 334), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m}
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, "abcd", 1, "testPartnerReference", true, "", 100, dateTimeUtcNow, QuoteRequestStatus.Created);
            var quoteRequest = QuoteMapper.Instance.GetQuote(quoteRequestId);

            Assert.AreEqual(1, quoteRequest.CustomerId);
            Assert.AreEqual(quoteRequestId, quoteRequest.Id);
            Assert.AreEqual("testPartnerReference", quoteRequest.PartnerReference);
            Assert.IsTrue(TestHelper.AreDateTimesEqual(dateTimeUtcNow, quoteRequest.ExpirationTimeUtc));

            var index = 0;
            foreach (var dbQuotedItem in quoteRequest.QuotedItems)
            {
                Assert.AreEqual(quotedItems[index].TransactionSystemQuoteId, dbQuotedItem.TransactionSystemQuoteId);
                Assert.AreEqual(quotedItems[index].TradeMoney.Currency.Code, dbQuotedItem.TradeMoney.Currency.Code);
                Assert.AreEqual(quotedItems[index].SettlementMoney.Currency.Code, dbQuotedItem.SettlementMoney.Currency.Code);
                Assert.AreEqual(quotedItems[index].IsDirect, dbQuotedItem.IsDirect);
                Assert.AreEqual(quotedItems[index].RateValue, dbQuotedItem.RateValue);
                Assert.AreEqual(quotedItems[index].RateValueInverted, dbQuotedItem.RateValueInverted);
                Assert.AreEqual(quotedItems[index].NumberOfDecimalsDirect, dbQuotedItem.NumberOfDecimalsDirect);
                Assert.AreEqual(quotedItems[index].NumberOfDecimalsIndirect, dbQuotedItem.NumberOfDecimalsIndirect);
                Assert.AreEqual(quotedItems[index].TradeMoney.Amount, dbQuotedItem.TradeMoney.Amount);
                Assert.AreEqual(quotedItems[index].SettlementMoney.Amount, dbQuotedItem.SettlementMoney.Amount);
                Assert.AreEqual(quotedItems[index].TradeMoney.Currency.Code, dbQuotedItem.TradeMoney.Currency.Code);
                Assert.AreEqual(quotedItems[index].SettlementMoney.Currency.Code, dbQuotedItem.SettlementMoney.Currency.Code);
                index++;
            }

            Assert.AreEqual(3, index);
        }


        [Test]
        public void GetQuoteByGuid_CanGetQuoteRequest()
        {
            var dateTimeUtcNow = timeStamp.ToUniversalTime();
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem {TransactionSystemQuoteId = 11, TradeMoney = new Money(Currency.CAD, 111), SettlementMoney = new Money(Currency.USD, 112), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
                new QuotedItem {TransactionSystemQuoteId = 22, TradeMoney = new Money(Currency.GBP, 222), SettlementMoney = new Money(Currency.JPY, 223), IsDirect = true, NumberOfDecimalsDirect = 0, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m},
                new QuotedItem {TransactionSystemQuoteId = 33, TradeMoney = new Money(Currency.USD, 333), SettlementMoney = new Money(Currency.CAD, 334), IsDirect = true, NumberOfDecimalsDirect = 2, NumberOfDecimalsIndirect = 2, RateValue = 1.2345m, RateValueInverted = 2.3456m}
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, "abcd", 1, "testPartnerReference", true, "", 100, dateTimeUtcNow, QuoteRequestStatus.Created);
            var quote = QuoteMapper.Instance.GetQuote(quoteRequestId);
            var quoteRequest = QuoteMapper.Instance.GetQuoteByGuid(quote.QuoteGuid);

            Assert.AreEqual(1, quoteRequest.CustomerId);
            Assert.AreEqual(quoteRequestId, quoteRequest.Id);
            Assert.AreEqual("testPartnerReference", quoteRequest.PartnerReference);
            Assert.IsTrue(TestHelper.AreDateTimesEqual(dateTimeUtcNow, quoteRequest.ExpirationTimeUtc));

            var index = 0;
            foreach (var dbQuotedItem in quoteRequest.QuotedItems)
            {
                Assert.AreEqual(quotedItems[index].TransactionSystemQuoteId, dbQuotedItem.TransactionSystemQuoteId);
                Assert.AreEqual(quotedItems[index].TradeMoney.Currency.Code, dbQuotedItem.TradeMoney.Currency.Code);
                Assert.AreEqual(quotedItems[index].SettlementMoney.Currency.Code, dbQuotedItem.SettlementMoney.Currency.Code);
                Assert.AreEqual(quotedItems[index].IsDirect, dbQuotedItem.IsDirect);
                Assert.AreEqual(quotedItems[index].RateValue, dbQuotedItem.RateValue);
                Assert.AreEqual(quotedItems[index].RateValueInverted, dbQuotedItem.RateValueInverted);
                Assert.AreEqual(quotedItems[index].NumberOfDecimalsDirect, dbQuotedItem.NumberOfDecimalsDirect);
                Assert.AreEqual(quotedItems[index].NumberOfDecimalsIndirect, dbQuotedItem.NumberOfDecimalsIndirect);
                Assert.AreEqual(quotedItems[index].TradeMoney.Amount, dbQuotedItem.TradeMoney.Amount);
                Assert.AreEqual(quotedItems[index].SettlementMoney.Amount, dbQuotedItem.SettlementMoney.Amount);
                Assert.AreEqual(quotedItems[index].TradeMoney.Currency.Code, dbQuotedItem.TradeMoney.Currency.Code);
                Assert.AreEqual(quotedItems[index].SettlementMoney.Currency.Code, dbQuotedItem.SettlementMoney.Currency.Code);
                index++;
            }

            Assert.AreEqual(3, index);
        }

        [Test]
        public void GetQuoteByGuid_ReturnsNullIfQuoteDoesNotExist()
        {
            var quoteRequest = QuoteMapper.Instance.GetQuoteByGuid("0718e73c-75a3-416c-b4f2-cedad1111111");
            Assert.AreEqual(null, quoteRequest);
        }

        [Test]
        public void GetQuoteByGuid_ReturnsNullIfQuoteGuidInvalid()
        {
            var quoteRequest = QuoteMapper.Instance.GetQuoteByGuid("");
            Assert.AreEqual(null, quoteRequest);
        }

        [Test]
        public void UpdateQuoteRequestStatus_Works()
        {
            var dateTimeCreated = timeStamp.AddMinutes(-15).ToUniversalTime();
            var dateTimeUpdated = timeStamp.ToUniversalTime();
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem{ TransactionSystemQuoteId = 11, TradeMoney = new Money(Currency.CAD, 0), SettlementMoney = new Money(Currency.USD, 0)},
                new QuotedItem{ TransactionSystemQuoteId = 22, TradeMoney = new Money(Currency.GBP, 0), SettlementMoney = new Money(Currency.JPY, 0)},
                new QuotedItem{ TransactionSystemQuoteId = 33, TradeMoney = new Money(Currency.USD, 0), SettlementMoney = new Money(Currency.CAD, 0)}
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, "abcd", 1, "testPartnerReference", true, "", 100, dateTimeCreated, QuoteRequestStatus.Created);
            var quoteRequest = QuoteMapper.Instance.GetQuote(quoteRequestId);

            Assert.AreEqual(1, quoteRequest.CustomerId);
            Assert.AreEqual(quoteRequestId, quoteRequest.Id);
            Assert.IsTrue(TestHelper.AreDateTimesEqual(quoteRequest.RequestTimeUtc, quoteRequest.LastUpdatedOnUtc));

            quoteRequest.Status = QuoteRequestStatus.Committed;

            QuoteMapper.Instance.UpdateQuoteStatus(quoteRequest, dateTimeUpdated);

            var quoteRequestUpdated = QuoteMapper.Instance.GetQuote(quoteRequestId);
            Assert.AreEqual(QuoteRequestStatus.Committed, quoteRequestUpdated.Status);
            Assert.IsTrue(TestHelper.AreDateTimesEqual(dateTimeUpdated, quoteRequestUpdated.LastUpdatedOnUtc));

        }

        [Test]
        public void GetTransactionSystemIncomingOrderId_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            
            const int transactionSystemQuoteId = 123;
            const string settlementCurrencyCode = "CAD";
            const string tradeCurrencyCode = "USD";
            const int transactionSystemOrderId = 1234566;
            const string transactionSystemOrderNumber = "123";
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(new Currency(settlementCurrencyCode), 0),
                    TradeMoney = new Money(new Currency(tradeCurrencyCode), 0),
                    TransactionSystemQuoteId = transactionSystemQuoteId,
                    OrderId = transactionSystemOrderId
                }
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customerBatch.ExternalId, customer.Id, "testPartnerReference", true, string.Empty, 120, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            
            var mockedOrders = new List<Order>
            {
                new Order
                {
                    ConfirmationNumber =transactionSystemOrderNumber,
                    OrderId = transactionSystemOrderId,
                    TransactionSystemQuoteId = transactionSystemQuoteId,
                    CustomerBatchExternalId = customerBatch.ExternalId
                }
            };

            QuoteMapper.Instance.UpdateQuoteToOrderRelationship(quoteRequestId, mockedOrders);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);
            
            var order = QuoteMapper.Instance.GetTransactionSystemIncomingOrder(customerBatch.Id, tradeCurrencyCode, settlementCurrencyCode);
            Assert.AreEqual(transactionSystemOrderId, order.OrderId);
            Assert.AreEqual(transactionSystemOrderNumber, order.ConfirmationNumber);
        }

        [Test]
        public void GetTransactionSystemIncomingOrderId_Throws()
        {
            Assert.Throws<ArgumentException>(() => QuoteMapper.Instance.GetTransactionSystemIncomingOrder(123, "CAD", "USD"));
        }

    }
}
