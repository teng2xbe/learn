﻿using System;
using System.Transactions;
using MassPayments.Domain.Entities.Subscription;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    public class SubscriptionEventHandlingMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void LoadSubscriptionEvent_IsSuccessful()
        {
            var subscriptionEvent = new SubscriptionEvent
            {
                CreatedOnUtc = DateTime.UtcNow,
                JsonEventArguments = "Blah",
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent);

            SubscriptionEventHandlingMapper.Instance.LoadEventsToProcessFromContainerByType(1, SubscriptionEventType.InvoiceGenerated);
            var loadedEvents = SubscriptionEventHandlingMapper.Instance.GetEventsToProcessByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(1, loadedEvents.Count);
        }

        [Test]
        public void LoadSubscriptionEvent_LoadsNewEvents()
        {
            var subscriptionEvent = new SubscriptionEvent
            {
                CreatedOnUtc = DateTime.UtcNow,
                JsonEventArguments = "Blah",
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent);

            SubscriptionEventHandlingMapper.Instance.LoadEventsToProcessFromContainerByType(1, SubscriptionEventType.InvoiceGenerated);
            var loadedEvents = SubscriptionEventHandlingMapper.Instance.GetEventsToProcessByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(1, loadedEvents.Count);
            Assert.AreEqual(subscriptionEvent.JsonEventArguments,loadedEvents[0].JsonEventArguments);

            var subscriptionEvent1 = new SubscriptionEvent
            {
                CreatedOnUtc = DateTime.UtcNow.AddSeconds(10),
                JsonEventArguments = "Blah1",
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent1);
            SubscriptionEventHandlingMapper.Instance.LoadEventsToProcessFromContainerByType(1, SubscriptionEventType.InvoiceGenerated);
            loadedEvents = SubscriptionEventHandlingMapper.Instance.GetEventsToProcessByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(2, loadedEvents.Count);
        }

        [Test]
        public void LoadSubscriptionEvent_DoesNotLoadEventsWithCreationTimeOlderThanMaxInToProcessTable()
        {
            var subscriptionEvent = new SubscriptionEvent
            {
                CreatedOnUtc = DateTime.UtcNow,
                JsonEventArguments = "Blah",
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent);

            SubscriptionEventHandlingMapper.Instance.LoadEventsToProcessFromContainerByType(1, SubscriptionEventType.InvoiceGenerated);
            var loadedEvents = SubscriptionEventHandlingMapper.Instance.GetEventsToProcessByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(1, loadedEvents.Count);
            Assert.AreEqual(subscriptionEvent.JsonEventArguments, loadedEvents[0].JsonEventArguments);

            var subscriptionEvent1 = new SubscriptionEvent
            {
                CreatedOnUtc = DateTime.UtcNow.AddDays(-1),
                JsonEventArguments = "Blah1",
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent1);
            SubscriptionEventHandlingMapper.Instance.LoadEventsToProcessFromContainerByType(1, SubscriptionEventType.InvoiceGenerated);
            loadedEvents = SubscriptionEventHandlingMapper.Instance.GetEventsToProcessByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(1, loadedEvents.Count);
        }

        [Test]
        public void SetEventsToProcessed_Works()
        {
            var subscriptionEvent = new SubscriptionEvent
            {
                CreatedOnUtc = DateTime.UtcNow,
                JsonEventArguments = "Blah",
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent);
            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent);

            SubscriptionEventHandlingMapper.Instance.LoadEventsToProcessFromContainerByType(1, SubscriptionEventType.InvoiceGenerated);
            var loadedEventsToProcess = SubscriptionEventHandlingMapper.Instance.GetEventsToProcessByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(2, loadedEventsToProcess.Count);
            
            SubscriptionEventHandlingMapper.Instance.SetEventsToProcessed(1, loadedEventsToProcess);
            loadedEventsToProcess = SubscriptionEventHandlingMapper.Instance.GetEventsToProcessByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(0, loadedEventsToProcess.Count);

            var processedEvents = SubscriptionEventHandlingMapper.Instance.GetProcessedEventsByType(1, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(2, processedEvents.Count);
        }
    }
}
