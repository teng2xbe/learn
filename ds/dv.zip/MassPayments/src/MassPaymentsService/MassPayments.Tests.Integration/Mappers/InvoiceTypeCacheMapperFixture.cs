﻿using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class InvoiceTypeCacheMapperFixture
    {
        [Test]
        public void AllTheCorrectInvoiceTypeAreThere()
        {
            var invoiceTypes = InvoiceTypeCacheMapper.Instance.GetInvoiceTypeDictionary();

            Assert.AreEqual(3, invoiceTypes.Count);
        }
    }
}
