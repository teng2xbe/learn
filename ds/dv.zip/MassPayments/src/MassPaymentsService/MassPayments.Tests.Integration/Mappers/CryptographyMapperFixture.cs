﻿using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class CryptographyMapperFixture
    {
        [Test]
        public void GetDecryptionPassword_Works_ForValidPartnerCode()
        {
            const string partnerCode = "HyperWallet";
            string password = CryptographyMapper.Instance.GetDecryptionPassword(partnerCode);

            Assert.AreEqual("password", password);
        }
    }
}
