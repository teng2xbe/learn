﻿using System;
using System.Diagnostics;
using System.Transactions;
using MassPayments.ActionHandlers;
using MassPayments.Exceptions;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Mappers
{
    [TestFixture]
    public class ActionHandlerMapperFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void GetLock_Works_ForNoneScheduledAction()
        {
            var handlerName = typeof (PartnerJsonFileHandler).FullName;
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", 0);
            Assert.True(handlerId > 0);

            var loadedHandler = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);
            Assert.True(loadedHandler.Id == handlerId);
        }

        [Test]
        public void GetLock_Works_ForScheduledAction()
        {
            var handlerName = typeof(IrisPollingHandler).FullName;
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", 10);
            Assert.True(handlerId > 0);

            var loadedHandler = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);
            Assert.True(loadedHandler.Id == handlerId);
        }

        [Test]
        public void GetLock_Throws_ForScheduledActionWhichDoesNotProvideProperPredictedExecutionTime()
        {
            var handlerName = typeof(IrisPollingHandler).FullName;
            var exception = Assert.Throws<FailedToObtainHandlerLockException>(() => ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", 0));
            Assert.IsTrue(exception.Message.StartsWith(handlerName + " is a scheduled action, but invalid predictedNextExecutionInSeconds value was provided"));
            
            exception = Assert.Throws<FailedToObtainHandlerLockException>(() => ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", -10));
            Assert.IsTrue(exception.Message.StartsWith(handlerName + " is a scheduled action, but invalid predictedNextExecutionInSeconds value was provided"));
        }

        [Test]
        public void GetLock_Throws_IfHandlerNotDefinedInDB()
        {
            var handlerName = "Whatever";
            var exception = Assert.Throws<FailedToObtainHandlerLockException>(() => ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", 0));
            Assert.IsTrue(exception.Message.StartsWith(handlerName + " is not defined"));
        }

        [Test]
        public void GetLock_Throws_IfLockIsTaken()
        {
            var aGuid = "A guid";
            var handlerName = typeof(PartnerJsonFileHandler).FullName;
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, aGuid, "a hostname", 0);
            var anotherGuid = "Another guid";
            var exception = Assert.Throws<FailedToObtainHandlerLockException>(() => ActionHandlerMapper.Instance.GetLock(handlerName, anotherGuid , "a hostname", 0));
            Assert.IsTrue(exception.Message.StartsWith(handlerName + " is already locked by service with GUID " + aGuid));
        }

        [Test]
        public void GetLock_Throws_IfActionIsPerformed_WhenOtherServiceTryToGetLock()
        {
            var handlerName = typeof(IrisPollingHandler).FullName;
            var aGuid = "A Guid";
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, aGuid, "a hostname", 600);
            Assert.DoesNotThrow(() => ActionHandlerMapper.Instance.ReleaseLock(handlerId));
            var handlerInfo = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);
            var exception = Assert.Throws<FailedToObtainHandlerLockException>(() => ActionHandlerMapper.Instance.GetLock(handlerName, "Another guid", "a hostname", 600));
            Assert.IsTrue(exception.Message.StartsWith("Action already performed by " + aGuid +""));
        }

        [Test]
        public void GetLock_Throws_IfActionIsPerformed_WhenSameServiceTryToGetLockAgain()
        {
            //this is to prevent the scenario, when a service just performed a recurring job, 
            //and then the service was restarted and try to execute the same job right away again.
            var aGuid = "A Guid";
            var handlerName = typeof(IrisPollingHandler).FullName;
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, aGuid, "a hostname", 600);
            Assert.DoesNotThrow(() => ActionHandlerMapper.Instance.ReleaseLock(handlerId));
            var handlerInfo = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);
            var exception = Assert.Throws<FailedToObtainHandlerLockException>(() => ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", 600));
            Assert.IsTrue(exception.Message.StartsWith("Action already performed by " + aGuid + ""));
        }

        [Test]
        public void GetLock_Works_WhenServiceWantsToExecuteActionSlightlyBeforePredictedExecutionTime()
        {
            //this is to mimic the scenario where, the service triggers a recurring job
            //sligntly before the predictedExecutionTime (within the grace period),
            //due to some time deviation, a lock should be successfully obtained.

            var guid = "A guid";
            var hostName = "a hostname";
            var nextExpectedExecutionInSeconds = 600;
            var handlerName = typeof(IrisPollingHandler).FullName;
            var handlerInfo = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);
            var gracePeriodInSeconds = handlerInfo.GracePeriodInSeconds;
            var now = DateTime.UtcNow;
            ActionHandlerMapper.Instance.UpdateLockForTesting(handlerInfo.Id, guid, hostName, now, now, now.AddSeconds(gracePeriodInSeconds));
            Assert.DoesNotThrow(() => ActionHandlerMapper.Instance.GetLock(handlerName, guid, hostName, nextExpectedExecutionInSeconds));
            handlerInfo = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);

            //check that the updated actual new predicted time calculated from DB is close to (NOW + gracePeriodInSeconds)
            Assert.IsTrue((now.AddSeconds(600) - handlerInfo.PredictedNextExecutionUtc).Milliseconds < 100);   
        }

        [Test]
        public void GetLock_RenewsExpiredLock_ForNonScheduledJobs()
        {
            //a service which want to execute non-scheduled jobs should be able to retrive expired lock with the same GUID anytime
            var handlerName = typeof(PartnerJsonFileHandler).FullName;
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", -1);
            Assert.DoesNotThrow(() => ActionHandlerMapper.Instance.ReleaseLock(handlerId));
            Assert.DoesNotThrow(() => ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", -1));
        }

        [Test]
        public void ReleaseLock_Works()
        {
            var handlerName = typeof(PartnerJsonFileHandler).FullName;
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, "A guid", "a hostname", -1);
            Assert.DoesNotThrow(() => ActionHandlerMapper.Instance.ReleaseLock(handlerId));
            var handlerInfo = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);

            Assert.IsTrue(handlerInfo.LockedTtlUtc < DateTime.UtcNow.AddMinutes(1));
        }

        [Test]
        public void ReleaseLockByGuid_Works()
        {
            var handlerName = typeof(PartnerJsonFileHandler).FullName;
            var guid = "A guid";
            var handlerId = ActionHandlerMapper.Instance.GetLock(handlerName, guid, "a hostname", -1);
            Assert.DoesNotThrow(() => ActionHandlerMapper.Instance.ReleaseLockByGuid(guid));
            var handlerInfo = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handlerName);

            Assert.IsTrue(handlerInfo.LockedTtlUtc < DateTime.UtcNow.AddMinutes(1));
        }
    }
}
