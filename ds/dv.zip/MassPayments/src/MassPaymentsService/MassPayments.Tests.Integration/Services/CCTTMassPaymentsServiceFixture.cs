﻿using System.Collections.Generic;
using System.ServiceModel;
using MassPayments.CCTMassPayments;
using MassPayments.Infrastructure;
using MassPayments.ServiceProviders.CCTTMassPayments;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Services
{
    [TestFixture, Explicit]
    public class CCTTMassPaymentsServiceFixture
    {
        [SetUp]
        public void SetUp()
        {
            var messageHeaders = new Dictionary<string, string>
            {
                {"Application", "MassPay"},
                {"AuthenticationToken",ServiceSettings.Instance.GetCctServiceSecurityToken()}
            };

            var cctServiceClient = new MassPaymentsServiceClient();
            cctServiceClient.Endpoint.Behaviors.Add(new HttpHeadersEndpointBehavior(messageHeaders));

            CCTTServiceFactory.InjectedServiceInterface = cctServiceClient;

        }

        [TearDown]
        public void TearDown()
        {
            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void AbleToCatchCcttMassPaymentsFault()
        {
            int customerId = 391490; //this customer has bad remitter setting
            var request = new Domain.ValueObjects.Booking.BookOutgoingOrderRequest
            {
                SettlementCurrencyCode = "CAD",
                ClientId = customerId,
                ItemsToBook = new List<Domain.ValueObjects.Booking.BookOutgoingOrderRequestItem>
                {
                    new Domain.ValueObjects.Booking.BookOutgoingOrderRequestItem
                    {
                        Amount = 3.0m,
                        TradeCurrencyCode = "USD",
                        IsAmountInSettlementCurrency = false
                    }
                }
            };

            Assert.Throws<FaultException<MassPaymentsFault>>(
                () => CCTTMassPaymentsServiceProvider.Instance.BookOutgoingAggregateOrder(request));
        }

        [Test]
        public void AbleToCatchCcttInsufficientFundFault()
        {
            int customerId = 559343;    //this customer has insufficient fund setting
            var request = new Domain.ValueObjects.Booking.BookOutgoingOrderRequest
            {
                SettlementCurrencyCode = "CAD",
                ClientId = customerId,
                ItemsToBook = new List<Domain.ValueObjects.Booking.BookOutgoingOrderRequestItem>
                    {
                        new Domain.ValueObjects.Booking.BookOutgoingOrderRequestItem
                        {
                            Amount = 3000.0m,
                            TradeCurrencyCode = "USD",
                            IsAmountInSettlementCurrency = false
                        }
                    }
            };
            Assert.Throws<FaultException<MassPaymentsFault>>(() => CCTTMassPaymentsServiceProvider.Instance.BookOutgoingAggregateOrder(request));
        }
    }
}
