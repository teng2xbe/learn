﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Transactions;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Enums;
using MassPayments.ResourceAccess.ClientRA;
using MassPayments.ResourceAccess.ClientRA.Interfaces;
using MassPayments.WUBSHoldingEngine;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using MassPayments.CCTEntityManagement;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Bus;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Managers.Interfaces;
using MassPayments.Mappers;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Services.MassPaymentsService;
using MassPayments.Services.MassPaymentsService.DataContracts.Transaction;
using MassPayments.Tests.Integration.Mappers.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;
using MassPaymentsCommon.WCFContracts.RESTContracts.quotes;
using NUnit.Framework;
using Rhino.Mocks;
using IMassPaymentsService = MassPayments.CCTMassPayments.IMassPaymentsService;
using IEntityManagementService = MassPayments.CCTEntityManagement.IMassPaymentsService;
using QuoteResult = MassPayments.CCTMassPayments.QuoteResult;
using QuoteResultItem = MassPayments.CCTMassPayments.QuoteResultItem;
using MassPaymentsCommon.WCFContracts.RESTContracts.orders;
using NServiceBus;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Infrastructure;

namespace MassPayments.Tests.Integration.Services
{
    [TestFixture]
    public class MassPaymentsServiceFacadeFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
            CurrencyCache.Instance.Reinitialize();

            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
            MassPayBus.Instance = null;
            CurrencyCache.Instance = null;
            CCTTServiceFactory.InjectedServiceInterface = null;
            ValidationRules.Instance = null;
        }

        [Test]
        public void GetQuoteFailsIfPartnerAssignedCustomerIdNotProvided()
        {
            var quoteRequest = new QuoteRequestData
            {
                CustomerExternalId = "",
                FundingId = "file1"
            };

            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var facade = new MassPaymentsServiceFacade();

            Assert.Throws<InternalErrorException>(() => facade.GetQuote(quoteRequest));
//            customerManager.VerifyAllExpectations();
        }


        [Test]
        public void GetQuote_Succeeds()
        {

            var quoteRequest = new QuoteRequestData
            {
                CustomerExternalId = "banana5",
                FundingId = "file1"
            };

            quoteRequest.ItemsToQuote = new List<QuoteRequestItemData>{ new QuoteRequestItemData {TradeCurrencyCode = "AUD", SettlementCurrencyCode = "USD", FixedTradeAmount = 1}};

            var quoteResult = new QuoteResult { QuotedItems = new List<QuoteResultItem>()
            {
                new QuoteResultItem {ExpirationDurationInSeconds = 60, IsDirect = true, OrderId = 122, QuoteId = 133, TradeCurrencyCode = "AUD", SettlementCurrencyCode = "USD"}
            } };
            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(q => q.Quote(Arg<QuoteRequest>.Is.Anything)).Return(quoteResult);

            Assert.Throws<InternalErrorException>(() => new MassPaymentsServiceFacade().GetQuote(quoteRequest));
        }

        [Test]
        public void GetPayment_NotFoundinDatabase()
        {
            var paymentId = "7878";
            var mpFacade = new MassPaymentsServiceFacade();

            var result = mpFacade.GetPayment(paymentId);

            Assert.IsNull(result);
        }

        [Test]
        public void GetPayment_ExistsinDatabase()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var request = new GetSinglePaymentRequestData { PaymentId = "111" };
            var mpFacade = new MassPaymentsServiceFacade();

            var result = mpFacade.GetPayment(request.PaymentId);

            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.Status);
            Assert.AreEqual("111", result.PaymentId);
        }

        [Test]
        public void GetPayment_ExistsForOtherPartnerinDatabase()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 2, Name = "Vikings" });
            var request = new GetSinglePaymentRequestData { PaymentId = "111" };
            var mpFacade = new MassPaymentsServiceFacade();

            var result = mpFacade.GetPayment(request.PaymentId);

            Assert.IsNull(result);            
        }

        [Test]
        public void GetPaymentStatus_NotFoundinDatabase()
        {
            var request = new GetPaymentsRequestData { PaymentIds = new List<string> { "7878" } };
            var mpFacade = new MassPaymentsServiceFacade();

            var result = mpFacade.GetPayments(request);

            Assert.AreEqual(request.PaymentIds.Count, result.PaymentItems.Count);
            Assert.IsNull(result.PaymentItems[0].Status);
            Assert.AreEqual("7878", result.PaymentItems[0].Id);
        }

        [Test]
        public void GetPaymentStatus_ExistsinDatabase()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var request = new GetPaymentsRequestData { PaymentIds = new List<string> { "111" } };
            var mpFacade = new MassPaymentsServiceFacade();

            var result = mpFacade.GetPayments(request);

            Assert.AreEqual(request.PaymentIds.Count, result.PaymentItems.Count);
            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.PaymentItems[0].Status);
            Assert.AreEqual("111", result.PaymentItems[0].Id);
        }

        [Test]
        public void GetBatchPayment_Status()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(payment1.AmountMoney.Currency, 777);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };           
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(payment1);

            var payments = new List<Payment> { payment1 };

            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);

            var mpFacade = new MassPaymentsServiceFacade();
            var result = mpFacade.GetBatchPayment(customer.PartnerAssignedCustomerId, customerBatch.ExternalId, payment1.ExternalId);
            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.Status);
            Assert.IsNullOrEmpty(result.UpdateErrorCode);
            Assert.IsNullOrEmpty(result.UpdateErrorOn);

            customerBatch.BatchStatus = CustomerBatchStatus.Committed;
            CustomerBatchMapper.Instance.UpdateCustomerBatchStatus(customerBatch);
            result = mpFacade.GetBatchPayment(customer.PartnerAssignedCustomerId, customerBatch.ExternalId, payment1.ExternalId);
            Assert.AreEqual(PaymentStatusData.Processing.ToString(), result.Status);
            Assert.IsNullOrEmpty(result.UpdateErrorCode);
            Assert.IsNullOrEmpty(result.UpdateErrorOn);
        }

        [Test]
        public void GetBatchPayment_LastUpdateError()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            PaymentMapper.Instance.InsertPayment(payment1);

            var payments = new List<Payment> { payment1 };
            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);

            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest>()
            };

            request.Id = PaymentRequestMapper.Instance.InsertPaymentRequest(request);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentUpdateHistory(new PaymentUpdateHistory
            {
                ErrorCode = "1104",
                PaymentId = payment1.Id,
                PaymentRequestId = request.Id
            }));

            
            var mpFacade = new MassPaymentsServiceFacade();
            var result = mpFacade.GetBatchPayment(customer.PartnerAssignedCustomerId, customerBatch.ExternalId, payment1.ExternalId);
            Assert.AreEqual("1104", result.UpdateErrorCode);
            Assert.IsNotNullOrEmpty(result.UpdateErrorOn);
        }

        [Test]
        public void GetBatchPayments_Status()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(payment1.AmountMoney.Currency, 777);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.AmountMoney = new Money(payment1.AmountMoney.Currency, 777);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "ref2a" };
            payment2.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(payment2);

            var payments = new List<Payment> { payment1, payment2 };

            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);

            var request = new GetPaymentsRequestData { PaymentIds = new List<string> { payment1.ExternalId, payment2.ExternalId} };
            var mpFacade = new MassPaymentsServiceFacade();

            var result = mpFacade.GetBatchPayments(customer.PartnerAssignedCustomerId, customerBatch.ExternalId, request);
            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.PaymentItems[0].Status);
            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.PaymentItems[1].Status);

            customerBatch.BatchStatus = CustomerBatchStatus.Committed;
            CustomerBatchMapper.Instance.UpdateCustomerBatchStatus(customerBatch);
            result = mpFacade.GetBatchPayments(customer.PartnerAssignedCustomerId, customerBatch.ExternalId, request);
            Assert.AreEqual(PaymentStatusData.Processing.ToString(), result.PaymentItems[0].Status);
            Assert.AreEqual(PaymentStatusData.Processing.ToString(), result.PaymentItems[1].Status);
        }

        [Test]
        public void GetPaymentStatus_ExistsForOtherPartnerinDatabase()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 2, Name = "Vikings" });
            var request = new GetPaymentsRequestData { PaymentIds = new List<string> { "111" } };
            var mpFacade = new MassPaymentsServiceFacade();

            var result = mpFacade.GetPayments(request);

            Assert.AreEqual(request.PaymentIds.Count, result.PaymentItems.Count);
            Assert.IsNull(result.PaymentItems[0].Status);
            Assert.AreEqual("111", result.PaymentItems[0].Id);
        }

        [Test]
        public void GetHoldingBalance_ThrowsException_CurrencyNotRecognized()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var holdingData = new HoldingBalanceResult {AvailableBalance  = 0.0m, BookedBalance = 0.0m};
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).Return(holdingData);

            var mpFacade = new MassPaymentsServiceFacade();
            var request = new GetHoldingBalanceRequestData() { PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId, CurrencyCode = "101"};
          
            Assert.Throws<CurrencyNotRecognizedException>(() => mpFacade.GetHoldingBalance(request));
            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void GetHoldingBalance_ThrowsException_DecoupledPartnerAccess()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var holdingData = new HoldingBalanceResult { AvailableBalance = 0.0m, BookedBalance = 0.0m };
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Coupled});

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).Return(holdingData);

            var mpFacade = new MassPaymentsServiceFacade();
            var request = new GetHoldingBalanceRequestData() { PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId, CurrencyCode = "101" };

            Assert.Throws<CoupledPartnerAccessException>(() => mpFacade.GetHoldingBalance(request));
            CCTTServiceFactory.InjectedServiceInterface = null;
        }


         [Test]
        public void GetHoldingBalanceByCurrency_ReturnsValidObject()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

            var mpFacade = new MassPaymentsServiceFacade();
            var request = new GetHoldingBalanceRequestData() { PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId, CurrencyCode = "USD" };
            var result = mpFacade.GetHoldingBalance(request);

            Assert.AreEqual(request.CurrencyCode, result.HoldingBalances[0].Currency);
            Assert.NotNull(result.HoldingBalances[0].Available);
            Assert.NotNull(result.HoldingBalances[0].Booked);
        }

         [Test]
         public void GetAllHoldingBalance_ReturnsValidObject()
         {
             var customer = CustomerHelper.Instance.CreateCustomer();
             customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
             ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

             var mpFacade = new MassPaymentsServiceFacade();
             var request = new GetHoldingBalanceRequestData() { PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId, CurrencyCode = string.Empty };
             var result = mpFacade.GetHoldingBalance(request);

             Assert.Greater(result.HoldingBalances.Count, 0);
         }

        [Test]
        public void GetAllHoldingBalance_WrongPartner()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var holdingData = new HoldingData() { CurrencyCode = null };

            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 2, Name = "Vikings" });
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Throw(new FaultException<NoClientFoundFault>(null, "test"));
            
            var mpFacade = new MassPaymentsServiceFacade();
            var request = new GetHoldingBalanceRequestData() { PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId, CurrencyCode = string.Empty };

            Assert.Throws<CustomerNotExistsException>(() => mpFacade.GetHoldingBalance(request));
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        [Test]
        public void GetFundingQuote_Retunrs_Null_For_NotFound()
        {
            var quote = new MassPaymentsServiceFacade().GetFundingQuote(new GetFundingQuoteRequestData {QuoteId = "0"});
            Assert.IsNull(quote);
        }

        [Test]
        public void GetFundingQuote_Retunrs_Null_For_InvalidId()
        {
            var quote = new MassPaymentsServiceFacade().GetFundingQuote(new GetFundingQuoteRequestData { QuoteId = "bleh" });
            Assert.IsNull(quote);
        }

        [Test]
        public void CreateFundingQuoteForBatch_DeCoupledPartner_ThrowsException()
        {
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Decoupled });

            Assert.Throws<DecoupledPartnerAccessException>(() => new MassPaymentsServiceFacade().CreateFundingQuoteForBatch("testBatch01", "blah"));
        }

        [Test]
        public void CreateFundingQuoteForBatch_NoCustomerBatchFound_ThrowsException()
        {
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Coupled });

            Assert.Throws<CustomerBatchNotFoundException>(() => new MassPaymentsServiceFacade().CreateFundingQuoteForBatch("testBatch01", "blah"));
        }

        [Test]
        public void CreateFundingQuoteForBatch_NoPayments_ThrowsException()
        {
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Coupled });
           
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            
            Assert.Throws<NoPaymentsCreatedUsingBatchIdException>(() => new MassPaymentsServiceFacade().CreateFundingQuoteForBatch(customer.PartnerAssignedCustomerId, customerBatch.ExternalId ));
        }

        [Test]
        public void CreateFundingQuoteForBatch_Works()
        {
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Coupled });

            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };
            PaymentMapper.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "ref2a", "ref2b" };
            PaymentMapper.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.UpdatedOnUTC = DateTime.UtcNow;
            payment3.RemittanceData = new List<string> { "ref3a", "ref3b", "ref3c" };
            PaymentMapper.Instance.InsertPayment(payment3);

            Assert.DoesNotThrow(() => new MassPaymentsServiceFacade().CreateFundingQuoteForBatch(customer.PartnerAssignedCustomerId, customerBatch.ExternalId));
        }

        
        [Test, Explicit]
        public void CommitBatch_Works()
        {
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Coupled });

            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var request = new CommitBatchRequestData()
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode = "CAD",
                        SettlementMethod = "WIRE"
                    }
                }
            };

            Assert.DoesNotThrow(() => new MassPaymentsServiceFacade().CommitBatch(customerBatch.ExternalId, customer.PartnerAssignedCustomerId, request));
        }

        [Test, Explicit]
        public void CommitBatch_WorksWithNullRequest()
        {
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Coupled });

            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            Assert.DoesNotThrow(() => new MassPaymentsServiceFacade().CommitBatch(customerBatch.ExternalId, customer.PartnerAssignedCustomerId, null));
        }

        [Test]
        public void BookFundingOrderForBatch_NoPayments_ThrowsException()
        {
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet", PaymentModel = PaymentModel.Coupled });

            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);           

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode = "USD",
                        SettlementMethod = "WIRE"
                    }
                }
            };

            Assert.Throws<NoPaymentsCreatedUsingBatchIdException>(() => new MassPaymentsServiceFacade().CommitBatch(customerBatch.ExternalId, customer.PartnerAssignedCustomerId, request));          
        }

        public class TestEntityManagementService : IEntityManagementService
        {
            public ClientDetailsForInvoice GetClientDetailsForInvoice(int clientId)
            {
                throw new NotImplementedException();
            }

            public void Ping()
            {
                throw new NotImplementedException();
            }

            public MassPayClientInfo GetMassPayClient(GetMassPayClientRequest request)
            {
                throw new FaultException<InvalidExternalIdFault>(new InvalidExternalIdFault());
            }

            public BankAccountResult GetBankAccount(BankAccountRequest request)
            {
                throw new NotImplementedException();
            }

            public ClientDetailsForPAIN GetClientDetailsForPAIN(int clientId)
            {
                throw new NotImplementedException();
            }
        }
    }
}
