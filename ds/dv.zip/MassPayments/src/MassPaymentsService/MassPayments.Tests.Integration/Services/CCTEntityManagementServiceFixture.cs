﻿using MassPayments.CCTEntityManagement;
using MassPayments.ServiceProviders.CCTEntityManagement;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Services
{
    [TestFixture, Explicit]
    public class CCTEntityManagementServiceFixture
    {
        [SetUp]
        public void SetUp()
        {
            EntityManagementServiceFactory.InjectedServiceInterface = new MassPaymentsServiceClient();
        }

        [TearDown]
        public void TearDown()
        {
            EntityManagementServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void TalkToEntityManagementService_Works()
        {
            Domain.ValueObjects.ClientDetailInfo result = null;
            Assert.DoesNotThrow(() => result = EntityManagementServiceProvider.Instance.GetClientDetailsForInvoice(559343));

            Assert.IsNotNull(result);
            Assert.AreEqual(result.Id, 559343);
        }
    }
}
