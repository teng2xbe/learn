﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers
{
    [TestFixture]
    public class CustomerBatchManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
            CurrencyCache.Instance = null;
        }

        [Test]
        public void CreateBatch_InsertCustomerBatchSuccessfully()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var createdCustomer = new Customer
            {
                Id = customer.Id,
                PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId,
                TransactionSystemCustomerId = customer.TransactionSystemCustomerId
            };

            var requestData = new BatchRequestData
            {
                Reference = "Insert Batch"
            };

            var manager = new CustomerBatchManager();
            var createdBatch = manager.CreateBatch( createdCustomer, "1234", requestData);
            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(createdBatch.Id);
            Assert.AreEqual(BatchType.ApiBatch, customerBatch.BatchType);
            Assert.AreEqual(requestData.Reference, customerBatch.BatchReference);
            Assert.AreEqual("1234", customerBatch.ExternalId, "1234");
            Assert.AreEqual(customer.PartnerAssignedCustomerId, customerBatch.ExternalCustomerId);
            Assert.IsNotNullOrEmpty(customerBatch.UpdatedOnUTC.ToString());
        }

        [Test]
        public void CreateBatch_InsertCustomerBatchNoBatchReference_Successfully()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var createdCustomer = new Customer
            {
                Id = customer.Id,
                PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId,
                TransactionSystemCustomerId = customer.TransactionSystemCustomerId
            };

            var manager = new CustomerBatchManager();
            var createdBatch = manager.CreateBatch(createdCustomer, "1234", null);
            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(createdBatch.Id);
            Assert.AreEqual(BatchType.ApiBatch, customerBatch.BatchType);
            Assert.IsNullOrEmpty(customerBatch.BatchReference);
            Assert.AreEqual("1234", customerBatch.ExternalId, "1234");
            Assert.AreEqual(customer.PartnerAssignedCustomerId, customerBatch.ExternalCustomerId);
            Assert.IsNotNullOrEmpty(customerBatch.UpdatedOnUTC.ToString());
        }

        [Test]
        public void CreateBatch_UpdateExistingCustomerBatchSuccessfully()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);
            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch1.Id);

            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now.AddMinutes(5), new Partner { Id = 1, Name = "HyperWallet" });

            var createdCustomer = new Customer
            {
                Id = customer.Id,
                PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId,
                TransactionSystemCustomerId = customer.TransactionSystemCustomerId
            };

            var requestData = new BatchRequestData
            {
                Reference = "Update Reference"
            };

            var manager = new CustomerBatchManager();
            var internalBatchId = manager.CreateBatch(createdCustomer, customerBatch1.ExternalId, requestData);
            var customerBatchUpdated = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch1.Id);
            //TODO: expected value is always first parameter, actual is second
            //TODO: what -1 was expected?
            //            Assert.AreEqual(internalBatchId, -1);
            Assert.AreEqual(BatchType.ApiBatch, customerBatch.BatchType);
            Assert.AreEqual(requestData.Reference, customerBatchUpdated.BatchReference);
            Assert.AreEqual(customerBatch1.ExternalId, customerBatchUpdated.ExternalId);
            Assert.AreEqual(customer.PartnerAssignedCustomerId, customerBatch.ExternalCustomerId);
            Assert.AreNotEqual(customerBatch.CreatedOnUTC, customerBatchUpdated.UpdatedOnUTC);
        }

        [Test]
        public void CreateBatch_UpdateExistingCustomerBatchNoBatchReference_Successfully()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch1 = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch1);
            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch1.Id);

            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now.AddMinutes(5), new Partner { Id = 1, Name = "HyperWallet" });

            var createdCustomer = new Customer
            {
                Id = customer.Id,
                PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId,
                TransactionSystemCustomerId = customer.TransactionSystemCustomerId
            };

            var manager = new CustomerBatchManager();
            var internalBatchId = manager.CreateBatch(createdCustomer, customerBatch1.ExternalId, null);
            var customerBatchUpdated = CustomerBatchMapper.Instance.GetCustomerBatch(customerBatch1.Id);
            Assert.AreEqual(BatchType.ApiBatch, customerBatch.BatchType);
            Assert.IsNullOrEmpty(customerBatchUpdated.BatchReference);
            Assert.AreEqual(customerBatch1.ExternalId, customerBatchUpdated.ExternalId);
            Assert.AreEqual(customer.PartnerAssignedCustomerId, customerBatch.ExternalCustomerId);
            Assert.AreNotEqual(customerBatch.CreatedOnUTC, customerBatchUpdated.UpdatedOnUTC);
        }

        [Test]
        public void PopulateBatchAmounts_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.CAD, 1.02m);
            payment.SettlementAmountMoney = new Money(Currency.USD, 0);
            payment.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment);


            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(Currency.CAD, 0.89m);
            payment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            payment1.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment1);


            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.AmountMoney = new Money(Currency.AUD, 0m);
            payment2.SettlementAmountMoney = new Money(Currency.USD, 1.23m);
            payment2.IsFixedAmountInSettlementCurrency = true;
            PaymentMapper.Instance.InsertPayment(payment2);


            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.AmountMoney = new Money(Currency.AUD, 0);
            payment3.SettlementAmountMoney = new Money(Currency.USD, 3.45m);
            payment3.IsFixedAmountInSettlementCurrency = true;
            PaymentMapper.Instance.InsertPayment(payment3);

            new CustomerBatchManager().PopulateBatchAmounts(customerBatch);

            Assert.AreEqual(2, customerBatch.AggregateAmounts.Count);
            Assert.AreEqual(payment.AmountMoney.Amount + payment1.AmountMoney.Amount,
                customerBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == payment.AmountMoney.Currency.Code
                && a.TotalPaymentsSettlementMoney.Currency.Code == payment.SettlementAmountMoney.Currency.Code).TotalPaymentsMoney.Amount);
            Assert.AreEqual(payment2.SettlementAmountMoney.Amount + payment3.SettlementAmountMoney.Amount,
                customerBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == payment2.AmountMoney.Currency.Code
                && a.TotalPaymentsSettlementMoney.Currency.Code == payment2.SettlementAmountMoney.Currency.Code).TotalPaymentsSettlementMoney.Amount);
        }

        [Test]
        public void GetCustomerBatchInCreatedStatus_LoadsAmounts()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.CAD, 1.02m);
            payment.SettlementAmountMoney = new Money(Currency.USD, 0);
            payment.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment);


            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.AmountMoney = new Money(Currency.CAD, 0.89m);
            payment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            payment1.IsFixedAmountInSettlementCurrency = false;
            PaymentMapper.Instance.InsertPayment(payment1);


            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.AmountMoney = new Money(Currency.AUD, 0m);
            payment2.SettlementAmountMoney = new Money(Currency.USD, 1.23m);
            payment2.IsFixedAmountInSettlementCurrency = true;
            PaymentMapper.Instance.InsertPayment(payment2);


            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.AmountMoney = new Money(Currency.AUD, 0);
            payment3.SettlementAmountMoney = new Money(Currency.USD, 3.45m);
            payment3.IsFixedAmountInSettlementCurrency = true;
            PaymentMapper.Instance.InsertPayment(payment3);


            var loadedBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            Assert.AreEqual(2, loadedBatch.AggregateAmounts.Count);
            Assert.AreEqual(payment.AmountMoney.Amount + payment1.AmountMoney.Amount,
                loadedBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == payment.AmountMoney.Currency.Code
                && a.TotalPaymentsSettlementMoney.Currency.Code == payment.SettlementAmountMoney.Currency.Code).TotalPaymentsMoney.Amount);
            Assert.AreEqual(payment2.SettlementAmountMoney.Amount + payment3.SettlementAmountMoney.Amount,
                loadedBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == payment2.AmountMoney.Currency.Code
                && a.TotalPaymentsSettlementMoney.Currency.Code == payment2.SettlementAmountMoney.Currency.Code).TotalPaymentsSettlementMoney.Amount);
        }

        [Test]
        public void GetCustomerBatchNotInCreatedStatus_LoadsAmounts()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            customerBatch.BatchStatus = CustomerBatchStatus.Committed;
            CustomerBatchMapper.Instance.UpdateCustomerBatchStatus(customerBatch);


            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id, new Money(Currency.AUD, 1.23m), new Money(Currency.CAD, 2.34m),null,true);
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id, new Money(Currency.USD, 3.45m), new Money(Currency.CAD, 4.56m),null,false);

            var loadedBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            Assert.AreEqual(2, loadedBatch.AggregateAmounts.Count);
            Assert.AreEqual(1.23m,
                loadedBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == "AUD"
                && a.TotalPaymentsSettlementMoney.Currency.Code == "CAD").TotalPaymentsMoney.Amount);
            Assert.AreEqual(2.34m,
                loadedBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == "AUD"
                && a.TotalPaymentsSettlementMoney.Currency.Code == "CAD").TotalPaymentsSettlementMoney.Amount);
            Assert.AreEqual(3.45m,
                loadedBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == "USD"
                && a.TotalPaymentsSettlementMoney.Currency.Code == "CAD").TotalPaymentsMoney.Amount);
            Assert.AreEqual(4.56m,
                loadedBatch.AggregateAmounts.First(a => a.TotalPaymentsMoney.Currency.Code == "USD"
                && a.TotalPaymentsSettlementMoney.Currency.Code == "CAD").TotalPaymentsSettlementMoney.Amount);
        }
    }

}
