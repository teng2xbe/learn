﻿using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Batches;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Tests.Integration.Mappers.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.ServiceModel;
using System.Transactions;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Bus;
using MassPayments.Managers.BatchManaging;
using MassPayments.ResourceAccess.QuotesRA;
using MassPayments.ResourceAccess.QuotesRA.Interfaces;
using NServiceBus;
using DomainSettlementPaymentMethod = MassPayments.Domain.Enums.SettlementPaymentMethod;

namespace MassPayments.Tests.Integration.Managers.BatchManaging
{
    [TestFixture]
    public class CustomerBatchOrderManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Expect(ccm => ccm.GetCurrencyDictionary())
                .Return(new Dictionary<string, Currency>
                {
                    {"CAD", new Currency("CAD")},
                    {"USD", new Currency("USD")},
                    {"JPY", new Currency("JPY")},
                    {"EUR", new Currency("EUR")},
                    {"GBP", new Currency("GBP")}

                });
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
            CCTTServiceFactory.InjectedServiceInterface = null;
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetCctServiceSecurityToken()).Return("token");
            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");            
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
            CurrencyCacheMapper.Instance = null;
            MassPayBus.Instance = null;

            ServiceSettings.Instance = null;
            ValidationRules.Instance = null;
        }

        [Test]
        public void BookBatch_ReturnsCorrectResults()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);


            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            var loadedBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = loadedBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = new Currency("USD"),
                        SettlementMethod = DomainSettlementPaymentMethod.Wire
                    },
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = new Currency("CAD"),
                        SettlementMethod = DomainSettlementPaymentMethod.ACH
                    }
                }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            Assert.DoesNotThrow(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));

            const int maxRecords = 1000;
            var payments = PaymentMapper.Instance.GetPayments(customerBatch, maxRecords);

            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Orders.Count);
            Assert.AreEqual("USD", result.Orders[0].SettlementCurrency.Code);
            Assert.AreEqual("CAD", result.Orders[1].SettlementCurrency.Code);
            Assert.AreEqual("Wire", result.Orders[0].SettlementMethod);
            Assert.AreEqual("Edebit", result.Orders[1].SettlementMethod);
            Assert.AreEqual(OrderStatus.Committed, result.Orders[0].OrderStatus);
            Assert.AreEqual(OrderStatus.Committed, result.Orders[1].OrderStatus);
        }

        [Test]
        public void BookBatch_ReturnsCorrectResults_ByCustomerIdAndBatchId()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);


            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            var loadedBatch = new CustomerBatchManager().GetCustomerBatch(customer.Id,customerBatch.ExternalId);

            var request = new CommitBatchRequest
            {
                CustomerBatch = loadedBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = new Currency("USD"),
                        SettlementMethod = DomainSettlementPaymentMethod.Wire
                    },
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = new Currency("CAD"),
                        SettlementMethod = DomainSettlementPaymentMethod.ACH
                    }
                }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            Assert.DoesNotThrow(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));

            const int maxRecords = 1000;
            var payments = PaymentMapper.Instance.GetPayments(customerBatch, maxRecords);

            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Orders.Count);
            Assert.AreEqual("USD", result.Orders[0].SettlementCurrency.Code);
            Assert.AreEqual("CAD", result.Orders[1].SettlementCurrency.Code);
            Assert.AreEqual("Wire", result.Orders[0].SettlementMethod);
            Assert.AreEqual("Edebit", result.Orders[1].SettlementMethod);
            Assert.AreEqual(OrderStatus.Committed, result.Orders[0].OrderStatus);
            Assert.AreEqual(OrderStatus.Committed, result.Orders[1].OrderStatus);
        }

        [Test]
        public void ValidateBatchPayments_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));

            Assert.DoesNotThrow(() => new CustomerBatchOrderManager().ValidateBatchPayments(customerBatch));
        }

        [Test]
        public void ValidateBatchPayments_ThrowsException_WhenNoPaymentsAreAccepted()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            Assert.Throws<NoPaymentsCreatedUsingBatchIdException>(() => new CustomerBatchOrderManager().ValidateBatchPayments(customerBatch));
        }

        [Test]
        public void ValidateBatchPayments_ThrowsException_WhenAllPaymentsareCancelled()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));

            Assert.DoesNotThrow(() => new PaymentManager().UpdatePaymentStatuses(new List<Payment> { clientBatchPayment1, clientBatchPayment2, clientBatchPayment3 }, PaymentStatus.Cancelled));

            Assert.Throws<NoPaymentsCreatedUsingBatchIdException>(() => new CustomerBatchOrderManager().ValidateBatchPayments(customerBatch));
        }

        [Test]
        public void BookBatch_ThrowsExceptionWhenExceptionOccursInService()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

//            new PaymentManager().UpdateBatchAggregatedAmountsWithPayments(customerBatch.Id, new List<Payment> { clientBatchPayment1, clientBatchPayment2, clientBatchPayment3
//            });

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
                    CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new DivideByZeroException()).Repeat.Once();

                    Assert.Throws<DivideByZeroException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
                    Assert.IsNull(result);
        }

        [Test]
        public void BookBatch_Throws_InvalidSettlementMethodException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<InvalidSettlementMethodFault>(null, "test"));

            Assert.Throws<InvalidSettlementMethodException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }

        [Test]
        public void BookBatch_Throws_DebitLimitExceededException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<DebitLimitExceededFault>(null, "test"));

            Assert.Throws<DebitLimitExceededException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }
        [Test]
        public void BookBatch_Throws_GenericOrderValidationException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<OrderValidationFault>(null, "test"));

            Assert.Throws<GenericOrderValidationException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }

        [Test]
        public void BookBatch_Throws_MinimumAmountNotMetException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<MinimumAmountNotMetFault>(null, "test"));

            Assert.Throws<MinimumAmountNotMetException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }

        [Test]
        public void BookBatch_Throws_MaximumAmountExceededxception()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<MaximumAmountExceededFault>(null, "test"));

            Assert.Throws<MaximumAmountExceededException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }

        [Test]
        public void BookBatch_Throws_CurrencyNotSupportedForHoldingException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<CurrencyNotCapableOfHoldingFault>(null, "test"));

            Assert.Throws<CurrencyNotCapableofHoldingException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }

        [Test]
        public void BookBatch_Throws_GenericCoupledLineItemException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<LineItemValidationFault>(null, "test"));

            Assert.Throws<GenericCoupledLineItemValidationException>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }

        [Test]
        public void BookBatch_Works_OtherException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.TransactionSystemCustomerId = 521479;
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment1.AmountMoney, clientBatchPayment1.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment2.AmountMoney, clientBatchPayment2.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));
            CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(customerBatch.Id,
                clientBatchPayment3.AmountMoney, clientBatchPayment3.SettlementAmountMoney, new Money(Currency.USD, 0),
                false);

            var quote = new CustomerBatchOrderManager().CreateQuoteForBatch(customerBatch, customer);

            customerBatch.ActiveQuoteRequestId = quote.Id;

            customerBatch = new CustomerBatchManager().GetCustomerBatch(customerBatch.Id);

            var request = new CommitBatchRequest
            {
                CustomerBatch = customerBatch,
                Settlements = new List<CommitBatchSettlementRequest>
                        {
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("USD"),
                                SettlementMethod = DomainSettlementPaymentMethod.Wire
                            },
                            new CommitBatchSettlementRequest
                            {
                                SettlementCurrency = new Currency("CAD"),
                                SettlementMethod = DomainSettlementPaymentMethod.ACH
                            }
                        }
            };

            var customerBatchOrderManager = new CustomerBatchOrderManager();
            CommitBatchResult result = null;

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<InvalidValueDateFault>(null, "test"));

            Assert.Throws<FaultException<InvalidValueDateFault>>(() => result = customerBatchOrderManager.BookBatch(request, customer, new Partner()));
            Assert.IsNull(result);
        }

        [Test]
        public void CommitOrder_InsertsPaymentStatusHistory()
        {
            var customerBatchOrderManager = new CustomerBatchOrderManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var mockedQuoteProvider = MockRepository.GenerateMock<IQuotesProvider>();
            QuotesProviderFactory.InjectedQuotesProviderInterface = mockedQuoteProvider;

            var quoteRequest = new Domain.ValueObjects.Quoting.QuoteRequest
            {
                ItemsToQuote = new List<Domain.ValueObjects.Quoting.QuoteRequestItem>
                {
                    new Domain.ValueObjects.Quoting.QuoteRequestItem
                    {
                        FixedSettlementMoney = new Money(Currency.USD, 1),
                        FixedTradeMoney = new Money(Currency.CAD, 0),
                        ValueDate = DateTime.Now.AddDays(1)
                    }
                }
            };
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    IsAmountInSettlementCurrency = true,
                    IsDirect = true,
                    NumberOfDecimalsDirect = 2,
                    NumberOfDecimalsIndirect = 2,
                    OrderId = 1234,
                    RateValue = 1,
                    RateValueInverted = 1,
                    SettlementMoney = new Money(Currency.USD, 1),
                    TradeMoney = new Money(Currency.CAD, 1),
                    TransactionSystemQuoteId = 1234
                }
            };

            mockedQuoteProvider.Expect(m => m.Quote(quoteRequest, customer))
                .Return(quotedItems);
            var quote = new QuoteManager().CreateQuote(quoteRequest, customer, true);
            
            customerBatch.ActiveQuoteRequestId = quote.Id;

            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            PaymentMapper.Instance.InsertPayment(payment);

            var loadedPaymentHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment.Id);
            Assert.AreEqual(0, loadedPaymentHistories.Count);

            customerBatchOrderManager.UpdatePaymentsAfterBatchIsBooked(customerBatch);

            loadedPaymentHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment.Id);
            Assert.AreEqual(1, loadedPaymentHistories.Count);
            Assert.AreEqual(PaymentStatus.Committed, loadedPaymentHistories[0].PaymentStatus);

            mockedQuoteProvider.VerifyAllExpectations();

            QuotesProviderFactory.InjectedQuotesProviderInterface = null;
        }

    }

}
