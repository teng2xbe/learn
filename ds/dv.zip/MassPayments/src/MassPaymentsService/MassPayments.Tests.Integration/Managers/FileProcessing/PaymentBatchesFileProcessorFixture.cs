﻿using System;
using System.ServiceModel;
using System.Text;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Gateways.Email.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers.FileProcessing;
using MassPayments.Mappers;
using MassPayments.ResourceAccess.ClientRA;
using MassPayments.ResourceAccess.ClientRA.Interfaces;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers.FileProcessing
{
    [TestFixture]
    public class PaymentBatchesFileProcessorFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            EmailMessageGateway.Instance = MockRepository.GenerateMock<IEmailMessageGateway>();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            ServiceCallContextManager.Instance = null;
        }

        [Test, Ignore("Oleg to review the test")]
        public void BatchesFileProcessor_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            const string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailString, 
                paymentExternalId,
                customer.PartnerAssignedCustomerId,
               DateTime.Now.ToString("yyyy-MM-dd")
            );

            var clientBatchString = string.Format(SampleClientbatchString, customer.PartnerAssignedCustomerId, paymentDetailString);
            var paymentBatchString = string.Format(SamplePaymentBatchString, clientBatchString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentBatchString),
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_testFileName.json"
            };
            FileMapper.Instance.InsertFile(file);

            var clientInfo = ClientProviderFactory.GetClientProvider().GetCustomerByExternalId(customer.PartnerAssignedCustomerId, "1");
            var clientDetailInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(customer.Id);
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(clientInfo);
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetClientDetailById(Arg<int>.Is.Anything)).Return(clientDetailInfo);

            var paymentBatchesProcessor = new PaymentBatchesFileProcessor(file);
            Assert.DoesNotThrow(() => paymentBatchesProcessor.Process());

            var loadedPayment = PaymentMapper.Instance.GetPayments(paymentExternalId, 1)[0];
            ValidateParsedPayment(loadedPayment);
            ValidateParsedBeneficiary(loadedPayment.Beneficiary);
            ValidateParsedBankAccount(loadedPayment.BankAccount);
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        [Test, Ignore("Oleg to review the test")]
        public void BatchesFileProcessor_Works_WithEmptyValueDate()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            const string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailString,
                paymentExternalId,
                customer.PartnerAssignedCustomerId,
                ""
            );

            var clientBatchString = string.Format(SampleClientbatchString, customer.PartnerAssignedCustomerId, paymentDetailString);
            var paymentBatchString = string.Format(SamplePaymentBatchString, clientBatchString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentBatchString),
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_testFileName.json"
            };
            FileMapper.Instance.InsertFile(file);

            var clientInfo = ClientProviderFactory.GetClientProvider().GetCustomerByExternalId(customer.PartnerAssignedCustomerId, "1");
            var clientDetailInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(customer.Id);
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(clientInfo);
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetClientDetailById(Arg<int>.Is.Anything)).Return(clientDetailInfo);
            
            var paymentBatchesProcessor = new PaymentBatchesFileProcessor(file);
            Assert.DoesNotThrow(() => paymentBatchesProcessor.Process());

            var loadedPayment = PaymentMapper.Instance.GetPayments(paymentExternalId, 1)[0];
            ValidateParsedPayment(loadedPayment);
            ValidateParsedBeneficiary(loadedPayment.Beneficiary);
            ValidateParsedBankAccount(loadedPayment.BankAccount); 
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        [Test, Ignore("Oleg to review the test")]
        public void BatchesFileProcessor_Works_WithEFTAsPaymentMethod()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            const string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailStringWithPaymentMethod,
               paymentExternalId,
               customer.PartnerAssignedCustomerId,
               "US_BANK_IAT_USD",
               DateTime.Now.ToString("yyyy-MM-dd")
            );

            var clientBatchString = string.Format(SampleClientbatchString, customer.PartnerAssignedCustomerId, paymentDetailString);
            var paymentBatchString = string.Format(SamplePaymentBatchString, clientBatchString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentBatchString),
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_testFileName.json"
            };
            FileMapper.Instance.InsertFile(file);

            var clientInfo = ClientProviderFactory.GetClientProvider().GetCustomerByExternalId(customer.PartnerAssignedCustomerId, "1");
            var clientDetailInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(customer.Id);
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(clientInfo);
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetClientDetailById(Arg<int>.Is.Anything)).Return(clientDetailInfo);

            var paymentBatchesProcessor = new PaymentBatchesFileProcessor(file);
            Assert.DoesNotThrow(() => paymentBatchesProcessor.Process());

            var loadedPayment = PaymentMapper.Instance.GetPayments(paymentExternalId, 1)[0];
            ValidateParsedPayment(loadedPayment);
            ValidateParsedBeneficiary(loadedPayment.Beneficiary);
            ValidateParsedBankAccount(loadedPayment.BankAccount);
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        [Test, Ignore("Oleg to review the test")]
        public void BatchesFileProcessor_UseFileCreationTimeForPayments()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            const string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailStringWithPaymentMethod,
               paymentExternalId,
               customer.PartnerAssignedCustomerId,
               "US_BANK_IAT_USD",
               DateTime.Now.ToString("yyyy-MM-dd")
            );

            var clientBatchString = string.Format(SampleClientbatchString, customer.PartnerAssignedCustomerId, paymentDetailString);
            var paymentBatchString = string.Format(SamplePaymentBatchString, clientBatchString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentBatchString),
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_testFileName.json"
            };
            FileMapper.Instance.InsertFile(file);
            file = FileMapper.Instance.GetFile(file.Id);
            file.FileContent = paymentBatchString;
            
            var clientInfo = ClientProviderFactory.GetClientProvider().GetCustomerByExternalId(customer.PartnerAssignedCustomerId, "1");
            var clientDetailInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(customer.Id);
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(clientInfo);
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetClientDetailById(Arg<int>.Is.Anything)).Return(clientDetailInfo);

            var paymentBatchesProcessor = new PaymentBatchesFileProcessor(file);
            Assert.DoesNotThrow(() => paymentBatchesProcessor.Process());

            var loadedPayment = PaymentMapper.Instance.GetPayments(paymentExternalId, 1)[0];
            ValidateParsedPayment(loadedPayment);
            ValidateParsedBeneficiary(loadedPayment.Beneficiary);
            ValidateParsedBankAccount(loadedPayment.BankAccount);

            Assert.AreEqual(file.CreatedOnUTC.ToShortTimeString(), loadedPayment.CreatedOnUTC.ToShortTimeString());
            Assert.AreEqual(file.CreatedOnUTC.Date, loadedPayment.CreatedOnUTC.Date);
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        [Test, Explicit]
        public void BatchesFileProcessor_Works_WithLargeAmountOfEntry()
        {
            //var customer = CustomerHelper.Instance.CreateCustomer();
            //customer.ExternalId = "VAN-KO1224";
            //customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var paymentBatchString =
                System.IO.File.ReadAllText(@"C:\Users\hem\Desktop\MassPaymentsDataGenerator1\ClientBatches.json");
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentBatchString),
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "testFileName"
            };
            FileMapper.Instance.InsertFile(file);

            Assert.DoesNotThrow(() => new PaymentBatchesFileProcessor(file).Process());
        }

        [Test, Explicit]
        public void BatchesFileProcessor_FailsToParse_OnBadPaymentMethod()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            const string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailStringWithPaymentMethod,
                paymentExternalId,
                customer.PartnerAssignedCustomerId,
                "abc_RBC",
               DateTime.Now.ToString("yyyy-MM-dd")
            );

            var clientBatchString = string.Format(SampleClientbatchString, customer.PartnerAssignedCustomerId, paymentDetailString);
            var paymentBatchString = string.Format(SamplePaymentBatchString, clientBatchString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentBatchString),
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.test"
            };
            FileMapper.Instance.InsertFile(file);

            var clientInfo = ClientProviderFactory.GetClientProvider().GetCustomerByExternalId(customer.PartnerAssignedCustomerId, "1");
            var clientDetailInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(customer.Id);
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(clientInfo);
            ClientProviderFactory.InjectedClientProviderInterface.Expect(sp => sp.GetClientDetailById(Arg<int>.Is.Anything)).Return(clientDetailInfo);
            

            var paymentBatchesProcessor = new PaymentBatchesFileProcessor(file);
            Assert.Throws<ProcessClientBatchFailedException>(() => paymentBatchesProcessor.Process());
            Assert.AreEqual(0,PaymentMapper.Instance.GetPayments(paymentExternalId, 1).Count);
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        private void ValidateParsedPayment(Payment payment)
        {
            Assert.IsNotNullOrEmpty(payment.AmountMoney.Currency.Code);
            Assert.IsNotNullOrEmpty(payment.ExternalId);
            Assert.Greater(payment.AmountMoney.Amount, 0);
            Assert.IsNotNull(payment.PaymentMethod);
            Assert.IsNotNull(payment.PaymentStatus);
            Assert.IsNotNull(payment.PaymentMethod);
            Assert.Greater(payment.TransactionSystemCustomerId, 0);
            Assert.Greater(payment.TransactionSystemId, 0);
        }

        private void ValidateParsedBeneficiary(Beneficiary parsedBeneficiary)
        {
            Assert.IsNotNullOrEmpty(parsedBeneficiary.CustomerBeneId);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.ExternalId);
            Assert.AreNotEqual(0, parsedBeneficiary.Version);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessContactRole);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessRegistrationCountry);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessRegistrationNumber);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessRegistrationStateProv);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.CellNumber);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.DateOfBirth);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.EmailAddress);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.EntityType);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.FirstName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.Gender);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.Industry);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.LastName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.MiddleName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.PhoneNumber);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.AddressLine1);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.AddressLine2);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.AddressLine3);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.City);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.CountryCode);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.StateOrProvince);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.ZipOrPostalCode);
        }

        private void ValidateParsedBankAccount(BankAccount bank)
        {
            Assert.IsNotNullOrEmpty(bank.BankName);
            Assert.IsNotNullOrEmpty(bank.AccountNumber);
            Assert.IsNotNullOrEmpty(bank.AccountPurpose);
            Assert.IsNotNullOrEmpty(bank.BankCode);
            Assert.IsNotNullOrEmpty(bank.BankName);
            Assert.IsNotNullOrEmpty(bank.BranchCode);
            Assert.IsNotNullOrEmpty(bank.BranchName);
            Assert.IsNotNullOrEmpty(bank.DisplayName);
            Assert.IsNotNullOrEmpty(bank.ExternalAccountType);
            Assert.IsNotNullOrEmpty(bank.ExternalId);
            Assert.AreNotEqual(0, bank.Version);
            Assert.IsNotNullOrEmpty(bank.BankAddress.AddressLine1);
            Assert.IsNotNullOrEmpty(bank.BankAddress.AddressLine2);
            Assert.IsNotNullOrEmpty(bank.BankAddress.AddressLine3);
            Assert.IsNotNullOrEmpty(bank.BankAddress.City);
            Assert.IsNotNullOrEmpty(bank.BankAddress.CountryCode);
            Assert.IsNotNullOrEmpty(bank.BankAddress.StateOrProvince);
            Assert.IsNotNullOrEmpty(bank.BankAddress.ZipOrPostalCode);
        }

        private const string SamplePaymentDetailString = @"{{
                                                'walletNumber': 'testWallNumberId',
                                                'paymentId': '{0}',   
                                                'clientCustomerId': '{1}',
                                                'clientReferenceNumber': 'someId',
                                                'programId': 'someId',
                                                'description': 'transferId',
                                                'transferId': 'testBatchId',
                                                'clientBankBatchId': 'testClientBatchId',
                                                'bankBatchId': 'testBankBatchId',
                                                'amount': '10.00',
                                                'currency': 'CAD',
                                                'profile': {{
                                                   'versionNumber': '1',
                                                    'identification': {{
                                                        'entityType': 'INDIVIDUAL',
                                                        'firstName': 'John',
                                                        'middleName': 'S',
                                                        'lastName': 'Doe',
                                                        'phoneNumber': '6048622810',
                                                        'mobileNumber': '6043698723',
                                                        'dateOfBirth': '1990-12-31',
                                                        'gender': 'MALE',
                                                        'businessName': 'A Name',
                                                        'businessRegistrationNumber': '12345',
                                                        'businessRegistrationCountry': '12345',
                                                        'businessRegistrationStateProv': 'BC',
                                                        'businessContactRole': 'asdf',
                                                        'industry': 'random',
                                                        'emailAddress': 'person@place.com'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }}
                                                }},
                                                'bankAccount': {{
                                                    'externalAccountId': 'testExternalAccountId',
                                                    'versionNumber': '2',
                                                    'externalAccountType': 'BANK_ACCOUNT_CANADA',
                                                    'accountPurpose': 'SAVINGS',
                                                    'currencyCode': 'USD',
                                                    'bankName': 'BMO',
                                                    'branchName': 'Metrotown Branch',
                                                    'bankAddress': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }},
                                                    'bankCode': '001',
                                                    'branchCode': '23456',
                                                    'accountNumber': '910002222',
                                                    'displayName': 'A Friendly Name',
                                                }},
                                                'dispensationType': 'US_BANK_IAT_USD',
                                                'valueDate' : '{2}'
                                            }}";
        private const string SamplePaymentDetailStringWithPaymentMethod = @"{{
                                                'clientCustomerId': '{1}',
                                                'walletNumber': 'testWallNumberId',
                                                'paymentId': '{0}',                                                                   
                                                'clientReferenceNumber': 'someId',
                                                'programId': 'someId',
                                                'description': 'transferId',
                                                'transferId': 'testBatchId',
                                                'clientBankBatchId': 'testClientBatchId',
                                                'bankBatchId': 'testBankBatchId',
                                                'amount': '10.00',
                                                'currency': 'CAD',
                                                'profile': {{
                                                   'versionNumber': '1',
                                                    'identification': {{
                                                        'entityType': 'INDIVIDUAL',
                                                        'firstName': 'John',
                                                        'middleName': 'S',
                                                        'lastName': 'Doe',
                                                        'phoneNumber': '6048622810',
                                                        'mobileNumber': '6043698723',
                                                        'dateOfBirth': '1990-12-31',
                                                        'gender': 'MALE',
                                                        'businessName': 'A Name',
                                                        'businessRegistrationNumber': '12345',
                                                        'businessRegistrationCountry': '12345',
                                                        'businessRegistrationStateProv': 'BC',
                                                        'businessContactRole': 'asdf',
                                                        'industry': 'random',
                                                        'emailAddress': 'person@place.com'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }}
                                                }},
                                                'bankAccount': {{
                                                    'externalAccountId': 'testExternalAccountId',
                                                    'versionNumber': '2',
                                                    'externalAccountType': 'BANK_ACCOUNT_CANADA',
                                                    'accountPurpose': 'SAVINGS',
                                                    'currencyCode': 'USD',
                                                    'bankName': 'BMO',
                                                    'branchName': 'Metrotown Branch',
                                                    'bankAddress': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }},
                                                    'bankCode': '001',
                                                    'branchCode': '23456',
                                                    'accountNumber': '910002222',
                                                    'displayName': 'A Friendly Name',
                                                }},
                                                'dispensationType': '{2}',
                                                'valueDate' : '{3}'
                                            }}";

        private const string SampleClientbatchString = @"{{
                                        'batchId': 'testBatchId',
                                        'clientBatchId' : 'testClientBatchId',
                                        'clientProgramId' : '{0}',
		                                'programId': 'testProgramId',
                                        'paymentDetails': [
                                            {1}
                                        ]
                                    }}";

        private const string SamplePaymentBatchString = @"
                              {{
                                'clientBatches': [
                                    {0}
                                ]
                            }}";
    }
}

       
