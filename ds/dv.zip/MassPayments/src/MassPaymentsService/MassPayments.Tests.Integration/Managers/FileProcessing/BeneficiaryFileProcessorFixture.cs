﻿using System;
using System.Text;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers.FileProcessing;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Providers.StorageProvider;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers.FileProcessing
{
    [TestFixture,Explicit]
    public class BeneficiaryFileProcessorFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            EventLogger.Instance = null;
            ServiceCallContextManager.Instance = null;
        }

        [Test, Explicit]
        public void BeneficiaryFileProcessor_Works()
        {
            var customer = new Customer
            {
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "3f3f3f",
                Name = "test",
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };

            var expectedBeneficiaryExternalId = "12345";
            var expectedBeneficiaryVersion = 123;
            var expectedBankId = "12345";
            var expectedBankVersion = 123456;

            var bankInfoString = string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                );

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedBeneficiaryExternalId,
                customer.PartnerAssignedCustomerId,
                expectedBeneficiaryVersion,
                bankInfoString
                );
            
            var file = new File
            {
                FileContent = beneficiaryString,
                FileNameWithExtension = "HPWL_Blah.test"
            };

            CustomerMapper.Instance.InsertCustomer(customer);

            var beneStorageProvider = StorageProviderFactory.GetBeneficiaryStorageProvider();
            StorageEventPublisher.Instance.BeneficiariesParsed += beneStorageProvider.HandleBeneficiariesInsertOrUpdate;

            Assert.DoesNotThrow(() => new BeneficiaryFileProcessor(file).Process());

            var bene = BeneHelper.GetBeneficiary(expectedBeneficiaryExternalId);
            var bank = BankAccountHelper.GetBankAccount(expectedBankId);

            ValidateParsedBeneficiary(bene);
            ValidateParsedBankAccount(bank);

            StorageEventPublisher.Instance.BeneficiariesParsed -= beneStorageProvider.HandleBeneficiariesInsertOrUpdate;
        }

        [Test, Explicit]
        public void BeneficiaryFileProcessor_DoesNotThrowIfBankAccountIsNullObject()
        {
            var customer = new Customer
            {
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "3f3f3f",
                Name = "test",
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };

            var expectedBeneficiaryExternalId = "12345";
            var expectedBeneficiaryVersion = 123;
            var expectedBankId = "12345";
            var expectedBankVersion = 123456;

            var bankInfoString = string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                );

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedBeneficiaryExternalId,
                customer.PartnerAssignedCustomerId,
                expectedBeneficiaryVersion,
                ""
                );

            var file = new File
            {
                FileContent = beneficiaryString,
                FileNameWithExtension = "HPWL_Blah.test"
            };

            CustomerMapper.Instance.InsertCustomer(customer);

            var beneStorageProvider = MockRepository.GeneratePartialMock<BeneficiaryBIStorageProvider>();
            StorageEventPublisher.Instance.BeneficiariesParsed += beneStorageProvider.HandleBeneficiariesInsertOrUpdate;

            EventLogger.Instance.AssertWasNotCalled(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));

            Assert.DoesNotThrow(() => new BeneficiaryFileProcessor(file).Process());

            beneStorageProvider.VerifyAllExpectations();
            var bene = BeneHelper.GetBeneficiary(expectedBeneficiaryExternalId);

            ValidateParsedBeneficiary(bene);

            StorageEventPublisher.Instance.BeneficiariesParsed -= beneStorageProvider.HandleBeneficiariesInsertOrUpdate;
        }

        [Test]
        public void BeneficiaryFileProcessor_Works_WithMock()
        {
            var customer = new Customer
            {
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "3f3f3f",
                Name = "test",
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };

            var expectedBeneficiaryExternalId = "12345";
            var expectedBeneficiaryVersion = 123;
            var expectedBankId = "12345";
            var expectedBankVersion = 123456;

            var bankInfoString = string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                );

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedBeneficiaryExternalId,
                customer.PartnerAssignedCustomerId,
                expectedBeneficiaryVersion,
                bankInfoString
                );

            var file = new File
            {
                FileContent = beneficiaryString,
                FileNameWithExtension = "HPWL_Blah.test"
            };
            BIMapper.Instance = MockRepository.GenerateMock<IBIMapper>();

            BIMapper.Instance.Expect(m => m.InsertBankAccount(Arg<BankAccount>.Is.Anything, Arg<string>.Is.Anything, Arg<DateTime>.Is.Anything, Arg<int>.Is.Anything, Arg<int>.Is.Anything));
            BIMapper.Instance.Expect(m => m.InsertBeneficiary(Arg<Beneficiary>.Is.Anything, Arg<string>.Is.Anything, Arg<int>.Is.Anything, Arg<int>.Is.Anything, Arg<DateTime>.Is.Anything));

            CustomerMapper.Instance.InsertCustomer(customer);

            var beneStorageProvider = StorageProviderFactory.GetBeneficiaryStorageProvider();
            StorageEventPublisher.Instance.BeneficiariesParsed += beneStorageProvider.HandleBeneficiariesInsertOrUpdate;

            Assert.DoesNotThrow(() => new BeneficiaryFileProcessor(file).Process());

            BIMapper.Instance.VerifyAllExpectations();

            StorageEventPublisher.Instance.BeneficiariesParsed -= beneStorageProvider.HandleBeneficiariesInsertOrUpdate;
            BIMapper.Instance = null;

        }

        [Test]
        public void BeneficiaryFileProcessor_DoesNotThrowIfBankAccountIsNullObject_WithMock()
        {
            var customer = new Customer
            {
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = "3f3f3f",
                Name = "test",
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };

            var expectedBeneficiaryExternalId = "12345";
            var expectedBeneficiaryVersion = 123;
            var expectedBankId = "12345";
            var expectedBankVersion = 123456;

            var bankInfoString = string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                );

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedBeneficiaryExternalId,
                customer.PartnerAssignedCustomerId,
                expectedBeneficiaryVersion,
                ""
                );

            var file = new File
            {
                FileContent = beneficiaryString,
                FileNameWithExtension = "HPWL_Blah.test"
            };

            CustomerMapper.Instance.InsertCustomer(customer);

            BIMapper.Instance = MockRepository.GenerateMock<IBIMapper>();
            BIMapper.Instance.Expect(m => m.InsertBeneficiary(Arg<Beneficiary>.Is.Anything, Arg<string>.Is.Anything, Arg<int>.Is.Anything, Arg<int>.Is.Anything, Arg<DateTime>.Is.Anything));

            var beneStorageProvider = MockRepository.GeneratePartialMock<BeneficiaryBIStorageProvider>();
            StorageEventPublisher.Instance.BeneficiariesParsed += beneStorageProvider.HandleBeneficiariesInsertOrUpdate;

            EventLogger.Instance.AssertWasNotCalled(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));

            Assert.DoesNotThrow(() => new BeneficiaryFileProcessor(file).Process());

            beneStorageProvider.VerifyAllExpectations();
            BIMapper.Instance.VerifyAllExpectations();

            StorageEventPublisher.Instance.BeneficiariesParsed -= beneStorageProvider.HandleBeneficiariesInsertOrUpdate;
            BIMapper.Instance = null;
        }
        private void ValidateParsedBeneficiary(Beneficiary parsedBeneficiary)
        {
            Assert.IsNotNullOrEmpty(parsedBeneficiary.ExternalId);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.WUBSExternalCustomerId);
            Assert.AreNotEqual(0, parsedBeneficiary.Version);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessContactRole);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessRegistrationCountry);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessRegistrationNumber);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.BusinessRegistrationStateProv);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.CellNumber);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.DateOfBirth);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.EmailAddress);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.EntityType);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.FirstName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.Industry);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.LastName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.MiddleName);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Identification.PhoneNumber);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.AddressLine1);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.AddressLine2);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.AddressLine3);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.City);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.CountryCode);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.StateOrProvince);
            Assert.IsNotNullOrEmpty(parsedBeneficiary.Address.ZipOrPostalCode);
        }

        private void ValidateParsedBankAccount(BankAccount bank)
        {
            Assert.IsNotNullOrEmpty(bank.BankName);
            Assert.IsNotNullOrEmpty(bank.AccountNumber);
            Assert.IsNotNullOrEmpty(bank.AccountPurpose);
            Assert.IsNotNullOrEmpty(bank.BankCode);
            Assert.IsNotNullOrEmpty(bank.BankName);
            Assert.IsNotNullOrEmpty(bank.BranchCode);
            Assert.IsNotNullOrEmpty(bank.BranchName);
            Assert.IsNotNullOrEmpty(bank.ExternalAccountType);
            Assert.IsNotNullOrEmpty(bank.ExternalId);
            Assert.AreNotEqual(0, bank.Version);
            Assert.IsNotNullOrEmpty(bank.BankAddress.AddressLine1);
            Assert.IsNotNullOrEmpty(bank.BankAddress.AddressLine2);
            Assert.IsNotNullOrEmpty(bank.BankAddress.AddressLine3);
            Assert.IsNotNullOrEmpty(bank.BankAddress.City);
            Assert.IsNotNullOrEmpty(bank.BankAddress.CountryCode);
            Assert.IsNotNullOrEmpty(bank.BankAddress.StateOrProvince);
            Assert.IsNotNullOrEmpty(bank.BankAddress.ZipOrPostalCode);
        }

        private const string SampleBankAccountString = @"
                                            {{
                                                'externalAccountId': '{0}',
                                                'versionNumber': '{1}',
                                                'externalAccountType': 'BANK_ACCOUNT_CANADA',
                                                'accountPurpose': 'SAVINGS',
                                                'currencyCode': 'USD',
                                                'bankName': 'BMO',
                                                'branchName': 'Metrotown Branch',
                                                'bankAddress': {{
                                                    'addressLine1': '736 Granville Street',
                                                    'addressLine2': 'test',
                                                    'addressLine3': 'test',
                                                    'city': 'Vancouver',
                                                    'stateProv': 'BC',
                                                    'postCode': 'V6Z1G3',
                                                    'countryCode': 'CA'
                                                }},
                                                'bankCode': '001',
                                                'branchCode': '23456',
                                                'accountNumber': '910002222',
                                                'displayName': 'A Friendly Name',
                                                
                                            }}";

        private const string SampleBeneficiaryString = @"
                                    {{
                                        'wallets': [
                                            {{
                                                'clientCustomerId': 'someId',
                                                'walletNumber': '{0}',
                                                'clientProgramId': '{1}',
                                                'programId': 'someId',
                                                'profile': {{
                                                    'versionNumber': '{2}',
                                                    'identification': {{
                                                        'entityType': 'INDIVIDIAL',
                                                        'firstName': 'John',
                                                        'middleName': 'S',
                                                        'lastName': 'Doe',
                                                        'phoneNumber': '6048622810',
                                                        'mobileNumber': '6043698723',
                                                        'dateOfBirth': '1990-12-31',
                                                        'gender': 'MALE',
                                                        'businessName': 'A Name',
                                                        'businessRegistrationNumber': '12345',
                                                        'businessRegistrationCountry': '12345',
                                                        'businessRegistrationStateProv': 'BC',
                                                        'businessContactRole': 'asdf',
                                                        'industry': 'random',
                                                        'emailAddress': 'person@place.com'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }}
                                                }},
                                                'bankAccounts': [
                                                    {3}
                                                ]
                                            }}
                                        ]
                                    }}
                                    ";
    }
}



