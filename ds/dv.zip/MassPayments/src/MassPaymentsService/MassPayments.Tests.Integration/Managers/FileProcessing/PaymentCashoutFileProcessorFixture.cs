﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers.FileProcessing;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers.FileProcessing
{
    [TestFixture]
    public class PaymentCashoutFileProcessorFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
        }

        [TearDown]
        public void TearDown()
        {
            QuoteMapper.Instance = null;
            if (transactionScope != null)
                transactionScope.Dispose();
            ServiceCallContextManager.Instance = null;
        }

        [Test, Explicit]
        public void CashoutFileProcessor_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailString,
                paymentExternalId,
                DateTime.Now.ToString("yyyy-MM-dd")
            );
            var originatingBatchString = string.Format(SamplePaymentOriginatingBatch, customer.PartnerAssignedCustomerId);
            var paymentCashoutString = string.Format(SamplePaymentCashoutString,originatingBatchString, paymentDetailString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentCashoutString),
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_testFileName"
            };
            FileMapper.Instance.InsertFile(file);
            QuoteMapper.Instance.Expect(qm =>qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order{ConfirmationNumber = "123",OrderId = 123});
            Assert.DoesNotThrow(() => new PaymentCashoutFileProcessor(file).Process());

            var payments = PaymentMapper.Instance.GetPayments(paymentExternalId, 1);
            Assert.AreNotEqual(0, payments.Count);
        }

        [Test, Explicit]
        public void CashoutFileProcessor_UpdatesPaymentReferenceCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailString,
                paymentExternalId,
               DateTime.Now.ToString("yyyy-MM-dd")
            );
            var originatingBatchString = string.Format(SamplePaymentOriginatingBatch, customer.PartnerAssignedCustomerId);
            var paymentCashoutString = string.Format(SamplePaymentCashoutString, originatingBatchString, paymentDetailString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentCashoutString),
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_PendingTransfers_2015-05-20.json"
            };
            FileMapper.Instance.InsertFile(file);
            QuoteMapper.Instance.Expect(qm => qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order { ConfirmationNumber = "123", OrderId = 123 });
            Assert.DoesNotThrow(() => new PaymentCashoutFileProcessor(file).Process());

            var payments = PaymentMapper.Instance.GetPayments(paymentExternalId, 1);
            Assert.AreNotEqual(0, payments.Count);
            Assert.AreEqual("MPHW_123", payments[0].PaymentReference);
        }

        [Test, Explicit]
        public void CashoutFileProcessor_UpdatesIncomingOrderIdCorrectly()
        {
            QuoteMapper.Instance = null;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
        
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = new CustomerBatch
            {
                CustomerId = customer.Id,
                BatchReference = "HPWL_pending_1_2015-01-22.json",
                ExternalCustomerId = "testHwAssignedCustomerId",
                ExternalId = "testBatchId"
            };

            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            customerBatch = CustomerBatchMapper.Instance.GetCustomerBatchByExternalId(customerBatch.ExternalId, customer.PartnerId);
            const int transactionSystemQuoteId = 123;
            const string settlementCurrencyCode = "USD";
            const string tradeCurrencyCode = "CAD";
            const int transactionSystemOrderId = 1234566;
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(new Currency(settlementCurrencyCode), 0),
                    TradeMoney = new Money(new Currency(tradeCurrencyCode), 0),
                    TransactionSystemQuoteId = transactionSystemQuoteId,
                    OrderId = transactionSystemOrderId
                }
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customerBatch.ExternalId, customer.Id, "testPartnerReference", true, string.Empty, 120, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);

            CustomerBatchMapper.Instance.UpdateCustomerBatch(customerBatch);

            var mockedOrders = new List<Order>
            {
                new Order
                {
                    ConfirmationNumber = "test1233",
                    OrderId = transactionSystemOrderId,
                    TransactionSystemQuoteId = transactionSystemQuoteId
                }
            };

            QuoteMapper.Instance.UpdateQuoteToOrderRelationship(quoteRequestId, mockedOrders);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);

            string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailString,
                paymentExternalId,
               DateTime.Now.ToString("yyyy-MM-dd")
            );
            var originatingBatchString = string.Format(SamplePaymentOriginatingBatch, customer.PartnerAssignedCustomerId);
            var paymentCashoutString = string.Format(SamplePaymentCashoutString, originatingBatchString, paymentDetailString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentCashoutString),
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_PendingTransfers_2015-05-20.json"
            };
            FileMapper.Instance.InsertFile(file);
            Assert.DoesNotThrow(() => new PaymentCashoutFileProcessor(file).Process());

            var payments = PaymentMapper.Instance.GetPayments(paymentExternalId, 1);
            Assert.AreNotEqual(0, payments.Count);

            ServiceCallContextManager.Instance = null;
        }

        [Test, Explicit]
        public void CashoutFileProcessor_Works_WIthEmptyValueDate()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            string paymentExternalId = "testPaymentId";
            var paymentDetailString = string.Format(SamplePaymentDetailString,
                paymentExternalId,
               ""
            );
            var originatingBatchString = string.Format(SamplePaymentOriginatingBatch, customer.PartnerAssignedCustomerId);
            var paymentCashoutString = string.Format(SamplePaymentCashoutString, originatingBatchString, paymentDetailString);
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentCashoutString),
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_testFileName"
            };
            FileMapper.Instance.InsertFile(file);
            QuoteMapper.Instance.Expect(qm => qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order { ConfirmationNumber = "123", OrderId = 123 });
            Assert.DoesNotThrow(() => new PaymentCashoutFileProcessor(file).Process());

            var payments = PaymentMapper.Instance.GetPayments(paymentExternalId, 1);
            Assert.AreNotEqual(0, payments.Count);
        }

        [Test,Explicit]
        public void CashoutFileProcessor_Works_WithLargeAmountOfEntry()
        {
            //var customer = CustomerHelper.Instance.CreateCustomer();
            //customer.ExternalId = "VAN-KO1224";
            //customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var paymentCashoutString = System.IO.File.ReadAllText(@"C:\Users\hem\Desktop\MassPaymentsDataGenerator5\PendingTransfers.json");
            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(paymentCashoutString),
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "testFileName"
            };
            FileMapper.Instance.InsertFile(file);

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Assert.DoesNotThrow(() => new PaymentCashoutFileProcessor(file).Process());
            stopwatch.Stop();
            Console.WriteLine("Time elapsed: {0}",stopwatch.Elapsed);
        }

        private const string SamplePaymentDetailString = @"{{
                                                'paymentId': '{0}',
                                                'clientCustomerId': 'asdfasdf',
                                                'walletNumber': '1234',
			                                    'clientReferenceNumber': '1234',
			                                    'description': '123',
			                                    'memo': '123',
			                                    'transferId': '123',
			                                    'bankBatchId': '123',
			                                    'clientBankBatchId': '123',
			                                    'amount': '10.00',
			                                    'currency': 'CAD',
                                                'profile': {{
                                                    'versionNumber': '1',
                                                    'identification': {{
                                                        'entityType': 'INDIVIDUAL',
                                                        'firstName': 'John',
                                                        'middleName': 'S',
                                                        'lastName': 'Doe',
                                                        'phoneNumber': '6048622810',
                                                        'mobileNumber': '6043698723',
                                                        'dateOfBirth': '1990-12-31',
                                                        'gender': 'MALE',
                                                        'businessName': 'A Name',
                                                        'businessRegistrationNumber': '12345',
                                                        'businessRegistrationCountry': '12345',
                                                        'businessRegistrationStateProv': 'BC',
                                                        'businessContactRole': 'asdf',
                                                        'industry': 'random',
                                                        'emailAddress': 'person@place.com'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }}
                                                }},
                                                'bankAccount': {{
                                                    'externalAccountId': 'testExternalAccountId',
                                                    'versionNumber': '2',
                                                    'externalAccountType': 'BANK_ACCOUNT_CANADA',
                                                    'accountPurpose': 'SAVINGS',
                                                    'currencyCode': 'USD',
                                                    'bankName': 'BMO',
                                                    'branchName': 'Metrotown Branch',
                                                    'bankAddress': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }},
                                                    'bankCode': '001',
                                                    'branchCode': '23456',
                                                    'accountNumber': '910002222',
                                                    'displayName': 'A Friendly Name',
                                                }},
                                                'dispensationType': 'US_BANK_IAT_USD',
                                                'valueDate' : '{1}',
                                                'settlementCurrencyCode' : 'USD'
                                            }}";

        private const string SamplePaymentCashoutString = @"{{
                                'pendingBankTransfers' : [{{
                                   {0},
                                   paymentDetail : {1} 
                                }}]
                            }}";
        private const string SamplePaymentOriginatingBatch = @"
                                    'originatingBatch' : {{
                                    'batchId' : 'testBatchId',
                                    'clientBatchId' : 'test_HPWL_pending_1_2015-01-22.json',
                                    'clientProgramId' : '{0}',
                                    'programId' : 'testHwAssignedCustomerId'
                                }} ";

        private const string SampleMultiplePaymentCashoutString =  @"{{
                                'pendingBankTransfers' : [{0}]
                            }}";
        private const string SampleMultiplePaymentCashoutDetail = @"{{
                                   {0},
                                   paymentDetail : {1} 
                                }}";

    }
}
