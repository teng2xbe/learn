﻿using System.Text;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Managers.FileProcessing;
using Newtonsoft.Json;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Managers.FileProcessing
{
    [TestFixture]
    public class FileTypeInspectorFixture
    {
        private TransactionScope transactionScope;
       
        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void FileTypeInspector_ReturnsCorrectFileType()
        {
            var beneFile = new File
            {
                Id = 1,
                FileContent = SampleBeneficiaryString
            };

            var paymentBatchesFile = new File
            {
                Id = 1,
                FileContent = SamplePaymentBatchesString
            };

            var paymentCashoutFile = new File
            {
                Id = 1,
                FileContent = SamplePaymentCashoutString
            };

            var returnedPaymentFile = new File
            {
                Id = 1,
                FileContent = SampleUndefinedString
            };

            var undefinedFile1 = new File()
            {
                Id = 1,
                FileContent = undefinedString1
            };

            var undefinedFile2 = new File()
            {
                Id = 1,
                FileContent = undefinedString2
            };

            var undefinedFile3 = new File()
            {
                Id = 1,
                FileContent = undefinedString3
            };

            Assert.AreEqual(FileType.Beneficiary, FileTypeInspector.DeriveFileType(beneFile));
            Assert.AreEqual(FileType.PaymentBatches, FileTypeInspector.DeriveFileType(paymentBatchesFile));
            Assert.AreEqual(FileType.PaymentCashout, FileTypeInspector.DeriveFileType(paymentCashoutFile));
            Assert.AreEqual(FileType.ReturnedPayment, FileTypeInspector.DeriveFileType(returnedPaymentFile));
            Assert.Throws(typeof(JsonReaderException), () => FileTypeInspector.DeriveFileType(undefinedFile1));
            Assert.Throws(typeof(JsonReaderException), () => FileTypeInspector.DeriveFileType(undefinedFile2));
            Assert.Throws(typeof(InvalidCacheItemException), () => FileTypeInspector.DeriveFileType(undefinedFile3));
        }

        private const string SampleBeneficiaryString = @"{wallets : []}";
        private const string SamplePaymentBatchesString = @"{clientBatches : {} }";
        private const string SamplePaymentCashoutString = @"{pendingBankTransfers: [] }";
        private const string SampleUndefinedString = @"{returnedPaymentDetails: [] }";
        private const string undefinedString1 = @"{}";
        private const string undefinedString2 = @"asdfasdf";
        private const string undefinedString3 = @"{adsf : {}}";

    }
}
