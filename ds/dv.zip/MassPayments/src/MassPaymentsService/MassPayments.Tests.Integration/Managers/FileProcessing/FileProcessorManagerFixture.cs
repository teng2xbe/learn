﻿using System;
using System.Text;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers.FileProcessing;
using MassPayments.Mappers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers.FileProcessing
{
    [TestFixture,Explicit]
    public class FileProcessorManagerFixture
    {
        private TransactionScope transactionScope;
       
        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            FileTypePropertyCache.Instance.Initialize();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            ServiceCallContextManager.Instance = null;
        }

        [Test]
        public void ProcessFile_ParseBeneficiary_FileStatusChangesToProcessed()
        {
            const string expectedCustomerExternalId = "someId";
            const string expectedBeneficiaryId = "12345";
            const string expectedBeneficiaryVersion = "1";
            const string expectedBankId = "12345";
            const string expectedBankVersion = "123";

            var bankInfoString = string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                );

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedCustomerExternalId,
                expectedBeneficiaryId,
                expectedBeneficiaryVersion,
                bankInfoString
                );

            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(beneficiaryString),
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.test"
            };
            FileMapper.Instance.InsertFile(file);

            var customer = new Customer
            {
                TransactionSystemCustomerId = 1,
                PartnerAssignedCustomerId = expectedCustomerExternalId,
                Name = "test",
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var fileProcessorManager = new FileProcessorManager();
            fileProcessorManager.ProcessFile(file);

            Assert.AreEqual(FileStatus.Processed, file.Status);
        }

        [Test]
        public void ProcessFile_ParseBeneficiary_StatusChangeToProcessWithError()
        {
            const string expectedCustomerExternalId = "someId";
            const string expectedBeneficiaryId = "12345";
            const string expectedBeneficiaryVersion = "1";
            const string expectedBankId = "12345";
            const string expectedBankVersion = "123";

            var bankInfoString = string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                );

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedCustomerExternalId,
                expectedBeneficiaryId,
                expectedBeneficiaryVersion,
                bankInfoString
                );

            var file = new File
            {
                Data = Encoding.UTF8.GetBytes(beneficiaryString),
                Status = FileStatus.Pending,
                FileNameWithExtension = "test.json"
            };
            FileMapper.Instance.InsertFile(file);

            var customer = new Customer
            {
                TransactionSystemCustomerId = 1,
                Name = "test",
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = DateTime.Now.AddHours(1)
            };
            CustomerMapper.Instance.InsertCustomer(customer);

            var fileProcessorManager = MockRepository.GeneratePartialMock<FileProcessorManager>();
            fileProcessorManager.Expect(fpm => fpm.Process(Arg<FileType>.Is.Anything, Arg<File>.Is.Anything)).Return(false);
            fileProcessorManager.ProcessFile(file);

            Assert.AreEqual(FileStatus.ProcessedWithError, file.Status);
        }
        private const string SampleBankAccountString = @"
                                            {{
                                                'externalAccountId': '{0}',
                                                'versionNumber': '{1}',
                                                'externalAccountType': 'BANK_ACCOUNT_CANADA',
                                                'accountPurpose': 'SAVINGS',
                                                'currencyCode': 'USD',
                                                'bankName': 'BMO',
                                                'branchName': 'Metrotown Branch',
                                                'bankAddress': {{
                                                    'addressLine1': '736 Granville Street',
                                                    'addressLine2': 'test',
                                                    'addressLine3': 'test',
                                                    'city': 'Vancouver',
                                                    'stateProv': 'BC',
                                                    'postCode': 'V6Z1G3',
                                                    'countryCode': 'CA'
                                                }},
                                                'bankCode': '001',
                                                'branchCode': '23456',
                                                'accountNumber': '910002222',
                                                'displayName': 'A Friendly Name',
                                                
                                            }}";

        private const string SampleBeneficiaryString = @"
                                    {{
                                        'wallets': [
                                            {{
                                                'clientCustomerId': '{0}',
                                                'walletNumber': '{1}',
                                                'programId': 'someId',
                                                'clientProgramId': 'someId',
                                                'profile': {{
                                                    'versionNumber': '{2}',
                                                    'identification': {{
                                                        'entityType': 'INDIVIDIAL',
                                                        'firstName': 'John',
                                                        'middleName': 'S',
                                                        'lastName': 'Doe',
                                                        'phoneNumber': '6048622810',
                                                        'mobileNumber': '6043698723',
                                                        'dateOfBirth': '1990-12-31',
                                                        'gender': 'MALE',
                                                        'businessName': 'A Name',
                                                        'businessRegistrationNumber': '12345',
                                                        'businessRegistrationCountry': '12345',
                                                        'businessRegistrationStateProv': 'BC',
                                                        'businessContactRole': 'asdf',
                                                        'industry': 'random',
                                                        'emailAddress': 'person@place.com'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }}
                                                }},
                                                'bankAccounts': [
                                                    {3}
                                                ]
                                            }}
                                        ]
                                    }}
                                    ";

    }
}
