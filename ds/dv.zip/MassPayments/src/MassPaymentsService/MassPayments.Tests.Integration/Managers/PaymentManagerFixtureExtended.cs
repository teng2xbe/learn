﻿using System;
using System.Collections.Generic;
using System.Linq;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Gateways.Iris;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Managers
{
    public partial class PaymentManagerFixture
    {
        [Test]
        public void IrisProcessing_UpdatePaymentStatus_AndInsertToStatusHistory()
        {
            var paymentManager = new PaymentManager();

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(existingPayment1);

            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(existingPayment2);

            var payment1StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment1.Id);
            Assert.AreEqual(0, payment1StatusHistories.Count);
            
            var payment2StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment2.Id);
            Assert.AreEqual(0, payment2StatusHistories.Count);

            var irisPaymentId1 = $"MP{customer.PartnerAssignedCustomerId}-{existingPayment1.Id}";
            var irisPaymentId2 = $"MP{customer.PartnerAssignedCustomerId}-{existingPayment2.Id}";

            var irisResult = new List<PaymentBlockMessage>
            {
                new PaymentBlockMessage {Id = irisPaymentId1, Status = IrisPaymentStatus.Unblock},
                new PaymentBlockMessage {Id = irisPaymentId2, Status = IrisPaymentStatus.PermanentBlock}
            };

            paymentManager.UpdatePaymentBlockStatuses(irisResult);

            payment1StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment1.Id);
            Assert.AreEqual(1, payment1StatusHistories.Count);
            Assert.AreEqual(PaymentStatus.SanctionCleared, payment1StatusHistories[0].PaymentStatus);

            payment2StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment2.Id);
            Assert.AreEqual(1, payment2StatusHistories.Count);
            Assert.AreEqual(PaymentStatus.SanctionBlocked, payment2StatusHistories[0].PaymentStatus);
        }

        [Test]
        public void PainProcesing_UpdatePaymentStatus_AndInsertToStatusHistory()
        {
            var paymentManager = new PaymentManager();

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(existingPayment1);

            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(existingPayment2);

            var payment1StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment1.Id);
            Assert.AreEqual(0, payment1StatusHistories.Count);

            var payment2StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment2.Id);
            Assert.AreEqual(0, payment2StatusHistories.Count);

            existingPayment1.PaymentStatus = PaymentStatus.Released;
            existingPayment1.GPGProcessedUTC = DateTime.UtcNow;
            existingPayment2.PaymentStatus = PaymentStatus.Rejected;
            existingPayment2.GPGProcessedUTC = DateTime.UtcNow;

            paymentManager.UpdatePaymentStatusBasedOnGPGAcceptance(new List<Payment> {existingPayment1, existingPayment2});

            payment1StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment1.Id);
            Assert.AreEqual(1, payment1StatusHistories.Count);
            Assert.AreEqual(PaymentStatus.Released, payment1StatusHistories[0].PaymentStatus);

            payment2StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(existingPayment2.Id);
            Assert.AreEqual(1, payment2StatusHistories.Count);
            Assert.AreEqual(PaymentStatus.Rejected, payment2StatusHistories[0].PaymentStatus);

        }

        [Test]
        public void CommittingPayment_UpdatePaymentStatus_AndInsertToStatusHistory()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var pr1 = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1, customer);
            pr1.PaymentsToProcess[0].PaymentId = "123";
            pr1.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            PaymentRequestMapper.Instance.InsertPaymentRequest(pr1);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var pr2 = PaymentRequestHelper.Instance.CreatePaymentRequestToProcess(1, customer);
            pr2.BatchId = customerBatch.Id;
            pr2.PaymentsToProcess[0].PaymentId = "456";
            pr2.PaymentsToProcess[0].PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            pr2.PaymentsToProcess[0].ExternalBatchId = customerBatch.ExternalId;
            pr2.PaymentsToProcess[0].SettlementCurrencyCode = "USD";
            PaymentRequestMapper.Instance.InsertPaymentRequest(pr2);

            pr1.Process();
            pr2.Process();

            var payment1 = PaymentMapper.Instance.GetPayment(1, pr1.PaymentsToProcess[0].PaymentId);
            var payment2 = PaymentMapper.Instance.GetPayment(1, pr2.PaymentsToProcess[0].PaymentId);


            var payment1StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment1.Id);
            Assert.AreEqual(1, payment1StatusHistories.Count);
            Assert.AreEqual(PaymentStatus.Committed, payment1StatusHistories[0].PaymentStatus);

            var payment2StatusHistories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment2.Id);
            Assert.AreEqual(1, payment2StatusHistories.Count);
            Assert.AreEqual(PaymentStatus.Created, payment2StatusHistories[0].PaymentStatus);

        }

        [Test]
        public void CancellingPayment_UpdatePaymentStatus_AndInsertToStatusHistory()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            payment1.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            payment1.PaymentStatus = PaymentStatus.Committed;
            PaymentMapper.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);
            payment2.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            payment2.PaymentStatus = PaymentStatus.Created;
            PaymentMapper.Instance.InsertPayment(payment2);

            var loadedPayment1 =
                PaymentMapper.Instance.GetPayment(payment1.ExternalId,
                    payment1.PaymentSourceId, PaymentStatus.Committed);

            var loadedPayment2 =
                PaymentMapper.Instance.GetPayment(payment2.ExternalId,
                    payment2.PaymentSourceId, PaymentStatus.Created);

            var loadedPayment1Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(loadedPayment1.Id);
            Assert.AreEqual(0, loadedPayment1Histories.Count);

            var loadedPayment2Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(loadedPayment2.Id);
            Assert.AreEqual(0, loadedPayment2Histories.Count);

            var result1 = paymentManager.CancelPayment(customer.PartnerId, loadedPayment1.ExternalId);
            Assert.AreEqual(PaymentStatus.Cancelled, result1.PaymentStatus);
            
            var result2 = paymentManager.CancelPayment(customer.PartnerId, loadedPayment2.ExternalId);
            Assert.AreEqual(PaymentStatus.Cancelled, result2.PaymentStatus);

            loadedPayment1Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(loadedPayment1.Id);
            Assert.AreEqual(1, loadedPayment1Histories.Count);
            Assert.AreEqual(PaymentStatus.Cancelled, loadedPayment1Histories[0].PaymentStatus);

            loadedPayment2Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(loadedPayment2.Id);
            Assert.AreEqual(1, loadedPayment2Histories.Count);
            Assert.AreEqual(PaymentStatus.Cancelled, loadedPayment2Histories[0].PaymentStatus);


        }
        [Test]
        public void PainGeneration_UpdatePaymentStatus_AndInsertToStatusHistory()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };
            payment1.PaymentStatus = PaymentStatus.Rejected;
            PaymentMapper.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "ref1a" };
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapper.Instance.InsertPayment(payment2);

            var payments = new List<Payment> { payment1, payment2 };
            var paymentManager = new PaymentManager();

            var loadedPayment1Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment1.Id);
            Assert.AreEqual(0, loadedPayment1Histories.Count);

            var loadedPayment2Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment2.Id);
            Assert.AreEqual(0, loadedPayment2Histories.Count);

            paymentManager.UpdatePaymentStatusesBasedOnPainGeneration(payments, PaymentStatus.Sent);
            var reloadedPayments = PaymentMapper.Instance.GetPayments(payments.Select(p => p.Id).ToList());

            Assert.AreEqual(PaymentStatus.Rejected, reloadedPayments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Sent, reloadedPayments[1].PaymentStatus);

            loadedPayment1Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment1.Id);
            Assert.AreEqual(0, loadedPayment1Histories.Count);

            loadedPayment2Histories = PaymentMapper.Instance.GetPaymentStatusHistoryById(payment2.Id);
            Assert.AreEqual(1, loadedPayment2Histories.Count);
            Assert.AreEqual(PaymentStatus.Sent, loadedPayment2Histories[0].PaymentStatus);

        }
    }
}
