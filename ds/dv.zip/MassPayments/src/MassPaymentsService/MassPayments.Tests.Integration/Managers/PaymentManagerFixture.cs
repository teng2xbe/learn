﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions.Resource.Payment;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Encryption.Managers;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.Query.Mappers;
using MassPayments.Query.ValueObjects;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPayments.Tests.Integration.Mappers.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Transactions;
using SharedUtilities;

namespace MassPayments.Tests.Integration.Managers
{
    [TestFixture]
    public partial class PaymentManagerFixture
    {
        private TransactionScope transactionScope;
        private Partner partner;

        private IPublisher<Payment, CustomerBatch, Customer> paymentStatusUpdatedpublisher;
        private IPublisher<List<PaymentRequest>> paymentNotAcceptedPublisher;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            PaymentBatchMapper.Instance = MockRepository.GenerateMock<IPaymentBatchMapper>();
            partner = CreatePartner(1);
            CurrencyCache.Instance.Reinitialize();
            paymentStatusUpdatedpublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentStatusUpdatedPublisher), paymentStatusUpdatedpublisher);
            paymentNotAcceptedPublisher = MockRepository.GenerateMock<IPublisher<List<PaymentRequest>>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentNotAcceptedPublisher), paymentNotAcceptedPublisher);

            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetCctServiceSecurityToken()).Return("token");
            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            var batchPath = Settings.GetStringValue("BankBatchPath");

            if (Directory.Exists(batchPath))
                Directory.Delete(batchPath, true);

            PaymentBatchMapper.Instance = null;
            CCTTServiceFactory.InjectedServiceInterface = null;

            PublisherFactory.CleanAllInjectedPublishers();
            paymentStatusUpdatedpublisher = null;
            paymentNotAcceptedPublisher = null;

            ServiceSettings.Instance = null;
            ValidationRules.Instance = null;
        }

        [Test]
        public void BatchPaymentsGetsSavedToFile()
        {
            var paymentList = new List<Payment>
            {
                new Payment("111", null) {AmountMoney = new Money(Currency.CAD, 0), PaymentMethod = PaymentMethod.ACH,PaymentReference = "BLAH1", PaymentSourceId = 1},
                new Payment("222", null) {AmountMoney = new Money(Currency.CAD, 0), PaymentMethod = PaymentMethod.ACH,PaymentReference = "BLAH2", PaymentSourceId = 1},
            };

            const int batchId = 5;
            PaymentBatchMapper.Instance.Expect(pbm => pbm.InsertPaymentBatch(null)).IgnoreArguments().Return(batchId);

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            var paymentManager = new PaymentManager(encryptionManager, null);
            Assert.DoesNotThrow(() => paymentManager.SavePaymentBatchFile(paymentList, 0));

            var fileName = $"bankBatches_{batchId}_{DateTime.Now.ToString("yyyy-MM-dd")}.json";
            var path = Settings.GetStringValue("BankBatchPath");

            using (var batchFile = System.IO.File.OpenText(Path.Combine(path, fileName)))
            {
                Assert.NotNull(batchFile);
                string fileContent = batchFile.ReadToEnd();
                Assert.IsTrue(encryptionManager.DoesContentLookEncrypted(fileContent));
                string unencryptedContent = encryptionManager.DecryptString(fileContent, partner);
                Assert.AreEqual(unencryptedContent, @"{""bankBatches"":[{""transfers"":[{""clientTransferId"":""BLAH1"",""transferId"":null},{""clientTransferId"":""BLAH2"",""transferId"":null}]}]}");
            }
        }

        [Test]
        public void NoFileIsSavedWhenThereAreNoPayments()
        {
            var paymentList = new List<Payment>();
            var paymentManager = new PaymentManager();

            const int batchId = 5;
            PaymentBatchMapper.Instance.Expect(pbm => pbm.InsertPaymentBatch(null)).IgnoreArguments().Return(batchId);

            paymentManager.SavePaymentBatchFile(paymentList, 0);

            var fileName = $@"bankBatches_{batchId}_{DateTime.Now.ToString("yyyy-MM-dd")}.json";
            var path = Settings.GetStringValue("BankBatchPath");

            Assert.IsFalse(System.IO.File.Exists(Path.Combine(path, fileName)));
        }

        [Test]
        public void ReturnedPayment_WillUpdateSimilarPaymentsWithRejectedStatus()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.Committed;
            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.Committed;

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment1));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment2));
            var insertedPayments = PaymentMapper.Instance.GetPayments("111", 1);
            insertedPayments[0].RejectReason = "ER102: Currency Not Found";
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPaymentsRejected(insertedPayments));
            Assert.DoesNotThrow(() => paymentManager.SaveAsReturnedPayment(newPayment));

            var updatedPayments = PaymentMapper.Instance.GetPayments("111", 1);

            Assert.AreEqual(updatedPayments.Count, 2);
            Assert.AreEqual(PaymentStatus.Rejected, updatedPayments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Committed, updatedPayments[1].PaymentStatus);
            Assert.AreEqual(insertedPayments[0].RejectReason, updatedPayments[0].RejectReason);
        }

        [Test]
        public void ReturnedPayment_WillNotUpdateSimilarPaymentsWithRejectedStatusIfItIsInSanctionBlockedState()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.SanctionBlocked;
            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.Committed;

            var newPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment1));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment2));
            Assert.DoesNotThrow(() => paymentManager.SaveAsReturnedPayment(newPayment));

            var updatedPayments = PaymentMapper.Instance.GetPayments("111", 1);

            Assert.AreEqual(updatedPayments.Count, 2);
            Assert.AreEqual(PaymentStatus.SanctionBlocked, updatedPayments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Committed, updatedPayments[1].PaymentStatus);
            Assert.AreEqual(RemittanceType.CTX, updatedPayments[0].RemittanceType);
            Assert.AreEqual(RemittanceType.CTX, updatedPayments[1].RemittanceType);
        }

        [Test]
        public void ReturnedPayment_WillLogAnErrorIfThereAreNoExistingPayments()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var newPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();

            Assert.DoesNotThrow(() => paymentManager.SaveAsReturnedPayment(newPayment));
            EventLogger.Instance.AssertWasCalled(e => e.WriteError(
                        "Cannot reject payments.  No existing payments were found for ExternalId: 111",
                        EventCode.PaymentReturnedError));
        }

        [Test]
        public void PaymentBatchRecievedAfterCashout_WorksCorrectly()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var clientBatchPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            Assert.DoesNotThrow(() => paymentManager.SaveAsPaymentBatch(clientBatchPayment));
        }

        [Test]
        public void ReturnedPayment_UpdateValueDate_Correctly()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var loadedCashoutPayment =
                PaymentMapper.Instance.GetPayment(cashoutPayment.ExternalId,
                    cashoutPayment.PaymentSourceId, PaymentStatus.Committed);

            Assert.AreEqual(PaymentStatus.Committed, loadedCashoutPayment.PaymentStatus);
            Assert.AreEqual(DateTime.Now.AddDays(-3).ToShortDateString(), loadedCashoutPayment.RequestedReleaseDate.Value.ToShortDateString());

            var returnedPayment = PaymentHelper.Instance.CreatePayment(customer, cashoutPayment.ExternalId, customerBatch);
            returnedPayment.RequestedReleaseDate = DateTime.Now;

            paymentManager.SaveAsReturnedPayment(returnedPayment);

            var savedReturnedPayment = PaymentMapper.Instance.GetPayment(cashoutPayment.ExternalId,
                    cashoutPayment.PaymentSourceId, PaymentStatus.Committed);

            Assert.AreEqual(DateTime.Now.ToShortDateString(), savedReturnedPayment.RequestedReleaseDate.Value.ToShortDateString());
        }

        [Test]
        public void RetievesPayments_GetPaymentById_Correctly()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var loadedCashoutPayment =
                PaymentMapper.Instance.GetPayment(cashoutPayment.ExternalId,
                    cashoutPayment.PaymentSourceId, PaymentStatus.Committed);

            Assert.AreEqual(PaymentStatus.Committed, loadedCashoutPayment.PaymentStatus);
            Assert.AreEqual(DateTime.Now.AddDays(-3).ToShortDateString(), loadedCashoutPayment.RequestedReleaseDate.Value.ToShortDateString());

            var payment = paymentManager.GetPayment(customer.PartnerId, cashoutPayment.ExternalId);

            Assert.AreEqual(cashoutPayment.ExternalId, payment.ExternalId);
        }

        [Test]
        public void GetPayment_Returns_Not_Accepted()
        {
            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest> { new PaymentRequest { PaymentId = "1" } }
            };

            var paymentRequestId = PaymentRequestMapper.Instance.InsertPaymentRequest(request);
            var paymentRequests = PaymentRequestMapper.Instance.GetPaymentRequestForProcessing(1);

            paymentRequests[0].PaymentsToProcess[0].PaymentMethod = ""; //force to fail
            paymentRequests[0].PaymentsToProcess[0].Validate(true); //should fail

            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequests[0], FileStatus.FailedToProcess, "failed");

            var paymentManager = new PaymentManager();
            var payment = paymentManager.GetPayment(request.PartnerId, request.PaymentsToProcess[0].PaymentId);
            Assert.IsInstanceOf<NotAcceptedPayment>(payment);
        }

        [Test]
        public void CancelPayment_Correctly()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var loadedCashoutPayment =
                PaymentMapper.Instance.GetPayment(cashoutPayment.ExternalId,
                    cashoutPayment.PaymentSourceId, PaymentStatus.Committed);

            var result = paymentManager.CancelPayment(customer.PartnerId, loadedCashoutPayment.ExternalId);
            var payment = paymentManager.GetPayment(loadedCashoutPayment.PaymentSourceId,
                loadedCashoutPayment.ExternalId);

            Assert.AreEqual(PaymentStatus.Cancelled, result.PaymentStatus);
            Assert.AreEqual(PaymentStatus.Cancelled, payment.PaymentStatus);
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void UpdatePaymentStatusBasedOnGPGAcceptance_PublishesForUpdatedPaymentStatus()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var paymentViewModels = PaymentQueryMapper.Instance.GetPayments(partner, new List<string> { "111", "222" }, 10, new SortBy());
            var payments = paymentViewModels.Select(p => new Payment(p.Id)).ToList();
            paymentManager.UpdatePaymentStatuses(payments, PaymentStatus.Sent);

            var rejectedPayment = paymentManager.GetPayment(customer.PartnerId, "111");
            rejectedPayment.PaymentStatus = PaymentStatus.Rejected;
            rejectedPayment.GPGProcessedUTC = DateTime.Today;
            var releasedPayment = paymentManager.GetPayment(customer.PartnerId, "222");
            releasedPayment.PaymentStatus = PaymentStatus.Released;
            releasedPayment.GPGProcessedUTC = DateTime.Today;
            paymentManager = new PaymentManager();
            paymentManager.UpdatePaymentStatusBasedOnGPGAcceptance(new List<Payment> { rejectedPayment, releasedPayment });

            var updatedPayment = paymentManager.GetPayment(customer.PartnerId, "111");
            Assert.AreEqual(PaymentStatus.Rejected, updatedPayment.PaymentStatus);
            updatedPayment = paymentManager.GetPayment(customer.PartnerId, "222");
            Assert.AreEqual(PaymentStatus.Released, updatedPayment.PaymentStatus);
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything), o => o.Repeat.Times(2));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void UpdateReturnedPaymentsFromPain_UpdatesPaymentAndPublishesNotification()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            Assert.DoesNotThrow(()=> PaymentMapper.Instance.InsertPayment(payment1));


            var payment2 = PaymentHelper.Instance.CreatePayment(customer, "222", customerBatch);
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(payment2));

            var returnedPayment1 = new ReturnedPayment(payment1.ExternalId, payment1.ExternalCustomerId)
            {
                Id = payment1.Id,
                PaymentStatus = PaymentStatus.Returned,
                RejectReason = "returned by bank",
                ReturnAmount = new Money(Currency.CAD, 50.0m)
            };

            var returnedPayment2 = new ReturnedPayment(payment2.ExternalId, payment2.ExternalCustomerId)
            {
                Id = payment2.Id,
                PaymentStatus = PaymentStatus.Returned,
                RejectReason = "refused by bank",
                ReturnAmount = new Money(Currency.USD, 10.0m)
            };

            paymentManager.UpdateReturnedPaymentsFromPain(new List<Payment> { returnedPayment1, returnedPayment2 });

            var updatedPayment = paymentManager.GetPayment(customer.PartnerId, "111");
            Assert.AreEqual(PaymentStatus.Returned, updatedPayment.PaymentStatus);
            Assert.AreEqual(returnedPayment1.RejectReason, updatedPayment.RejectReason);
            Assert.AreEqual(returnedPayment1.ReturnAmount.Currency.Code, ((ReturnedPayment)updatedPayment).ReturnAmount.Currency.Code);
            Assert.AreEqual(returnedPayment1.ReturnAmount.NonDecimalAmount, ((ReturnedPayment)updatedPayment).ReturnAmount.NonDecimalAmount);

            var updatedPayment2 = paymentManager.GetPayment(customer.PartnerId, "222");
            Assert.AreEqual(PaymentStatus.Returned, updatedPayment2.PaymentStatus);
            Assert.AreEqual(returnedPayment2.RejectReason, updatedPayment2.RejectReason);
            Assert.AreEqual(returnedPayment2.ReturnAmount.Currency.Code, ((ReturnedPayment)updatedPayment2).ReturnAmount.Currency.Code);
            Assert.AreEqual(returnedPayment2.ReturnAmount.NonDecimalAmount, ((ReturnedPayment)updatedPayment2).ReturnAmount.NonDecimalAmount);

            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything), o=>o.Repeat.Times(2));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void UpdatePaymentStatusBasedOnGPGAcceptance_OnlyUpdatesIfGPGProcessedDateisLatest()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            var paymentViewModels = PaymentQueryMapper.Instance.GetPayments(partner, new List<string> { "111", "222" }, 10, new SortBy());
            var payments = paymentViewModels.Select(p => new Payment(p.Id)).ToList();
            PaymentMapper.Instance.UpdatePaymentStatuses(new List<int> { payments[0].Id }, new List<PaymentStatus> { PaymentStatus.Rejected }, new List<DateTime> { DateTime.Now.AddHours(-5) });

            var releasedPayment = paymentManager.GetPayment(customer.PartnerId, "111");
            releasedPayment.PaymentStatus = PaymentStatus.Released;
            releasedPayment.GPGProcessedUTC = DateTime.Now;
            paymentManager = new PaymentManager();
            paymentManager.UpdatePaymentStatusBasedOnGPGAcceptance(new List<Payment> { releasedPayment });

            var updatedPayment = paymentManager.GetPayment(customer.PartnerId, "111");
            Assert.AreEqual(PaymentStatus.Released, updatedPayment.PaymentStatus);
        }

        [Test]
        public void CancelPayment_ThrowsException()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            var cashoutPayment = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            cashoutPayment.RequestedReleaseDate = DateTime.Now.AddDays(-3);
            cashoutPayment.PaymentStatus = PaymentStatus.Committed;
            paymentManager.SaveAsPaymentCashout(cashoutPayment);

            paymentManager.UpdatePaymentStatuses(new List<Payment>() { cashoutPayment }, PaymentStatus.Sent);

            Assert.Throws<PaymentCannotBeCancelledException>(() => paymentManager.CancelPayment(customer.PartnerId, cashoutPayment.ExternalId));
        }

        [Test]
        public void SendToBankBatck_Works()
        {
            const int batchId = 5;
            PaymentBatchMapper.Instance.Expect(pbm => pbm.InsertPaymentBatch(null)).IgnoreArguments().Return(batchId);

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment1.AmountMoney = new Money(Currency.CAD, 10);
            existingPayment1.PaymentMethod = PaymentMethod.ACH;

            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment2.AmountMoney = new Money(Currency.CAD, 20);
            existingPayment2.PaymentMethod = PaymentMethod.ACH;

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment1));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment2));

            var paymentManager = MockRepository.GeneratePartialMock<PaymentManager>();
            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();

            bookOutgoingManager.Expect(pm => pm.BookOutgoingOrder(Arg<List<Payment>>.Is.Anything, Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything)).Return(new List<Payment> { existingPayment1, existingPayment2 });
            paymentManager.Expect(pm => pm.SavePaymentBatchFile(Arg<List<Payment>>.Is.Anything, Arg<int>.Is.Anything));

            var results = bookOutgoingManager.ProcessSanctionClearedPayments(Currency.CAD, PaymentMethod.ACH);
            paymentManager.SendPaymentsToBankBatch(results.NewBookedOutOfHoldingPayments, 1);
            var updatedPayments1 = PaymentMapper.Instance.GetPayments("111", 1);
            var updatedPayments2 = PaymentMapper.Instance.GetPayments("333", 1);

            Assert.AreEqual(updatedPayments1[0].PaymentStatus, PaymentStatus.Sent);
            Assert.AreEqual(updatedPayments2[0].PaymentStatus, PaymentStatus.Sent);
        }

        [Test]
        public void SavePaymentInsertsAllTheCorrectValues()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            CustomerMapper.Instance.InsertCustomer(customer);

            const int partnerId = 1;
            var paymentManager = new PaymentManager();
            var paymentRequest = new PaymentRequestToProcess()
            {
                PartnerId = partnerId,
                CreatedOnUtc = DateTime.Now,
                PaymentsToProcess = new List<PaymentRequest>
                {
                    new PaymentRequest
                    {
                        PaymentId = "111",
                        PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId,
                        PartnerReference = "",
                        ExternalBatchId = "",
                        PaymentMethod = "WIRE",
                        FixedAmount = 10,
                        CurrencyCode = "JPY",
                        Beneficiary = new Domain.Entities.PaymentRequest.Beneficiary()
                        {
                            Id = "222",
                            VersionedOn = "2015-08-23T00:00:00Z",
                            EmailAddress = "",
                            Type = "Business",
                            FirstName = "Fred",
                            MiddleName = "H",
                            LastName = "Flintstone",
                            PhoneNumber = "",
                            CellNumber = "",
                            DateOfBirth = "",
                            Gender = "",
                            BusinessName = "abc",
                            BusinessRegistrationNumber = "",
                            BusinessRegistrationCountry = "",
                            BusinessRegistrationStateProv = "",
                            Industry = "",
                            Address = new Domain.Entities.PaymentRequest.Address
                            {
                                AddressLine1 = "abc",
                                AddressLine2 = "",
                                AddressLine3 = "",
                                City = "aaaa",
                                StateOrPovince = "CC",
                                ZipOrPostalCode = "23423",
                                CountryCode = "DD"
                            }
                        },
                        BankAccount = new Domain.Entities.PaymentRequest.BankAccount
                        {
                            Id = "333",
                            VersionedOn = "2015-08-23T00:00:00Z",
                            AccountNumber = "34234",
                            AccountType = "",
                            BankName = "aefase fase fasef",
                            BranchName = "",
                            BankCode = "sfserfsef",
                            BankBranchCode = "23423",
                            BankAddress = new Domain.Entities.PaymentRequest.Address
                            {
                                AddressLine1 = "23423 2342",
                                AddressLine2 = "",
                                AddressLine3 = "",
                                City = "asfasefa",
                                StateOrPovince = "cc",
                                ZipOrPostalCode = "df",
                                CountryCode = "sf"
                            },
                            IntermediaryBank = new IntermediaryBank
                            {
                                AccountNumber = "",
                                Address = new Domain.Entities.PaymentRequest.Address
                                {
                                    AddressLine1 = "",
                                    AddressLine2 = "",
                                    AddressLine3 = "",
                                    City = "",
                                    StateOrPovince = "",
                                    ZipOrPostalCode = "",
                                    CountryCode = ""
                                },
                                BankBranchCode = "",
                                BankCode = "",
                                BankName = ""
                            }
                        },
                        PurposeOfPayment = "",
                        InstructionForBank = "",
                        InstructionCodeForBank = "",
                        RemittanceType = "",
                        RemittanceData = null
                    }
                }
            };

            paymentManager.SavePaymentRequest(paymentRequest);
            paymentRequest.Process();
            var payment = paymentManager.GetPayment(partnerId, "111");
            var customerBatch = new CustomerBatchManager().GetCustomerBatch(payment.CustomerBatchId);
            var partnerCustomerId = customerBatch.ExternalCustomerId;
            var paymentData = PaymentResultAssembler.AssembleSinglePayment(payment, partnerId, partnerCustomerId);

            Assert.AreEqual("", paymentData.PartnerReference);
            Assert.AreEqual("", paymentData.Beneficiary.EmailAddress);
            Assert.AreEqual("", paymentData.Beneficiary.PhoneNumber);
            Assert.AreEqual("", paymentData.Beneficiary.CellNumber);
            Assert.AreEqual("", paymentData.Beneficiary.DateOfBirth);
            Assert.AreEqual("", paymentData.Beneficiary.Gender);
            Assert.AreEqual("", paymentData.Beneficiary.BusinessRegistrationNumber);
            Assert.AreEqual("", paymentData.Beneficiary.BusinessRegistrationCountry);
            Assert.AreEqual("", paymentData.Beneficiary.BusinessRegistrationStateProv);
            Assert.AreEqual("", paymentData.Beneficiary.Industry);
            Assert.AreEqual("", paymentData.Beneficiary.Address.AddressLine2);
            Assert.AreEqual("", paymentData.Beneficiary.Address.AddressLine3);
            Assert.AreEqual("", paymentData.BankAccount.AccountType);
            Assert.AreEqual("", paymentData.BankAccount.BranchName);
            Assert.AreEqual("", paymentData.BankAccount.BankAddress.AddressLine2);
            Assert.AreEqual("", paymentData.BankAccount.BankAddress.AddressLine3);
            if (paymentData.BankAccount.IntermediaryBank != null)
            {
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.AccountNumber);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.BankBranchCode);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.BankCode);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.BankName);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.Address.AddressLine1);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.Address.AddressLine2);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.Address.AddressLine3);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.Address.City);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.Address.CountryCode);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.Address.StateOrPovince);
                Assert.AreEqual("", paymentData.BankAccount.IntermediaryBank.Address.ZipOrPostalCode);
            }
            Assert.AreEqual("", paymentData.PurposeOfPayment);
            Assert.AreEqual("", paymentData.InstructionForBank);
            Assert.AreEqual("", paymentData.InstructionCodeForBank);
            Assert.AreEqual(null, paymentData.RemittanceType);
            Assert.AreEqual(null, paymentData.RemittanceData);
        }

        [Test]
        public void SavePaymentInsertsCustomerBatchForFailedPayment()
        {
            var paymentManager = new PaymentManager();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = new CustomerBatchManager().CreateBatch(customer, "Batch001", new BatchRequestData());
            var paymentRequest = new PaymentRequestToProcess()
            {
                PartnerId = 1,
                BatchId = customerBatch.Id,
                CreatedOnUtc = DateTime.Now,
                PaymentsToProcess = new List<PaymentRequest>
                {
                    new PaymentRequest
                    {
                        PaymentId = "111",
                        PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId,
                        PartnerReference = "",
                        ExternalBatchId = customerBatch.ExternalId,
                        PaymentMethod = "WIRE",
                        FixedAmount = 10,
                        CurrencyCode = "ZZD",
                        Beneficiary = new Domain.Entities.PaymentRequest.Beneficiary()
                        {
                            Id = "222",
                            VersionedOn = "2015-08-23T00:00:00Z",
                            EmailAddress = "",
                            Type = "Business",
                            FirstName = "Fred",
                            MiddleName = "H",
                            LastName = "Flintstone",
                            PhoneNumber = "",
                            CellNumber = "",
                            DateOfBirth = "",
                            Gender = "",
                            BusinessName = "abc",
                            BusinessRegistrationNumber = "",
                            BusinessRegistrationCountry = "",
                            BusinessRegistrationStateProv = "",
                            Industry = "",
                            Address = new Domain.Entities.PaymentRequest.Address
                            {
                                AddressLine1 = "abc",
                                AddressLine2 = "",
                                AddressLine3 = "",
                                City = "aaaa",
                                StateOrPovince = "CC",
                                ZipOrPostalCode = "23423",
                                CountryCode = "DD"
                            }
                        },
                        BankAccount = new Domain.Entities.PaymentRequest.BankAccount
                        {
                            Id = "333",
                            VersionedOn = "2015-08-23T00:00:00Z",
                            AccountNumber = "34234",
                            AccountType = "",
                            BankName = "aefase fase fasef",
                            BranchName = "",
                            BankCode = "sfserfsef",
                            BankBranchCode = "23423",
                            BankAddress = new Domain.Entities.PaymentRequest.Address
                            {
                                AddressLine1 = "23423 2342",
                                AddressLine2 = "",
                                AddressLine3 = "",
                                City = "asfasefa",
                                StateOrPovince = "cc",
                                ZipOrPostalCode = "df",
                                CountryCode = "sf"
                            },
                            IntermediaryBank = new IntermediaryBank
                            {
                                AccountNumber = "",
                                Address = new Domain.Entities.PaymentRequest.Address
                                {
                                    AddressLine1 = "",
                                    AddressLine2 = "",
                                    AddressLine3 = "",
                                    City = "",
                                    StateOrPovince = "",
                                    ZipOrPostalCode = "",
                                    CountryCode = ""
                                },
                                BankBranchCode = "",
                                BankCode = "",
                                BankName = ""
                            }
                        },
                        PurposeOfPayment = "",
                        InstructionForBank = "",
                        InstructionCodeForBank = "",
                        RemittanceType = "",
                        RemittanceData = null
                    }
                }
            };

            paymentRequest.Id = paymentManager.SavePaymentRequest(paymentRequest);
            paymentRequest.Process();

            Payment payment = null;
            Assert.DoesNotThrow(() => payment = paymentManager.GetPayment(customerBatch, "111"));

            Assert.IsInstanceOf<NotAcceptedPayment>(payment);
            Assert.AreEqual("1005:currency", ((NotAcceptedPayment)payment).ErrorCode);
        }

        private Partner CreatePartner(int partnerId)
        {
            return new Partner
            {
                Id = partnerId,
                Code = "HyperWallet"
            };
        }

        [Test]
        public void GetAcceptedPaymentsByBatch_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };
            PaymentMapper.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "ref2a", "ref2b" };
            PaymentMapper.Instance.InsertPayment(payment2);

            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment3.UpdatedOnUTC = DateTime.UtcNow;
            payment3.RemittanceData = new List<string> { "ref3a", "ref3b", "ref3c" };
            PaymentMapper.Instance.InsertPayment(payment3);

            var paymentManager = new PaymentManager();
            ServiceSettings.Instance.Stub(s => s.GetIntValue("MaxReturnedResources.Payments", 1000)).Return(100);

            var payments = paymentManager.GetAcceptedPaymentsByBatch(customerBatch);

            Assert.AreEqual(3, payments.Count);

            paymentManager.UpdatePaymentStatuses(new List<Payment> { payment2 }, PaymentStatus.Cancelled);

            payments = paymentManager.GetAcceptedPaymentsByBatch(customerBatch);
            Assert.AreEqual(2, payments.Count);
        }

        [Test]
        public void GetAcceptedPaymentsByBatchId_ReturnsCorrectPayments()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var clientBatchPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            var clientBatchPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            var clientBatchPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            clientBatchPayment1.SettlementAmountMoney = new Money(Currency.USD, 0);
            clientBatchPayment1.AmountMoney = new Money(Currency.CAD, 11.00m);
            clientBatchPayment2.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment2.AmountMoney = new Money(Currency.EUR, 22.00m);
            clientBatchPayment3.SettlementAmountMoney = new Money(Currency.CAD, 0);
            clientBatchPayment3.AmountMoney = new Money(Currency.EUR, 33.00m);
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment1));
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment2));
            Assert.DoesNotThrow(() => new PaymentManager().SaveAsPaymentBatch(clientBatchPayment3));

            Assert.DoesNotThrow(() => new PaymentManager().UpdatePaymentStatuses(new List<Payment> { clientBatchPayment3 }, PaymentStatus.Cancelled));
            ServiceSettings.Instance.Stub(s => s.GetIntValue("MaxReturnedResources.Payments", 1000)).Return(100);
            var result = new PaymentManager().GetAcceptedPaymentsByBatch(customerBatch);

            Assert.AreEqual(2, result.Count);
        }

        [Test]
        public void UpdatePaymentStatusBasedOnPainGeneration_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);
            
            var payment1 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment1.UpdatedOnUTC = DateTime.UtcNow;
            payment1.RemittanceData = new List<string> { "ref1a" };
            payment1.PaymentStatus = PaymentStatus.Rejected;
            PaymentMapper.Instance.InsertPayment(payment1);

            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment2.UpdatedOnUTC = DateTime.UtcNow;
            payment2.RemittanceData = new List<string> { "ref1a" };
            payment2.PaymentStatus = PaymentStatus.SanctionCleared;
            PaymentMapper.Instance.InsertPayment(payment2);

            var payments = new List<Payment> {payment1, payment2};
            var paymentManager = new PaymentManager();
            paymentManager.UpdatePaymentStatusesBasedOnPainGeneration(payments, PaymentStatus.Sent);

            var reloadedPayments = PaymentMapper.Instance.GetPayments(payments.Select(p => p.Id).ToList());

            Assert.AreEqual(PaymentStatus.Rejected, reloadedPayments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Sent, reloadedPayments[1].PaymentStatus); 
        }
    }
}
