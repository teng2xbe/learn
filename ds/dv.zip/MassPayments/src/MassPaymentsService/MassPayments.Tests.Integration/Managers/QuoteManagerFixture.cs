﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Tests.Integration.Mappers.Helpers;
using MassPayments.Exceptions;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using NUnit.Framework;
using Rhino.Mocks;
using QuoteRequest = MassPayments.Domain.ValueObjects.Quoting.QuoteRequest;
using QuoteRequestItem = MassPayments.Domain.ValueObjects.Quoting.QuoteRequestItem;
using QuoteResult = MassPayments.CCTMassPayments.QuoteResult;
using QuoteResultItem = MassPayments.CCTMassPayments.QuoteResultItem;

namespace MassPayments.Tests.Integration.Managers
{
    [TestFixture]
    public class QuoteManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();

            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetCctServiceSecurityToken()).Return("token");
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();


            ServiceSettings.Instance = null;
        }

        [Test]
        public void CreateQuoteWillUseDefaultExpirationForDifferentCurrencyPair()
        {
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

            const string customerBatchExternalId = "111";
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);

            var quoteRequest = new QuoteRequest
            {
                PartnerReference = customerBatchExternalId,
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 200), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 200), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            ServiceSettings.Instance.Stub(s => s.GetIntValue("QuoteExpiryDurationInSeconds", 60)).Return(60);

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);

            var quoteDurationInSec = ServiceSettings.Instance.GetIntValue("QuoteExpiryDurationInSeconds", 60);

            var selectStatement = string.Format("SELECT * FROM MP.QuoteRequest WHERE Id = {0}", quoteResult.Id);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    var i = 0;
                    while (reader.Read())
                    {
                        Assert.AreEqual(quoteResult.Id, Convert.ToInt32(reader["Id"]));
                        Assert.AreEqual(quoteDurationInSec, Convert.ToInt32(reader["DurationInSec"]));
                        i++;
                    }
                }
            }
            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void CreateQuoteWillUseExtendedExpirationForSameCurrencyPair()
        {
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

            const string customerBatchExternalId = "111";
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "CAD",
                        QuoteId = 1234,
                        OrderId = 111
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "USD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 2345,
                        OrderId = 111
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);

            var quoteRequest = new QuoteRequest
            {
                PartnerReference = customerBatchExternalId,
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 200), FixedTradeMoney = new Money(Currency.CAD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 200), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quoteDurationInSecSameCurrencyPair = ServiceSettings.Instance.GetIntValue("QuoteExpiryDurationInSecondsSameCurrencyPair");

            var selectStatement = string.Format("SELECT * FROM MP.QuoteRequest WHERE Id = {0}", quoteResult.Id);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    var i = 0;
                    while (reader.Read())
                    {
                        Assert.AreEqual(quoteResult.Id, Convert.ToInt32(reader["Id"]));
                        Assert.AreEqual(quoteDurationInSecSameCurrencyPair, Convert.ToInt32(reader["DurationInSec"]));
                        i++;
                    }
                }
            }
            CCTTServiceFactory.InjectedServiceInterface = null;
        }


        [Test]
        public void CreateQuoteReturnsExtendedExpirationForSameCurrencyPair()
        {
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

            const string customerBatchExternalId = "111";
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "CAD",
                        QuoteId = 1234,
                        OrderId = 111
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "USD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 2345,
                        OrderId = 111
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);

            var quoteRequest = new QuoteRequest
            {
                PartnerReference = customerBatchExternalId,
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 200), FixedTradeMoney = new Money(Currency.CAD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 200), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);

            ServiceSettings.Instance.Stub(s => s.GetIntValue("QuoteExpiryDurationInSecondsSameCurrencyPair", 43200)).Return(43200);

            var quoteDurationInSecSameCurrencyPair = ServiceSettings.Instance.GetIntValue("QuoteExpiryDurationInSecondsSameCurrencyPair");

            Assert.AreEqual(quoteResult.DurationInSec, quoteDurationInSecSameCurrencyPair);
            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void CreateQuoteSavesFundingOrderItems()
        {
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

            const string customerBatchExternalId = "111";
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "USD",
                        TradeCurrencyCode = "AUD",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 200
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);

            var quoteRequest = new QuoteRequest
            {
                PartnerReference = customerBatchExternalId,
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 200), FixedTradeMoney = new Money(Currency.AUD, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);

            var selectStatement = string.Format("SELECT * FROM MP.FundingOrderItem WHERE TransactionSystemQuoteId = {0}", quoteResult.Id);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection);
                command.CommandType = CommandType.Text;
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    var i = 0;
                    while (reader.Read())
                    {
                        Assert.AreEqual(1, Convert.ToInt32(reader["IsAmountInSettlementCurrency"]));
                        i++;
                    }
                }
            }

            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void CallingCreateQuoteTwiceUsingTheSameBatchIdWithoutBookingWillNotThrowException()
        {
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });

            const string customerBatchExternalId = "111";
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var quoteRequest = new QuoteRequest
            {
                PartnerReference = customerBatchExternalId,
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now },
                }
            };

            var quoteManager = new QuoteManager();

            Assert.DoesNotThrow(() => quoteManager.CreateQuote(quoteRequest, customer));
        }
    }
}
