﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Gateways.Invoice;
using MassPayments.Gateways.Invoice.Entities;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.ResourceAccess.ClientRA;
using NUnit.Framework;
using Rhino.Mocks;
using File = MassPayments.Domain.Entities.File;
using IOFile = System.IO.File;

namespace MassPayments.Tests.Integration.Managers
{
   [TestFixture]
    public class InvoiceManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void SetUp()
        {
            InvoiceGateway.Instance = MockRepository.GeneratePartialMock<InvoiceGateway>();
            FileMapper.Instance = MockRepository.GenerateMock<IFileMapper>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            OutOfHoldingMapper.Instance = MockRepository.GenerateMock<IOutOfHoldingMapper>();
            InvoiceTypeCache.Instance.Initialize();
            transactionScope = new TransactionScope();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetBooleanValue("Invoice.EnableAsync")).Return(false);
            ServiceSettings.Instance.Stub(s => s.GetBooleanValue("Invoice.EnableInvoiceXmlValidation")).Return(true);
        }

        [TearDown]
        public void TearDown()
        {
            InvoiceGateway.Instance = null;
            FileMapper.Instance = null;
            QuoteMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            EventLogger.Instance = null;
            CustomerMapper.Instance = null;
            PartnerMapper.Instance = null;
            OrderMapper.Instance = null;
            InvoiceTypeCache.Instance = null;
            OutOfHoldingMapper.Instance = null;
            if (transactionScope != null)
                transactionScope.Dispose();
            ServiceSettings.Instance = null;
        }

        [Test]
        public void InvoiceManager_GenerateInvoice_Works()
        {
            var path = Directory.GetCurrentDirectory();
            var fileName = "test.xml";
            var filePath = string.Format("{0}\\{1}", path, fileName);
            if (IOFile.Exists(filePath))
                IOFile.Delete(filePath);
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();
            InvoiceGateway.Instance = MockRepository.GeneratePartialMock<InvoiceGateway>();
            invoiceManager.Stub(im => ((InvoiceManager)im).GetDropPath()).Return(path);
            invoiceManager.Stub(im => im.GetInvoiceXmlFileName(Arg<AggregateInvoice>.Is.Anything)).Return(fileName);

            var invoiceNumber = 1;
            var clientId = 1234;
            var bookIncomingOrder = CreateBookIncomingOrdersResult();

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(clientId);
            invoiceManager.Expect(im => im.GetClientInfo(Arg<int>.Is.Anything)).Return(clientInfo);
            
            FileMapper.Instance.Expect(fm => fm.InsertFile(Arg<File>.Is.Anything));
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoice(Arg<int>.Is.Anything, Arg<int>.Is.Anything));

            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner() {InvoiceTypeId = 1, Code = "HyperWallet"});
            
            invoiceManager.GenerateInvoice(bookIncomingOrder, clientId, invoiceNumber);

            invoiceManager.VerifyAllExpectations();
            FileMapper.Instance.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            
            Assert.IsTrue(IOFile.Exists(filePath));
            if (IOFile.Exists(filePath))
                IOFile.Delete(filePath);
        }

        [Test]
        public void InvoiceManager_GenerateType3Invoice_Works()
        {
            var partner = new Partner
            {
                Id = 1,
                Code = "testPartner"
            };

            var customer = new Customer
            {
                Id = 1,
                TransactionSystemCustomerId = 123
            };

            var scheduleId = 1;
            var reportId = 1;

            var order = new OutOfHoldingOrder
            {
                Id = 1,
                PartnerId = partner.Id,
                CustomerId = customer.Id,
                OrderNumber = "testOrderNumber",
                ReportId = reportId,
                LineItems = new List<OutOfHoldingOrderItem>
                {
                    new OutOfHoldingOrderItem
                    {
                        Id = 1,
                        OrderId = 1,
                        TradeCurrencyCode = "CAD",
                        SettlementCurrencyCode = "USD",
                        Amount = 10
                    }
                },
                CreatedOnUTC = DateTime.Now
            };

            var path = Directory.GetCurrentDirectory();
            var expectedFileName = string.Format("{0}_{1}_{2}_{3}_{4}.xml", InvoiceManager.REPORT_FILE_PREFIX, partner.Code, customer.Id, reportId, DateTime.Now.ToString("yyyy-MM-dd"));
            var filePath = string.Format("{0}\\{1}", path, expectedFileName);
            if (IOFile.Exists(filePath))
                IOFile.Delete(filePath);

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(customer.TransactionSystemCustomerId);
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.GetOutOfHoldingOrderCustomers(partner.Id)).Return(new List<int> {customer.Id});
            CustomerMapper.Instance.Expect(cm => cm.GetCustomer(customer.Id)).Return(customer);
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.GetOutOfHoldingOrders(partner.Id, customer.Id)).Return(new List<OutOfHoldingOrder> {order});
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.InsertOutOfHoldingOrderReport(scheduleId, customer.Id)).Return(reportId);
            
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();
            invoiceManager.Expect(im => im.GetClientInfo(customer.TransactionSystemCustomerId)).Return(clientInfo);
            invoiceManager.Expect(im => im.GetDropPath()).Return(path);

            FileMapper.Instance.Expect(fm => fm.InsertFile(Arg<File>.Is.Anything));
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.UpdateFileIdForReport(Arg<int>.Is.Anything, Arg<int>.Is.Anything));
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.UpdateOutOfHoldingOrder(Arg<int>.Is.Anything, Arg<int>.Is.Anything));

            invoiceManager.GenerateOutOfHoldingReportDataFile(partner,scheduleId);

            invoiceManager.VerifyAllExpectations();
            OutOfHoldingMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            FileMapper.Instance.VerifyAllExpectations();

            Assert.IsTrue(IOFile.Exists(filePath));
            if (IOFile.Exists(filePath))
                IOFile.Delete(filePath);
        }

        private static List<BookedIncomingOrder> CreateBookIncomingOrdersResult()
       {
           return new List<BookedIncomingOrder>
           {
               new BookedIncomingOrder
               {
                    ConfirmationNumber = "banana",
                    OrderId = 1234,
                    SettlementCurrencyCode = "CAD",
                    SettlementPaymentMethod = "ACH",
                    SettlementBankAccount = 
                        new BookedIncomingOrderBankAccount
                                {
                                    AccountNumber = "123",
                                    BankAccountOwnerName = "name",
                                    BankName = "bank",
                                    SWIFTCode = "swift",
                                    RoutingCode = "blah"
                                },
                    LineItems = new List<BookedIncomingOrderItem>
                    {
                        new BookedIncomingOrderItem
                        {
                            Number = 1,
                            ItemId = 111,
                            RateValue = 1.2345m,
                            TradeAmount = 4000.00m,
                            SettlementAmount = 3000.00m,
                            TradeCurrencyCode = "USD",
                            Fee = 0.00m,
                        }
                    }
                }
           };
       }
    }
}
