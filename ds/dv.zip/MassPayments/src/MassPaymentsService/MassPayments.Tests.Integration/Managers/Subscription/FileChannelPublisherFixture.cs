﻿using System.IO;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Interfaces;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Managers.Subscription.Publishers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;
using File = System.IO.File;
namespace MassPayments.Tests.Integration.Managers.Subscription
{
    [TestFixture]
    public class FileChannelPublisherFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            SubscriptionLogger.Instance = MockRepository.GenerateMock<ISubscriptionLogger>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            SubscriptionLogger.Instance = null;
            PartnerMapper.Instance = null;

            if (Directory.Exists("test"))
                Directory.Delete("test", true);
        }

        [Test]
        public void FileChannelPublisher_SendInvoiceGeneratedNotification_Correctly()
        {
            var publisher = MockRepository.GeneratePartialMock<FileChannelPublisher>();
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequest(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            SubscriptionLogger.Instance.Expect(sl => sl.LogResponse(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));

            string invoicePath = Directory.GetCurrentDirectory()+ "/test_invoice_for_subscription.pdf";
            string resultPath = Directory.GetCurrentDirectory() + "/test/test_invoice_for_subscription_result.pdf";

            while (File.Exists(invoicePath) || File.Exists(resultPath))
            {
                System.Threading.Thread.Sleep(50);

                if (File.Exists(invoicePath))
                    File.Delete(invoicePath);

                if (File.Exists(resultPath))
                    File.Delete(resultPath);
            }

            var file = File.CreateText(invoicePath);
            file.Close();

            var subscription = new FileChannelSubscription();
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner {Code="test"});
            publisher.Expect(p => p.GetDestinationPath(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(resultPath);
            publisher.PublishInvoiceNotificationAsync(subscription, invoicePath).Wait();

            Assert.True(File.Exists(resultPath));

            if (File.Exists(invoicePath))
                File.Delete(invoicePath);

            if (File.Exists(resultPath))
                File.Delete(resultPath);

            
            publisher.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            SubscriptionLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void FileChannelPublisher_UsesInvoicePath_WhenSubscriptionPathNotSet()
        {
            var publisher = MockRepository.GeneratePartialMock<FileChannelPublisher>();
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequest(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            SubscriptionLogger.Instance.Expect(sl => sl.LogResponse(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));

            string invoicePath = Directory.GetCurrentDirectory() + "/test_invoice_for_subscription.pdf";
            string resultPath = invoicePath;

            while (File.Exists(invoicePath) || File.Exists(resultPath))
            {
                System.Threading.Thread.Sleep(50);

                if (File.Exists(invoicePath))
                    File.Delete(invoicePath);

                if (File.Exists(resultPath))
                    File.Delete(resultPath);
            }

            var file = File.CreateText(invoicePath);
            file.Close();

            var subscription = new FileChannelSubscription();
            publisher.Expect(
                p => p.GetConfiguredFileChannelPath(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything))
                .Return(null);
            publisher.PublishInvoiceNotificationAsync(subscription, invoicePath).Wait();

            Assert.True(File.Exists(resultPath));

            if (File.Exists(invoicePath))
                File.Delete(invoicePath);

            if (File.Exists(resultPath))
                File.Delete(resultPath);

            publisher.VerifyAllExpectations();
            SubscriptionLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void FileChannelPublisher_SendInvoiceGeneratedNotification_LoggedWhenInvoiceNotAvailable()
        {
            var publisher = MockRepository.GeneratePartialMock<FileChannelPublisher>();
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequest(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequestFailure(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "test" });
            string invoicePath = "NON_EXISTING_FILE";
            string resultPath = @"\NON_EXISTING_PATH";

            while (File.Exists(invoicePath) || File.Exists(resultPath))
            {
                System.Threading.Thread.Sleep(50);

                if (File.Exists(invoicePath))
                    File.Delete(invoicePath);

                if (File.Exists(resultPath))
                    File.Delete(resultPath);
            }

            var subscription = new FileChannelSubscription();

            publisher.Expect(p => p.GetDestinationPath(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(resultPath);
            
            publisher.PublishInvoiceNotificationAsync(subscription, invoicePath).Wait();

            if (File.Exists(invoicePath))
                File.Delete(invoicePath);

            if (File.Exists(resultPath))
                File.Delete(resultPath);

            publisher.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            SubscriptionLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void FileChannelPublisher_SendInvoiceGeneratedNotification_LoggedWhenMoveFailure()
        {
            var publisher = MockRepository.GeneratePartialMock<FileChannelPublisher>();
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequest(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequestFailure(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "test" });
            string invoicePath = "test_invoice_for_subscription.pdf";
            string resultPath = @"\NON_Existing_folder\test_invoice_for_subscription_result.pdf";

            while (File.Exists(invoicePath) || File.Exists(resultPath))
            {
                System.Threading.Thread.Sleep(50);

                if (File.Exists(invoicePath))
                    File.Delete(invoicePath);

                if (File.Exists(resultPath))
                    File.Delete(resultPath);
            }

            var file = File.CreateText(invoicePath);
            file.Close();

            var subscription = new FileChannelSubscription();

            publisher.Expect(p => p.GetDestinationPath(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(resultPath);
            
            publisher.PublishInvoiceNotificationAsync(subscription, invoicePath).Wait();

            Assert.True(File.Exists(invoicePath));
            Assert.False(File.Exists(resultPath));

            if (File.Exists(invoicePath))
                File.Delete(invoicePath);

            if (File.Exists(resultPath))
                File.Delete(resultPath);

            publisher.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            SubscriptionLogger.Instance.VerifyAllExpectations();
        }
    }
}
