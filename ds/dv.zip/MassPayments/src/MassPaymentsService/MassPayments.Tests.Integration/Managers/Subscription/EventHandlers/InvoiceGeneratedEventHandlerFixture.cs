﻿using System;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.Subscription;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Managers.Subscription.EventHandlers;
using MassPayments.Managers.Subscription.Interfaces;
using MassPayments.Managers.Subscription.JsonEventArguments;
using MassPayments.Mappers;
using NUnit.Framework;
using Rhino.Mocks;
using File = System.IO.File;

namespace MassPayments.Tests.Integration.Managers.Subscription.EventHandlers
{
    public class InvoiceGeneratedEventHandlerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now);
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            ServiceCallContextManager.Instance = null;
        }

        [Test]
        public void HandleEvents_Successfully()
        {
            string invoicePath = "test_invoice_for_subscription.pdf";
            string resultPath = "test_invoice_for_subscription_result.pdf";

            if (File.Exists(invoicePath))
                File.Delete(invoicePath);

            if (File.Exists(resultPath))
                File.Delete(resultPath);

            while (File.Exists(invoicePath) || File.Exists(resultPath))
            {
                System.Threading.Thread.Sleep(50);
            }

            var file = File.CreateText(invoicePath);
            file.Close();

            var subscription = new FileChannelSubscription
            {
                PartnerId = 1,
                SubscriptionType = SubscriptionType.Invoice
            };

            SubscriptionMapper.Instance.InsertSubscription(subscription); 

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var handler = new InvoiceGeneratedEventHandler(new ActionHandlingManager(), subscriptionManager, 20);

            subscriptionManager.Expect(sm => sm.HandleInvoiceGeneratedEvent(Arg<InvoiceGeneratedEventArgument>.Is.Anything));
            var subscriptionEvent = new SubscriptionEvent
            {
                SubscriptionEventType = SubscriptionEventType.InvoiceGenerated,
                CreatedOnUtc = DateTime.UtcNow,
                JsonEventArguments = string.Format("{{'PartnerId':'1', 'PathToInvoice':'{0}'}}", invoicePath)
            };

            SubscriptionMapper.Instance.InsertSubscriptionEvent(subscriptionEvent);

            handler.Handle(Guid.NewGuid().ToString(), "HostName");

            var handlerInfo = ActionHandlerMapper.Instance.GetActionHandlerInfoForTesting(handler.GetType().FullName);

            var processedEvents = SubscriptionEventHandlingMapper.Instance.GetProcessedEventsByType(handlerInfo.Id, SubscriptionEventType.InvoiceGenerated);
            Assert.AreEqual(1, processedEvents.Count);
            Assert.AreEqual(subscriptionEvent.Id, processedEvents[0].Id);
            subscriptionManager.VerifyAllExpectations();
        }
    }
}
