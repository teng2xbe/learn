﻿using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Managers.Subscription;
using MassPayments.Managers.Subscription.Publishers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers.Subscription
{
    [TestFixture]
    public class PublisherFactoryFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void GetPublisherForPartner_Works()
        {
            var partner = PartnerMapper.Instance.GetPartnerByName("HyperWallet");
            var subscription = new ApiChannelSubscription
            {
                PartnerId = partner.Id,
                SubscriptionType = SubscriptionType.Ping
            };

            var publisher = PublisherFactory.GetPublisher(subscription);
            Assert.IsTrue(publisher is ApiChannelPublisher);
        }
    }
}
