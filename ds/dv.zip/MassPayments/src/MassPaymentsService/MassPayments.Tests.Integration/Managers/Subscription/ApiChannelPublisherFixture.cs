﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Interfaces;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Managers.Subscription.Publishers;
using NUnit.Framework;
using Rhino.Mocks;
using IOFile = System.IO.File;

namespace MassPayments.Tests.Integration.Managers.Subscription
{
    [TestFixture]
    public class ApiChannelPublisherFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            SubscriptionLogger.Instance = MockRepository.GenerateMock<ISubscriptionLogger>();
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            SubscriptionLogger.Instance = null;
        }

        [Test]
        public void ApiChannelPublisher_SendPingNotification_Correctly()
        {
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequest(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            SubscriptionLogger.Instance.Expect(sl => sl.LogResponse(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));

            var subscription = new ApiChannelSubscription
            {
                Endpoint = "http://www.microsoft.com"
            };

            var publisher = MockRepository.GeneratePartialMock<ApiChannelPublisher>();
            var response = new HttpResponseMessage();
            publisher.Expect(p => p.GetAsync(Arg<string>.Is.Anything)).Return(Task.FromResult(response));
            publisher.PublishPingNotificationAsync(subscription).Wait();
            SubscriptionLogger.Instance.VerifyAllExpectations();
            publisher.VerifyAllExpectations();
        }

        [Test]
        public void ApiChannelPublisher_SendPingNotification_LogsRequestFailure()
        {
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequest(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequestFailure(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));

            var subscription = new ApiChannelSubscription
            {
                Endpoint = "http://www.microsoft.com"
            };

            var publisher = MockRepository.GeneratePartialMock<ApiChannelPublisher>();
            publisher.Expect(p => p.GetAsync(Arg<string>.Is.Anything)).Throw(new Exception());
            publisher.PublishPingNotificationAsync(subscription).Wait();
            SubscriptionLogger.Instance.VerifyAllExpectations();
            publisher.VerifyAllExpectations();
        }

        [Test]
        public void ApiChannelPublisher_SendInvoice_Correctly()
        {
            SubscriptionLogger.Instance.Expect(sl => sl.LogRequest(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));
            SubscriptionLogger.Instance.Expect(sl => sl.LogResponse(Arg<ISubscription>.Is.Anything, Arg<string>.Is.Anything));

            var subscription = new ApiChannelSubscription
            {
                Endpoint = "Blah"
            };

            string invoicePath = "test_invoice_for_subscription.pdf";

            if (!IOFile.Exists(invoicePath))
            {
                var file = IOFile.CreateText(invoicePath);
                file.Close();
            }

            var publisher = MockRepository.GeneratePartialMock<ApiChannelPublisher>();
            var response = new HttpResponseMessage();
            publisher.Expect(p => p.PostAsync(Arg<string>.Is.Anything, Arg<HttpContent>.Is.Anything)).Return(Task.FromResult(response));
            publisher.PublishInvoiceNotificationAsync(subscription, invoicePath).Wait();
            SubscriptionLogger.Instance.VerifyAllExpectations();
            publisher.VerifyAllExpectations();

            if (IOFile.Exists(invoicePath))
                IOFile.Delete(invoicePath);
        }
    }
}
