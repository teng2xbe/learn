﻿using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Managers.Subscription;
using MassPayments.Mappers;
using NUnit.Framework;
using Rhino.Mocks;
using IOFile = System.IO.File;

namespace MassPayments.Tests.Integration.Managers.Subscription
{
    [TestFixture]
    public class SubscriptionManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            SubscriptionLogger.Instance = MockRepository.GenerateMock<ISubscriptionLogger>();
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            SubscriptionLogger.Instance = null;
        }

        [Test]
        public void IsPartnerRegistered_ReturnCorrectly()
        {
            SubscriptionMapper.Instance.InsertSubscription(new ApiChannelSubscription
            {
                Endpoint = "blah",
                PartnerId = 1,
                SubscriptionType = SubscriptionType.Invoice
            });

            Assert.True(new SubscriptionManager().IsPartnerRegistered(1, SubscriptionType.Invoice));
        }
    }
}
