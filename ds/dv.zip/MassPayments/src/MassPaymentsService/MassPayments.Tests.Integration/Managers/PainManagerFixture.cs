﻿using System.Transactions;
using MassPayments.Domain.Enums;
using MassPayments.Managers.PainGeneration;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Managers
{
   [TestFixture]
    public class PainManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void IsCurrencyPaymentMethodSupported_ReturnCorrectly()
        {
            var painManager = new PainManager();
            Assert.IsTrue(painManager.IsCurrencyAndPaymentMethodSupported("SBD", PaymentMethod.Wire));
            Assert.IsTrue(painManager.IsCurrencyAndPaymentMethodSupported("GBP", PaymentMethod.ACH));
            Assert.IsTrue(painManager.IsCurrencyAndPaymentMethodSupported("USD", PaymentMethod.ACH));
        }
    }
}
