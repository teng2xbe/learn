﻿using System;
using System.IO;
using System.Threading;
using MassPayments.ActionHandlers;
using MassPayments.Infrastructure.Polling;
using MassPayments.Managers.FileManaging.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers.FileManaging
{
    [TestFixture]
    public class FileWatcherFixture
    {
        private string path;
        private string filePath;

        [SetUp]
        public void SetUp()
        {
            path = Directory.GetCurrentDirectory();
            filePath = Path.Combine(path, "testfile.txt");

            if (File.Exists(filePath))
                File.Delete(filePath);
        }

        [TearDown]
        public void TearDown()
        {
            Exception ex;

            //wait for file watcher to let go fo this file
            do
            {
                try
                {
                    if (File.Exists(filePath))
                        File.Delete(filePath);
                    ex = null;
                }
                catch (Exception e)
                {
                    ex = e;
                }
                
            } while (ex != null);

        }
        
        [Test]
        public void TheWatcherWillTriggerWhenAFileIsCopied()
        {
            var handler = MockRepository.GenerateMock<PartnerJsonFileHandler>();
            var fileManager = MockRepository.GenerateMock<IFileManager>();

            new FileWatcher(fileManager, handler).StartWatching(path);

            File.CreateText(filePath);

            Thread.Sleep(1000);
            handler.AssertWasCalled(h => h.Handle(Arg<string>.Is.Anything,Arg<string>.Is.Anything,Arg<ActionHandlerDelegate>.Is.Anything));
        }

        [Test]
        public void TheWatcherWillIgnoreWindowsGeneratedFile()
        {
            var systemFilePath = Path.Combine(path, "thumbs.db");

            var handler = MockRepository.GenerateMock<PartnerJsonFileHandler>();
            var fileManager = MockRepository.GenerateMock<IFileManager>();

            new FileWatcher(fileManager, handler).StartWatching(path);

            File.CreateText(systemFilePath);

            Thread.Sleep(1000);
            fileManager.AssertWasNotCalled(fm => fm.UploadFile(systemFilePath));
        }
    }
}
