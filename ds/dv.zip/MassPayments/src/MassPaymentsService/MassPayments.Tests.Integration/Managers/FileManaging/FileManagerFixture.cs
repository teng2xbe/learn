﻿using MassPayments.Domain.Enums;
using MassPayments.Gateways.Email.Interfaces;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Managers.FileManaging;
using MassPayments.Managers.FileProcessing.Interfaces;
using MassPayments.Managers.Notification.Interfaces;
using MassPayments.Mappers;
using NUnit.Framework;
using Rhino.Mocks;
using System.IO;
using System.Text;
using System.Transactions;
using IOFile = System.IO.File;

namespace MassPayments.Tests.Integration.Managers.FileManaging
{
    [TestFixture]
    [Explicit("Many of these tests often fail during the TearDown stage on some machines.")]
    public class FileManagerFixture
    {
        public const string TestFileName = "TestFile.txt";

        private static void CreateTestFile(int numBytes)
        {
            IOFile.WriteAllBytes(TestFileName, new byte[numBytes]);
        }

        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            if (IOFile.Exists(TestFileName))
                IOFile.Delete(TestFileName);

            if (Directory.Exists("Archive"))
                Directory.Delete("Archive", true);

            if (Directory.Exists("FailedToLoad"))
                Directory.Delete("FailedToLoad", true);

            EventLogger.Instance = null;
        }

        [Test]
        public void FileManagerWillUploadAFile()
        {
            CreateTestFile(100);

            var fileManager = new FileManager();
            fileManager.FileProcessorManager = MockRepository.GenerateMock<IFileProcessorManager>();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.UploadFile(TestFileName);

            Assert.IsTrue(fileManager.UploadedFile.Id > 0);
        }

        [Test]
        public void LargeFilesWillGetLogged()
        {
            CreateTestFile(100 * 1024 * 1024 + 1);

            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            var fileManager = new FileManager();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.UploadFile(TestFileName);
            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        [Explicit("This test often fails when the file can't be cleaned up.  It's trivial and we probably don't really need to run it all the time.")]
        public void WrongFileExtensionWillGetLogged()
        {
            IOFile.WriteAllBytes("afile.wrong", new byte[1]);
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));

            var fileManager = new FileManager();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.UploadFile("afile.wrong");

            EventLogger.Instance.VerifyAllExpectations();
            IOFile.Delete("afile.wrong");
        }

        [Test]
        public void WrongFileExtensionWillGetPutIntoFailedFolder()
        {
            IOFile.WriteAllBytes("afile.wrong", new byte[1]);

            var fileManager = new FileManager();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.UploadFile("afile.wrong");
            Assert.IsTrue(IOFile.Exists(@"FailedToLoad\afile.wrong"));

        }

        [Test]
        public void WrongFileWillhaveFailedStatus()
        {
            IOFile.WriteAllBytes("afile.txt", new byte[1]);

            var fileManager = new FileManager();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.UploadFile("afile.txt");

            var loadedFile = FileMapper.Instance.GetFile(fileManager.UploadedFile.Id);
            Assert.AreEqual(FileStatus.FailedToProcess, loadedFile.Status);

            Assert.IsTrue(IOFile.Exists(@"FailedToLoad\afile.txt"));

            IOFile.Delete("afile.txt");
        }


        [Test]
        public void RightFileExtensionWillNotGetIgnored()
        {
            CreateTestFile(1);

            EmailMessageGateway.Instance = MockRepository.GenerateMock<IEmailMessageGateway>();

            var fileManager = new FileManager();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.FileProcessorManager = MockRepository.GenerateMock<IFileProcessorManager>();
            fileManager.UploadFile(TestFileName);

            Assert.AreEqual(fileManager.UploadedFile.Data.Length, 1);
            Assert.AreEqual(fileManager.UploadedFile.Status, FileStatus.Pending);
        }

        [Test]
        public void UploadedFileWillGetArchived()
        {
            CreateTestFile(100);
            EmailMessageGateway.Instance = MockRepository.GenerateMock<IEmailMessageGateway>();

            var fileManager = new FileManager();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.FileProcessorManager = MockRepository.GenerateMock<IFileProcessorManager>();

            fileManager.UploadFile(TestFileName);

            Assert.IsTrue(IOFile.Exists(@"Archive\TestFile.txt"));
        }

        [Test]
        public void UploadingTheSameFileThreeTimesWillArchivedItWithAUniqueName()
        {
            var fileManager = new FileManager();
            fileManager.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            fileManager.FileProcessorManager = MockRepository.GenerateMock<IFileProcessorManager>();

            EmailMessageGateway.Instance = MockRepository.GenerateMock<IEmailMessageGateway>();

            CreateTestFile(100);
            fileManager.UploadFile(TestFileName);

            CreateTestFile(100);
            fileManager.UploadFile(TestFileName);

            CreateTestFile(100);
            fileManager.UploadFile(TestFileName);

            Assert.IsTrue(IOFile.Exists(@"Archive\TestFile.txt"));
            Assert.IsTrue(IOFile.Exists(@"Archive\TestFile~1.txt"));
            Assert.IsTrue(IOFile.Exists(@"Archive\TestFile~2.txt"));
        }

        [Test]
        public void GetFileById_Works()
        {
            var file = new Domain.Entities.File
            {
                Data = Encoding.UTF8.GetBytes("anything"),
                Status = FileStatus.Pending,
                FileNameWithExtension = "test.json"
            };

            FileMapper.Instance.InsertFile(file);

            var loadedFile = FileMapper.Instance.GetFile(file.Id);

            Assert.AreEqual(file.Data, loadedFile.Data);
            Assert.IsNotNull(file.CreatedOnUTC);
        }
    }
}
