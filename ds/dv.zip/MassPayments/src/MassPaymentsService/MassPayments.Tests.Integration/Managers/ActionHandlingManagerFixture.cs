﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Transactions;
using MassPayments.ActionHandlers;
using MassPayments.Infrastructure.Persistence.Enums;
using MassPayments.Managers;
using MassPayments.Managers.Subscription.EventHandlers;
using MassPayments.Providers.StorageProvider;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Managers
{
    [TestFixture]
    public class ActionHandlingManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void Concurrent_InsertLock_OnlyOneGetsLock()
        {
            //disable transaction scope and manually wipe table
            //because cannot handle transaction in async scenario
            //which this test is trying to mimic
            transactionScope.Dispose();
            WipeLockTable();

            var handlerName = typeof (PartnerJsonFileHandler).FullName;

            var taskList = new List<Task>();
            int lock1 = 0;
            int lock2 = 0;

            taskList.Add(Task.Run(() =>
            {
                lock1 = new ActionHandlingManager().GetLock(handlerName, "Guid1", "Blah1",0);
            }));
            taskList.Add(Task.Run(() =>
            {
                lock2 = new ActionHandlingManager().GetLock(handlerName, "Guid2", "Blah2", 0);
            }));
            Assert.Throws<AggregateException>(() => Task.WaitAll(taskList.ToArray()));
            
            Assert.IsTrue( lock1 != 0 || lock2 != 0); //at least one of them obtain a lock.
            Assert.IsFalse(lock1 != 0 && lock2 != 0); //only one should get a lock. Not two.

            WipeLockTable();
            transactionScope = null;
        }

        [Test]
        public void Concurrent_InsertLock_ForDifferentHandler_Works()
        {
            //disable transaction scope and manually wipe table
            //because cannot handle transaction in async scenario
            //which this test is trying to mimic
            transactionScope.Dispose(); 
            WipeLockTable();

            var handlerName1 = typeof(PartnerJsonFileHandler).FullName;
            var handlerName2 = typeof (IncomingInvoiceFileHandler).FullName;
            var taskList = new List<Task>();
            
            int lock1 = 0;
            int lock2 = 0;

            taskList.Add(Task.Run(() =>
            {
                lock1 = new ActionHandlingManager().GetLock(handlerName1, "Guid1", "Blah1", 0);   
            }));
            taskList.Add(Task.Run(() =>
            {
                lock2 = new ActionHandlingManager().GetLock(handlerName2, "Guid2", "Blah2", 0);
            }));
            Assert.DoesNotThrow(() => Task.WaitAll(taskList.ToArray()));
            Assert.IsTrue(lock1 != 0 && lock2 != 0); //Both should obtain lock

            WipeLockTable();
            transactionScope = null;
        }

        private void WipeLockTable()
        {
            var connectionString = DatabaseConnectionStringProvider.Instance.GetDatabaseConnectionString(Database.MassPayments);

            using (var connection = new SqlConnection(connectionString))
            using(var command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = @"update [MP].[LockableActionHandler]
                                          set 
                                              [LockedGuid] = NULL
                                              ,[LockedHostName] = NULL
                                              ,[LockedOnUTC] = NULL
                                              ,[LockedTtlUTC] = NULL
                                              ,[PredictedNextExecutionUTC] = NULL";
                command.ExecuteNonQuery();
            }
        }
    }
}
