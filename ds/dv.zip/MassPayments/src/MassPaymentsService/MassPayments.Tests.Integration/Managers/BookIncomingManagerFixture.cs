﻿using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Bus;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.ServiceModel;
using System.Transactions;
using MassPayments.Infrastructure;
using BookIncomingOrderRequest = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrderRequest;
using BookIncomingOrderRequestItem = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrderRequestItem;
using BookIncomingOrdersRequest = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrdersRequest;
using Order = MassPayments.Domain.Entities.Order;
using QuoteRequest = MassPayments.Domain.ValueObjects.Quoting.QuoteRequest;
using QuoteRequestItem = MassPayments.Domain.ValueObjects.Quoting.QuoteRequestItem;
using QuoteResultItem = MassPayments.CCTMassPayments.QuoteResultItem;

namespace MassPayments.Tests.Integration.Managers
{
    [TestFixture]
    public class BookIncomingManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Expect(ccm => ccm.GetCurrencyDictionary())
                .Return(new Dictionary<string, Currency>
                {
                    {"CAD", new Currency("CAD")},
                    {"USD", new Currency("USD")},
                    {"JPY", new Currency("JPY")},
                    {"EUR", new Currency("EUR")},
                    {"GBP", new Currency("GBP")}

                });
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
            CCTTServiceFactory.InjectedServiceInterface = null;

            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetCctServiceSecurityToken()).Return("token");
            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();

            ServiceCallContextManager.Instance = null;
            CurrencyCacheMapper.Instance = null;
            MassPayBus.Instance = null;

            ServiceSettings.Instance = null;
            ValidationRules.Instance = null;
        }

        [Test]
        public void BookIncomingOrderForFileBasedPayments_UpdatesCustomerBatchRecordWhenOneDoesAlreadyExist()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.CAD, 100.00m),
                    TradeMoney = new Money(Currency.USD, 100.00m),
                    TransactionSystemQuoteId = 1234,
                    IsAmountInSettlementCurrency = false,
                    OrderId = 1212
                }
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customer.PartnerAssignedCustomerId, customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            QuoteMapper.Instance.InsertQuoteToOrderRelationship(quoteRequestId, new List<int> { 1212 }, TransactionSystem.CCT);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);
            var quoteRequest = QuoteMapper.Instance.GetQuote(quoteRequestId);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteRequestId,
                QuoteGuid = quoteRequest.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.USD, 100.00m),
                                IsAmountInSettlementCurrency = false

                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                },
                ShouldEnsureCustomerBatch = true
            };

            var newCustomerBatch = new CustomerBatch
            {
                CustomerId = customer.Id,
                ExternalId = quoteRequest.CustomerBatchExternalId,
                UpdatedOnUTC = DateTime.UtcNow
            };

            CustomerBatchMapper.Instance.InsertCustomerBatch(newCustomerBatch);

            new BookIncomingManager().BookIncomingOrder(request, customer, new Partner());

            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(newCustomerBatch.CustomerId, newCustomerBatch.ExternalId);

            Assert.IsNotNull(customerBatch);
            Assert.AreEqual(quoteRequest.CustomerBatchExternalId, customerBatch.ExternalId);

            PaymentMapper.Instance = null;
        }

        [Test]
        public void BookIncomingOrder_DoesNotFail_WhenInvoiceGenerationFails()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();

            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();
            invoiceManager.Expect(im => im.GetClientInfo(Arg<int>.Is.Anything)).Throw(new Exception());
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.CAD, 100.00m),
                    TradeMoney = new Money(Currency.USD, 100.00m),
                    TransactionSystemQuoteId = 1234,
                    IsAmountInSettlementCurrency = false,
                    OrderId = 1212
                }
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customer.PartnerAssignedCustomerId, customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            QuoteMapper.Instance.InsertQuoteToOrderRelationship(quoteRequestId, new List<int> { 1212 }, TransactionSystem.CCT);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);
            var quote = QuoteMapper.Instance.GetQuote(quoteRequestId);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteRequestId,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.USD, 100.00m),
                                IsAmountInSettlementCurrency = false

                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                },
                ShouldEnsureCustomerBatch = true
            };

            Assert.DoesNotThrow(() => new BookIncomingManager().BookIncomingOrder(request, customer, new Partner()));
            PaymentMapper.Instance = null;
        }

        [Test]
        public void BookIncomingOrderForFileBasedPayments_CreatesCustomerBatchRecordWhenOneDoesNotAlreadyExist()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.CAD, 100.00m),
                    TradeMoney = new Money(Currency.USD, 100.00m),
                    TransactionSystemQuoteId = 1234,
                    IsAmountInSettlementCurrency = false,
                    OrderId = 1212
                }
            };

            var quoteRequestId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customer.PartnerAssignedCustomerId, customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            QuoteMapper.Instance.InsertQuoteToOrderRelationship(quoteRequestId, new List<int> { 1212 }, TransactionSystem.CCT);
            QuoteMapper.Instance.InsertQuoteToOrderItemsRelationship(quotedItems);
            var quoteRequest = QuoteMapper.Instance.GetQuote(quoteRequestId);
            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteRequestId,
                QuoteGuid = quoteRequest.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.USD, 100.00m),
                                IsAmountInSettlementCurrency = false

                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                },
                ShouldEnsureCustomerBatch = true,
                BatchId = "Batch001",
                BatchReference = "BatchReference001"
            };

            Assert.Throws<ArgumentException>(() => CustomerBatchMapper.Instance.GetCustomerBatch(customer.Id, customer.PartnerAssignedCustomerId));

            new BookIncomingManager().BookIncomingOrder(request, customer, new Partner());

            var customerBatch = CustomerBatchMapper.Instance.GetCustomerBatch(customer.Id, customer.PartnerAssignedCustomerId);

            Assert.IsNotNull(customerBatch);
            Assert.AreEqual(quoteRequest.CustomerBatchExternalId, customerBatch.ExternalId);

            PaymentMapper.Instance = null;
        }

        [Test]
        public void BookIncomingOrder_UpdatesQuoteRequest_And_InsertsQuoteRequestToOrderRelationship()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Return(bookIncomingOrderResult);

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            var result = bookIncomingManager.BookIncomingOrder(request, customer, new Partner());

            var quotedRequest = QuoteMapper.Instance.GetQuote(request.QuoteId);
            Assert.AreEqual(QuoteRequestStatus.Committed, quotedRequest.Status);

            var selectStatement = string.Format("SELECT FO.QuoteRequestId, Q.TransactionSystemQuoteId, FO.TransactionSystemOrderId, FO.TransactionSystemOrderNumber " +
                                                "FROM MP.FundingOrder FO " +
                                                "inner join " +
                                                "mp.MPSQuoteTransactionSystemQuote Q on FO.QuoteRequestId = Q.QuoteRequestId WHERE FO.QuoteRequestId = {0}", quoteResult.Id);
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["MassPayments.ConnectionString"].ConnectionString))
            {
                var command = new SqlCommand(selectStatement, connection) { CommandType = CommandType.Text };
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                using (reader)
                {
                    var i = 0;
                    while (reader.Read())
                    {
                        Assert.AreEqual(quoteResult.Id, Convert.ToInt32(reader["QuoteRequestId"]));
                        Assert.AreEqual(cctQuoteResult.QuotedItems[i].QuoteId, Convert.ToInt32(reader["TransactionSystemQuoteId"]));
                        Assert.AreEqual(cctQuoteResult.QuotedItems[i].OrderId, Convert.ToInt32(reader["TransactionSystemOrderId"]));
                        Assert.AreEqual(result.BookedOrders[0].OrderConfirmationNo, Convert.ToString(reader["TransactionSystemOrderNumber"]));
                        i++;
                    }
                }
            }

            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void BookIncomingOrder_Throws_InvalidSettlementMethodException()
        { 
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<InvalidSettlementMethodFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<InvalidSettlementMethodException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }

        [Test]
        public void BookIncomingOrder_Throws_DebitLimitExceededException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<DebitLimitExceededFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<DebitLimitExceededException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }

        [Test]
        public void BookIncomingOrder_Throws_GenericOrderValidationException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<OrderValidationFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<GenericOrderValidationException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }

        [Test]
        public void BookIncomingOrder_Throws_MinimumAmountNotMetException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<MinimumAmountNotMetFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<MinimumAmountNotMetException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }
        [Test]
        public void BookIncomingOrder_Throws_MaximumAmountExceededException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<MaximumAmountExceededFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<MaximumAmountExceededException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }
        [Test]
        public void BookIncomingOrder_Throws_CurrencyNotCapableofHolidngException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<CurrencyNotCapableOfHoldingFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<CurrencyNotCapableofHoldingException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }
        [Test]
        public void BookIncomingOrder_Throws_GenericDecoupledLineItemValidationException()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<LineItemValidationFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<GenericDecoupledLineItemValidationException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }

        [Test]
        public void BookIncomingOrder_Works_WithOtherFaultExceptionFromCCT()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<InvalidValueDateFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<FaultException<InvalidValueDateFault>>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }

        [Test]
        public void BookIncomingOrder_Throws_TheOriginalFaultExceptionFromCCT()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["EnableCCTOrderValidationMessages"].Value = "false";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var cctQuoteResult = new QuoteResult
            {
                QuotedItems = new List<QuoteResultItem>
                {
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        QuoteId = 1234,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 120.00m,
                    },
                    new QuoteResultItem
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "EUR",
                        QuoteId = 2345,
                        OrderId = 111,
                        SettlementAmount = 100.00m,
                        TradeAmount = 150.00m
                    }
                }
            };
            var bookIncomingOrderResult = new BookIncomingOrdersResult
            {
                BookedOrders = new List<BookIncomingOrderResult>
                {
                    new  BookIncomingOrderResult
                    {
                        OrderId = 111,
                        ConfirmationNumber = "TX111",
                        SettlementCurrencyCode = "CAD",
                        SettlementBankAccount = new SettlementBankAccountResult(),
                        OrderDate = DateTime.UtcNow,
                        LineItems = new List<LineItemResult>
                        {
                            new LineItemResult
                            {
                                TradeCurrencyCode = "USD",
                                SettlementAmount = 100.00m,
                                TradeAmount = 120.00m,

                            },
                            new LineItemResult
                            {
                                TradeCurrencyCode = "EUR",
                                SettlementAmount = 100.00m,
                                TradeAmount = 150.00m,
                            }
                        }
                    }
                }
            };

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.Quote(Arg<MassPayments.CCTMassPayments.QuoteRequest>.Is.Anything)).Return(cctQuoteResult);
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.BookIncomingOrders(Arg<MassPayments.CCTMassPayments.BookIncomingOrdersRequest>.Is.Anything)).Throw(new FaultException<LineItemValidationFault>(null, "test"));

            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100.00m), FixedTradeMoney = new Money(Currency.EUR, 0), ValueDate = DateTime.Now.AddDays(2) }
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true

                            },
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.EUR,
                                AmountMoney = new Money(Currency.CAD, 100.00m),
                                IsAmountInSettlementCurrency = true
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            Assert.Throws<FaultException<LineItemValidationFault>>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }

        [Test]
        public void BookIncomingOrder_WillReuseTheQuoteIdsThatWereCreatedDuringTheInitialQuote()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var bookIncomingManager = new BookIncomingManager();
            var quoteRequest = new QuoteRequest
            {
                PartnerReference = "111",
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 200), FixedTradeMoney = new Money(Currency.USD, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.GBP, 200), FixedTradeMoney = new Money(Currency.JPY, 0), ValueDate = DateTime.Now.AddDays(2) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 200), FixedTradeMoney = new Money(Currency.CAD, 0), ValueDate = DateTime.Now.AddDays(2) },
                }
            };

            var quoteResult = new QuoteManager().CreateQuote(quoteRequest, customer);
            var quote = QuoteMapper.Instance.GetQuote(quoteResult.Id);

            var bookRequest = new BookIncomingOrdersRequest
            {
                QuoteId = quoteResult.Id,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.CAD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem {AmountMoney = new Money(Currency.CAD, 200), IsAmountInSettlementCurrency = true, TradeCurrency = Currency.USD}
                        }
                    },
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem {AmountMoney = new Money(Currency.USD, 200), IsAmountInSettlementCurrency = true, TradeCurrency = Currency.CAD}
                        }
                    },
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.GBP,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem {AmountMoney = new Money(Currency.GBP, 200), IsAmountInSettlementCurrency = true, TradeCurrency = Currency.JPY}
                        }
                    }
                }
            };

            var bookResult = bookIncomingManager.BookIncomingOrder(bookRequest, customer, new Partner());

            Assert.AreEqual(3, bookResult.BookedOrders.Count);
            Assert.AreEqual("CAD", bookResult.BookedOrders[0].SettlementCurrencyCode);
            Assert.IsTrue(bookResult.BookedOrders[0].OrderConfirmationNo.StartsWith("TX"));
            Assert.AreEqual("USD", bookResult.BookedOrders[1].SettlementCurrencyCode);
            Assert.IsTrue(bookResult.BookedOrders[1].OrderConfirmationNo.StartsWith("TX"));
            Assert.AreEqual("GBP", bookResult.BookedOrders[2].SettlementCurrencyCode);
            Assert.IsTrue(bookResult.BookedOrders[2].OrderConfirmationNo.StartsWith("TX"));
        }

        [Test]
        public void BookIncomingOrder_Fails_WhenCalledTwiceUsingTheSameQuoteId()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.CAD, 0),
                    TradeMoney = new Money(Currency.USD, 0),
                    TransactionSystemQuoteId = 1234,
                }
            };

            var quoteId = QuoteMapper.Instance.InsertQuoteRequest(quotedItems, customer.PartnerAssignedCustomerId, customer.Id, "testPartnerReference", true, "", 60, DateTime.Now.AddDays(1), QuoteRequestStatus.Created);
            var quote = QuoteMapper.Instance.GetQuote(quoteId);

            var request = new BookIncomingOrdersRequest
            {
                QuoteId = quoteId,
                QuoteGuid = quote.QuoteGuid,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                TradeCurrency = Currency.USD,
                                AmountMoney = new Money(Currency.USD, 0),
                                IsAmountInSettlementCurrency = false
                            }
                        },
                        SettlementCurrency = Currency.CAD
                    }
                }
            };

            var bookIncomingManager = new BookIncomingManager();

            bookIncomingManager.BookIncomingOrder(request, customer, new Partner());
            Assert.Throws<QuoteAlreadyCommittedException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
        }

        [Test]
        public void GetOrders_OrderStatusShouldBeSetToNotFoudWhenOrderIsNotFoundInDb()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderNumbers = new List<string> { order1.ConfirmationNumber ,order2.ConfirmationNumber, order3.ConfirmationNumber};

            var bookIncomingManager = new BookIncomingManager();
            var orders = bookIncomingManager.GetOrders(orderNumbers, customer.PartnerId);

            Assert.AreEqual(orders[0].OrderStatus, OrderStatus.NotFound);
            Assert.AreEqual(orders[1].OrderStatus, OrderStatus.NotFound);
            Assert.AreEqual(orders[2].OrderStatus, OrderStatus.NotFound);
        }

        [Test]
        public void GetOrders_OrderStatusShouldBeSetToNotFoudWhenOrderBelongsToDifferentPartner()
        {
            const int partnerId = 2;
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrderStatus(orderList));

            var orderNumbers = new List<string> { order1.ConfirmationNumber ,order2.ConfirmationNumber, order3.ConfirmationNumber};

            var bookIncomingManager = new BookIncomingManager();
            var orders = bookIncomingManager.GetOrders(orderNumbers, partnerId);

            Assert.AreEqual(orders[0].OrderStatus, OrderStatus.NotFound);
            Assert.AreEqual(orders[1].OrderStatus, OrderStatus.NotFound);
            Assert.AreEqual(orders[2].OrderStatus, OrderStatus.NotFound);
        }

        [Test,Description("When order number(s) are not passed")]
        public void GetOrders_AllOrdersAreReturned()
        {
            const int partnerId = 1;
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);

            var order1 = OrderHelper.Instance.CreateOrder(customer);
            var order2 = OrderHelper.Instance.CreateOrder(customer);
            var order3 = OrderHelper.Instance.CreateOrder(customer);

            var orderList = new List<Order> { order1, order2, order3 };
            Assert.DoesNotThrow(() => OrderMapper.Instance.UpdateOrders(orderList));
            
            
            var bookIncomingManager = new BookIncomingManager();
            var orders = bookIncomingManager.GetOrders(null, partnerId);

            Assert.IsNotNull(orders);
            Assert.AreEqual(3, orders.Count);
        }
    }
}
