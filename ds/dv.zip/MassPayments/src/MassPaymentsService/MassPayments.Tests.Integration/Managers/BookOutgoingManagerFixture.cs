﻿using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.ResourceAccess.OrdersRA;
using MassPayments.ResourceAccess.OrdersRA.Interfaces;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Tests.Integration.Mappers.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Managers
{
    [TestFixture]
    public class BookOutgoingManagerFixture
    {
        private TransactionScope transactionScope;
        private IPublisher<Payment, CustomerBatch, Customer> paymentStatusUpdatedPublisher;
        private IPublisher<Order> orderStatusUpdatedPublisher;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
            PaymentBatchMapper.Instance = MockRepository.GenerateMock<IPaymentBatchMapper>();
            CurrencyCache.Instance.Reinitialize();
            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            paymentStatusUpdatedPublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentStatusUpdatedPublisher), paymentStatusUpdatedPublisher);
            orderStatusUpdatedPublisher = MockRepository.GenerateMock<IPublisher<Order>>();
            PublisherFactory.InjectPublisherForTesting(typeof(OrderStatusUpdatedPublisher), orderStatusUpdatedPublisher);

            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            PaymentBatchMapper.Instance = null;
            CurrencyCache.Instance = null;
            CCTTServiceFactory.InjectedServiceInterface = null;            
            PaymentMapper.Instance = null;
            OrderMapper.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            paymentStatusUpdatedPublisher = null;
            orderStatusUpdatedPublisher = null;
            ValidationRules.Instance = null;
            PaymentMapper.Instance = null;
        }

        [Test]
        public void ProcessSanctionClearedPayments_UpdatesConfirmationNumberAndStatusToFunded()
        {
            const int batchId = 5;
            PaymentBatchMapper.Instance.Expect(pbm => pbm.InsertPaymentBatch(null)).IgnoreArguments().Return(batchId);

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment1.AmountMoney = new Money(Currency.JPY, 10); 
            existingPayment1.PaymentMethod = PaymentMethod.ACH;
            
            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment2.AmountMoney = new Money(Currency.JPY, 20);
            existingPayment2.PaymentMethod = PaymentMethod.ACH;

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment1));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment2));


            CCTTServiceFactory.InjectedServiceInterface.Expect(
                service => service.BookOutgoingOrder(Arg<BookOutgoingOrderRequest>.Is.Anything))
                .Return(new BookOutgoingOrderResult
                {
                    ConfirmationNumber = "TestConfirmationNo",
                    OrderId = 12345
                });
            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
               Return(new HoldingBalanceResult
               {
                   AvailableBalance = 20000.00m,
                   BookedBalance = 20000.00m,
                   Currency = "JPY"
               });
            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();

            bookOutgoingManager.Expect(m =>m.HandleSuccessfulBooking(Arg<AggregatedPayment>.Is.Anything, Arg<Domain.ValueObjects.Booking.BookOutgoingOrderResult>.Is.Anything));

            PaymentMapper.Instance.Expect(pm => pm.UpdatePaymentsConfirmationNo(Arg<int>.Is.Anything, Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<Currency>.Is.Anything, Arg<PaymentStatus>.Is.Anything)).Return(new List<Payment> { existingPayment1, existingPayment2 });
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(customerBatch.Id, "JPY")).Return(new Order { OrderStatus = OrderStatus.Funded });

            var result = bookOutgoingManager.ProcessSanctionClearedPayments(Currency.JPY, PaymentMethod.ACH);
            Assert.AreEqual(2, result.NewBookedOutOfHoldingPayments.Count);
            Assert.True(result.NewBookedOutOfHoldingPayments[0].TransactionSystemOrderId == 12345);
            Assert.True(result.NewBookedOutOfHoldingPayments[0].TransactionSystemOrderNumber.Equals("TestConfirmationNo"));
            Assert.True(result.NewBookedOutOfHoldingPayments[0].IsFunded.Equals(true));
            Assert.True(result.NewBookedOutOfHoldingPayments[1].TransactionSystemOrderId == 12345);
            Assert.True(result.NewBookedOutOfHoldingPayments[1].TransactionSystemOrderNumber.Equals("TestConfirmationNo"));
            Assert.True(result.NewBookedOutOfHoldingPayments[1].IsFunded.Equals(true));
            PaymentMapper.Instance.VerifyAllExpectations();
            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        //FZ TODO: Update after holding service reference is added
        [Test]
        public void ProcessSanctionClearedPayments_CheckHoldingBalancesIsSufficient()
        {
            const int batchId = 5;
            PaymentBatchMapper.Instance.Expect(pbm => pbm.InsertPaymentBatch(null)).IgnoreArguments().Return(batchId);

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment1.PaymentMethod = PaymentMethod.ACH;
            
            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment2.PaymentMethod = PaymentMethod.ACH;

            var existingPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            existingPayment3.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment3.PaymentMethod = PaymentMethod.ACH;

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment1));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment2));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment3));
           
            CCTTServiceFactory.InjectedServiceInterface.Expect(
                service => service.BookOutgoingOrder(Arg<BookOutgoingOrderRequest>.Is.Anything))
                .Return(new BookOutgoingOrderResult
                {
                    ConfirmationNumber = "TestConfirmationNo",
                    OrderId = 12345
                });
            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
               Return(new HoldingBalanceResult
               {
                   AvailableBalance = 200.00m,
                   BookedBalance = 200.00m,
                   Currency = "JPY"
               });

            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();

            bookOutgoingManager.Expect(m => m.HandleSuccessfulBooking(Arg<AggregatedPayment>.Is.Anything, Arg<Domain.ValueObjects.Booking.BookOutgoingOrderResult>.Is.Anything));
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(customerBatch.Id, "JPY")).Return(new Order { OrderStatus = OrderStatus.Funded });
            PaymentMapper.Instance.Expect(pm => pm.UpdatePaymentsConfirmationNo(Arg<int>.Is.Anything, Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<Currency>.Is.Anything, Arg<PaymentStatus>.Is.Anything)).Return(new List<Payment> { existingPayment1, existingPayment2, existingPayment3 });

            var result = bookOutgoingManager.ProcessSanctionClearedPayments(Currency.JPY, PaymentMethod.ACH);
            Assert.AreEqual(2, result.NewBookedOutOfHoldingPayments.Count);
            PaymentMapper.Instance.VerifyAllExpectations();
            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        [Test]
        public void ProcessSanctionClearedPayments_CheckHoldingBalancesIsSufficient_UpdateOrderStatusToFunded()
        {
            OrdersProviderFactory.InjectedOrdersProviderInterface = MockRepository.GenerateMock<IOrdersProvider>();
            const int batchId = 5;
            PaymentBatchMapper.Instance.Expect(pbm => pbm.InsertPaymentBatch(null)).IgnoreArguments().Return(batchId);

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.Id = CustomerMapper.Instance.InsertCustomer(customer);
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            CustomerBatchMapper.Instance.InsertCustomerBatch(customerBatch);

            var existingPayment1 = PaymentHelper.Instance.CreatePayment(customer, "111", customerBatch);
            existingPayment1.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment1.PaymentMethod = PaymentMethod.ACH;

            var existingPayment2 = PaymentHelper.Instance.CreatePayment(customer, "333", customerBatch);
            existingPayment2.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment2.PaymentMethod = PaymentMethod.ACH;

            var existingPayment3 = PaymentHelper.Instance.CreatePayment(customer, "555", customerBatch);
            existingPayment3.PaymentStatus = PaymentStatus.SanctionCleared;
            existingPayment3.PaymentMethod = PaymentMethod.ACH;

            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment1));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment2));
            Assert.DoesNotThrow(() => PaymentMapper.Instance.InsertPayment(existingPayment3));

            CCTTServiceFactory.InjectedServiceInterface.Expect(
                service => service.BookOutgoingOrder(Arg<BookOutgoingOrderRequest>.Is.Anything))
                .Return(new BookOutgoingOrderResult
                {
                    ConfirmationNumber = "TestConfirmationNo",
                    OrderId = 12345
                });
            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
               Return(new HoldingBalanceResult
               {
                   AvailableBalance = 200.00m,
                   BookedBalance = 200.00m,
                   Currency = "JPY"
               });

            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();

            var order = new Order { OrderStatus = OrderStatus.Committed, ConfirmationNumber = "TR123",  };


            bookOutgoingManager.Expect(m => m.HandleSuccessfulBooking(Arg<AggregatedPayment>.Is.Anything, Arg<Domain.ValueObjects.Booking.BookOutgoingOrderResult>.Is.Anything));
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(customerBatch.Id, "JPY")).Return(order);           
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<Currency>.Is.Anything, Arg<PaymentStatus>.Is.Anything)).Return(new List<Payment> { existingPayment1, existingPayment2, existingPayment3 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(new List<string> { order.ConfirmationNumber }))
               .IgnoreArguments()
               .Return(new OrdersFundedStatusResult()
               {
                   Orders = new List<OrderFundedStatusResult>
                   {
                        new OrderFundedStatusResult
                        {
                            OrderId = order.ConfirmationNumber,
                            IsFunded = true,
                            IsOrderFound = false,
                            FundedOnUtc = DateTime.UtcNow.AddMinutes(-5)
                        }
                   }
               });          


            var result = bookOutgoingManager.ProcessSanctionClearedPayments(Currency.JPY, PaymentMethod.ACH);
            Assert.AreEqual(2, result.NewBookedOutOfHoldingPayments.Count);
            PaymentMapper.Instance.VerifyAllExpectations();

            orderStatusUpdatedPublisher.AssertWasCalled(m => m.Publish(Arg<Order>.Is.Anything));
            orderStatusUpdatedPublisher.VerifyAllExpectations();

            OrdersProviderFactory.InjectedOrdersProviderInterface = null;
        }
    }
}
