﻿using System.Transactions;
using MassPayments.Domain.Enums;
using MassPayments.Managers;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Managers
{
   [TestFixture]
    public class CurrencyManagerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

       [Test]
       public void IsCurrencySupportedAndEnabled_ReturnTrue_ForValidCurrency()
       {
           Assert.IsTrue(new CurrencyManager().IsCurrencySupportedAndEnabled("USD"));
       }

       [Test]
       public void IsCurrencySupportedAndEnabled_ReturnFalse_ForInvalidCurrency()
       {
           Assert.IsFalse(new CurrencyManager().IsCurrencySupportedAndEnabled("RandomCurrency"));
       }

       [Test]
       public void IsPaymentMethodSupportedForCurrency_ReturnTrue_ForValidCurrencyAndPaymentMethod()
       {
           Assert.IsTrue(new CurrencyManager().IsPaymentMethodSupportedForCurrency("USD",PaymentMethod.ACH));
       }

       [Test]
       public void IsPaymentMethodSupportedForCurrency_ReturnFalse_ForInvalidCurrency()
       {
           Assert.IsFalse(new CurrencyManager().IsPaymentMethodSupportedForCurrency("RandomCurrency", PaymentMethod.ACH));
       }

       [Test]
       public void IsPaymentMethodSupportedForCurrency_ReturnFalse_ForUnsupportedPaymentMethod()
       {
           Assert.IsFalse(new CurrencyManager().IsPaymentMethodSupportedForCurrency("USD", PaymentMethod.Draft));
       }


    }
}
