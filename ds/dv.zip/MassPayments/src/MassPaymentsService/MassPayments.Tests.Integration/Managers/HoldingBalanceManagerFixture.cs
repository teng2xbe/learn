﻿
namespace MassPayments.Tests.Integration.Managers
{
    //Place holder, calls to Holding Engine Service already covered in UT
    public class HoldingBalanceManagerFixture
    {
        
    }
}
