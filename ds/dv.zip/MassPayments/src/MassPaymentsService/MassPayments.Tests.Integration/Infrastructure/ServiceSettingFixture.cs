﻿using MassPayments.Infrastructure;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure
{
    [TestFixture]
    public class ServiceSettingFixture
    {
        [Test]
        public void GetCctServiceSecurityToken_ReturnsValue()
        {
            Assert.IsNotNullOrEmpty(ServiceSettings.Instance.GetCctServiceSecurityToken());
        }

        [Test]
        public void GetUseNsbMessagingForPain_ReturnsValue()
        {
            Assert.IsTrue(ServiceSettings.Instance.UseNsbBetweenMpsAndPain());
        }
    }
}
