﻿using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Infrastructure.Logger
{
    [TestFixture]
    public class SubscriptionLoggerFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }
    
        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
            ServiceCallContextManager.Instance = null;
        }

        [Test]
        public void GetLogToInsert_Returns_Correctly()
        {
            var logger = MockRepository.GeneratePartialMock<SubscriptionLogger>();
            Assert.True(logger.GetLogToInsert(new ApiChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").ApiChannelSubscriptionId > 0);
            Assert.True(logger.GetLogToInsert(new ApiChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").FileChannelSubscriptionId == 0);
            Assert.True(logger.GetLogToInsert(new ApiChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").EmailChannelSubscriptionId == 0);

            Assert.True(logger.GetLogToInsert(new FileChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").ApiChannelSubscriptionId == 0);
            Assert.True(logger.GetLogToInsert(new FileChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").FileChannelSubscriptionId > 0);
            Assert.True(logger.GetLogToInsert(new FileChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").EmailChannelSubscriptionId == 0);

            Assert.True(logger.GetLogToInsert(new EmailChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").ApiChannelSubscriptionId == 0);
            Assert.True(logger.GetLogToInsert(new EmailChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").FileChannelSubscriptionId == 0);
            Assert.True(logger.GetLogToInsert(new EmailChannelSubscription { Id = 1 }, SubscriptionLogPurpose.Request, "Blah").EmailChannelSubscriptionId > 0);
        }

    }
}
