﻿using System.Collections.Generic;
using System.Transactions;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure.Caches
{
    [TestFixture]
    public class CurrencyPaymentMethodCacheFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void CurrencyPaymentMethodCache_ReturnsCorrectly()
        {
            Assert.AreEqual(new List<PaymentMethod> { PaymentMethod.ACH, PaymentMethod.Wire }, CurrencyPaymentMethodCache.Instance.GetById("USD"));
            Assert.AreEqual(new List<PaymentMethod> { PaymentMethod.ACH, PaymentMethod.Wire }, CurrencyPaymentMethodCache.Instance.GetById("CAD"));

            Assert.AreEqual(new List<PaymentMethod> { PaymentMethod.ACH, PaymentMethod.Wire }, CurrencyPaymentMethodCache.Instance.GetById("AUD"));
            Assert.AreEqual(new List<PaymentMethod> { PaymentMethod.ACH, PaymentMethod.Wire }, CurrencyPaymentMethodCache.Instance.GetById("GBP"));
            Assert.AreEqual(new List<PaymentMethod> { PaymentMethod.ACH, PaymentMethod.Wire }, CurrencyPaymentMethodCache.Instance.GetById("EUR"));
            Assert.AreEqual(new List<PaymentMethod> { PaymentMethod.Wire }, CurrencyPaymentMethodCache.Instance.GetById("JPY"));
        }

    }
}
