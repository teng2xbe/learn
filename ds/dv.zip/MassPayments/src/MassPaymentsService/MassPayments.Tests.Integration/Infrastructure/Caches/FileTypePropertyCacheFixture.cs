﻿using System;
using System.Transactions;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure.Caches
{
    [TestFixture]
    public class FileTypePropertyCacheFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void FileTypePropertyCache_ReturnFileTypeAsExpected()
        {
            Assert.AreEqual(FileType.Beneficiary, (FileType)Enum.Parse(typeof(FileType), FileTypePropertyCache.Instance.GetId("wallets").ToString()));
            Assert.AreEqual(FileType.PaymentBatches, (FileType)Enum.Parse(typeof(FileType), FileTypePropertyCache.Instance.GetId("clientBatches").ToString()));
            Assert.AreEqual(FileType.PaymentCashout, (FileType)Enum.Parse(typeof(FileType), FileTypePropertyCache.Instance.GetId("pendingBankTransfers").ToString()));
            Assert.AreEqual(FileType.ReturnedPayment, (FileType)Enum.Parse(typeof(FileType), FileTypePropertyCache.Instance.GetId("returnedPaymentDetails").ToString()));
            Assert.Throws(typeof(InvalidCacheItemException), () => FileTypePropertyCache.Instance.GetId("asdf"));
        }
    }
}
