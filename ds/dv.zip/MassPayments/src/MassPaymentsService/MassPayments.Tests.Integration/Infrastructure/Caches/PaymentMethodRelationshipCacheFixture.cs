﻿using System;
using System.Transactions;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure.Caches
{
    [TestFixture]
    public class PaymentMethodRelationshipCacheFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [TestCase("US_BANK_IAT_USD", PaymentMethod.ACH)]
        [TestCase("BMO_CAD", PaymentMethod.ACH)]
        [TestCase("WUBS_MASSPAY_WIRE", PaymentMethod.Wire)]
        public void PaymentMethodRelationshipCache_ReturnPaymentMethodAsExpected(string externalMethod, PaymentMethod expectedPaymentMethod )
        {
            Assert.AreEqual(expectedPaymentMethod, PaymentMethodRelationshipCache.Instance.GetById(externalMethod));
        }

        [Test]
        public void PaymentMethodRelationshipCache_Throws_WhenInvalidPaymentMethodsubmitted()
        {
            Assert.Throws(typeof(InvalidCacheItemException), () => PaymentMethodRelationshipCache.Instance.GetById("asdfasdf"));
        }

    }
}

