﻿using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure.Caches
{
    [TestFixture]
    public class PartnerCacheFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void PartnerCacheFixture_ReturnsCorrectly()
        {
            var hyperWallet = PartnerCache.Instance.GetById(1);
            Assert.AreEqual("HyperWallet", hyperWallet.Code);
            var concur = PartnerCache.Instance.GetById(2);
            Assert.AreEqual("Concur", concur.Code);
        }
    }
}