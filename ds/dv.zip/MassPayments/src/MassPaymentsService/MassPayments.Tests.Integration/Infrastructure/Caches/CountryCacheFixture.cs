﻿using System.Transactions;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure.Caches
{
    [TestFixture]
    public class CountryCacheFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void CountryCache_GetsAllTheCorrectCountries()
        {
            Assert.AreEqual(4, CountryCache.Instance.CacheList.Count);
            Assert.IsTrue(CountryCache.Instance.CacheList.Contains("CA"));
            Assert.IsTrue(CountryCache.Instance.CacheList.Contains("US"));
            Assert.IsTrue(CountryCache.Instance.CacheList.Contains("MX"));
            Assert.IsTrue(CountryCache.Instance.CacheList.Contains("AU"));
        }
    }
}
