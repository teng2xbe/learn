﻿using System.Transactions;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure.Caches
{
    [TestFixture]
    public class CurrencyCacheFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [Test]
        public void CurrencyCache_ReturnsCorrectly()
        {
            Assert.AreEqual(CurrencyStatus.Enabled, CurrencyCache.Instance.GetById("USD").Status);
          //Assert.AreEqual(CurrencyStatus.Disabled, CurrencyCache.Instance.GetById("CAD").Status);
            Assert.AreEqual(2, CurrencyCache.Instance.GetById("USD").DecimalPlaces);
            Assert.AreEqual(0, CurrencyCache.Instance.GetById("JPY").DecimalPlaces);
            Assert.AreEqual(0.05, CurrencyCache.Instance.GetById("CHF").RoundToNearestValue);
            Assert.AreEqual(1, CurrencyCache.Instance.GetById("HUF").RoundToNearestValue);
            Assert.AreEqual(0.05, CurrencyCache.Instance.GetById("EGP").RoundToNearestValue);
            Assert.AreEqual(0.1, CurrencyCache.Instance.GetById("INR").RoundToNearestValue);
            Assert.AreEqual(10, CurrencyCache.Instance.GetById("KRW").RoundToNearestValue);
            Assert.AreEqual(0.05, CurrencyCache.Instance.GetById("MAD").RoundToNearestValue);
            Assert.AreEqual(0.05, CurrencyCache.Instance.GetById("SCR").RoundToNearestValue);
          //Assert.AreEqual(0.1, CurrencyCache.Instance.GetById("SKK").RoundToNearestValue);
          //Assert.AreEqual(5000, CurrencyCache.Instance.GetById("TRL").RoundToNearestValue);
            Assert.AreEqual(0.05, CurrencyCache.Instance.GetById("SAR").RoundToNearestValue);
          //Assert.AreEqual(1, CurrencyCache.Instance.GetById("VEB").RoundToNearestValue);
            Assert.AreEqual(0.05, CurrencyCache.Instance.GetById("MUR").RoundToNearestValue);
          //Assert.AreEqual(0.5, CurrencyCache.Instance.GetById("SIT").RoundToNearestValue);
        }

        [Test]
        public void CurrencyCache_CanUseLowerCaseCurrencyStrings()
        {
            Assert.AreEqual(Currency.USD, CurrencyCache.Instance.GetById("usd"));
        }
    }
}