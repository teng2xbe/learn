﻿using System;
using System.Collections.Generic;
using System.Transactions;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Integration.Infrastructure.Caches
{
    [TestFixture]
    public class CurrencyPaymentMethodPainSupportCacheFixture
    {
        private TransactionScope transactionScope;

        [SetUp]
        public void Setup()
        {
            transactionScope = new TransactionScope();
        }

        [TearDown]
        public void TearDown()
        {
            if (transactionScope != null)
                transactionScope.Dispose();
        }

        [TestCase("USD", PaymentMethod.ACH, true)]
        [TestCase("GBP", PaymentMethod.ACH, true)]
        [TestCase("USD", PaymentMethod.Wire, true)]
        [TestCase("GBP", PaymentMethod.Wire, true)]
        public void CurrencyPaymentMethodPainSupportCache_ReturnCorrectly(string currencyCode, PaymentMethod paymentMethod, bool expectation)
        {
            Assert.AreEqual(expectation, CurrencyPaymentMethodPainSupportCache.Instance.GetById(new Tuple<string, PaymentMethod>(currencyCode, paymentMethod)));
        }
    }
}
