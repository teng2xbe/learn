﻿using System.Collections.Generic;
using MassPayments.ActionHandlers;
using MassPayments.Domain.Enums;
using MassPayments.Gateways.Iris;
using MassPayments.Infrastructure.Polling;
using MassPayments.Managers.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Infrastructure
{
    [TestFixture]
    public class IrisPollerFixture
    {
        [SetUp]
        public void Setup()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
        }


        [Test, Explicit("Requires working IRIS service AND authorized account")]
        public void ResponseFromIrisGetsPassedToPaymentManager()
        {
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            var irisPoller = new IrisWsPoller(null, paymentManager);
//            irisPoller.SetIrisPathForTesting("http://10.66.34.145:8090/HardStopService/GetPaymentStatus?dataSourceId=13&paymentIds={0}");
            irisPoller.SetIrisPathForTesting("http://navm-speas101.chdev.local:8095/HardStopService/GetPaymentStatus?dataSourceId=13&paymentIds={0}");
            var paymentIds = new List<int> { 11, 12, 13, 14 };
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentIds(PaymentStatus.Committed)).Return(paymentIds);

            var args = paymentManager.GetArgumentsForCallsMadeOn(pm => pm.UpdatePaymentBlockStatuses(Arg<List<PaymentBlockMessage>>.Is.Anything));
            var paymentBlockMessages = (List<PaymentBlockMessage>)args[0][0];

            PaymentMapper.Instance.VerifyAllExpectations();
            Assert.AreEqual(args.Count, 1);
            Assert.AreEqual(4, paymentBlockMessages.Count);
            Assert.AreEqual(11, paymentBlockMessages[0].Id);
            Assert.AreEqual(IrisPaymentStatus.Unknown, paymentBlockMessages[0].Status);
        }

    }
}
