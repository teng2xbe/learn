﻿using System.Collections.Generic;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Infrastructure.Polling;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Infrastructure
{
    [TestFixture]
    public class PaymentRequestProcessorFixture
    {
        [SetUp]
        public void Setup()
        {
            PaymentRequestMapper.Instance = MockRepository.GenerateStub<IPaymentRequestMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentRequestProcessor.Instance = null;
            PaymentRequestMapper.Instance = null;
        }

        [Test]
        public void TestNotificationsOnEmptyLoopWhenEventHandlersAreNotAssigned()
        {
            PaymentRequestMapper.Instance.Stub(ppm => ppm.GetPaymentRequestForProcessing(10)).Return(new List<PaymentRequestToProcess>());

            using (var subscription = PaymentRequestProcessor.Instance.SubscribeToEvents(null, null, null, null))
            {
                Assert.DoesNotThrow(() => PaymentRequestProcessor.Instance.Process(10));
            }
        }

        [Test]
        public void TestNotificationsOnEmptyLoop()
        {
            PaymentRequestMapper.Instance.Stub(q => q.GetPaymentRequestForProcessing(10)).Return(new List<PaymentRequestToProcess>());

            int requestBatchStart = 0, requestBatchStop = 0, requestPaymentStart = 0, requestPaymentStop = 0;

            using (var subscription = PaymentRequestProcessor.Instance.SubscribeToEvents(
                () => requestBatchStart++,
                () => requestBatchStop++,
                () => requestPaymentStart++,
                () => requestPaymentStop++))
            {
                Assert.DoesNotThrow(() => PaymentRequestProcessor.Instance.Process(10));

                Assert.AreEqual(1, requestBatchStart);
                Assert.AreEqual(1, requestBatchStop);
                Assert.AreEqual(0, requestPaymentStart);
                Assert.AreEqual(0, requestPaymentStop);
            }
        }

        [Test]
        public void TestNotificationsOnEmptyLoopAndSeveralSubscriptions()
        {
            PaymentRequestMapper.Instance.Stub(q => q.GetPaymentRequestForProcessing(10)).Return(new List<PaymentRequestToProcess>());

            int requestBatchStart = 0, requestBatchStop = 0, requestPaymentStart = 0, requestPaymentStop = 0;

            using (var subscription = PaymentRequestProcessor.Instance.SubscribeToEvents(
                () => requestBatchStart++,
                () => requestBatchStop++,
                () => requestPaymentStart++,
                () => requestPaymentStop++))
            {
                using (var subscription2 = PaymentRequestProcessor.Instance.SubscribeToEvents(
                    () => requestBatchStart++,
                    () => requestBatchStop++,
                    () => requestPaymentStart++,
                    () => requestPaymentStop++))
                {
                    Assert.DoesNotThrow(() => PaymentRequestProcessor.Instance.Process(10));

                    Assert.AreEqual(2, requestBatchStart);
                    Assert.AreEqual(2, requestBatchStop);
                    Assert.AreEqual(0, requestPaymentStart);
                    Assert.AreEqual(0, requestPaymentStop);
                }
            }
        }
    }
}
