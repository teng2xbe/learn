﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.ServiceModel;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.Persistence.Enums;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.MassPaymentsQuery;
using MassPayments.Providers.StorageProvider;
using MassPayments.Providers.StorageProvider.Interfaces;
using MassPayments.ServiceProviders.CCTEntityManagement;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.ServiceProviders.MassPaymentsQuery;
using MassPayments.ServiceProviders.SubscriptionsQuery;
using MassPayments.SubscriptionsQuery;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Integration.Infrastructure
{
    //TODO: Modify test methods to actually test missing connection to the database
    [TestFixture]
    public class StartupChecksFixture
    {
        [SetUp]
        public void SetUp()
        {
            DatabaseConnectionStringProvider.Instance = MockRepository.GenerateStub<IDatabaseConnectionStringProvider>();
            CCTTServiceFactory.InjectedServiceInterface = null;
            EntityManagementServiceFactory.InjectedServiceInterface = null;
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();

            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
        }

        [TearDown]
        public void TearDown()
        {
            DatabaseConnectionStringProvider.Instance = null;
            CCTTServiceFactory.InjectedServiceInterface = null;
            EntityManagementServiceFactory.InjectedServiceInterface = null;
            EventLogger.Instance = null;
            PartnerMapper.Instance = null;

            ServiceSettings.Instance = null;
            SubscriptionsQueryServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void StartUpChecks_CheckCCTTServiceWorks()
        {
            var mockedService = MockRepository.GenerateMock<MassPaymentsServiceClient>();
            mockedService.Stub(s => s.Ping());

            CCTTServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteInfoForStartupCheckSuccess(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            Assert.IsTrue(StartupChecks.CheckCCTTService());

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_CheckCCTTServiceFails()
        {
            var mockedService = MockRepository.GenerateMock<MassPaymentsServiceClient>();

            CCTTServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteExceptionToEventLog(Arg<Exception>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            Assert.IsFalse(StartupChecks.CheckCCTTService());

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_CheckCCTEMServiceWorks()
        {
            var mockedService = MockRepository.GenerateMock<CCTEntityManagement.MassPaymentsServiceClient>();
            mockedService.Stub(s => s.Ping());

            EntityManagementServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteInfoForStartupCheckSuccess(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            Assert.IsTrue(StartupChecks.CheckCCTEMService());

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_CheckCCTEMServiceFails()
        {
            var mockedService = MockRepository.GenerateMock<CCTEntityManagement.MassPaymentsServiceClient>();

            EntityManagementServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteExceptionToEventLog(Arg<Exception>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            Assert.IsFalse(StartupChecks.CheckCCTEMService());

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartupChecksFailWhenConnectionToMPSDBFails()
        {
            DatabaseConnectionStringProvider.Instance.Stub((d => d.GetDatabaseConnectionString(Database.MassPayments))).Return("data source=localhost;initial catalog=MassPaymentsDoesNotExist;Integrated Security=SSPI; packet size=4096");

            Assert.IsFalse(StartupChecks.PerformChecks());
        }

        [Test]
        public void StartupChecksFailWhenConnectionToFBSDBFails()
        {
            DatabaseConnectionStringProvider.Instance.Stub((d => d.GetDatabaseConnectionString(Database.FBS))).Return("data source=localhost;initial catalog=FBSDoesNotExist;Integrated Security=SSPI; packet size=4096");

            Assert.IsFalse(StartupChecks.PerformChecks());
        }

        [Test]
        public void StartupChecksFailWhenConnectionToDispatcherDBFails()
        {
            DatabaseConnectionStringProvider.Instance.Stub((d => d.GetDatabaseConnectionString(Database.Dispatcher))).Return("data source=localhost;initial catalog=DispatcherDoesNotExist;Integrated Security=SSPI; packet size=4096");

            Assert.IsFalse(StartupChecks.PerformChecks());
        }

        [Test]
        public void StartupChecksFailWhenConnectionToBIDBFails()
        {
            DatabaseConnectionStringProvider.Instance.Stub((d => d.GetDatabaseConnectionString(Database.BI))).Return("data source=localhost;initial catalog=BIDoesNotExist;Integrated Security=SSPI; packet size=4096");

            Assert.IsFalse(StartupChecks.PerformChecks());
        }

        [Test]
        public void InvoicePathCheck_Works()
        {
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(3);
            Assert.DoesNotThrow(() => StartupChecks.CheckInvoicePath());
            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void JsonPathCheck_Works()
        {
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(3);
            Assert.DoesNotThrow(() => StartupChecks.CheckJsonFilePath());
            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PainPathCheck_Works()
        {
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(4);
            Assert.DoesNotThrow(() => StartupChecks.CheckPainPath());
            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecksDoesNotFailIfEncryptionIsDisabled()
        {
            ServiceSettings.Instance.Stub(s => s.GetBooleanValue("Encryption.EncryptInvoicePdfFile")).Return(false);
   
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            EventLogger.Instance.Expect(e => e.WriteInfo("")).IgnoreArguments();

            Assert.IsTrue(StartupChecks.CheckEncryptionKeyPath());
            EventLogger.Instance.VerifyAllExpectations();
        }
        
        [Test]
        public void StartUpChecks_FailsForInValidPgpKeyRootPath()
        {
            ServiceSettings.Instance.Stub(s => s.GetStringValue("Encryption.PgpKeyRootPath")).Return("gorilla");
            ServiceSettings.Instance.Stub(s => s.GetBooleanValue("Encryption.EncryptInvoicePdfFile",true)).Return(true);
            Assert.IsFalse(StartupChecks.CheckEncryptionKeyPath());
        }

        [Test]
        public void StartUpChecks_FailsForMissingPublicFolderInPgpKeyRootPath()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            ServiceSettings.Instance.Stub(s => s.GetStringValue("Encryption.PgpKeyRootPath")).Return("gorilla");
            ServiceSettings.Instance.Stub(s => s.GetBooleanValue("Encryption.EncryptInvoicePdfFile", true)).Return(true);
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Assert.IsFalse(StartupChecks.CheckEncryptionKeyPath());
        }

        [Test]
        public void StartUpChecks_WorksIfPartnerPrivateAndPublicFoldersExistUnderPgpKeyRootPath()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Encryption.PgpKeyRootPath"].Value = Directory.GetCurrentDirectory();
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            EventLogger.Instance.Expect(el => el.WriteInfoForStartupCheckSuccess(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(1);

            ServiceSettings.Instance.Stub(s => s.GetBooleanValue("Encryption.EncryptInvoicePdfFile", true)).Return(true);
            var partnerDir = Path.Combine(Directory.GetCurrentDirectory(), "partnerCode");
            Directory.CreateDirectory(partnerDir);
            Directory.CreateDirectory(Path.Combine(partnerDir, "public"));
            Directory.CreateDirectory(Path.Combine(partnerDir, "private"));
            PartnerMapper.Instance.Expect(p => p.GetPartnersDictionary()).Return(new Dictionary<int, Partner> { { 0, new Partner { Code = "partnerCode" } } });
            PartnerCache.Instance.Reinitialize();

            Assert.IsTrue(StartupChecks.CheckEncryptionKeyPath());
            PartnerMapper.Instance.VerifyAllExpectations();
            EventLogger.Instance.VerifyAllExpectations();

            Directory.Delete(partnerDir, true);
        }

        [Test]
        public void StartUpChecks_LogsSuccess_ForSnqsConnection()
        {
            var mockedService = MockRepository.GenerateMock<SubscriptionsQueryServiceClient>();
            mockedService.Stub(s => s.Ping());

            SubscriptionsQueryServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteInfoForStartupCheckSuccess(Arg<string>.Is.Anything,Arg<string>.Is.Anything,Arg<EventCode>.Is.Anything));
            StartupChecks.CheckSnqsService();

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_LogsFail_ForSnqsConnection()
        {
            var mockedService = MockRepository.GenerateMock<SubscriptionsQueryServiceClient>();
            mockedService.Stub(s => s.Ping()).Throw(new Exception());

            SubscriptionsQueryServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteExceptionToEventLog(Arg<Exception>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            StartupChecks.CheckSnqsService();

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_LogsSuccess_ForMpqConnection_UsingSimulator()
        {
            var mockedService = MockRepository.GenerateMock<MassPaymentsQueryServiceClient>();
            mockedService.Stub(s => s.Ping());

            MassPaymentsQueryServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteInfoForStartupCheckSuccess(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            StartupChecks.CheckMpqService();

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_LogsFail_ForMpqConnection_UsingEndpoint()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.MassPaymentsQueryService"].Value = "false";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            EventLogger.Instance.Expect(e => e.WriteExceptionToEventLog(Arg<Exception>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            StartupChecks.CheckMpqService();

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_LogsFail_ForMpqConnection_GenericException()
        {
            var mockedService = MockRepository.GenerateMock<MassPaymentsQueryServiceClient>();
            mockedService.Stub(s => s.Ping()).Throw(new Exception());

            MassPaymentsQueryServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteExceptionToEventLog(Arg<Exception>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            StartupChecks.CheckMpqService();

            EventLogger.Instance.VerifyAllExpectations();
        }

        [Test]
        public void StartUpChecks_LogsFail_ForMpqConnection_FaultException()
        {
            var mockedService = MockRepository.GenerateMock<MassPaymentsQueryServiceClient>();
            mockedService.Stub(s => s.Ping()).Throw(new FaultException());

            MassPaymentsQueryServiceFactory.InjectedServiceInterface = mockedService;
            EventLogger.Instance.Expect(e => e.WriteExceptionToEventLog(Arg<Exception>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));
            StartupChecks.CheckMpqService();

            EventLogger.Instance.VerifyAllExpectations();
        }
    }
}
