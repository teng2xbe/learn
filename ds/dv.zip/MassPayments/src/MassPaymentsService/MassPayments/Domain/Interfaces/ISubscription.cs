﻿using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Interfaces
{
    public interface ISubscription
    {
        int Id { get; set; }
        int PartnerId { get; set; }
        SubscriptionType SubscriptionType { get; set; }
    }
}
