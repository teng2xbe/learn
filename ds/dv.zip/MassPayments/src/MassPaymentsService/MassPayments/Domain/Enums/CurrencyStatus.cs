﻿namespace MassPayments.Domain.Enums
{
    public enum CurrencyStatus
    {
        Enabled = 1,
        Disabled = 2
    }
}