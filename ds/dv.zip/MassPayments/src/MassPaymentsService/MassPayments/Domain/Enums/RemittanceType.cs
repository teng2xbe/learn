﻿namespace MassPayments.Domain.Enums
{
    public enum RemittanceType
    {
        Undefined,
        CTX,
        CCD,
        PPD,
        IAT
    }
}
