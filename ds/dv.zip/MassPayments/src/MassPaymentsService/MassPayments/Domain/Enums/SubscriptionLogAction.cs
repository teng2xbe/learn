﻿namespace MassPayments.Domain.Enums
{
    public enum SubscriptionLogPurpose
    {
        Request,
        RequestFailed,
        Response
    }
}
