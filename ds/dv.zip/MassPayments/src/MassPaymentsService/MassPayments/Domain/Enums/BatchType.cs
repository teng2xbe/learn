﻿
namespace MassPayments.Domain.Enums
{
    public enum BatchType
    {
        FileBatch = 1,
        PaymentRequest = 2,
        ApiBatch = 3
    }
}
