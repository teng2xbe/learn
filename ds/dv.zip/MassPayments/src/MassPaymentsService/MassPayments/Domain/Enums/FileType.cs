﻿namespace MassPayments.Domain.Enums
{
    public enum FileType
    {
        Beneficiary = 1,
        PaymentBatches = 2,
        PaymentCashout = 3,
        ReturnedPayment = 4
    }
}
