﻿namespace MassPayments.Domain.Enums
{
    public enum CustomerBatchStatus
    {
        Created = 0,
        Committed = 1,
        Funded = 2,
        Processing = 3,
        Completed = 4
    }
}
