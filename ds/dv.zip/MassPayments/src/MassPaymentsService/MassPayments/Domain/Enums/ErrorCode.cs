﻿namespace MassPayments.Domain.Enums
{
    public enum ErrorCode
    {

        AccessDenied = 1001,
        NotAuthorized = 1002,

        GenericMassPaymentsServiceError = 1100,
        ResourceNotFound = 1101,
        QuoteInvalid = 1102,
        QuoteExpired = 1103,
        CurrencyUnsupported = 1104,
        PaymentCancellationNotAllowed = 1105,
        MultipleBankAccountsExist = 1106,
        CustomerNotFound = 1107,
        CustomerNotEnabledForMassPay = 1108,
        AmountTooHigh = 1110,
        
        AmountInvalid = 1109,
        CurrencyNotSubmitted = 1111,
        CurrencyNotSupported = 1112,
        CurrencyInvalid = 1113,
        CurrencyPaymentMethodCombinationNotSupported = 1115,
        PaymentMethodInvalid = 1116,
        RemittanceTypeInvalid = 1117,
        RemittanceTypeMismatch = 1118,
        GenericInvalidInput = 1300,
        GenericMassPayError = 1100,
        CustomerDoesNotExist = 1107
    }
}
