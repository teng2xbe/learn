﻿namespace MassPayments.Domain.Enums
{
    public enum SubscriptionType
    {
        FundingStatus = 1,
        PaymentStatus = 2,
        Ping = 3,
        Invoice = 4
    }
}
