﻿namespace MassPayments.Domain.Enums
{
    public enum PaymentModel
    {
        Coupled = 1,
        Decoupled = 2
    }
}
