﻿namespace MassPayments.Domain.Enums
{
    public enum SortDirection
    {
        ASC, DESC
    }
}
