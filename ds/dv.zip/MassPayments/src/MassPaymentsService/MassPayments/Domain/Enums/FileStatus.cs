﻿namespace MassPayments.Domain.Enums
{
    public enum FileStatus
    {
        Pending = 1,
        Processed = 2,
        FailedToProcess = 3,
        ProcessedWithError = 4
    }
}
