﻿namespace MassPayments.Domain.Enums
{
    public enum PaymentSanctionScanStatus
    {
        Block = 0,
        Unknown = 1,
        PermanentBlock = 2,
        Unblock = 3
    }
}
