﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MassPayments.Domain.Enums
{
    public enum SettlementPaymentMethod
    {
        Undefined,
        ACH = 1,
        Wire =2,
        OtherDefault = 99
    }
}
