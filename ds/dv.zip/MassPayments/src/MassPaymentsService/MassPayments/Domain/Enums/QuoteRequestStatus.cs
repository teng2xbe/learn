﻿namespace MassPayments.Domain.Enums
{
    public enum QuoteRequestStatus
    {
        Failed = 1,
        Created = 2,
        Committed = 3,
        Expired = 4
    }
}
