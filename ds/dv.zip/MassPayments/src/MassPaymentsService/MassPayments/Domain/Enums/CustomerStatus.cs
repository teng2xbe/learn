﻿namespace MassPayments.Domain.Enums
{
    public enum CustomerStatus
    {
        Enabled = 1,
        Disabled = 2
    }
}
