﻿namespace MassPayments.Domain.Enums
{
    public enum SubscriptionEventType
    {
        FundingStatusChanged = 1,
        PaymentStatusChanged = 2,
        PingRequested = 3,
        InvoiceGenerated = 4
    }
}
