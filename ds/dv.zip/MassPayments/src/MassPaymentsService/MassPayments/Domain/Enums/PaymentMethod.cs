﻿namespace MassPayments.Domain.Enums
{
    public enum PaymentMethod
    {
        //Undefined = 0,
        ACH = 1,
        Draft = 2,
        Wire = 3
    }
}
