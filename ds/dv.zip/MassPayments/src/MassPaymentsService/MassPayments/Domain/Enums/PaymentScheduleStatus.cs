﻿namespace MassPayments.Domain.Enums
{
    public enum PaymentScheduleStatus
    {
        Failed = 1,
        Successful = 2,
        MaxRetryFailed = 3
    }
}
