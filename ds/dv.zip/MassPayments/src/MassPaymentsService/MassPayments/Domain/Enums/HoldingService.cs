﻿namespace MassPayments.Domain.Enums
{
    public enum HoldingService
    {
        WUBS = 1,
        CCTT = 2
    }
}
