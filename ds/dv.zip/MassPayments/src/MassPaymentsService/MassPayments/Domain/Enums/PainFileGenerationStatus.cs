﻿namespace MassPayments.Domain.Enums
{
    public enum PainFileGenerationStatus
    {
        NullStatus = 0, //should not happen in normal flows.
        NotGenerated = 1,
        Sent = 2,
        FailedToSend = 3,
        SendByThirdParty = 4
    }
}
