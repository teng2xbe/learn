﻿namespace MassPayments.Domain.Enums
{
    public enum PaymentStatus
    {
        Undefined = 0,
        Created = 1,
        Committed = 2,
        SanctionCleared = 3,
        Sent = 4,
        Released = 5,
        Rejected = 6,
        SanctionBlocked = 7,
        Reconciled = 8,
        Cancelled = 9,
        Returned = 10
    }
}
