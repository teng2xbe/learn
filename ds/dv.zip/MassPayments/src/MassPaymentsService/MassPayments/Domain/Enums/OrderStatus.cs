﻿namespace MassPayments.Domain.Enums
{
    public enum OrderStatus
    {
        NotFound = 0,
        Committed = 1,
        Received = 2,
        Funded = 3,
        Cancelled = 4
    }
}
