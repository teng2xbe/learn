﻿namespace MassPayments.Domain.Enums
{
    public enum TransactionSystem
    {
        Spot = 1,
        CCT = 10
    }
}
