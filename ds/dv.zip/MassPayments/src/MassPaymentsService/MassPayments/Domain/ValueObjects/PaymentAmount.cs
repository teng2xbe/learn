﻿using MassPayments.Domain.Entities;

namespace MassPayments.Domain.ValueObjects
{
    public class PaymentAmount
    {
        public Money Money { get; set; }
        public Money SettlementMoney { get; set; }
        public bool IsFixedAmountInSettlementCurrency { get; set; }
    }
}
