﻿using System;

namespace MassPayments.Domain.ValueObjects
{
    public class PublishedNotification
    {
        public Guid Id { get; set; }

        public string WebhookUrl { get; set; }

        public DateTime PublishedOnUtc { get; set; }

        public Guid DomainEventId { get; set; }

        public Guid WebhookId { get; set; }

        public string Payload { get; set; }

        public int SubscriberApplicationId { get; set; }

        public string SubscriberCode { get; set; }
    }
}
