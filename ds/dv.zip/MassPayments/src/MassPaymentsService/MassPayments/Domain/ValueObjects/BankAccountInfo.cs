﻿using System;

namespace MassPayments.Domain.ValueObjects
{
    public class BankAccountInfo
    {
        public string Id { get; set; }
        public string Status { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public string BankName { get; set; }
        public string CurrencyCode { get; set; }
        public string RoutingCode { get; set; }
        public string SwiftCode { get; set; }
        public string AccountHolderName { get; set; }
        public bool IsDirectDebit { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string StateOrProvince { get; set; }
        public string City { get; set; }
        public string ZipOrPostalCode { get; set; }
        public string CountryCode { get; set; }
    }
}
