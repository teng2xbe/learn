﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;

namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookIncomingOrderRequest
    {
        public Currency SettlementCurrency { get; set; }
        public string SettlementMethod { get; set; }
        public List<BookIncomingOrderRequestItem> ItemsToBook { get; set; }
    }
}
