﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;

namespace MassPayments.Domain.ValueObjects.Batches
{
    public class CommitBatchRequest
    {
        public CustomerBatch CustomerBatch { get; set; }

        public List<CommitBatchSettlementRequest> Settlements { get; set; }
    }
}
