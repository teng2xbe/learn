﻿using System;

namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookIncomingOrderResult
    {
        public string OrderConfirmationNo { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public string OrderStatus { get; set; }
        public string PartnerAssignedCustomerId { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public string PartnerReference { get; set; }
        public string BatchId { get; set; }
        public string BatchReference { get; set; }
    }
}
