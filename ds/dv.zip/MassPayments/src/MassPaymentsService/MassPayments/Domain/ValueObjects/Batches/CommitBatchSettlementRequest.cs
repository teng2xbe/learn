﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.ValueObjects.Batches
{
    public class CommitBatchSettlementRequest
    {
        public Currency SettlementCurrency { get; set; }
        public SettlementPaymentMethod SettlementMethod { get; set; }
    }
}
