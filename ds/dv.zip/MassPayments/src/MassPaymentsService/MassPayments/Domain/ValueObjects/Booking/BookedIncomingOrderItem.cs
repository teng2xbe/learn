﻿namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookedIncomingOrderItem
    {
        public decimal Fee { get; set; }
        public int ItemId { get; set; }
        public int Number { get; set; }
        public decimal RateValue { get; set; }
        public decimal SettlementAmount { get; set; }
        public decimal TradeAmount { get; set; }
        public string TradeCurrencyCode { get; set; }
    }
}
