﻿
namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookOutgoingOrderRequestItem
    {
        public decimal Amount { get; set; }

        public string TradeCurrencyCode { get; set; }

        public bool IsAmountInSettlementCurrency { get; set; }

        public string PaymentMethod { get; set; }
    }
}
