﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.ValueObjects.Batches
{
    public class CommitBatchOrderResult
    {
        public string OrderId { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastUpdatedOn { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public Currency SettlementCurrency { get; set; }
        public string SettlementMethod { get; set; }
    }
}
