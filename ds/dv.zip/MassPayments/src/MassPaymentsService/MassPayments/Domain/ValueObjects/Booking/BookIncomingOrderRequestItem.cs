﻿using MassPayments.Domain.Entities;

namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookIncomingOrderRequestItem
    {
        public Money AmountMoney { get; set; }
        public Currency TradeCurrency { get; set; }
        public bool IsAmountInSettlementCurrency { get; set; }
    }
}
