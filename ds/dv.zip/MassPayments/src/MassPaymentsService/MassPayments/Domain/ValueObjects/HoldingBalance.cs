﻿using MassPayments.Domain.Entities;

namespace MassPayments.Domain.ValueObjects
{
    public class HoldingBalance
    {
        public Currency Currency { get; set; }
        public Money AvailableBalance { get; set; }
        public Money BookedBalance { get; set; }
    }
}
