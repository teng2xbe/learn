﻿using System;

namespace MassPayments.Domain.ValueObjects
{
    public class WebhookPushedEvent
    {
        public string EventType { get; set; }

        public string Status { get; set; }

        public DateTime PushedOnUtc { get; set; }
    }
}
