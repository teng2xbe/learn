﻿using System.Collections.Generic;
using NHibernate.Mapping;

namespace MassPayments.Domain.ValueObjects.Batches
{
    public class CommitBatchResult
    {
        public List<CommitBatchOrderResult> Orders { get; set; }
    }
}
