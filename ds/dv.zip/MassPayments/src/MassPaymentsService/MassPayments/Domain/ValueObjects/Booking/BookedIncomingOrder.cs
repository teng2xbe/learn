﻿using System;
using System.Collections.Generic;

namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookedIncomingOrder
    {
        public string ConfirmationNumber { get; set; }
        public int OrderId { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public List<BookedIncomingOrderItem> LineItems;
        public string SettlementPaymentMethod { get; set; }
        public BookedIncomingOrderBankAccount SettlementBankAccount { get; set; }
        public DateTime OrderDate { get; set; }
    }
}
