﻿using System;
using MassPayments.Domain.Entities;

namespace MassPayments.Domain.ValueObjects.Quoting
{
    public class QuoteRequestItem
    {
        public Money FixedTradeMoney { get; set; }
        public Money FixedSettlementMoney { get; set; }
        public DateTime ValueDate { get; set; }
    }
}
