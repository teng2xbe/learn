﻿namespace MassPayments.Domain.ValueObjects
{
    public class LineItem
    {
        public string TradeCurrencyCode { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public decimal Amount { get; set; }
        public bool IsAmountInSettlementCurrency { get; set; }
    }
}
