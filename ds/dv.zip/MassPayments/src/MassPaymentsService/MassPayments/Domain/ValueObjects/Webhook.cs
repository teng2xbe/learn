﻿using System;

namespace MassPayments.Domain.ValueObjects
{
    public class Webhook
    {
        public Guid Id { get; set; }

        public string Uri { get; set; }

        public bool? IsPrimary { get; set; }

        public string SecurityToken { get; set; }

        public DateTime CreatedOnUtc { get; set; }

        public DateTime UpdatedOnUtc { get; set; }

        public WebhookPushedEvent LastPushedEvent { get; set; }
    }
}
