﻿namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookedIncomingOrderBankAccount
    {
        public string AccountNumber { get; set; }
        public string BankAccountOwnerName { get; set; }
        public string BankAddress1 { get; set; }
        public string BankAddress2 { get; set; }
        public string BankAddress3 { get; set; }
        public string BankCountry { get; set; }
        public string BankName { get; set; }
        public int Id { get; set; }
        public string RoutingCode { get; set; }
        public string SWIFTCode { get; set; }
    }
}
