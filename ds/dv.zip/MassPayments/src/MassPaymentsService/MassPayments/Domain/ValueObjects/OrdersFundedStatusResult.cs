﻿using System.Collections.Generic;

namespace MassPayments.Domain.ValueObjects
{
    public class OrdersFundedStatusResult
    {
        public List<OrderFundedStatusResult> Orders { get; set; }
    }
}
