﻿using System.Collections.Generic;

namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookOutgoingOrderRequest
    {
        public int ClientId { get; set; }

        public string SettlementCurrencyCode { get; set; }

        public List<BookOutgoingOrderRequestItem> ItemsToBook { get; set; }
    }
}
