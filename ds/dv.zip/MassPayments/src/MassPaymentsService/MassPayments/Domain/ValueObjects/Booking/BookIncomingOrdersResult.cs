﻿using System.Collections.Generic;

namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookIncomingOrdersResult
    {
        public List<BookIncomingOrderResult> BookedOrders { get; set; }
    }
}
