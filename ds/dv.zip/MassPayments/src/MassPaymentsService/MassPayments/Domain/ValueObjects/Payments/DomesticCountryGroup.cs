﻿using System.Collections.Generic;
using System.Linq;
using MassPayments.Domain.Entities;

namespace MassPayments.Domain.ValueObjects.Payments
{
    public class DomesticCountryGroup
    {
        private List<string> countryCodes;

        public List<string> CountryCodes
        {
            get{ return countryCodes;   }
            set { countryCodes = value.Select(s => s.ToUpper()).ToList(); }
        }

        public Currency Currency { get; set; }
    }
}
