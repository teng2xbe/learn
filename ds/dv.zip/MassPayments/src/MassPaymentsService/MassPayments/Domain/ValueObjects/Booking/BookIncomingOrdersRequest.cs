﻿using System.Collections.Generic;

namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookIncomingOrdersRequest
    {
        public int QuoteId { get; set; }
        public string QuoteGuid { get; set; }
        public List<BookIncomingOrderRequest> OrdersToBook { get; set; }
        public bool ShouldEnsureCustomerBatch { get; set; }
        public string PartnerReference { get; set; }
        public string BatchId { get; set; }
        public string BatchReference { get; set; }
    }
}
