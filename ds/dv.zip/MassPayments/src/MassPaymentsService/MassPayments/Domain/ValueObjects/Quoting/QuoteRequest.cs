﻿using System.Collections.Generic;

namespace MassPayments.Domain.ValueObjects.Quoting
{
    public class QuoteRequest
    {
        public string PartnerReference { get; set; }
        public List<QuoteRequestItem> ItemsToQuote { get; set; }
    }
}
