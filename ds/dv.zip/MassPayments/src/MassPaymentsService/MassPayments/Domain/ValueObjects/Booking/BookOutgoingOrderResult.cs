﻿namespace MassPayments.Domain.ValueObjects.Booking
{
    public class BookOutgoingOrderResult
    {
        public int OrderId { get; set; }

        public string ConfirmationNumber { get; set; }
    }
}
