﻿using System;

namespace MassPayments.Domain.ValueObjects
{
    public class OrderFundedStatusResult
    {
        public string OrderId { get; set; }
        public bool IsOrderFound { get; set; }
        public bool IsFunded { get; set; }
        public DateTime FundedOnUtc { get; set; }
    }
}
