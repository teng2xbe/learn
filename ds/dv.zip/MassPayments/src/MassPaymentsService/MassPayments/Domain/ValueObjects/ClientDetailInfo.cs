﻿namespace MassPayments.Domain.ValueObjects
{
    public class ClientDetailInfo
    {
        public int Id { get; set; }
        public string AccountNumber { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string City { get; set; }
        public string CompanyName { get; set; }
        public string CountryCode { get; set; }
        public string DefaultUserName { get; set; }
        public string InvoiceLanguageCode { get; set; }
        public string OfficeAddress { get; set; }
        public string OfficeFaxNumber { get; set; }
        public int OfficeId { get; set; }
        public string OfficeLegalEntityLicenseNumber { get; set; }
        public string OfficeLegalEntityLongName { get; set; }
        public string OfficeLegalEntityShortName { get; set; }
        public string OfficeName { get; set; }
        public string OfficePhoneNumber { get; set; }
        public string OfficeTollFreePhoneNumber { get; set; }
        public string PostalCode { get; set; }
        public string ProcessCenterCode { get; set; }
        public int ProcessCenterId { get; set; }
        public string State { get; set; }
    }
}
