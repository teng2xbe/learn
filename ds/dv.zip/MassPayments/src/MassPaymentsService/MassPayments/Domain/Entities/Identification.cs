﻿using System.Text;

namespace MassPayments.Domain.Entities
{
    public class Identification
    {
        public string EntityType { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string CellNumber { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string BusinessName { get; set; }
        public string BusinessRegistrationNumber { get; set; }
        public string BusinessRegistrationCountry { get; set; }
        public string BusinessRegistrationStateProv { get; set; }
        public string BusinessContactRole { get; set; }
        public string Industry { get; set; }
        public string EmailAddress { get; set; }

        public string GetName()
        {
            if (!string.IsNullOrEmpty(BusinessName))
            {
                return BusinessName;
            }

            var name = new StringBuilder();

            if (!string.IsNullOrEmpty(FirstName))
                name.Append(FirstName);

            if (!string.IsNullOrEmpty(MiddleName))
                name.Append(" ").Append(MiddleName);

            if (!string.IsNullOrEmpty(LastName))
                name.Append(" ").Append(LastName);

            return name.ToString();
        }
    }
}
