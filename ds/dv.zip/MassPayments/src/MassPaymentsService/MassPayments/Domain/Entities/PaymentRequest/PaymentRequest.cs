﻿using System;
using System.Collections.Generic;
using System.Text;
using MassPayments.Domain.Entities.PaymentRequest.Validators;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Logger;
using Newtonsoft.Json;

namespace MassPayments.Domain.Entities.PaymentRequest
{
    public class PaymentRequest
    {
        public int ItemIndex { get; set; }
        public int PartnerId { get; set; }
        [JsonIgnore]
        public int PaymentRequestArchiveDetailId { get; set; }
        public string PartnerAssignedCustomerId { get; set; }
        public string PartnerReference { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentId { get; set; }
        public long FixedAmount { get; set; }
        public string CurrencyCode { get; set; }        
        public bool IsFixedAmountInSettlementCurrency { get; set; }
        public Beneficiary Beneficiary { get; set; }
        public BankAccount BankAccount { get; set; }
        public string ExternalBatchId { get; set; }
        public string PurposeOfPayment { get; set; }
        public string InstructionForBank { get; set; }
        public string InstructionCodeForBank { get; set; }
        public List<RemittanceReference> UnstructuredRemittance { get; set; }
        public List<RemittanceReference> StructuredRemittance { get; set; }
        public string RemittanceType { get; set; }
        public List<RemittanceReference> RemittanceData { get; set; }
        public ThirdPartyRemitter ThirdPartyRemitter { get; set; }
        public string PaymentReference { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public long SettlementAmount { get; set; }

        [JsonIgnore]
        public string PaymentVersionId { get; set; }

        [JsonIgnore]
        public DateTime ProcessedOnUtc { get; set; }

        [JsonIgnore]
        public string Message { get; set; }
        
        [JsonIgnore]
        public bool HasFailed { get; private set; }
        
        [JsonIgnore]
        public int CustomerBatchId { get; private set; }
        
        [JsonIgnore]
        public Customer Customer { get; private set; }

        [JsonIgnore] private Partner partner;

        public void Validate(bool validateRequiredForRelease)
        {
            IPaymentRequestResult result = null;

            try
            {
                SetValidators(validateRequiredForRelease);
                result = RunValidators();
            }
            catch (Exception ex)
            {
                result = new PaymentRequestFailedResult<string>(ex);

                EventLogger.Instance.WriteError(
                    new StringBuilder().AppendLine(ex.Message).AppendLine(ex.StackTrace).ToString(),
                    new ExceptionToEventCodeConverter().GetErrorEventCodeForException(ex));

            }
            finally
            {
                if (result != null)
                    result.Record(this);
            }
        }

        public void SetCustomer(Customer customer)
        {
            Customer = customer;
        }

        public void SetCustomerBatchId(int customerBatchId)
        {
            CustomerBatchId = customerBatchId;
        }

        public void RecordSuccessfulValidation()
        {
            HasFailed = false;
        }

        public void RecordFailedValidation(string message)
        {
            Message = message;
            HasFailed = true;
        }

        private readonly List<IPaymentRequestValidator> validators = new List<IPaymentRequestValidator>();

        private IPaymentRequestResult RunValidators()
        {
            foreach (var validator in validators)
            {
                var result = validator.Validate();
                if (result.HasFailed())
                    return result;
            }

            return new PaymentRequestSuccessful();
        }

        private void SetValidators(bool validateRequiredForRelease)
        {
            AddValidator(new PaymentRequiredFieldsValidator(this));
            AddValidator(new FormatValidator(this));

            if(partner.PaymentModel == PaymentModel.Coupled)
                AddValidator(new PaymentSettlementCurrencyValidator(this));
        }

        private void AddValidator(IPaymentRequestValidator validator)
        {
            validators.Add(validator);
        }

        public void SetPartner(Partner partner)
        {
            this.partner = partner;
        }
    }
}
