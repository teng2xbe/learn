﻿
namespace MassPayments.Domain.Entities.PaymentRequest
{
    public class Address
    {
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string City { get; set; }
        public string StateOrPovince { get; set; }
        public string ZipOrPostalCode { get; set; }
        public string CountryCode { get; set; }
    }
}
