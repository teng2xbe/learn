﻿using System;

namespace MassPayments.Domain.Entities
{
    public class BatchFile
    {
        public int Id { get; set; }
        public int CustomerBatchId { get; set; }
        public int FileId { get; set; }
    }
}
