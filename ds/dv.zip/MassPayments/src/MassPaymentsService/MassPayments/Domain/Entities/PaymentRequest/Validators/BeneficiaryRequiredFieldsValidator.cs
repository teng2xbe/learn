﻿using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class BeneficiaryRequiredFieldsValidator: IPaymentRequestValidator
    {
        private readonly Beneficiary beneficiaryRequest;

        public BeneficiaryRequiredFieldsValidator(Beneficiary beneficiary)
        {
            beneficiaryRequest = beneficiary;
        }

        public IPaymentRequestResult Validate()
        {
            if (beneficiaryRequest == null)
                return new PaymentRequestFailedResult<string>(ErrorCode.RequiredField, "beneficiary");

            if (string.IsNullOrEmpty(beneficiaryRequest.Id))
                return new PaymentRequestFailedResult<string>(() => beneficiaryRequest.Id);

            if (string.IsNullOrEmpty(beneficiaryRequest.VersionedOn))
                return new PaymentRequestFailedResult<string>(() => beneficiaryRequest.VersionedOn);

            if (string.IsNullOrEmpty(beneficiaryRequest.Type) || !(beneficiaryRequest.Type.Trim().ToLower() == "individual" || beneficiaryRequest.Type.Trim().ToLower() == "business"))
                return new PaymentRequestFailedResult<string>(() => beneficiaryRequest.Type);

            if (beneficiaryRequest.Type.Trim().ToLower() == "individual")
            {
                if (string.IsNullOrEmpty(beneficiaryRequest.FirstName))
                    return new PaymentRequestFailedResult<string>(() => beneficiaryRequest.FirstName, ErrorCode.ConditionalField);

                if (string.IsNullOrEmpty(beneficiaryRequest.LastName))
                    return new PaymentRequestFailedResult<string>(() => beneficiaryRequest.LastName, ErrorCode.ConditionalField);
            }

            if (beneficiaryRequest.Type.Trim().ToLower() == "business" && string.IsNullOrEmpty(beneficiaryRequest.BusinessName))
                return new PaymentRequestFailedResult<string>(() => beneficiaryRequest.BusinessName, ErrorCode.ConditionalField);

            if (beneficiaryRequest.Address == null)
                return new PaymentRequestFailedResult<Address>(() => beneficiaryRequest.Address);

            return new PaymentRequestSuccessful();
        }
    }
}
