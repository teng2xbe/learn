﻿
namespace MassPayments.Domain.Entities.PaymentRequest
{
    public class Beneficiary
    {
        public string Id { get; set; }
        public string VersionedOn { get; set; }
        public string EmailAddress { get; set; }
        public string Type { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string CellNumber { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string BusinessName { get; set; }
        public string BusinessRegistrationNumber { get; set; }
        public string BusinessRegistrationCountry { get; set; }
        public string BusinessRegistrationStateProv { get; set; }
        public string BusinessContactRole { get; set; }
        public string Industry { get; set; }
        public Address Address { get; set; }
    }
}
