﻿using System;
using MassPayments.Domain.Enums;
using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class RemittanceTypeValidator : IPaymentRequestValidator
    {
        private readonly PaymentRequest paymentRequest;
        private RemittanceType remittanceType;

        public RemittanceTypeValidator(PaymentRequest paymentRequest)
        {
            this.paymentRequest = paymentRequest;
        }

        public IPaymentRequestResult Validate()
        {
            if (string.IsNullOrEmpty(paymentRequest.RemittanceType))
                return new PaymentRequestSuccessful();

            if (!IsValidRemittanceType(paymentRequest.RemittanceType))
                return new PaymentRequestFailedResult<string>(ErrorCode.RemittanceTypeInvalid);

            if (!IsApplicableCurrencyAndPaymentMethod())
                return new PaymentRequestFailedResult<string>(ErrorCode.RemittanceTypeMismatch);

            if (paymentRequest.Beneficiary == null || string.IsNullOrEmpty(paymentRequest.Beneficiary.Type)) 
                return new PaymentRequestSuccessful();

            if (!IsValidRemittanceTypeForBeneficiary(paymentRequest.Beneficiary.Type.ToLower()))
                return new PaymentRequestFailedResult<string>(ErrorCode.RemittanceTypeMismatch);

            return new PaymentRequestSuccessful();
        }

        private bool IsValidRemittanceTypeForBeneficiary(string beneType)
        {
            if (paymentRequest.Customer == null)
                return true;

            var countryCode = paymentRequest.Customer.CountryCode;

            if (string.IsNullOrEmpty(countryCode))
                countryCode = "";

            switch (remittanceType)
            {
                case RemittanceType.PPD:
                    return beneType == "individual" && countryCode == "US";
                case RemittanceType.CCD:
                    return beneType == "business" && countryCode == "US";
                case RemittanceType.CTX:
                    return beneType == "business" && countryCode == "US" && paymentRequest.RemittanceData != null && paymentRequest.RemittanceData.Count != 0;
                case RemittanceType.IAT:
                    return countryCode != "US";
                case RemittanceType.Undefined:
                    return false;
                default:
                    return true;
            }
        }

        private bool IsApplicableCurrencyAndPaymentMethod()
        {
            if (string.IsNullOrEmpty(paymentRequest.CurrencyCode))
                return false;

            if (string.IsNullOrEmpty(paymentRequest.PaymentMethod))
                return false;

            if (!(paymentRequest.CurrencyCode == Currency.USD.Code && paymentRequest.PaymentMethod.ToUpper() == "ACH"))
                return false;

            if (paymentRequest.CurrencyCode != Currency.USD.Code)
                return false;
            
            return true;
        }

        private bool IsValidRemittanceType(string remittanceTypeRequest)
        {
            var result = Enum.TryParse(remittanceTypeRequest, true, out remittanceType);

            if (remittanceType == RemittanceType.Undefined)
                result = false;

            return result;
        }
    }
}
