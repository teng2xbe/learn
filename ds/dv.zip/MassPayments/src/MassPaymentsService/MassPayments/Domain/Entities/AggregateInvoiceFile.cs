﻿using System.Collections.Generic;

namespace MassPayments.Domain.Entities
{
    public class AggregateInvoiceFile : File
    {
        public List<Order> Orders;
        public string InvoiceFileName;
        public Partner Partner;
    }
}
