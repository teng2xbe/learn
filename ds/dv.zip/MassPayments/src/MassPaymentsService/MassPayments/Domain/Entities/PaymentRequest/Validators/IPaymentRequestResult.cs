﻿
namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public interface IPaymentRequestResult
    {
        void Process();
        bool HasFailed();
        void Record(PaymentRequest paymentRequest);
    }
}
