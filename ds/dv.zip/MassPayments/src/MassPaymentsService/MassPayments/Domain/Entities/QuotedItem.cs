﻿using System;

namespace MassPayments.Domain.Entities
{
    public class QuotedItem
    {
        public Money TradeMoney { get; set; }
        public Money SettlementMoney { get; set; }
        public bool IsDirect { get; set; }
        public decimal RateValue { get; set; }
        public decimal RateValueInverted { get; set; }
        public int NumberOfDecimalsDirect { get; set; }
        public int NumberOfDecimalsIndirect { get; set; }
        public DateTime ValueDate { get; set; }
        public int TransactionSystemQuoteId { get; set; }
        public int OrderId { get; set; }
        public bool IsAmountInSettlementCurrency { get; set; }
    }
}
