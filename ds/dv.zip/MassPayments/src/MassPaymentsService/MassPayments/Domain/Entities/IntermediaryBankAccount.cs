﻿namespace MassPayments.Domain.Entities
{
    public class IntermediaryBankAccount
    {
        public string BankName { get; set; }
        public string BankCode { get; set; }
        public string AccountNumber { get; set; }
        public Address BankAddress { get; set; }
        public string BankBranchCode { get; set; }
    }
}
