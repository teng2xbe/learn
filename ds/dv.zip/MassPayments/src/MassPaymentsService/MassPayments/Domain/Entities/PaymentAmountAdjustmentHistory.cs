﻿using System;

namespace MassPayments.Domain.Entities
{
    public class PaymentAmountAdjustmentHistory
    {
        public int PaymentId { get; set; }
        public decimal? OldAmount { get; set; }
        public decimal? NewAmount { get; set; }
        public decimal? OldSettlementAmount { get; set; }
        public decimal? NewSettlementAmount { get; set; }
        public DateTime UpdatedOnUtc { get; set; }
    }
}
