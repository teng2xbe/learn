﻿using System;
using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class PaymentSettlementCurrencyValidator : IPaymentRequestValidator
    {
        private readonly PaymentRequest paymentRequest;

        public PaymentSettlementCurrencyValidator(PaymentRequest paymentRequest)
        {
            this.paymentRequest = paymentRequest;
        }
        public IPaymentRequestResult Validate()
        {
            if (string.IsNullOrEmpty(paymentRequest.SettlementCurrencyCode))
            {
                if (paymentRequest.Customer.SettlementCurrency != null)
                {
                    paymentRequest.SettlementCurrencyCode = paymentRequest.Customer.SettlementCurrency.Code;
                    return new PaymentRequestSuccessful();
                }
                return new PaymentRequestFailedResult<string>(ErrorCode.PaymentSettlementCurrencyNotDefined);
            }
            return new PaymentRequestSuccessful();
        }
    }
}
