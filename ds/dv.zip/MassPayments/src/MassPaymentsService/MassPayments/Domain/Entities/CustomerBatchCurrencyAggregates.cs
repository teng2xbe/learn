﻿namespace MassPayments.Domain.Entities
{
    public class CustomerBatchCurrencyAggregates
    {
        public int CustomerBatchId { get; set; }
        public Money TotalPaymentsMoney { get; set; }
        public Money TotalPaymentsSettlementMoney { get; set; }
        public Money TotalOrdersMoney { get; set; }
        public bool IsFixedAmountInSettlementCurrency { get; set; }

        public void AddPaymentsMoney(decimal amount)
        {
            TotalPaymentsMoney = new Money(TotalPaymentsMoney.Currency, TotalPaymentsMoney.Amount + amount);
        }

        public void AddPaymentsSettlementMoney(decimal amount)
        {
            TotalPaymentsSettlementMoney = new Money(TotalPaymentsSettlementMoney.Currency, TotalPaymentsSettlementMoney.Amount + amount);
        }



    }
}
