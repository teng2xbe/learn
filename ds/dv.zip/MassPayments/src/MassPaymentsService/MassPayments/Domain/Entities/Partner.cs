﻿using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class Partner
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string BankRefPrefix { get; set; }
        public string Code { get; set; }
        public int InvoiceTypeId { get; set; }
        public string FilePrefix { get; set; }
        public bool IsThirdPartyRemitterEnabled { get; set; }
        public bool IsActive { get; set; }
        public PaymentModel PaymentModel { get; set; }
        public string SecurityToken { get; set; }
    }
}
