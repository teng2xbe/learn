﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MassPayments.Exceptions;

namespace MassPayments.Domain.Entities.Validators
{
    public class FormatValidator : IFormatValidator
    {
        public string ValidateDateFormat(string dateTime)
        {
            if (string.Format("{0:u}", Convert.ToDateTime(dateTime)) != dateTime)
                throw new InvalidDataFormatException(dateTime, "YYYY-MM-ddTHH:mm:ssZ");

            return dateTime;
        }
    }
}
