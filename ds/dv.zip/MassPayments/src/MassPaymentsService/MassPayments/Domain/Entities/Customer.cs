﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public CustomerStatus Status { get; set; }

        public int TransactionSystemCustomerId { get; set; }

        private List<String> notificationEmails;
        public List<String> NotificationEmails
        {
            get { return notificationEmails ?? (notificationEmails = new List<string>()); }
            set { notificationEmails = value; }
        }

        public int TransactionSystemId { get; set; }
        public int PartnerId { get; set; }
        public DateTime TTLExpiration { get; set; }
        public string PartnerAssignedCustomerId { get; set; }
        public string TransactionSystemCustomerExternalId { get; set; }
        public string CountryCode { get; set; }
        public Currency SettlementCurrency { get; set; }
        public SettlementPaymentMethod SettlementMethod { get; set; }
    }
}
