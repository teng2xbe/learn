﻿using System;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class PaymentStatusHistory
    {
        public int PaymentId { get; set; }
        public string TransferId { get; set; }
        public PaymentStatus PaymentStatus { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
