﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class Quote
    {
        public int Id { get; set; }
        public string QuoteGuid { get; set; }  //todo: this should be a Guid type, not a string
        public int CustomerId { get; set; }
        public string PartnerReference { get; set; }
        public DateTime RequestTimeUtc { get; set; }
        public DateTime ExpirationTimeUtc { get; set; }
        public int DurationInSec { get; set; }
        public string CustomerBatchExternalId { get; set; }
        public int PartnerId { get; set; }
        public QuoteRequestStatus Status { get; set; }
        public DateTime LastUpdatedOnUtc { get; set; }
        public List<QuotedItem> QuotedItems { get; set; }
    }
}
