﻿
namespace MassPayments.Domain.Entities.PaymentRequest
{
    public class BankAccount
    {
        public string Id { get; set; }
        public string VersionedOn { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public string BankName { get; set; }
        public string BranchName { get; set; }
        public string BankCode { get; set; }
        public string BankBranchCode { get; set; }
        public Address BankAddress { get; set; }
        public IntermediaryBank IntermediaryBank { get; set; }
        public string BankAccountOwnerName { get; set; }
    }
}
