﻿using System;

namespace MassPayments.Domain.Entities
{
    public class Money
    {
        private readonly Currency currency;
        private readonly decimal amount;

        public Money(Currency currency, decimal amount)
        {
            this.currency = currency;
            var roundedAmount = amount;

            if (currency != null && currency.RoundToNearestValue != 0)
                roundedAmount = Math.Round(amount / currency.RoundToNearestValue, MidpointRounding.AwayFromZero) * currency.RoundToNearestValue;

            this.amount = currency == null ? roundedAmount : Math.Round(roundedAmount, currency.DecimalPlaces, MidpointRounding.AwayFromZero);
            this.currency = currency;
        }

        public Money(Currency currency, long amount)
            : this(currency, amount/(decimal) Math.Pow(10, currency.DecimalPlaces))
        {
            
        }

        public Currency Currency
        {
            get { return currency; }
        }

        public decimal Amount
        {
            get { return amount; }
        }

        public long NonDecimalAmount
        {
            get { return Convert.ToInt64(amount*(long)Math.Pow(10, currency.DecimalPlaces)); }
        }
    }
}
