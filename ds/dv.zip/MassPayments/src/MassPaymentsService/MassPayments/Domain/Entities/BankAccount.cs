﻿namespace MassPayments.Domain.Entities
{
    public class BankAccount
    {
        public int Id { get; set; }
        public long Version { get; set; }
        public string VersionedOn { get; set; }
        public string ExternalId { get; set; }
        public string BeneficiaryId { get; set; }
        public string AccountNumber { get; set; }
        public string ExternalAccountType { get; set; }
        public string AccountPurpose { get; set; }
        public string BankName { get; set; }
        public string BranchName { get; set; }
        public Address BankAddress { get; set; }
        public string BankCode { get; set; }
        public string BranchCode { get; set; }
        public string DisplayName { get; set; }
        public string CurrencyCode { get; set; }
        public IntermediaryBankAccount IntermediaryBankAccount { get; set; }
        public string BankAccountOwnerName { get; set; }
    }
}
