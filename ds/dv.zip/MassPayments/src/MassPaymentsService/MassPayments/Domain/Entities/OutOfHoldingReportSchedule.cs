﻿namespace MassPayments.Domain.Entities
{
    public class OutOfHoldingReportSchedule
    {
        public int Id;
        public int PartnerId;
        public string Interval;
    }
}
