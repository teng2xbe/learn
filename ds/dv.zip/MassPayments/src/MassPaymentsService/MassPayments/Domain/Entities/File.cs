﻿using System;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class File
    {
        public int Id { get; set; }
        public FileStatus Status { get; set; }
        public byte[] Data { get; set; }
        public DateTime CreatedOnUTC { get; set; }
        public DateTime UpdatedOnUTC { get; set; }
        public string FileNameWithExtension { get; set; }
        public string FileContent { get; set; } //decrypted content
    }
}
