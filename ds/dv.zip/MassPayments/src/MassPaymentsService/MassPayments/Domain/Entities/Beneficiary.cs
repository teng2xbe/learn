﻿using System;

namespace MassPayments.Domain.Entities
{
    public class Beneficiary
    {
        public int Id { get; set; }
        public long Version { get; set; }
        public string VersionedOn { get; set; }
        public string ExternalId { get; set; }
        public string CustomerBeneId { get; set; }
        public string WUBSExternalCustomerId { get; set; }   
        public Address Address { get; set; }
        public Identification Identification { get; set; }
        public string Type { get; set; }
    }
}
