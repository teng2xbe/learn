﻿using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities.Subscription
{
    public class SubscriptionLog
    {
        public int ApiChannelSubscriptionId { get; set; }
        public int FileChannelSubscriptionId { get; set; }
        public int EmailChannelSubscriptionId { get; set; }
        public SubscriptionLogPurpose Purpose { get; set; }
        public string Message { get; set; } 
    }
}
