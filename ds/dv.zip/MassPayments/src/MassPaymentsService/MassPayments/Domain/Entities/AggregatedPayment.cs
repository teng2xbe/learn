﻿using System.Collections.Generic;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class AggregatedPayment
    {
        public int TransactionSystemCustomerId;
        public int TransactionSystemId;
        public Currency Currency;
        public PaymentMethod PaymentMethod;
        public decimal TotalAllPaymentMethods;
        public decimal Total;
        public bool HoldingBalanceExceeded;
        public decimal AvailableHoldingBalance;
        public int Count;
        public List<Payment> OriginalPayments;
    }
}
