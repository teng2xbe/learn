﻿using System;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class Currency : IComparable
    {
        //Static currencies are for tests only.
        //Do not use for amount calculation.
        public static readonly Currency Null = new Currency("");
        public static readonly Currency USD = new Currency("USD") { Description = "US Dollar", DecimalPlaces = 2 , Status = CurrencyStatus.Enabled};
        public static readonly Currency CAD = new Currency("CAD") { Description = "Canadian Dollar", DecimalPlaces = 2 };
        public static readonly Currency EUR = new Currency("EUR") { Description = "Euro", DecimalPlaces = 2 };
        public static readonly Currency GBP = new Currency("GBP") { Description = "British Pound", DecimalPlaces = 2 };
        public static readonly Currency AUD = new Currency("AUD") { Description = "Australian Dollar", DecimalPlaces = 2 };
        public static readonly Currency JPY = new Currency("JPY") { Description = "Japanese Yen", DecimalPlaces = 0 };

        public string Code { get; private set; }
        public string Description { get; set; }
        public CurrencyStatus Status { get; set; } 
        public int DecimalPlaces { get; set; }
        public decimal RoundToNearestValue { get; set; }
        public Currency(string code)
        {
            Code = code.ToUpper();
        }

        public override int GetHashCode()
        {
            return (Code != null ? Code.GetHashCode() : 0);
        }

        public override string ToString()
        {
            return Code;
        }

        public int CompareTo(object obj)
        {
            return String.Compare(Code, obj.ToString(), StringComparison.Ordinal);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is Currency))
                return false;

            return Code == ((Currency) obj).Code;
        }

        public static bool operator ==(Currency one, Currency another)
        {
            if ((object) one == null)
                return (object) another == null;

            return one.Equals(another);
        }

        public static bool operator !=(Currency one, Currency another)
        {
            return !(one == another);
        }
    }
}
