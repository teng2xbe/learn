﻿using MassPayments.Domain.Entities.PaymentRequest.Assemblers;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Payments;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Logger;
using MassPayments.Managers.PaymentManaging;
using MassPayments.Mappers;
using MassPayments.Providers.StorageProvider.EventArguments;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPaymentsCommon.WCFContracts.Enums;
using Quartz.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MassPayments.Domain.Entities.PaymentRequest
{
    public class PaymentRequestToProcess
    {
        public int Id { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public int PartnerId { get; set; }
        public List<PaymentRequest> PaymentsToProcess { get; set; }
        public int BatchId { get; set; }
        private Partner partnerForProcessing;

        private int TotalNumberOfPaymentsAccepted
        {
            get
            {
                return PaymentsToProcess?.Count(p => !p.HasFailed) ?? 0;
            }
        }

        private int TotalNumberOfPaymentsReceived
        {
            get
            {
                return PaymentsToProcess?.Count ?? 0;
            }
        }

        public int PaymentCount
        {
            get
            {
                return PaymentsToProcess?.Count ?? 0;
            }
        }

        private ProcessingStatus processingStatus { get; set; }

        public void Process()
        {
            var batch = new CustomerBatch();

            try
            {
                partnerForProcessing = PartnerMapper.Instance.GetPartnerById(PartnerId);

                if ((PaymentsToProcess == null) || PaymentsToProcess.Count <= 0)
                    return;

                var customers = CustomerMapper.Instance.GetCustomersByPartnerAndCustomerIds(partnerForProcessing.Id, PaymentsToProcess.Select(pr => pr.PartnerAssignedCustomerId).ToList());

                LogCustomersWithoutCountry(customers);

                var domesticCountryGroupsSetting = ServiceSettings.Instance.GetStringValue("DomesticCountryGroups", "");
                var domesticCountryGroups = new DomesticCountryGroupParser().ParseFromString(domesticCountryGroupsSetting);

                foreach (var paymentRequest in PaymentsToProcess)
                {
                    paymentRequest.SetPartner(partnerForProcessing);

                    if (!SetCustomer(paymentRequest, customers))
                        continue;

                    paymentRequest.Validate(true);

                    if (paymentRequest.HasFailed)
                        continue;

                    var assembledPayment = PaymentRequestAssembler.AssemblePayment(paymentRequest, partnerForProcessing, CreatedOnUtc, PaymentStatus.Committed);
                    var validationResult = ValidateAssembledPayment(assembledPayment, paymentRequest.Customer, domesticCountryGroups, true, partnerForProcessing.IsThirdPartyRemitterEnabled);

                    if (string.IsNullOrEmpty(validationResult))
                        paymentRequest.RecordSuccessfulValidation();
                    else
                        paymentRequest.RecordFailedValidation(validationResult);
                }

                if (IsRequestsForBatch(PaymentsToProcess))
                {
                    batch = CustomerBatchMapper.Instance.GetCustomerBatch(BatchId);
                    Validate(PaymentsToProcess, batch, isRequestForBatch: true);
                    Create(PaymentsToProcess, batch, customers);
                    CancelCustomerBatchQuote(PaymentsToProcess.Where(p => !p.HasFailed).ToList(), batch);
                    UpdateBatchPaymentsProcessed(batch);
                }
                else
                {
                    Validate(PaymentsToProcess, batch, isRequestForBatch: false);
                    CommitDecoupledPayments(PaymentsToProcess, batch, customers);
                }
            }
            catch (Exception ex)
            {
                var msg = new StringBuilder().AppendLine(ex.Message).AppendLine(ex.StackTrace).ToString();
                MarkPaymentsAsFailedWhenErrorOccurs(((int)ErrorCode.GenericMassPaymentsServiceError).ToString());
                processingStatus = new ProcessingStatus { Message = msg, Status = FileStatus.FailedToProcess };
                EventLogger.Instance.WriteError(msg, new ExceptionToEventCodeConverter().GetErrorEventCodeForException(ex));
            }
            finally
            {
                Archive(this);
                LogNotAcceptedPayments();
                DeleteAcceptedPaymentsFromLog();
                PublishNotAcceptedPayments();
            }
        }

        //wrap the call to static method for unit testing/mocking purpose.
        internal virtual string ValidateAssembledPayment(Payment payment, Customer customer, List<DomesticCountryGroup> domesticCountryGroups, bool isValidationRequiredForRelease, bool isThirdPartyRemitterEnabled)
        {
            return PaymentValidator.Validate(payment, partnerForProcessing, customer, domesticCountryGroups, isValidationRequiredForRelease, isThirdPartyRemitterEnabled);
        }

        private void CancelCustomerBatchQuote(List<PaymentRequest> paymentRequests, CustomerBatch customerBatch)
        {
            if (paymentRequests.Count == 0) return;

            CustomerBatchMapper.Instance.UpdateCustomerBatchActiveQuoteRequestId(null, customerBatch.ExternalId, customerBatch.CustomerId);
        }

        private bool SetCustomer(PaymentRequest paymentRequest, List<Customer> customers)
        {
            if (customers.All(c => !AreEqual(c.PartnerAssignedCustomerId, paymentRequest.PartnerAssignedCustomerId)))
            {
                paymentRequest.RecordFailedValidation(((int)ErrorCode.CustomerDoesNotExist).ToString());
                return false;
            }

            if (customers.Any(c => AreEqual(c.PartnerAssignedCustomerId, paymentRequest.PartnerAssignedCustomerId)))
                paymentRequest.SetCustomer(customers.First(i => AreEqual(i.PartnerAssignedCustomerId, paymentRequest.PartnerAssignedCustomerId)));

            return true;
        }

        private static bool AreEqual(string text1, string text2)
        {
            return string.Equals(text1, text2, StringComparison.CurrentCultureIgnoreCase);
        }

        private void UpdateBatchPaymentsProcessed(CustomerBatch batch)
        {
            batch.TotalPaymentsAccepted += TotalNumberOfPaymentsAccepted;
            batch.TotalPaymentsReceived += TotalNumberOfPaymentsReceived;
            CustomerBatchMapper.Instance.UpdateCustomerBatchTotalPaymentsProcessed(batch);

            foreach (var aggregatedBatch in AggregateBatchPayments(PaymentsToProcess))
            {
                CustomerBatchCurrencyMapper.Instance.InsertCustomerBatchCurrency(batch.Id
                    , aggregatedBatch.TotalPaymentsMoney
                    , aggregatedBatch.TotalPaymentsSettlementMoney
                    , aggregatedBatch.TotalOrdersMoney
                    , aggregatedBatch.IsFixedAmountInSettlementCurrency);
            }
        }

        internal virtual List<CustomerBatchCurrencyAggregates> AggregateBatchPayments(List<PaymentRequest> payments)
        {
            var aggregatedPayments = new List<CustomerBatchCurrencyAggregates>();

            foreach (var payment in payments.Where(p => !p.HasFailed).ToList())
            {
                var existingAggregate = aggregatedPayments.Find(aggregatedPayment =>
                    aggregatedPayment.TotalPaymentsMoney.Currency.Code == payment.CurrencyCode &&
                    aggregatedPayment.TotalPaymentsSettlementMoney.Currency.Code == payment.SettlementCurrencyCode &&
                    aggregatedPayment.IsFixedAmountInSettlementCurrency == payment.IsFixedAmountInSettlementCurrency
                    );
                var paymentCurrency = CurrencyCache.Instance.GetById(payment.CurrencyCode);
                var paymentSettlmentCurrency = CurrencyCache.Instance.GetById(payment.SettlementCurrencyCode);

                if (existingAggregate != null)
                {
                    existingAggregate.AddPaymentsSettlementMoney(new Money(paymentSettlmentCurrency, payment.IsFixedAmountInSettlementCurrency ? payment.FixedAmount : 0).Amount);
                    existingAggregate.AddPaymentsMoney(new Money(paymentCurrency, payment.IsFixedAmountInSettlementCurrency ? 0 : payment.FixedAmount).Amount);
                }
                else
                {
                    aggregatedPayments.Add(new CustomerBatchCurrencyAggregates
                    {
                        TotalPaymentsMoney = new Money(paymentCurrency, payment.IsFixedAmountInSettlementCurrency ? 0 : payment.FixedAmount),
                        TotalPaymentsSettlementMoney = new Money(paymentSettlmentCurrency, payment.IsFixedAmountInSettlementCurrency ? payment.FixedAmount : 0),
                        IsFixedAmountInSettlementCurrency = payment.IsFixedAmountInSettlementCurrency
                    });
                }
            }

            return aggregatedPayments;
        }

        private void LogCustomersWithoutCountry(List<Customer> customerList)
        {
            var customersWithoutCountry = customerList.FindAll(c => string.IsNullOrEmpty(c.CountryCode));
            if (customersWithoutCountry.Count > 0)
            {
                var stringBuilder = new StringBuilder();

                foreach (var customer in customersWithoutCountry)
                {
                    stringBuilder.Append(customer.PartnerAssignedCustomerId).Append(";");
                }

                EventLogger.Instance.WriteWarning(
                    $"Processing Payments request. the following customers do not have country specified {stringBuilder}. Country specific validation won't be performed");
            }
        }

        private void Create(List<PaymentRequest> paymentRequests, CustomerBatch batch, List<Customer> customers)
        {
            var successfulRequests = paymentRequests.Where(pr => !pr.HasFailed).ToList();

            ProcessCustomerInPaymentRequest(paymentRequests, "PaymentsToCreate", batch);

            var payments = successfulRequests.Select(pr => PaymentRequestAssembler.AssemblePayment(pr, partnerForProcessing, CreatedOnUtc, PaymentStatus.Created)).ToList();
            var successfulPaymentIds = payments.Select(payment => payment.ExternalId).ToList();
            PaymentMapper.Instance.PaymentBulkInsert(payments);

            List<Payment> insertedPayments = new List<Payment>();
            if (payments.Count > 0)
                insertedPayments = PaymentMapper.Instance.GetPayments(successfulRequests[0].Customer, successfulPaymentIds);
            
            PublishAcceptedPayments(insertedPayments, batch, customers);
            ProcessBeneficiaryAndBankAccountInPayments(Id, payments);
        }

        internal virtual void CommitDecoupledPayments(List<PaymentRequest> paymentRequests, CustomerBatch batch, List<Customer> customers)
        {
            var successfulRequests = paymentRequests.Where(pr => !pr.HasFailed).ToList();

            ProcessCustomerInPaymentRequest(successfulRequests, "PaymentsToProcess", batch);

            var payments = successfulRequests.Select(pr => PaymentRequestAssembler.AssemblePayment(pr, partnerForProcessing, CreatedOnUtc, PaymentStatus.Committed)).ToList();
            var successfulPaymentIds = payments.Select(payment => payment.ExternalId).ToList();

            PaymentMapper.Instance.BulkInsertUpdatePayment(payments);

            List<Payment> insertedPayments= new List<Payment>();
            if(payments.Count > 0)
                insertedPayments = PaymentMapper.Instance.GetPayments(partnerForProcessing.Id, successfulPaymentIds);


            PublishAcceptedPayments(insertedPayments, batch, customers);
        }

        internal virtual void PublishAcceptedPayments(List<Payment> payments, CustomerBatch batch, List<Customer> customers)
        {
            var publisher = (IPublisher<Payment, CustomerBatch, Customer>)PublisherFactory.GetPublisher(typeof(PaymentStatusUpdatedPublisher), partnerForProcessing);

            foreach (var payment in payments)
            {
                var customer = customers.First(c => c.TransactionSystemCustomerId == payment.TransactionSystemCustomerId);
                publisher.Publish(payment, batch, customer);
            }
        }

        private void PublishNotAcceptedPayments()
        {
            var allPaymentRequests = new List<PaymentRequest>();

            if (PaymentsToProcess != null)
                allPaymentRequests.AddRange(PaymentsToProcess.Where(p => p.HasFailed).ToList());

            var published = (IPublisher<List<PaymentRequest>>)PublisherFactory.GetPublisher(typeof(PaymentNotAcceptedPublisher), partnerForProcessing);

            if (published != null)
            {
                if (allPaymentRequests.Count > 0)
                    published.Publish(allPaymentRequests);
            }
        }

        private void LogNotAcceptedPayments()
        {
            var failedPaymentIds = new List<string>();
            var failedPayments = new List<PaymentRequest>();
            var updateNotAllowedErrorCode = ((int)ErrorCode.PaymentUpdateNotAllowed).ToString();

            if (PaymentsToProcess != null)
            {
                failedPayments.AddRange(PaymentsToProcess.Where(p => p.HasFailed && !p.Message.Contains(updateNotAllowedErrorCode)).ToList());
                failedPaymentIds.AddRange(failedPayments.Select(fp => fp.PaymentId).ToList());

                var archivedPayments = PaymentRequestMapper.Instance.GetFailedPaymentRequests(Id);

                if (archivedPayments.Count > 0)
                {
                    foreach (var payment in archivedPayments)
                    {
                        var failedPayment = failedPayments.FirstOrDefault(p => p.ItemIndex == payment.ItemIndex);
                        if (failedPayment != null)
                        {
                            failedPayment.PaymentRequestArchiveDetailId = payment.PaymentRequestArchiveDetailId;
                            failedPayment.PartnerId = payment.PartnerId;
                        }
                    }
                    PaymentRequestMapper.Instance.LogNotAcceptedPayments(failedPayments);
                }
            }
        }

        private void DeleteAcceptedPaymentsFromLog()
        {
            var successfulPayments = new List<PaymentRequest>();

            if (PaymentsToProcess != null)
            {
                successfulPayments.AddRange(PaymentsToProcess.Where(p => !p.HasFailed).ToList());

                foreach (var payment in successfulPayments)
                {
                    payment.PartnerId = PartnerId;
                }

                PaymentRequestMapper.Instance.DeleteAcceptedPaymentsFromLog(successfulPayments);
            }
        }

        private void Validate(List<PaymentRequest> paymentRequests, CustomerBatch batch, bool isRequestForBatch)
        {
            MarkDuplicatesAsFailed(paymentRequests);
            MarkPaymentsWithExistingPaymentIdsAsFailed(paymentRequests, isRequestForBatch, batch);
            if (isRequestForBatch)
            {
                ValidateIsFixedOnSettlementMatchesWithBatchCurrencyPair(paymentRequests, batch);
                MarkPaymentsAsFailedWhenBatchIsCommitted(paymentRequests, batch);
            }
        }

        private void MarkPaymentsAsFailedWhenBatchIsCommitted(List<PaymentRequest> paymentRequests, CustomerBatch batch)
        {
            //var batch = CustomerBatchMapper.Instance.GetCustomerBatchByCustomerAndBatchId(paymentRequests[0].Customer.Id, paymentRequests[0].BatchId);
            if (batch.BatchStatus != CustomerBatchStatus.Created)
            {
                foreach (var pr in paymentRequests)
                {
                    pr.RecordFailedValidation(((int)ErrorCode.PaymentsForCommittedBatch).ToString());
                }
            }

        }

        private bool IsRequestsForBatch(List<PaymentRequest> paymentRequests)
        {
            return paymentRequests.FindAll(p => !string.IsNullOrEmpty(p.ExternalBatchId)).Count == paymentRequests.Count;
        }

        private bool IsCustomerMatching(PaymentRequest paymentRequest, CustomerBatch customerBatch)
        {
            if (string.IsNullOrEmpty(customerBatch.ExternalCustomerId))
            {
                return paymentRequest.Customer == null;
            }

            return paymentRequest.Customer != null && paymentRequest.Customer.Id != customerBatch.CustomerId;
        }

        internal virtual void ProcessCustomerInPaymentRequest(List<PaymentRequest> paymentRequests, string idPrefix, CustomerBatch batch)
        {
            if (!paymentRequests.Any())
                return;

            if (IsRequestsForBatch(paymentRequests))
            {
                foreach (var paymentRequest in paymentRequests)
                {
                    if (IsCustomerMatching(paymentRequest, batch))
                    {
                        paymentRequest.RecordFailedValidation(((int)ErrorCode.CustomerNotMatch).ToString());
                        continue;
                    }

                    paymentRequest.SetCustomerBatchId(batch.Id);
                }
            }
            else
            {
                var customerBatchesForAutoGeneration = paymentRequests
                    .Select(paymentRequest => new CustomerBatch
                    {
                        CustomerId = paymentRequest.Customer.Id,
                        CreatedOnUTC = CreatedOnUtc,
                        ExternalCustomerId = paymentRequest.PartnerAssignedCustomerId,
                        BatchType = BatchType.PaymentRequest,
                        ExternalId = $"{idPrefix}-{Id}", //to avoid duplicates
                        BatchReference = Id.ToString() //store requestId as reference
                    });

                var customerBatchList = customerBatchesForAutoGeneration.GroupBy(p => new { p.CustomerId, p.ExternalId }).Select(g => g.First()).ToList();
                var loadedCustomerBatches = CustomerBatchMapper.Instance.InsertCustomerBatches(customerBatchList);

                var customerIds = loadedCustomerBatches.Select(i => i.CustomerId).ToList();

                foreach (var paymentRequest in paymentRequests)
                {
                    if (customerIds.Contains(paymentRequest.Customer.Id))
                        paymentRequest.SetCustomerBatchId(loadedCustomerBatches.First(i => i.CustomerId == paymentRequest.Customer.Id).Id);
                }
            }
        }

        private void ValidateIsFixedOnSettlementMatchesWithBatchCurrencyPair(List<PaymentRequest> paymentRequests, CustomerBatch batch)
        {
            ValidateIsFixedOnSettlementMatchesWithSavedBatchCurrencyPair(paymentRequests, batch);
            ValidateIsFixedOnSettlementMatchesWithRequestCurrencyPair(paymentRequests);
        }

        private void ValidateIsFixedOnSettlementMatchesWithSavedBatchCurrencyPair(List<PaymentRequest> paymentRequests, CustomerBatch batch)
        {
            if (batch == null) return;
            var batchAggregates = CustomerBatchCurrencyMapper.Instance.GetCustomerBatchCurrencyAggregatesByBatchId(batch.Id);
            if (batchAggregates == null) return;
            foreach (var paymentRequest in paymentRequests.Where(p => !p.HasFailed).ToList())
            {
                if (batchAggregates.Any(x => x.TotalPaymentsMoney.Currency.Code == paymentRequest.CurrencyCode &&
                                             x.TotalPaymentsSettlementMoney.Currency.Code == paymentRequest.SettlementCurrencyCode &&
                                             x.IsFixedAmountInSettlementCurrency != paymentRequest.IsFixedAmountInSettlementCurrency))
                    paymentRequest.RecordFailedValidation(Convert.ToString((int)ErrorCode.FixedOnDoesNotMatch) + ":" + "isFixedAmountInSettlementCurrency");
            }
        }

        private void ValidateIsFixedOnSettlementMatchesWithRequestCurrencyPair(List<PaymentRequest> paymentRequests)
        {
            var currencyPairs = new List<CustomerBatchCurrencyAggregates>();
            foreach (var paymentRequest in paymentRequests.Where(p => !p.HasFailed).ToList())
            {

                var currencyPair = currencyPairs.Find(x => x.TotalPaymentsMoney?.Currency.Code == paymentRequest.CurrencyCode &&
                        x.TotalPaymentsSettlementMoney?.Currency.Code == paymentRequest.SettlementCurrencyCode);
                if (currencyPair == null)
                    currencyPairs.Add(new CustomerBatchCurrencyAggregates
                    {
                        TotalPaymentsMoney = new Money(new Currency(paymentRequest.CurrencyCode), 0),
                        TotalPaymentsSettlementMoney = paymentRequest.SettlementCurrencyCode == null ? null : new Money(new Currency(paymentRequest.SettlementCurrencyCode), 0),
                        IsFixedAmountInSettlementCurrency = paymentRequest.IsFixedAmountInSettlementCurrency
                    });
                else if (currencyPair.IsFixedAmountInSettlementCurrency != paymentRequest.IsFixedAmountInSettlementCurrency)
                    paymentRequest.RecordFailedValidation(Convert.ToString((int)ErrorCode.FixedOnDoesNotMatch) + ":" + "isFixedAmountInSettlementCurrency");
            }
        }

        private void MarkDuplicatesAsFailed(List<PaymentRequest> paymentRequests)
        {
            var duplicatePaymentIds = paymentRequests.Where(f => !f.HasFailed).GroupBy(q => new { q.PaymentId }).Where(g => g.Count() > 1).Select(g => g.Key.PaymentId).ToList();

            foreach (var paymentRequest in paymentRequests)
            {
                if (paymentRequest.HasFailed)
                    continue;
                if (duplicatePaymentIds.Contains(paymentRequest.PaymentId))
                    paymentRequest.RecordFailedValidation((int)ErrorCode.InvalidValueOrFormat + ":" + "id");
            }
        }

        internal virtual void MarkPaymentsWithExistingPaymentIdsAsFailed(IReadOnlyList<PaymentRequest> paymentRequests, bool isRequestForBatch, CustomerBatch batch)
        {
            var existingPaymentIds = paymentRequests.Select(payment => payment.PaymentId).ToList();
            var existingPayments = isRequestForBatch ?
                PaymentMapper.Instance.GetPayments(paymentRequests[0].Customer, existingPaymentIds) :
                PaymentMapper.Instance.GetPayments(partnerForProcessing.Id, existingPaymentIds);

            foreach (var paymentRequest in paymentRequests)
            {
                var payment = existingPayments.FindAll(x => x.ExternalId == paymentRequest.PaymentId);

                if (payment.Count == 0)
                    continue;

                if (paymentRequest.HasFailed)
                    LogPaymentUpdateAttempt(paymentRequest.Message, payment[0], batch);
                else
                {
                    if (!isRequestForBatch) //special handling for decoupled payment which is cancelled
                    {
                        if (payment.Any(x => x.PaymentStatus == PaymentStatus.Cancelled))
                        {
                            RecordFailedValidationAndLogUpdateAttempt(ErrorCode.PaymentUpdateForCancelledPayment, payment.Find(x => x.PaymentStatus == PaymentStatus.Cancelled), paymentRequest, batch);
                            return;
                        }
                    }

                    //generic handling for all payments
                    RecordFailedValidationAndLogUpdateAttempt(ErrorCode.PaymentUpdateNotAllowed, payment.First(), paymentRequest, batch);
                }
            }
        }

        private void RecordFailedValidationAndLogUpdateAttempt(ErrorCode errorCode, Payment payment, PaymentRequest paymentRequest, CustomerBatch batch)
        {
            var error = (int)errorCode;
            paymentRequest.RecordFailedValidation(error.ToString());
            LogPaymentUpdateAttempt(error.ToString(), payment, batch);
        }

        private void LogPaymentUpdateAttempt(string error, Payment payment, CustomerBatch batch)
        {
            var paymentUpdateHistory = new PaymentUpdateHistory
            {
                ErrorCode = error,
                PaymentId = payment.Id,
                PaymentRequestId = Id,
                UpdatedOnUtc = DateTime.UtcNow
            };

            PaymentMapper.Instance.InsertPaymentUpdateHistory(paymentUpdateHistory);

            payment.LastUpdateError = paymentUpdateHistory;

            var publisher = (IPublisher<Payment, CustomerBatch>)PublisherFactory.GetPublisher(typeof(PaymentUpdateFailedPublisher), partnerForProcessing);
            publisher.Publish(payment, batch);
        }

        private void MarkPaymentsAsFailedWhenErrorOccurs(string message)
        {
            if ((PaymentsToProcess != null) && PaymentsToProcess.Count > 0)
            {
                foreach (var payment in PaymentsToProcess)
                {
                    payment.RecordFailedValidation(message);
                }
            }
        }

        private void Archive(PaymentRequestToProcess paymentRequestToProcess)
        {
            processingStatus = processingStatus ?? GetPaymentProcessingStatus(paymentRequestToProcess);

            PaymentRequestMapper.Instance.ArchivePaymentRequest(paymentRequestToProcess, processingStatus.Status, processingStatus.Message);
        }

        internal virtual void ProcessBeneficiaryAndBankAccountInPayments(int requestId, List<Payment> payments)
        {
            var eventArgs = new List<BeneficiaryEventArgs>();

            foreach (var payment in payments)
            {
                var bankAccounts = new List<Entities.BankAccount>();
                if (payment.BankAccount != null)
                    bankAccounts.Add(payment.BankAccount);

                eventArgs.Add(BeneficiaryEventArgs.GetBeneficiaryEventArgs(payment.Beneficiary, bankAccounts, "Payment Request", requestId, payment.ThirdPartyRemitter, partnerForProcessing.Code, payment.TransactionSystemId, payment.TransactionSystemCustomerId, payment.CreatedOnUTC));
            }

            StorageEventPublisher.Instance.OnBeneficiariesParsed(eventArgs);
        }

        private ProcessingStatus GetPaymentProcessingStatus(PaymentRequestToProcess paymentRequestToProcess)
        {
            var message = new List<string>();

            if (paymentRequestToProcess.PaymentsToProcess != null)
            {
                if (paymentRequestToProcess.PaymentsToProcess.Count(f => f.HasFailed) > 0)
                    message.Add($"Process Failed: {string.Join(",", paymentRequestToProcess.PaymentsToProcess.Where(f => f.HasFailed).Select(p => ((p.PaymentId.IsNullOrWhiteSpace() ? ("index:" + p.ItemIndex.ToString()) : ("id:" + p.PaymentId)))))}");

                if (paymentRequestToProcess.PaymentsToProcess.Count(f => !f.HasFailed) > 0)
                    message.Add($"Pocess Success: {string.Join(",", paymentRequestToProcess.PaymentsToProcess.Where(f => !f.HasFailed).Select(p => p.PaymentId))}");
            }

            if (!message.Any(str => str.Contains("Failed")) && message.Any(str => str.Contains("Success")))
                return new ProcessingStatus
                {
                    Status = FileStatus.Processed,
                    Message = string.Join(" | ", message.Select(p => p))
                };

            if (message.Any(str => str.Contains("Failed")) && message.Any(str => str.Contains("Success")))
                return new ProcessingStatus
                {
                    Status = FileStatus.ProcessedWithError,
                    Message = string.Join(" | ", message.Select(p => p))
                };

            if (message.Any(str => str.Contains("Failed")) && !message.Any(str => str.Contains("Success")))
                return new ProcessingStatus
                {
                    Status = FileStatus.FailedToProcess,
                    Message = string.Join(" | ", message.Select(p => p))
                };

            return new ProcessingStatus { Status = FileStatus.FailedToProcess, Message = "Unknown" };
        }

        private class ProcessingStatus
        {
            public FileStatus Status { get; set; }
            public string Message { get; set; }
        }

        public void ApplyBatchForPayments(string externalBatchId)
        {
            if (PaymentsToProcess != null)
            {
                foreach (var request in PaymentsToProcess)
                {
                    request.ExternalBatchId = externalBatchId;
                }
            }
        }

        [Obsolete("This method is for testing purpose only!")]
        internal virtual void SetPartnerForProcessing(Partner partner)
        {
            this.partnerForProcessing = partner;
        }
    }
}
