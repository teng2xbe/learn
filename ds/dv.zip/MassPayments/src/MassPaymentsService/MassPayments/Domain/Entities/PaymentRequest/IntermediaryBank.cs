﻿
namespace MassPayments.Domain.Entities.PaymentRequest
{
    public class IntermediaryBank
    {
        public string BankName { get; set; }
        public string BankCode { get; set; }
        public string AccountNumber { get; set; }
        public Address Address { get; set; }
        public string BankBranchCode { get; set; }
    }
}
