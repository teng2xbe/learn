﻿
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities 
{
    public class ReturnedPayment : Payment
    {

        public ReturnedPayment(int id) : base(id)
        {

        }
        public ReturnedPayment(string externalId, string externalCustomerId) : base(externalId, externalCustomerId)
        {
            
        }

        public Money ReturnAmount { get; set; }
        public string UserName { get; set; } //for saving only in the database, not being retrieved yet
    }
}
