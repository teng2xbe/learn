﻿
namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class PaymentRequestSuccessful: IPaymentRequestResult
    {
        public void Process()
        {            
        }

        public bool HasFailed()
        {
            return false;
        }

        public void Record(PaymentRequest paymentRequest)
        {
            paymentRequest.RecordSuccessfulValidation();
        }
    }
}
