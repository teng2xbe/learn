﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;

namespace MassPayments.Domain.Entities
{
    public class CustomerBatch
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public string ExternalId { get; set; }  //external batch id
        public string BatchReference { get; set; }
        public string ExternalCustomerId { get; set; } //programId
        public DateTime CreatedOnUTC { get; set; }
        public DateTime UpdatedOnUTC { get; set; }
        public BatchType BatchType { get; set; }
        public int TotalPaymentsReceived { get; set; }
        public int TotalPaymentsAccepted { get; set; }
        public List<CustomerBatchCurrencyAggregates> AggregateAmounts { get; set; }
        public CustomerBatchStatus BatchStatus { get; set; }
        public int ActiveQuoteRequestId { get; set; }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (GetType() != obj.GetType()) return false;
                
            var castedObj = (CustomerBatch) obj;

            if (ExternalId != null && castedObj.ExternalId != null)
            {
                if (!ExternalId.Equals(castedObj.ExternalId)) return false;
            }
            else if (ExternalId == null && castedObj.ExternalId == null)
            {
                return true;
            }
            else
            {
                return false;
            }
                
            if (ExternalCustomerId != null && castedObj.ExternalCustomerId != null)
            {
                if (!ExternalCustomerId.Equals(castedObj.ExternalCustomerId)) return false;
            }
            else if (ExternalCustomerId == null && castedObj.ExternalCustomerId == null)
            {
                return true;
            }
            else
            {
                return false;
            }
                
            return true;
        }

        public override int GetHashCode()
        {
            return ExternalId != null ? ExternalId.GetHashCode() : 0 +
                (ExternalCustomerId != null ? ExternalCustomerId.GetHashCode() : 0);
        }

        public void Validate()
        {
            var rgxExternalIdPattern = new Regex("^" + ValidationRules.Instance.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}") + "$");

            if (BatchType == BatchType.ApiBatch || BatchType == BatchType.FileBatch) 
            {
                if (string.IsNullOrEmpty(ExternalId))
                {
                    if (Id < 1)
                        throw new MissingDataException("ExternalId");
                    throw new MissingDataException("ExternalId", Id);
                }

                if (!rgxExternalIdPattern.IsMatch(ExternalId))
                    throw new InvalidDataFormatException("id", ValidationRules.Instance.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}"), "id");
            }                
        }
    }
}
