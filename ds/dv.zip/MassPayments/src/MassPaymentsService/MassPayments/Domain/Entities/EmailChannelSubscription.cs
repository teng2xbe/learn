﻿using MassPayments.Domain.Enums;
using MassPayments.Domain.Interfaces;

namespace MassPayments.Domain.Entities
{
    public class EmailChannelSubscription : ISubscription
    {
        public int Id { get; set; }
        public int PartnerId { get; set; }
        public SubscriptionType SubscriptionType { get; set; }
        public string Recipient { get; set; }
    }
}
