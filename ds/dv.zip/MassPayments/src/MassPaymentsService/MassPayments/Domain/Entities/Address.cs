﻿using System.Text;

namespace MassPayments.Domain.Entities
{
    public class Address
    {
        private string addressLine1;
        private string addressLine2;
        private string addressLine3;

        public string AddressLine1
        {
            get
            {
                if (!string.IsNullOrEmpty(addressLine1) && addressLine1.Length > 35)
                    addressLine1 = addressLine1.Substring(0,35);
                return addressLine1;
            }
            set
            {
                addressLine1 = value;
            }
        }

        public string AddressLine2
        {
            get
            {
                if (!string.IsNullOrEmpty(addressLine2) && addressLine2.Length > 35)
                    addressLine2 = addressLine2.Substring(0, 35);
                return addressLine2;
            }
            set
            {
                addressLine2 = value;
            }
        }

        public string AddressLine3
        {
            get
            {
                if (!string.IsNullOrEmpty(addressLine3) && addressLine3.Length > 35)
                    addressLine3 = addressLine3.Substring(0, 35);
                return addressLine3;
            }
            set
            {
                addressLine3 = value;
            }
        }

        public string City { get; set; }
        public string StateOrProvince { get; set; }
        public string ZipOrPostalCode { get; set; }
        public string CountryCode { get; set; }

        public string AggregatedAddressLine
        {
            get
            {
                if (string.IsNullOrEmpty(AddressLine1) &&
                    string.IsNullOrEmpty(AddressLine2) &&
                    string.IsNullOrEmpty(AddressLine3)
                    )
                    return null;

                var address = new StringBuilder();
                
                if (!string.IsNullOrEmpty(AddressLine1))
                    address.Append(AddressLine1);

                if (!string.IsNullOrEmpty(AddressLine2))
                    address.Append(" ").Append(AddressLine2);

                if (!string.IsNullOrEmpty(AddressLine3))
                    address.Append(" ").Append(AddressLine3);

                return address.ToString();
            }
        }
    }
}
