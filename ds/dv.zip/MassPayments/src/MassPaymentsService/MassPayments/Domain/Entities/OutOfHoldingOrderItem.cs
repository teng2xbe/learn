﻿using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class OutOfHoldingOrderItem
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public string TradeCurrencyCode { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public decimal Amount { get; set; }
    }
}
