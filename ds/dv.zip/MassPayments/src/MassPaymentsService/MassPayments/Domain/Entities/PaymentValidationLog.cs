﻿using System;

namespace MassPayments.Domain.Entities
{
    public class PaymentValidationLog
    {
        public int PaymentId { get; set; }
        public string ExternalPaymentId { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string StackTrace { get; set; }
        public string ExternalCustomerId { get; set; }
        public int CustomerBatchId { get; set; }
    }
}
