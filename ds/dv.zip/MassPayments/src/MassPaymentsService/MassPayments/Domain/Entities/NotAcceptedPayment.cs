﻿
namespace MassPayments.Domain.Entities 
{
    public class NotAcceptedPayment : Payment
    {

        public NotAcceptedPayment(string externalId, string externalCustomerId) : base(externalId, externalCustomerId)
        {
            
        }

        public string ErrorCode { get; set; }
    }
}
