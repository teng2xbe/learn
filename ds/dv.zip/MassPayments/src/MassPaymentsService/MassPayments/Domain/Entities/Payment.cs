﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class Payment
    {
        public Payment(int id)
        {
            Id = id;
        }

        public Payment(string externalId, string externalCustomerId)
        {
            ExternalId = externalId;
            ExternalCustomerId = externalCustomerId;
        }

        public int Id { get; set; }
        public int CustomerBatchId { get; set; }
        public string ExternalId { get; private set; }  //paymentId
        public string ExternalCustomerId { get; private set; }  //partner assigned customerId

        public string PartnerReference { get; set; }
        public Money AmountMoney { get; set; } 
        public Beneficiary Beneficiary { get; set; }
        public BankAccount BankAccount { get; set; }
        public PaymentMethod? PaymentMethod { get; set; }
        public PaymentStatus PaymentStatus { get; set; }
        public int TransactionSystemCustomerId { get; set; }
        public int TransactionSystemId { get; set; }
        public int PaymentSourceId { get; set; }
        public DateTime CreatedOnUTC { get; set; }
        public DateTime UpdatedOnUTC { get; set; }
        public DateTime? RequestedReleaseDate { get; set; }
        public DateTime? GPGProcessedUTC { get; set; }
        public int TransactionSystemOrderId { get; set; }
        public string TransactionSystemOrderNumber { get; set; }
        public int TransactionSystemIncomingOrderId { get; set; }
        public string TransactionSystemIncomingOrderNumber { get; set; }
        public string PaymentReference { get; set; }
        public string InstructionCodeForBank { get; set; }
        public string InstructionForBank { get; set; }
        public string PurposeOfPayment { get; set; }
        public bool IsFunded { get; set; }
        public PainFileGenerationStatus PainFileGenerationStatus { get; set; }
        public List<string> RemittanceData { get; set; }
        public RemittanceType RemittanceType { get; set; }
        public string RejectReason { get; set; }
        public ThirdPartyRemitter ThirdPartyRemitter { get; set; }
        public bool IsFixedAmountInSettlementCurrency { get; set; }
        public Money SettlementAmountMoney { get; set; }

        public string CurrencyCode { get { return AmountMoney?.Currency.Code;  } }
        public string SettlementCurrencyCode { get { return SettlementAmountMoney?.Currency.Code; } }

        public PaymentSanctionScanStatus? SanctionScanStatus { get; set; }
        public DateTime? SanctionScanStatusUpdatedOnUtc { get; set; }

        public PaymentUpdateHistory LastUpdateError { get; set; }
    }
}
