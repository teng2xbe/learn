﻿using System;

namespace MassPayments.Domain.Entities
{
    public class OrderItem
    {
        public int OrderId { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public string TargetCurrencyCode { get; set; }
        public decimal Amount { get; set; }
        public DateTime? CreatedOn { get; set; }
    }
}
