﻿using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class BankAccountRequiredFieldsValidator : IPaymentRequestValidator
    {
        private readonly BankAccount bankAccountRequest;

        public BankAccountRequiredFieldsValidator(BankAccount bankAccount)
        {
            bankAccountRequest = bankAccount;
        }

        public IPaymentRequestResult Validate()
        {
            if (bankAccountRequest == null)
                return new PaymentRequestFailedResult<string>(ErrorCode.RequiredField, "bankAccount");

            if (string.IsNullOrEmpty(bankAccountRequest.Id))
                return new PaymentRequestFailedResult<string>(() => bankAccountRequest.Id);

            if (string.IsNullOrEmpty(bankAccountRequest.VersionedOn))
                return new PaymentRequestFailedResult<string>(() => bankAccountRequest.VersionedOn);

            if (string.IsNullOrEmpty(bankAccountRequest.AccountNumber))
                return new PaymentRequestFailedResult<string>(() => bankAccountRequest.AccountNumber);

            if (string.IsNullOrEmpty(bankAccountRequest.BankName))
                return new PaymentRequestFailedResult<string>(() => bankAccountRequest.BankName);

            if (string.IsNullOrEmpty(bankAccountRequest.BankCode) && string.IsNullOrEmpty(bankAccountRequest.BankBranchCode))
                return new PaymentRequestFailedResult<string>(() => bankAccountRequest.BankCode, ErrorCode.ConditionalField);

            if (bankAccountRequest.BankAddress == null)
                return new PaymentRequestFailedResult<Address>(() => bankAccountRequest.BankAddress);

            return new PaymentRequestSuccessful();
        }
    }
}
