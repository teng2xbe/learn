﻿using System;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class PaymentScheduleError
    {
        public int Id { get;set; }
        public int PaymentIntervalId { get; set; }
        public int CustomerId { get; set; }
        public DateTime FailedTimeUTC { get; set; }
        public string Message { get; set; }
        public DateTime NextRetryTimeUTC { get; set; }
        public int Count { get; set; }
        public PaymentScheduleStatus Status { get; set; }
    }
}
