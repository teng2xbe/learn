﻿using System;

namespace MassPayments.Domain.Entities
{
    public class ActionHandler
    {
        public int Id{ get; set; }
		public string UniqueName{ get; set; } 
		public int TimeToLiveInSeconds{ get; set; } 
		public string LockedGuid{ get; set; }
		public string LockedHostName{ get; set; } 
		public DateTime LockedOnUtc{ get; set; }
		public DateTime LockedTtlUtc{ get; set; }
		public bool IsScheduled{ get; set; }
		public DateTime PredictedNextExecutionUtc{ get; set; } 
		public int GracePeriodInSeconds{ get; set; }
    }
}
