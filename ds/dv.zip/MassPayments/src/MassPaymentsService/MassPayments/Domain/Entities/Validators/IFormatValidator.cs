﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MassPayments.Domain.Entities.Validators
{
    public interface IFormatValidator
    {
        string ValidateDateFormat(string dateTime);
    }
}
