﻿using System;
using System.Collections.Generic;
using System.Linq;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Caches;
using Newtonsoft.Json;

namespace MassPayments.Domain.Entities.PaymentRequest.Assemblers
{
    public static class PaymentRequestAssembler
    {
        public static Payment AssemblePayment(PaymentRequest paymentRequest, Partner partner, DateTime createdOnUtc, PaymentStatus paymentStatus)
        {
            var settlementCurrency = partner.PaymentModel == PaymentModel.Decoupled? null:
                                        String.IsNullOrEmpty(paymentRequest.SettlementCurrencyCode)
                                            ? paymentRequest.Customer.SettlementCurrency
                                            : CurrencyCache.Instance.GetById(paymentRequest.SettlementCurrencyCode);

            return new Payment(paymentRequest.PaymentId, paymentRequest.Customer.PartnerAssignedCustomerId)
            {
                PartnerReference = paymentRequest.PartnerReference,
                PaymentMethod = AssemblePaymentMethod(paymentRequest.PaymentMethod),
                CustomerBatchId = paymentRequest.CustomerBatchId,
                //TODO review how this amountMoney is used
                AmountMoney = String.IsNullOrEmpty(paymentRequest.CurrencyCode) ? null : 
                    new Money(CurrencyCache.Instance.GetById(paymentRequest.CurrencyCode), paymentRequest.IsFixedAmountInSettlementCurrency?
                        0:paymentRequest.FixedAmount),
                SettlementAmountMoney = (partner.PaymentModel == PaymentModel.Decoupled || settlementCurrency == null) ? null:
                    new Money(settlementCurrency, paymentRequest.IsFixedAmountInSettlementCurrency ?
                        paymentRequest.FixedAmount: 0),
                BankAccount = AssembleBankAccount(paymentRequest.BankAccount, paymentRequest.CurrencyCode),
                Beneficiary = AssembleBeneficiary(paymentRequest.Beneficiary),
                InstructionCodeForBank = paymentRequest.InstructionCodeForBank,
                InstructionForBank = paymentRequest.InstructionForBank,
                PurposeOfPayment = paymentRequest.PurposeOfPayment,
                TransactionSystemCustomerId = paymentRequest.Customer.TransactionSystemCustomerId,
                TransactionSystemId = paymentRequest.Customer.TransactionSystemId,
                CreatedOnUTC = createdOnUtc,
                UpdatedOnUTC = createdOnUtc,
                PaymentStatus = paymentStatus,
                PaymentSourceId = partner.Id,
                RemittanceType = AssembleRemittanceType(paymentRequest.RemittanceType),
                RemittanceData = AssembleRemittanceData(paymentRequest.RemittanceData),
                ThirdPartyRemitter = AssembleThirdPartyRemitter(paymentRequest.ThirdPartyRemitter),
                PaymentReference = paymentRequest.PaymentReference,
                IsFixedAmountInSettlementCurrency = paymentRequest.IsFixedAmountInSettlementCurrency
            };
        }

        private static string AssembleExternalTransferId(long version, string lastUpdatedOn)
        {
            return version > 0 ? version.ToString() : lastUpdatedOn;
        }

        public static string AssembleVersionedOn(string lastUpdatedOn)
        {
            DateTime lastUpdatedOnDate;
            if (DateTime.TryParse(lastUpdatedOn, out lastUpdatedOnDate))
                return lastUpdatedOn;

            return null;
        }

        private static long AssembleVersion(string versionedOn)
        {
            DateTime dateVersion;
            DateTime.TryParse(versionedOn, out dateVersion);
            long longVersion;
            long.TryParse(dateVersion.ToUniversalTime().ToString("yyyyMMddHHmmss"), out longVersion);

            return longVersion;
        }

        //private static long AssembleVersion(long version, string lastUpdatedOn)
        //{
        //    DateTime dateVersion;
        //    DateTime.TryParse(lastUpdatedOn, out dateVersion);
        //    long longVersion;
        //    long.TryParse(dateVersion.ToUniversalTime().ToString("yyyyMMddHHmmss"), out longVersion);

        //    return version > 0 ? version : longVersion;
        //}

        public static PaymentMethod AssemblePaymentMethod(string paymentMethodRequest)
        {
            PaymentMethod paymentMethod;
            Enum.TryParse(paymentMethodRequest, true, out paymentMethod);
            return paymentMethod;
        }

        public static RemittanceType AssembleRemittanceType(string remittanceTypeRequest)
        {
            RemittanceType remittanceType;
            Enum.TryParse(remittanceTypeRequest, true, out remittanceType);
            return remittanceType;
        }

        private static Entities.Beneficiary AssembleBeneficiary(Beneficiary beneficiaryRequest)
        {
            if (beneficiaryRequest == null) return null;
            var versionedOn = AssembleVersionedOn(beneficiaryRequest.VersionedOn);
            return new Entities.Beneficiary
            {
                ExternalId = beneficiaryRequest.Id,
                Address = AssembleAddress(beneficiaryRequest.Address),
                Identification = AssembleIdentification(beneficiaryRequest),
                VersionedOn = versionedOn,
                Version = AssembleVersion(versionedOn),
                Type = beneficiaryRequest.Type
            };
        }
        
        private static Entities.Identification AssembleIdentification(Beneficiary beneficiaryRequest)
        {
            return (beneficiaryRequest != null) ? new Entities.Identification
                {
                    FirstName = beneficiaryRequest.FirstName,
                    MiddleName = beneficiaryRequest.MiddleName,
                    LastName = beneficiaryRequest.LastName,
                    PhoneNumber = beneficiaryRequest.PhoneNumber,
                    CellNumber = beneficiaryRequest.CellNumber,
                    DateOfBirth = beneficiaryRequest.DateOfBirth,
                    Gender = beneficiaryRequest.Gender,
                    EntityType = beneficiaryRequest.Type,
                    BusinessName = beneficiaryRequest.BusinessName,
                    BusinessRegistrationNumber = beneficiaryRequest.BusinessRegistrationNumber,
                    BusinessRegistrationCountry = beneficiaryRequest.BusinessRegistrationCountry,
                    BusinessRegistrationStateProv = beneficiaryRequest.BusinessRegistrationStateProv,
                    BusinessContactRole = beneficiaryRequest.BusinessContactRole,
                    Industry = beneficiaryRequest.Industry,
                    EmailAddress = beneficiaryRequest.EmailAddress,
                }
                : null;
        }

        private static Entities.BankAccount AssembleBankAccount(BankAccount bankAccountRequest, string currencyCode)
        {
            if (bankAccountRequest == null) return null;
            var versionedOn = AssembleVersionedOn(bankAccountRequest.VersionedOn);
            return new Entities.BankAccount
            {
                VersionedOn = versionedOn,
                Version = AssembleVersion(versionedOn),
                ExternalId = bankAccountRequest.Id,
                CurrencyCode = currencyCode,
                AccountNumber = bankAccountRequest.AccountNumber,
                AccountPurpose = bankAccountRequest.AccountType,
                BankName = bankAccountRequest.BankName,
                BranchName = bankAccountRequest.BranchName,
                BankCode = bankAccountRequest.BankCode,
                BranchCode = bankAccountRequest.BankBranchCode,
                BankAddress = AssembleAddress(bankAccountRequest.BankAddress),
                IntermediaryBankAccount = AssembleIntermediaryBankAccount(bankAccountRequest.IntermediaryBank),
                BankAccountOwnerName = bankAccountRequest.BankAccountOwnerName
            };
        }

        private static Entities.Address AssembleAddress(Address addressRequest)
        {
            return (addressRequest != null) ? new Entities.Address
            {
                AddressLine1 = addressRequest.AddressLine1,
                AddressLine2 = addressRequest.AddressLine2,
                AddressLine3 = addressRequest.AddressLine3,
                City = addressRequest.City,
                StateOrProvince = addressRequest.StateOrPovince,
                ZipOrPostalCode = addressRequest.ZipOrPostalCode,
                CountryCode = addressRequest.CountryCode,
            } : null;
        }

        private static Entities.IntermediaryBankAccount AssembleIntermediaryBankAccount(IntermediaryBank intermediaryBank)
        {
            return (intermediaryBank != null) ? new Entities.IntermediaryBankAccount
                {
                    BankName = intermediaryBank.BankName,
                    BankCode = intermediaryBank.BankCode,
                    AccountNumber = intermediaryBank.AccountNumber,
                    BankAddress = AssembleAddress(intermediaryBank.Address),
                    BankBranchCode = intermediaryBank.BankBranchCode
                } : null;
        }
        
        private static List<string> AssembleRemittanceData(List<RemittanceReference> remittanceData)
        {
            return remittanceData != null ? remittanceData.Select(i=>i.Reference).ToList() : null;
        }

        private static Entities.ThirdPartyRemitter AssembleThirdPartyRemitter(ThirdPartyRemitter thirdPartyRemitter)
        {
            if (thirdPartyRemitter == null) return null;
            var versionedOn = AssembleVersionedOn(thirdPartyRemitter.VersionedOn);
            return new Entities.ThirdPartyRemitter
            {
                Id = thirdPartyRemitter.Id,
                VersionedOn = versionedOn,
                Version = AssembleVersion(versionedOn),
                Type = thirdPartyRemitter.Type,
                BusinessName = thirdPartyRemitter.BusinessName,
                Address = AssembleAddress(thirdPartyRemitter.Address),
                Email = thirdPartyRemitter.Email,
                PhoneNumber = thirdPartyRemitter.PhoneNumber,
                IdentificationType = thirdPartyRemitter.IdentificationType,
                Identification = thirdPartyRemitter.Identification,
                Industry = thirdPartyRemitter.Industry
            };
        }

    }
}
