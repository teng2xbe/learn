﻿using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class AddressRequiredFieldsValidator: IPaymentRequestValidator
    {
        private readonly Address addressRequest;

        public AddressRequiredFieldsValidator(Address address)
        {
            addressRequest = address;
        }

        public IPaymentRequestResult Validate()
        {
            if (addressRequest == null)
                return new PaymentRequestFailedResult<string>(ErrorCode.RequiredField, "address"); 
            
            if (string.IsNullOrEmpty(addressRequest.AddressLine1))
                return new PaymentRequestFailedResult<string>(() => addressRequest.AddressLine1);

            if (string.IsNullOrEmpty(addressRequest.City))
                return new PaymentRequestFailedResult<string>(() => addressRequest.City);
            
            if (string.IsNullOrEmpty(addressRequest.StateOrPovince))
                return new PaymentRequestFailedResult<string>(() => addressRequest.StateOrPovince);
            
            if (string.IsNullOrEmpty(addressRequest.ZipOrPostalCode))
                return new PaymentRequestFailedResult<string>(() => addressRequest.ZipOrPostalCode);
            
            if (string.IsNullOrEmpty(addressRequest.CountryCode))
                return new PaymentRequestFailedResult<string>(() => addressRequest.CountryCode);
            
            return new PaymentRequestSuccessful();
        }
    }
}
