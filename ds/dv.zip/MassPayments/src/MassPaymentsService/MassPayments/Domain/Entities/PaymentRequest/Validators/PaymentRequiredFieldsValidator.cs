﻿using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class PaymentRequiredFieldsValidator : IPaymentRequestValidator
    {
        private readonly PaymentRequest paymentRequest;

        public PaymentRequiredFieldsValidator(PaymentRequest paymentRequest)
        {
            this.paymentRequest = paymentRequest;
        }

        public IPaymentRequestResult Validate()
        {
            if (paymentRequest == null)
                return new PaymentRequestFailedResult<string>(ErrorCode.RequiredField, "payment");           

            if (paymentRequest.Beneficiary == null)
                return new PaymentRequestFailedResult<Beneficiary>(() => paymentRequest.Beneficiary);

            if (string.IsNullOrEmpty(paymentRequest.Beneficiary.VersionedOn))
                return new PaymentRequestFailedResult<string>(() => paymentRequest.Beneficiary.VersionedOn);

            if (paymentRequest.BankAccount == null)
                return new PaymentRequestFailedResult<string>(ErrorCode.RequiredField, "bankAccount");

            if (string.IsNullOrEmpty(paymentRequest.BankAccount.VersionedOn))
                return new PaymentRequestFailedResult<string>(() => paymentRequest.BankAccount.VersionedOn);
            
            return new PaymentRequestSuccessful();
        }
    }
}
