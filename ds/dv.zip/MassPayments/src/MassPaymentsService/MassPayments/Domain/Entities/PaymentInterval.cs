﻿using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class PaymentInterval
    {
        public int Id;
        public Currency Currency;
        public PaymentMethod PaymentMethod;
        public string Interval;
    }
}
