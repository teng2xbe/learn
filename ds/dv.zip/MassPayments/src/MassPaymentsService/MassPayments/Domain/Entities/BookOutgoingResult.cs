﻿using System.Collections.Generic;
namespace MassPayments.Domain.Entities
{
    public class BookOutgoingResult
    {
        public List<Payment> SanctionClearedPaymentsForCurrency;
        public List<Payment> NewBookedOutOfHoldingPayments;
        public List<Payment> AlreadyBookedOutOfHoldingPayments;
    }
}
