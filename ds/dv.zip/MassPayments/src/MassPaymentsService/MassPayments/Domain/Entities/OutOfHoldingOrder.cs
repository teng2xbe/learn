﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Enums;
using NHibernate.Mapping;

namespace MassPayments.Domain.Entities
{
    public class OutOfHoldingOrder
    {
        public int Id { get; set; }
        public int PartnerId { get; set; }
        public int CustomerId { get; set; }
        public string OrderNumber { get; set; }
        public int ReportId { get; set; }
        public List<OutOfHoldingOrderItem> LineItems { get; set; }
        public DateTime CreatedOnUTC { get; set; }
    }
}
