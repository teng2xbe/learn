﻿using System;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities.Subscription
{
    public class SubscriptionEvent
    {
        public int Id { get; set; }
        public SubscriptionEventType SubscriptionEventType { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public string JsonEventArguments { get; set; }
    }
}
