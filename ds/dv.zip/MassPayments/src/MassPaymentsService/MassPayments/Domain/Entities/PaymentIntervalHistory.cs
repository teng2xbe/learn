﻿using System;

namespace MassPayments.Domain.Entities
{
    public class PaymentIntervalHistory
    {
        public int PaymentId { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
