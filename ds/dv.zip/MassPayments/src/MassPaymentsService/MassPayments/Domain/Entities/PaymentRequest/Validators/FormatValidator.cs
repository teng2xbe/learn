﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using MassPayments.Domain.Entities.PaymentRequest.Assemblers;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class FormatValidator : IPaymentRequestValidator
    {
        private readonly PaymentRequest paymentRequest;
        const string TimestampFormat = "yyyy-MM-ddTHH:mm:ssZ";
        private Regex rgxExternalIdPattern = null;

        public FormatValidator(PaymentRequest request)
        {
            paymentRequest = request;
            rgxExternalIdPattern = new Regex("^" + ValidationRules.Instance.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}") + "$");
        }

        public IPaymentRequestResult Validate()
        {
            if (!string.IsNullOrEmpty(paymentRequest.Beneficiary.VersionedOn) && IsNotValidTimeStamp(paymentRequest.Beneficiary.VersionedOn))
                return new PaymentRequestFailedResult<string>(() => paymentRequest.Beneficiary.VersionedOn, ErrorCode.InvalidValueOrFormat);

            if (paymentRequest.BankAccount != null && 
                (!string.IsNullOrEmpty(paymentRequest.BankAccount.VersionedOn) && IsNotValidTimeStamp(paymentRequest.BankAccount.VersionedOn)))
                return new PaymentRequestFailedResult<string>(() => paymentRequest.BankAccount.VersionedOn, ErrorCode.InvalidValueOrFormat);

            if (paymentRequest.ThirdPartyRemitter != null &&
                (!string.IsNullOrEmpty(paymentRequest.ThirdPartyRemitter.VersionedOn) && IsNotValidTimeStamp(paymentRequest.ThirdPartyRemitter.VersionedOn)))
                return new PaymentRequestFailedResult<string>(ErrorCode.InvalidValueOrFormat, "thirdPartyRemitter.versionedOn");

            if (!IsValidCurrency(paymentRequest.CurrencyCode))
                return new PaymentRequestFailedResult<string>(ErrorCode.InvalidValueOrFormat, "currency");

            if (!IsCurrencySupported(paymentRequest.CurrencyCode))
                return new PaymentRequestFailedResult<string>(ErrorCode.CurrencyNotSupported, "currency");

            if (!string.IsNullOrEmpty(paymentRequest.SettlementCurrencyCode) && !IsValidCurrency(paymentRequest.SettlementCurrencyCode))
                return new PaymentRequestFailedResult<string>(ErrorCode.InvalidValueOrFormat, "settlementCurrency");

            if (!string.IsNullOrEmpty(paymentRequest.SettlementCurrencyCode) && !IsCurrencySupported(paymentRequest.SettlementCurrencyCode))
                return new PaymentRequestFailedResult<string>(ErrorCode.CurrencyNotSupported, "settlementCurrency");

            if (!rgxExternalIdPattern.IsMatch(paymentRequest.PaymentId))
                return new PaymentRequestFailedResult<string>(ErrorCode.InvalidValueOrFormat, "id");

            if (paymentRequest.Beneficiary != null && !rgxExternalIdPattern.IsMatch(paymentRequest.Beneficiary.Id))
                return new PaymentRequestFailedResult<string>(ErrorCode.InvalidValueOrFormat, "beneficiary.id");

            if (paymentRequest.BankAccount != null && !rgxExternalIdPattern.IsMatch(paymentRequest.BankAccount.Id))
                return new PaymentRequestFailedResult<string>(ErrorCode.InvalidValueOrFormat, "bankAccount.id");

            if (paymentRequest.ThirdPartyRemitter != null && !rgxExternalIdPattern.IsMatch(paymentRequest.ThirdPartyRemitter.Id))
                return new PaymentRequestFailedResult<string>(ErrorCode.InvalidValueOrFormat, "thirdPartyRemitter.id");

            return new PaymentRequestSuccessful();
        }

        private static bool IsNotValidTimeStamp(string timestamp)
        {
            DateTime lastUpdatedOn;
            return (!DateTime.TryParseExact(timestamp, TimestampFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out lastUpdatedOn));
        }

        private static bool IsValidCurrency(string currencyCode)
        {
            try
            {
                var currency = CurrencyCache.Instance.GetById(currencyCode);
                return !(currency == null || currency == Currency.Null);
            }
            catch
            {
                return false;
            }
        }


        private static bool IsCurrencySupported(string currencyCode)
        {
            try
            {
                return CurrencyCache.Instance.GetById(currencyCode).Status == CurrencyStatus.Enabled;
            }
            catch
            {
                return false;
            }
        }

        private static bool IsPaymentMethodSupportedForCurrency(string currencyCode, string paymentMethod)
        {
            try
            {
                return (IsValidPaymentMethod(paymentMethod)) &&
                       CurrencyPaymentMethodCache.Instance.GetById(currencyCode)
                           .Contains(PaymentRequestAssembler.AssemblePaymentMethod(paymentMethod));
            }
            catch
            {
                return false;
            }
        }

        private static bool IsValidPaymentMethod(string paymentMethodRequest)
        {
            PaymentMethod paymentMethod;
            return Enum.TryParse(paymentMethodRequest, true, out paymentMethod);
        }
    }
}
