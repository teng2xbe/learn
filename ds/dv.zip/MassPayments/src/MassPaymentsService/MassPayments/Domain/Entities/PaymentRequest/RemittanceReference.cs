﻿
namespace MassPayments.Domain.Entities.PaymentRequest
{
    public class RemittanceReference
    {
        public string Reference { get; set; }
    }
}
