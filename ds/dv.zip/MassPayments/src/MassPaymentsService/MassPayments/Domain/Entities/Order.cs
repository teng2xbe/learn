﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Enums;

namespace MassPayments.Domain.Entities
{
    public class Order
    {
        public int OrderId { get; set; }
        public string ConfirmationNumber { get; set; }
        public int TransactionSystemQuoteId { get; set; }
        public int TransactionSystemCustomerId { get; set; }
        public int QuoteRequestId { get; set; }
        public OrderStatus OrderStatus { get; set; }
        public int PartnerId { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public string SettlementPaymentMethod { get; set; }
        public int CustomerId { get; set; }
        public string PartnerAssignedCustomerId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? LastUpdatedOn { get; set; }
        public string PartnerReference { get; set; }
        public List<OrderItem> OrderItems { get; set; }
        public string CustomerBatchExternalId { get; set; }
    }
}
