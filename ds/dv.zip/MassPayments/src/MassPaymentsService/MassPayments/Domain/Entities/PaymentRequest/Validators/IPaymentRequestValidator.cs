﻿
namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public interface IPaymentRequestValidator
    {
        IPaymentRequestResult Validate();
    }
}
