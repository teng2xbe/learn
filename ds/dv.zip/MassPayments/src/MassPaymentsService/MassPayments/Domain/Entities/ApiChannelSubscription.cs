﻿using MassPayments.Domain.Enums;
using MassPayments.Domain.Interfaces;

namespace MassPayments.Domain.Entities
{
    public class ApiChannelSubscription : ISubscription
    {
        public int Id { get; set; }
        public int PartnerId { get; set; }
        public SubscriptionType SubscriptionType { get; set; }
        public string Endpoint { get; set; }
        public string Certificate { get; set; }
        public string BodyTemplate { get; set; }
    }
}
