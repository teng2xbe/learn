﻿using System;

namespace MassPayments.Domain.Entities
{
    public class PaymentUpdateHistory
    {
        public int PaymentId { get; set; }
        public int PaymentRequestId { get; set; }
        public DateTime UpdatedOnUtc { get; set; }
        public string ErrorCode { get; set; }
    }
}
