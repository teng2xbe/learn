﻿using System;
using System.Linq.Expressions;
using MassPayments.Infrastructure.Caches;
using MassPaymentsCommon.WCFContracts.Enums;

namespace MassPayments.Domain.Entities.PaymentRequest.Validators
{
    public class PaymentRequestFailedResult<T>: IPaymentRequestResult
    {
        public string Message { get; private set; }

        public PaymentRequestFailedResult(ErrorCode errorCode)
        {
            Message = ((int)errorCode).ToString();
        }

        public PaymentRequestFailedResult(ErrorCode errorCode, string message)
        {
            Message = ((int)errorCode) + ":" + message;
        }

        public PaymentRequestFailedResult(string errorMessage)
        {
            Message = errorMessage;
        }
        
        public PaymentRequestFailedResult(Exception exception)
        {
            Message = exception.Message;
        }

        public PaymentRequestFailedResult(Expression<Func<T>> propertyExpression, ErrorCode errorCode = ErrorCode.RequiredField)
            : this(errorCode, PaymentValidationCache.Instance.GetById(propertyExpression))
        {
        }

        public virtual void Process()
        {
        }

        public bool HasFailed()
        {
            return true;
        }

        public void Record(PaymentRequest paymentRequest)
        {
            paymentRequest.RecordFailedValidation(Message);
        }
    }
}
