﻿using System;


namespace MassPayments.Exceptions
{
    public class DailyTransactionAmountExceedsException : InternalErrorException
    {
        public DailyTransactionAmountExceedsException() : base("Please try transaction tomorrow") { }
    }
}
