﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MassPayments.Domain.Entities;

namespace MassPayments.Exceptions
{
    public class FileExtensionNotSupportedException : InputDataValidationException
    {
        public FileExtensionNotSupportedException(string fileName) : base(string.Format("File {0} has an unsupported extension.",fileName))
        {
            
        }
    }
}
