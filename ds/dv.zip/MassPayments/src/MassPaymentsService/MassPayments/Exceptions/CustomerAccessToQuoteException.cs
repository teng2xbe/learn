﻿using System;

namespace MassPayments.Exceptions
{
    public class CustomerAccessToQuoteException : InputDataValidationException
    {
        public CustomerAccessToQuoteException(string message) : base(message)
        {
        }
    }
}
