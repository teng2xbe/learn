﻿using System;
namespace MassPayments.Exceptions
{
    public class AccessDeniedException : InputDataValidationException
    {
        public AccessDeniedException() : base("Access denied.")
        {
            
        }

        public AccessDeniedException(string message)
            : base(message)
        {

        }
    }
}
