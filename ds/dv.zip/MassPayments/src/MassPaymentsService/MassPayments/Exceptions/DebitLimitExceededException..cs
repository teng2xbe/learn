﻿using System;

namespace MassPayments.Exceptions
{
    public class DebitLimitExceededException : InputDataValidationException
    {
        public DebitLimitExceededException(string errorMessage) : base(errorMessage) {}
    }
}
