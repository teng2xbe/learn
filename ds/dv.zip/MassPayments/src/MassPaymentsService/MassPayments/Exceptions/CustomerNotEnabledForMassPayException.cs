﻿using System;

namespace MassPayments.Exceptions
{
    public class CustomerNotEnabledForMassPayException : InputDataValidationException
    {
        public CustomerNotEnabledForMassPayException(string message)
            : base(message)
        {
        }
    }
}
