﻿using System;

namespace MassPayments.Exceptions
{
    public class CurrencyNotCapableofHoldingException : InputDataValidationException
    {
        public CurrencyNotCapableofHoldingException(string errorMessage) : base(errorMessage) {}
    }
}
