﻿using System;

namespace MassPayments.Exceptions
{
    public class DecoupledPartnerAccessException : InputDataValidationException
    {
        public DecoupledPartnerAccessException(string message) : base(message)
        {
        }
    }
}
