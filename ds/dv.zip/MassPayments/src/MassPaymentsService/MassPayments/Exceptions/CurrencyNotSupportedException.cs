﻿using System;


namespace MassPayments.Exceptions
{
    public class CurrencyNotSupportedException : InputDataValidationException
    {
        public CurrencyNotSupportedException(string currencyType, string invalidField)
            : base(invalidField, string.Format("{0} currency not supported", currencyType) )
        {
        }
    }
}
