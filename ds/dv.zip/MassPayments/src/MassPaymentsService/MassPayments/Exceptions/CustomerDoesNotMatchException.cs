﻿using System;


namespace MassPayments.Exceptions
{
    public class CustomerDoesNotMatchException : InputDataValidationException
    {
        public CustomerDoesNotMatchException(string partnerAssignedCustomerId, string batchId)
            : base(string.Format("{0} customer does not match batch {1}", partnerAssignedCustomerId, batchId))
        {
        }
    }
}
