﻿using System;


namespace MassPayments.Exceptions
{
    public class CurrencyNotRecognizedException : InputDataValidationException
    {
        public CurrencyNotRecognizedException(string currencyType, string invalidField)
            : base(invalidField, string.Format("{0} currency not recognized", currencyType))
        {
        }

        public CurrencyNotRecognizedException()
            : base(null, "Currency code not recognized.")
        {
        }
    }
}
