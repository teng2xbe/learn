﻿using System;

namespace MassPayments.Exceptions
{
    public class CoupledPartnerAccessException : InputDataValidationException
    {
        public CoupledPartnerAccessException(string message) : base(message) { }
    }
}
