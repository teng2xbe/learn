﻿using System;

namespace MassPayments.Exceptions
{
    public class CannotQuoteUsingBatchIdException : InputDataValidationException
    {
        public CannotQuoteUsingBatchIdException(string batchId)
            : base(string.Format("Cannot quote using batchId #{0}.  This batchId may have already been booked in a previous order.", batchId))
        {
        }
    }
}
