﻿using System;


namespace MassPayments.Exceptions
{
    public class AmountTooHighException : InputDataValidationException
    {
        public AmountTooHighException() : base("Amount too high") { }
    }
}
