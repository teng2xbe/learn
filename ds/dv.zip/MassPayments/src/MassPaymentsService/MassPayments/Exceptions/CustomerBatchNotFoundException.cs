﻿namespace MassPayments.Exceptions
{
    public class CustomerBatchNotFoundException: InputDataValidationException
    {
        public CustomerBatchNotFoundException(string message) : base(message) { }
    }
}
