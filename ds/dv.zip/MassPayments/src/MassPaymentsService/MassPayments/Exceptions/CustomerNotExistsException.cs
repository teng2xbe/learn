﻿using System;

namespace MassPayments.Exceptions
{
    public class CustomerNotExistsException : ValidationException
    {
        public CustomerNotExistsException(string message)
            : base(message)
        {
        }
    }
}
