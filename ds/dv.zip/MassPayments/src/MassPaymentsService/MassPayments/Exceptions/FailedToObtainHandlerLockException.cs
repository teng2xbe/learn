﻿using System;

namespace MassPayments.Exceptions
{
    public class FailedToObtainHandlerLockException : InternalErrorException
    {
        public FailedToObtainHandlerLockException(string message)
            : base(message)
        {   
        }
    }
}
