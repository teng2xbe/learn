﻿using System;
using System.Runtime.ExceptionServices;
using System.Text;
using MassPayments.ActionHandlers.Interfaces;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Logger;
using MassPayments.Managers;
using MassPayments.Managers.Interfaces;
using SharedUtilities;

namespace MassPayments.ActionHandlers
{
    public abstract class BaseActionHandler : IActionHandler
    {
        private readonly IActionHandlingManager actionHandlingManager;
        
        protected BaseActionHandler()
        {
            actionHandlingManager = new ActionHandlingManager();
        }

        protected BaseActionHandler(IActionHandlingManager actionHandlingManager)
        {
            this.actionHandlingManager = actionHandlingManager;
        }

        protected int GetLock(string handlerGuid, string hostName, int predictedNextExecutionTimeInSeconds)
        {
            string handlerFullName = GetHandlerFullName();
            return actionHandlingManager.GetLock(handlerFullName, handlerGuid, hostName, predictedNextExecutionTimeInSeconds);
        }

        protected virtual string GetHandlerFullName()
        {
            return GetType().FullName;
        }

        protected void ReleaseLock(int handlerId)
        {
            actionHandlingManager.ReleaseLock(handlerId);
        }

        public virtual void Handle(string handlerGuid, string hostName, ActionHandlerDelegate handle)
        {
            Handle(handlerGuid, hostName, handle, 0);
        }

        public virtual void Handle(string handlerGuid, string hostName, ActionHandlerDelegate handle, int predictedNextExecutionInSeconds)
        {
            ExceptionDispatchInfo exceptionInfoToBubbleUp = null;
            int handlerId = 0;

            bool isLockingDisabled = Settings.GetBooleanValue("ActionHandler.DisableLocking", false);
            try
            {
                if (!isLockingDisabled)
                    handlerId = GetLock(handlerGuid, hostName, predictedNextExecutionInSeconds);
                handle();
            }
            catch (FailedToObtainHandlerLockException ex)
            {
                var shouldLog = Settings.GetBooleanValue("ActionHandler.LogWhenGetLockFails", false);
                if (shouldLog)
                    EventLogger.Instance.WriteWarning(
                    string.Format("{0} failed to obtain lock. {1}", GetHandlerFullName(), ex.Message),EventCode.FailToObtainActionHandlerLockWarning);
            }
            catch (Exception ex)
            {
                exceptionInfoToBubbleUp = ExceptionDispatchInfo.Capture(ex);
            }
            finally
            {

                if (handlerId != 0 && !isLockingDisabled)
                    ReleaseLock(handlerId);

                if (exceptionInfoToBubbleUp != null)
                {
                    var errorMessageBuilder = new StringBuilder().AppendFormat("An error happened during execution of {0}", GetHandlerFullName());
                    errorMessageBuilder
                        .AppendLine("Detail: ")
                        .AppendLine(exceptionInfoToBubbleUp.SourceException != null ? exceptionInfoToBubbleUp.SourceException.Message : "")
                        .AppendLine( exceptionInfoToBubbleUp.SourceException != null ? exceptionInfoToBubbleUp.SourceException.StackTrace : "");

                    EventLogger.Instance.WriteError(errorMessageBuilder.ToString(), EventCode.ActionHandlerExecutionError);
                }
            }
        }
    }
}
