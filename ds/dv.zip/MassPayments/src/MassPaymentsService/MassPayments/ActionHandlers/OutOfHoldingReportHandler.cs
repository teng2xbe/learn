﻿using MassPayments.Managers.Interfaces;

namespace MassPayments.ActionHandlers
{
    public class OutOfHoldingReportHandler : BaseActionHandler
    {
        private string partnerCode;
        
        public OutOfHoldingReportHandler(string partnerCode) : base()
        {
            this.partnerCode = partnerCode;
        }

        public OutOfHoldingReportHandler(IActionHandlingManager actionHandlingManager, string partnerCode)
            : base(actionHandlingManager)
        {
            this.partnerCode = partnerCode;
        }

        protected override string GetHandlerFullName()
        {
            return string.Format("{0}_{1}", GetType().FullName, partnerCode);
        }

    }
}
