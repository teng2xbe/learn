﻿namespace MassPayments.ActionHandlers
{
    public delegate void ActionHandlerDelegate();
}
