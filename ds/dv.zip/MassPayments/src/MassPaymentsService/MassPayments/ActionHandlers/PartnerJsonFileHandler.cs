﻿namespace MassPayments.ActionHandlers
{
    public class PartnerJsonFileHandler : BaseActionHandler{
    }
}
