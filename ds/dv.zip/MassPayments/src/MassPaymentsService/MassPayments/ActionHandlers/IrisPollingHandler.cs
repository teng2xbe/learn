﻿namespace MassPayments.ActionHandlers
{
    public class IrisPollingHandler : BaseActionHandler
    {
    }
}
