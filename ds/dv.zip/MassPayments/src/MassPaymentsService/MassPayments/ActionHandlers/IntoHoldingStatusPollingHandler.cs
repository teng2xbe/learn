﻿namespace MassPayments.ActionHandlers
{
    public class IntoHoldingStatusPollingHandler : BaseActionHandler
    {
    }
}
