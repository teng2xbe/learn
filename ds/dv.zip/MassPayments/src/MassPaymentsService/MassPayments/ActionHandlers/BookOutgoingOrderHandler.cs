﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Managers.Interfaces;

namespace MassPayments.ActionHandlers
{
    public class BookOutgoingOrderHandler : BaseActionHandler
    {
        private Currency currency;
        private PaymentMethod paymentMethod;

        public BookOutgoingOrderHandler(Currency currency, PaymentMethod paymentMethod) : base()
        {
            this.currency = currency;
            this.paymentMethod = paymentMethod;
        }

        public BookOutgoingOrderHandler(IActionHandlingManager actionHandlingManager, Currency currency, PaymentMethod paymentMethod)
            : base(actionHandlingManager)
        {
            this.currency = currency;
            this.paymentMethod = paymentMethod;
        }

        protected override string GetHandlerFullName()
        {
            return string.Format("{0}_{1}_{2}",GetType().FullName, currency.Code,paymentMethod);
        }

    }
}
