﻿namespace MassPayments.ActionHandlers
{
    public class IrisQueuePollingHandler : BaseActionHandler
    {
    }
}
