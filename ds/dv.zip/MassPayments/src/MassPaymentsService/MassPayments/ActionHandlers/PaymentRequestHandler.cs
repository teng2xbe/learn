﻿namespace MassPayments.ActionHandlers
{
    public class PaymentRequestHandler : BaseActionHandler
    {
    }
}
