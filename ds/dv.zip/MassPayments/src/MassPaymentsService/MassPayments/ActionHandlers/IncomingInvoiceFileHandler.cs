﻿namespace MassPayments.ActionHandlers
{
    public class IncomingInvoiceFileHandler : BaseActionHandler{
    }
}
