﻿using System;

namespace MassPayments.ActionHandlers.Interfaces
{
    public interface IActionHandler
    {
        void Handle(string handlerGuid, string hostName, ActionHandlerDelegate handle);
        void Handle(string handlerGuid, string hostName, ActionHandlerDelegate handle, int predictedNextExecutionInSeconds);
    }
}
