﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MassPayments.Domain.Entities;
using MassPayments.Gateways.Invoice.Assemblers;
using MassPayments.ResourceAccess.ClientRA;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Gateways.Invoice.Assemblers
{
    [TestFixture]
    public class OutOfHoldingReportAssemblerFixture
    {
        [Test]
        public void ToOutOfHoldingReport_Assembles_ItemNo_Correclty()
        {
            var orderItems = new List<OutOfHoldingOrderItem>
            {
                new OutOfHoldingOrderItem {Id = 10, Amount = 100, OrderId = 1, SettlementCurrencyCode = "CAD", TradeCurrencyCode = "USD"},
                new OutOfHoldingOrderItem {Id = 20, Amount = 200, OrderId = 1, SettlementCurrencyCode = "CAD", TradeCurrencyCode = "EUR"},
                new OutOfHoldingOrderItem {Id = 30, Amount = 300, OrderId = 1, SettlementCurrencyCode = "CAD", TradeCurrencyCode = "AUS"}
            };

            var oohOrder = new OutOfHoldingOrder
            {
                Id = 1,
                CreatedOnUTC = DateTime.UtcNow,
                CustomerId = 1,
                OrderNumber = "bleh",
                PartnerId = 1,
                ReportId = 1,
                LineItems = orderItems
                
            };
            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(1234);
            var aggregateInvoice = OutOfHoldingReportAssembler.ToOutOfHoldingReport(new List<OutOfHoldingOrder> {oohOrder}, clientInfo);

            Assert.AreEqual(3, aggregateInvoice.OrderDetails[0].Items.Count);
            Assert.AreEqual(1, aggregateInvoice.OrderDetails[0].Items[0].ItemNo);
            Assert.AreEqual(2, aggregateInvoice.OrderDetails[0].Items[1].ItemNo);
            Assert.AreEqual(3, aggregateInvoice.OrderDetails[0].Items[2].ItemNo);
        }
    }
}
