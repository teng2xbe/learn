﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Mappers
{
    [TestFixture]
    public class PaymentFactoryFixture
    {
        [Test]
        public void Create_ShouldCreate_Payment_Instance()
        {
            var payment = PaymentFactory.Create("1", "2", PaymentStatus.Created);
            Assert.IsInstanceOf<Payment>(payment);
        }

        [Test]
        public void Create_ShouldCreate_ReturnPayment_Instance()
        {
            var payment = PaymentFactory.Create("1", "2", PaymentStatus.Returned);
            Assert.IsInstanceOf<ReturnedPayment>(payment);
        }
    }
}
