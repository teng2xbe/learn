﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Providers.StorageProvider;
using MassPayments.Providers.StorageProvider.EventArguments;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Providers
{
    [TestFixture]
    public class BeneficiaryBIStorageProviderFixture
    {
        [SetUp]
        public void Setup()
        {
            BIMapper.Instance = MockRepository.GenerateMock<IBIMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
        }

        [TearDown]
        public void TearDown()
        {
            BIMapper.Instance = null;
            EventLogger.Instance = null;
        }

        [Test]
        public void BeneficiaryProvider_MakeCorrectCalls()
        {
            var beneficiary = new Beneficiary();
            var bank = new BankAccount();
            var bankAccounts = new List<BankAccount> {bank};
            var thirdParty = new ThirdPartyRemitter();
            var datetime = DateTime.UtcNow;
            var args = BeneficiaryEventArgs.GetBeneficiaryEventArgs(beneficiary, bankAccounts, "test",1, thirdParty, "testPartnerCode",10, 0, datetime);

            Assert.DoesNotThrow(()=> new BeneficiaryBIStorageProvider().HandleBeneficiariesInsertOrUpdate(new object {}, new List<BeneficiaryEventArgs>{args}));

            BIMapper.Instance.AssertWasCalled(bm => bm.InsertBeneficiary(beneficiary, "testPartnerCode", 10, 0, datetime), options => options.Repeat.Times(1));
            BIMapper.Instance.AssertWasCalled(bm => bm.InsertBankAccount(bank, "testPartnerCode", datetime, 0, 10), options => options.Repeat.Times(1));
            BIMapper.Instance.AssertWasCalled(bm => bm.InsertThirdPartyRemitter(thirdParty, "testPartnerCode", 0, datetime, 10), options => options.Repeat.Times(1));
        }

        [Test]
        public void BeneficiaryProvider_WritesToLog_WhenErrorOnBeneficiarySave()
        {
            var beneficiary = new Beneficiary();
            var bank = new BankAccount();
            var bankAccounts = new List<BankAccount> { bank };
            var datetime = DateTime.UtcNow;
            var args = BeneficiaryEventArgs.GetBeneficiaryEventArgs(beneficiary, bankAccounts, "test",1, null,"testParterCode", 10, 0, datetime);
            BIMapper.Instance.Expect(bm => bm.InsertBeneficiary(beneficiary, "testParterCode", 10, 0, datetime)).Throw(new Exception());

            var provider = MockRepository.GeneratePartialMock<BeneficiaryBIStorageProvider>();
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(1);
            Assert.DoesNotThrow(() => provider.HandleBeneficiariesInsertOrUpdate(Arg<object>.Is.Anything, new List<BeneficiaryEventArgs> { args }));

            provider.VerifyAllExpectations();
            BIMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BeneficiaryProvider_WritesToLog_WhenErrorOnBankAccountSave()
        {
            var beneficiary = new Beneficiary();
            var bank = new BankAccount();
            var bankAccounts = new List<BankAccount> { bank, bank, bank };
            var datetime = DateTime.UtcNow;
            var args = BeneficiaryEventArgs.GetBeneficiaryEventArgs(beneficiary, bankAccounts, "test", 1, null, "testParterCode", 10, 0, datetime);
            BIMapper.Instance.Expect(bm => bm.InsertBeneficiary(beneficiary, "testParterCode", 10, 0, datetime));
            BIMapper.Instance.Expect(bm => bm.InsertBankAccount(Arg<BankAccount>.Is.Anything, Arg<string>.Is.Anything, Arg<DateTime>.Is.Anything, 
                Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Throw(new Exception());

            var provider = MockRepository.GeneratePartialMock<BeneficiaryBIStorageProvider>();
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(1);
            Assert.DoesNotThrow(() => provider.HandleBeneficiariesInsertOrUpdate(Arg<object>.Is.Anything, new List<BeneficiaryEventArgs> { args }));

            provider.VerifyAllExpectations();
            BIMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BeneficiaryProvider_OneBankAccountFails_ProceedToNextBankAccount()
        {
            var beneficiary = new Beneficiary();
            var bank1 = new BankAccount { ExternalId = "123" };
            var bank2 = new BankAccount { ExternalId = "1234" };
            var bank3 = new BankAccount { ExternalId = "12345" };
            var bankAccounts = new List<BankAccount> { bank1, bank2, bank3 };
            var datetime = DateTime.UtcNow;
            var args = BeneficiaryEventArgs.GetBeneficiaryEventArgs(beneficiary, bankAccounts, "test", 1, null, "testParterCode",10, 0, datetime);
            BIMapper.Instance.Expect(bm => bm.InsertBeneficiary(beneficiary, "testParterCode", 10, 0, datetime));
            BIMapper.Instance.Expect(bm => bm.InsertBankAccount(bank1, "testParterCode", datetime, 0, 10)).Throw(new Exception()).Repeat.Times(1);//bank1 will fail
            BIMapper.Instance.Expect(bm => bm.InsertBankAccount(bank2, "testParterCode", datetime, 0, 10)).Repeat.Times(1);  //bank 2 and 3 is still processed even if bank 1 fails
            BIMapper.Instance.Expect(bm => bm.InsertBankAccount(bank3, "testParterCode", datetime, 0, 10)).Repeat.Times(1); 

            var provider = MockRepository.GeneratePartialMock<BeneficiaryBIStorageProvider>();
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(1);
            Assert.DoesNotThrow(() => provider.HandleBeneficiariesInsertOrUpdate(Arg<object>.Is.Anything, new List<BeneficiaryEventArgs> { args }));

            provider.VerifyAllExpectations();
            BIMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BeneficiaryProvider_DoesNotThrow_WithNullBank()
        {
            var beneficiary = new Beneficiary();
            var bankAccounts = new List<BankAccount> {null};
            var datetime = DateTime.UtcNow;
            var args = BeneficiaryEventArgs.GetBeneficiaryEventArgs(beneficiary, bankAccounts, "test", 1, null, "testParterCode", 10, 0, datetime);
            BIMapper.Instance.Expect(bm => bm.InsertBeneficiary(beneficiary, "testParterCode", 10, 0, datetime));
            var provider = MockRepository.GeneratePartialMock<BeneficiaryBIStorageProvider>();
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Times(1);
            Assert.DoesNotThrow(() => provider.HandleBeneficiariesInsertOrUpdate(Arg<object>.Is.Anything, new List<BeneficiaryEventArgs> { args }));

            provider.VerifyAllExpectations();
            BIMapper.Instance.VerifyAllExpectations();
        }
    }
}
