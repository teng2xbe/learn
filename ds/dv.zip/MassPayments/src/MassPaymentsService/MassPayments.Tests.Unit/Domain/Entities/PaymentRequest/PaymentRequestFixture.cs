﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.Enums;
using NUnit.Framework;
using Rhino.Mocks;
using Address = MassPayments.Domain.Entities.PaymentRequest.Address;
using BankAccount = MassPayments.Domain.Entities.PaymentRequest.BankAccount;
using Beneficiary = MassPayments.Domain.Entities.PaymentRequest.Beneficiary;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest
{
    [TestFixture]
    public class PaymentRequestFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
            ValidationRules.Instance = null;
        }

        [Test]
        public void Validate_All_Correclty()
        {
            var paymentRequest = CreatePaymentRequest("1", 0, 1, null);
            paymentRequest.SetPartner(new Partner {PaymentModel = PaymentModel.Coupled});
            paymentRequest.SetCustomer(new Customer {SettlementCurrency = Currency.USD});
            paymentRequest.Validate(true);
            Assert.IsFalse(paymentRequest.HasFailed);
        }

        [Test]
        public void Validate_Fails_IfNoSettlementCurrencySetForCoupledModel()
        {
            var paymentRequest = CreatePaymentRequest("1", 0, 1, null);
            paymentRequest.SetPartner(new Partner { PaymentModel = PaymentModel.Coupled });
            paymentRequest.SetCustomer(new Customer {});
            paymentRequest.Validate(true);
            Assert.IsTrue(paymentRequest.HasFailed);
            Assert.AreEqual(Convert.ToString((int)ErrorCode.PaymentSettlementCurrencyNotDefined), paymentRequest.Message);
        }

        private MassPayments.Domain.Entities.PaymentRequest.PaymentRequest CreatePaymentRequest(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.PaymentRequest
            {
                ItemIndex = itemIndex,
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerAssignedCustomerId = "123",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "ach",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                FixedAmount = 100,
                CurrencyCode = "CAD",
                RemittanceData = new List<RemittanceReference>
                    {
                        new RemittanceReference { Reference = "ref1" }, 
                        new RemittanceReference { Reference = "ref2" }
                    }
            };
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddress(),
                BankBranchCode = "br code",
                BankAccountOwnerName = "bank Account Name",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                IntermediaryBank = CreateIntermediaryBank(),
                VersionedOn = "2015-08-23T00:00:00Z"
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

        private IntermediaryBank CreateIntermediaryBank()
        {
            return new IntermediaryBank
            {
                AccountNumber = "acct no",
                Address = CreateAddress(),
                BankCode = "bnk code",
                BankName = "bnk name"
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                VersionedOn = "2015-08-23T00:00:00Z",
                PhoneNumber = "123",
                Type = "individual",
            };
        }
        
    }
}
