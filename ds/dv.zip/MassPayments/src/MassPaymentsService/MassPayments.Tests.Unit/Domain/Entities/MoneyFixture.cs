﻿using System;
using MassPayments.Domain.Entities;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Domain.Entities
{
    [TestFixture]
    public class MoneyFixture
    {
        [Test]
        public void MoneyCreatedWithIntegerAmountReturnsDecimalWithCorrectNumberOfPlaces()
        {
            var cadCurrency = new Currency("CAD") {DecimalPlaces = 2};
            var jpyCurrency = new Currency("JPY") {DecimalPlaces = 0};
            var cadMoney = new Money(cadCurrency, 12345);
            var jpyMoney = new Money(jpyCurrency, 12345);

            Assert.AreEqual(123.45m, cadMoney.Amount);
            Assert.AreEqual(12345m, jpyMoney.Amount);
            Assert.AreEqual(12345, cadMoney.NonDecimalAmount);
            Assert.AreEqual(12345, jpyMoney.NonDecimalAmount);
        }

        [Test]
        public void MoneyCreatedWithLongAmountReturnsDecimalWithCorrectNumberOfPlaces()
        {
            var cadCurrency = new Currency("CAD") { DecimalPlaces = 2 };
            var jpyCurrency = new Currency("JPY") { DecimalPlaces = 0 };
            const long amount = 9876543210;
            var cadMoney = new Money(cadCurrency, amount);
            var jpyMoney = new Money(jpyCurrency, amount);

            Assert.AreEqual(amount, cadMoney.NonDecimalAmount);
            Assert.AreEqual(amount, jpyMoney.NonDecimalAmount);
            Assert.AreEqual(amount/(decimal)Math.Pow(10,cadCurrency.DecimalPlaces), cadMoney.Amount);
            Assert.AreEqual(amount, jpyMoney.Amount);
        }

        [Test]
        public void MoneyCreatedWithDecimalAmountReturnsDecimalWithCorrectNumberOfPlaces()
        {
            var cadCurrency = new Currency("CAD") { DecimalPlaces = 2 };
            const decimal amount = 98765432.10m;
            var cadMoney = new Money(cadCurrency, amount);
            
            Assert.AreEqual(Convert.ToInt64(amount*(long)Math.Pow(10, cadCurrency.DecimalPlaces)), cadMoney.NonDecimalAmount);
            Assert.AreEqual(amount, cadMoney.Amount);
        }

        [Test]
        public void MoneyRoundsDecimalValueCorrectly()
        {
            var cadMoney = new Money(Currency.CAD, 1.2345m);
            Assert.AreEqual(1.23m, cadMoney.Amount);
            
            var cadMoney1 = new Money(Currency.CAD, 1234);
            Assert.AreEqual(12.34m, cadMoney1.Amount);

            var cadMoney2 = new Money(Currency.CAD, 1.295m);
            Assert.AreEqual(1.30m, cadMoney2.Amount);
            
            var cadMoney3 = new Money(Currency.CAD, 1.294m);
            Assert.AreEqual(1.29m, cadMoney3.Amount);
        }
    }
}
