﻿using System;
using MassPayments.Domain.Entities.PaymentRequest.Validators;
using MassPayments.Infrastructure;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest.Validators
{
    [TestFixture]
    public class FormatValidatorFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
            ValidationRules.Instance = null;
        }

        [Test]
        public void FormatValidator_DateFormat_Success()
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("s") + "Z";
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, lastUpdatedOn);
            paymentRequest.PaymentMethod = "ACH";
           
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new FormatValidator(paymentRequest).Validate();
            
            Assert.IsFalse(result.HasFailed());

        }

        [TestCase("2015/09/14 17:51:31Z")]
        [TestCase("2015/14/01 17:51:31Z")]
        [TestCase("2015-14-09T17:51:31Z")]
        [TestCase("2015-14-09T00:00Z")]
        [TestCase("2015-09-09 17:51:31")]
        [TestCase("2015-09-09T17:51:31.000000Z")]
        public void FormatValidator_DateFormat_Fails(string versionedOn)
        {
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, versionedOn);
            var result = new FormatValidator(paymentRequest).Validate();
            Assert.AreEqual("1005:beneficiary.versionedOn", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }
        
        [Test]
        public void FormatValidator_DateFormatOptional_Success()
        {
            var versionedOn = DateTime.UtcNow.ToString("s") + "Z";
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, versionedOn);
            paymentRequest.Beneficiary.VersionedOn = versionedOn;
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.BankAccount = null;
            
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new FormatValidator(paymentRequest).Validate();
            Assert.IsFalse(result.HasFailed());
        }


        [Test]
        public void FormatValidator_ExternalId_Success()
        {
            var versionedOn = DateTime.UtcNow.ToString("s") + "Z";
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, versionedOn);
            paymentRequest.Beneficiary.VersionedOn = versionedOn;
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.BankAccount = null;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new FormatValidator(paymentRequest).Validate();
            Assert.IsFalse(result.HasFailed());
        }

        [Test]
        public void FormatValidator_Payment_ExternalId_Fails()
        {
            var versionedOn = DateTime.UtcNow.ToString("s") + "Z";
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1!", 0, 1, versionedOn);
            paymentRequest.Beneficiary.VersionedOn = versionedOn;
            paymentRequest.Beneficiary.Id = "1!";
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.BankAccount = null;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new FormatValidator(paymentRequest).Validate();
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void FormatValidator_Beneficiary_ExternalId_Fails()
        {
            var versionedOn = DateTime.UtcNow.ToString("s") + "Z";
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, versionedOn);
            paymentRequest.Beneficiary.VersionedOn = versionedOn;
            paymentRequest.Beneficiary.Id = "1!";
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.BankAccount = null;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new FormatValidator(paymentRequest).Validate();
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void FormatValidator_BankId_ExternalId_Fails()
        {
            var versionedOn = DateTime.UtcNow.ToString("s") + "Z";
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1!", 0, 1, versionedOn);
            paymentRequest.Beneficiary.VersionedOn = versionedOn;
            paymentRequest.BankAccount.Id = "1!";
            paymentRequest.PaymentMethod = "ach";

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new FormatValidator(paymentRequest).Validate();
            Assert.IsTrue(result.HasFailed());
        }
        
    }
}

