﻿using System;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Entities.PaymentRequest.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest.Validators
{
    [TestFixture]
    public class BeneficiaryRequiredFieldsValidatorFixture
    {
        [Test]
        public void BeneficiaryRequiredFieldsValidator_Success()
        {
            var result = new BeneficiaryRequiredFieldsValidator(CreateBeneficiary("1")).Validate();
            Assert.IsFalse(result.HasFailed());
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Beneficiary_IsNotProvided()
        {
            var result = new BeneficiaryRequiredFieldsValidator(null).Validate();
            Assert.IsTrue(result.HasFailed());
        }
        
        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Id_IsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.Id = "";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.id", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_VersionedOn_IsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.VersionedOn = null;
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.versionedOn", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Type_IsNotIndividualOrBusiness()
        {
            var bene = CreateBeneficiary("2");
            bene.Type = "b/i";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.type", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Type_IsIndividual_ButNameIsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.Type = "individual";
            bene.LastName = "";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1004:beneficiary.lastName", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Type_IsBusiness_ButBusinessNameIsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.Type = "Business";
            bene.BusinessName = "";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1004:beneficiary.businessName", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Address_IsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.Address = null;
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.address", ((PaymentRequestFailedResult<Address>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                VersionedOn = DateTime.UtcNow.ToString(),
                PhoneNumber = "123",
                Type = "BUSINESS"
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
