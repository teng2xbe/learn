﻿using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Entities.PaymentRequest.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest.Validators
{
    [TestFixture]
    public class AddressRequiredFieldsValidatorFixture
    {
        [Test]
        public void AddressRequiredFieldsValidator_Success()
        {
            var result = new AddressRequiredFieldsValidator(CreateAddress()).Validate();
            Assert.IsFalse(result.HasFailed());
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_Address_IsNotProvided()
        {
            var result = new AddressRequiredFieldsValidator(null).Validate();
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_Line1_IsNotProvided()
        {
            var address = CreateAddress();
            address.AddressLine1 = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.line1", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_City_IsNotProvided()
        {
            var address = CreateAddress();
            address.City = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.city", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_StateProv_IsNotProvided()
        {
            var address = CreateAddress();
            address.StateOrPovince = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.stateOrProv", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_Zip_IsNotProvided()
        {
            var address = CreateAddress();
            address.ZipOrPostalCode = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.zipOrPostal", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_CountryCode_IsNotProvided()
        {
            var address = CreateAddress();
            address.CountryCode = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.countryCode", ((PaymentRequestFailedResult<string>)result).Message);
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
