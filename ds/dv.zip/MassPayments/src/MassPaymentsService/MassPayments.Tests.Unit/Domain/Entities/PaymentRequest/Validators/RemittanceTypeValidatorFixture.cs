﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Entities.PaymentRequest.Validators;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.Enums;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest.Validators
{
    [TestFixture]
    public class RemittanceTypeValidatorFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
        }

        [Test]
        public void Validate_Fails_ForNonUsdAchPaymentWithRemittanceTypeSpecified()
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, lastUpdatedOn);
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.CurrencyCode = "CAD";
            paymentRequest.RemittanceType = RemittanceType.CTX.ToString();

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(paymentRequest).Validate();
            Assert.IsTrue(result.HasFailed());
            Assert.AreEqual(((int)ErrorCode.RemittanceTypeMismatch).ToString(), ((PaymentRequestFailedResult<string>)result).Message);
        }

        [TestCase("US", "", false, null)]
        [TestCase("US", "CTX", true, "1118")]
        [TestCase("US", "CCD", true, "1118")]
        [TestCase("MX", "PPD", true, "1118")]
        [TestCase("US", "IAT", true, "1118")]
        [TestCase("US", "PPD", false, null)]
        [TestCase("MX", "IAT", false, null)]
        [TestCase("", "IAT", false, null)]
        [TestCase(null, "IAT", false, null)]
        [TestCase("US", "Undefined", true, "1117")]
        [TestCase("US", "CCC", true, "1117")]
        public void Validate_WorksCorrectly_ForSupportedCombinationForIndividualBenefiary(string countryCode, string remittanceType, bool expectedToFailValidation, string expectedErrorCode)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, lastUpdatedOn);

            paymentRequest.Customer.CountryCode = countryCode;
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.CurrencyCode = "USD";
            paymentRequest.Beneficiary.Type = "individual";
            paymentRequest.RemittanceType = remittanceType;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(paymentRequest).Validate();
            Assert.AreEqual(expectedToFailValidation, result.HasFailed());
            if (expectedToFailValidation)
                Assert.AreEqual(expectedErrorCode, ((PaymentRequestFailedResult<string>)result).Message);
        }

        [TestCase("US","IAT", true)]
        [TestCase("MX", "IAT", false)]
        [TestCase(null, "IAT", false)]
        [TestCase("US", "PPD", true)]
        [TestCase("MX", "PPD", true)]
        [TestCase("US", "CCD", false)]
        [TestCase("CA", "CCD", true)]
        [TestCase("", "CCD", true)]
        public void Validate_WorksCorrectly_ForBusinessBenefiary(string countryCode, string remittanceType, bool expectedToFailValidation)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, lastUpdatedOn);
            paymentRequest.Customer.CountryCode = countryCode;
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.CurrencyCode = "USD";
            paymentRequest.Beneficiary.Type = "business";
            paymentRequest.RemittanceType = remittanceType;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(paymentRequest).Validate();
            Assert.AreEqual(expectedToFailValidation, result.HasFailed());
            if (expectedToFailValidation)
                Assert.AreEqual("1118", ((PaymentRequestFailedResult<string>)result).Message);
        }

        [TestCase("US", 1, false)]
        [TestCase("MX", 1, true)]
        [TestCase("MX", 0, true)]
        [TestCase("US", 0, true)]
        [TestCase("US", 2, false)]
        public void Validate_WorksCorrectly_WhenCTXForBusinessBenefiary(string countryCode, int numberOfRemittanceRecords, bool expectedToFailValidation)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var paymentRequest = PaymentRequestHelper.CreatePaymentRequest("1", 0, 1, lastUpdatedOn);
            paymentRequest.Customer.CountryCode = countryCode;
            paymentRequest.PaymentMethod = "ach";
            paymentRequest.CurrencyCode = "USD";
            paymentRequest.Beneficiary.Type = "business";
            paymentRequest.RemittanceType = "CTX";

            if (numberOfRemittanceRecords > 0)
            {
                paymentRequest.RemittanceData = new List<RemittanceReference>();
                for(var i=0; i<numberOfRemittanceRecords; i++)
                    paymentRequest.RemittanceData.Add(new RemittanceReference{ Reference = "ref"+i});
            }

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(paymentRequest).Validate();
            Assert.AreEqual(expectedToFailValidation, result.HasFailed());
            if (expectedToFailValidation)
                Assert.AreEqual("1118", ((PaymentRequestFailedResult<string>)result).Message);
        }
    }
}
