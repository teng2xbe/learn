﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Payments;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Managers.FileProcessing.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Providers.StorageProvider.EventArguments;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using MassPayments.Tests.Unit.Services.MassPayments.Validators;
using MassPaymentsCommon.WCFContracts.Enums;
using NUnit.Framework;
using Rhino.Mocks;
using System.Collections.Generic;
using System.Linq;
using Address = MassPayments.Domain.Entities.PaymentRequest.Address;
using BankAccount = MassPayments.Domain.Entities.PaymentRequest.BankAccount;
using Beneficiary = MassPayments.Domain.Entities.PaymentRequest.Beneficiary;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest
{
    [TestFixture]
    public class PaymentRequestToProcessFixture
    {
        private IPublisher<Payment, CustomerBatch, Customer> paymentStatusUpdatedpublisher;
        private IPublisher<List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>> paymentNotAcceptedPublisher;
        private IPublisher<Payment, CustomerBatch> paymentUpdateFailedpublisher;

        [SetUp]
        public void Setup()
        {
            PaymentMapper.Instance = MockRepository.GenerateStub<IPaymentMapper>();
            PaymentRequestMapper.Instance = MockRepository.GenerateStub<IPaymentRequestMapper>();
            StorageEventPublisher.Instance = MockRepository.GenerateMock<IStorageEventPublisher>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            PartnerMapper.Instance = MockRepository.GenerateStub<IPartnerMapper>();
            paymentStatusUpdatedpublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentStatusUpdatedPublisher), paymentStatusUpdatedpublisher);
            paymentNotAcceptedPublisher =
                MockRepository
                    .GenerateMock<IPublisher<List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentNotAcceptedPublisher), paymentNotAcceptedPublisher);
            paymentUpdateFailedpublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentUpdateFailedPublisher), paymentUpdateFailedpublisher);
            CustomerBatchCurrencyMapper.Instance = MockRepository.GenerateMock<ICustomerBatchCurrencyMapper>();
            CurrencyCache.Instance.Reinitialize();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetStringValue("DomesticCountryGroups")).Return("");
            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
            PaymentRequestMapper.Instance = null;
            StorageEventPublisher.Instance = null;
            CustomerMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
            PartnerMapper.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            paymentStatusUpdatedpublisher = null;
            paymentNotAcceptedPublisher = null;
            CustomerBatchCurrencyMapper.Instance = null;
            CurrencyCache.Instance = null;
            paymentUpdateFailedpublisher = null;
            ServiceSettings.Instance = null;
            ValidationRules.Instance = null;
        }

        [Test]
        public void Process_Successfully()
        {
            var pr = MockRepository.GeneratePartialMock<PaymentRequestToProcess>();
            pr.PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>
            {
                CreatePaymentRequest("1", 0, 1, ""),
                CreatePaymentRequest("2", 1, 1, "")
            };

            pr.PaymentsToProcess[0].PaymentRequestArchiveDetailId = 1;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentMapper.Instance.Expect(pm => pm.BulkInsertUpdatePayment(new List<Payment> { Arg<Payment>.Is.Anything }));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123", SettlementCurrency = Currency.USD } });
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything })).Return(new List<CustomerBatch> { new CustomerBatch { Id = 1 } });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false, PaymentModel = PaymentModel.Decoupled });
            pr.Expect(r => r.ValidateAssembledPayment(Arg<Payment>.Is.Anything, Arg<Customer>.Is.Anything, Arg<List<DomesticCountryGroup>>.Is.Anything, Arg<bool>.Is.Anything, Arg<bool>.Is.Anything)).Return(string.Empty);

            pr.Process();

            pr.VerifyAllExpectations();
            PaymentMapper.Instance.AssertWasCalled(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentMapper.Instance.AssertWasCalled(pm => pm.BulkInsertUpdatePayment(new List<Payment> { Arg<Payment>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            CustomerMapper.Instance.AssertWasCalled(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            CustomerBatchMapper.Instance.AssertWasCalled(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(0, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(2, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            StorageEventPublisher.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
            CurrencyPaymentMethodCacheMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_BatchPaymentSuccessfully()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment1 = CreatePaymentRequest("1", 0, 1, "");
            var payment2 = CreatePaymentRequest("2", 1, 1, "");
            payment1.ExternalBatchId = customerBatch.ExternalId;
            payment2.ExternalBatchId = customerBatch.ExternalId;
            payment1.PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            payment2.PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            payment1.IsFixedAmountInSettlementCurrency = false;
            payment2.IsFixedAmountInSettlementCurrency = false;
            payment1.SettlementCurrencyCode = "USD";
            payment2.SettlementCurrencyCode = "USD";
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { payment1, payment2 }
            };
            pr.PaymentsToProcess[0].ExternalBatchId = customerBatch.ExternalId;
            pr.PaymentsToProcess[0].PaymentRequestArchiveDetailId = 1;
            pr.BatchId = customerBatch.Id;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerBatchMapper.Instance.Expect(pm => pm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { Id = customerBatch.Id, ExternalId = customerBatch.ExternalId, CustomerId = customerBatch.CustomerId });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<Customer>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentMapper.Instance.Expect(pm => pm.PaymentBulkInsert(new List<Payment> { Arg<Payment>.Is.Anything }));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            StorageEventPublisher.Instance.Expect(sep => sep.OnBeneficiariesParsed(Arg<List<BeneficiaryEventArgs>>.Is.Anything));
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId, SettlementCurrency = Currency.USD } });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false, PaymentModel = PaymentModel.Decoupled });
            CustomerBatchCurrencyMapper.Instance.Expect(pm => pm.InsertCustomerBatchCurrency(Arg<int>.Is.Anything, Arg<Money>.Is.Anything, Arg<Money>.Is.Anything, Arg<Money>.Is.Anything, Arg<bool>.Is.Anything));

            pr.Process();

            CustomerBatchMapper.Instance.AssertWasCalled(pm => pm.GetCustomerBatch(Arg<int>.Is.Anything));
            PaymentMapper.Instance.AssertWasCalled(pm => pm.GetPayments(Arg<Customer>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentMapper.Instance.AssertWasCalled(pm => pm.PaymentBulkInsert(new List<Payment> { Arg<Payment>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            StorageEventPublisher.Instance.AssertWasCalled(sep => sep.OnBeneficiariesParsed(Arg<List<BeneficiaryEventArgs>>.Is.Anything));
            CustomerMapper.Instance.AssertWasCalled(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            CustomerBatchCurrencyMapper.Instance.AssertWasCalled(pm => pm.InsertCustomerBatchCurrency(Arg<int>.Is.Anything, Arg<Money>.Is.Anything, Arg<Money>.Is.Anything, Arg<Money>.Is.Anything, Arg<bool>.Is.Anything));
            Assert.AreEqual(0, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(2, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            StorageEventPublisher.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
            CurrencyPaymentMethodCacheMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerBatchCurrencyMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }


        [Test]
        public void Process_Payment_Failed_When_RequiredField_IsMissing()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { CreatePaymentRequest("1", 0, 1, ""), CreatePaymentRequest("", 1, 1, "") }
            };
            pr.PaymentsToProcess[0].PaymentRequestArchiveDetailId = 1;
            pr.PaymentsToProcess[1].PaymentRequestArchiveDetailId = 2;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123" } });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });

            pr.Process();
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            Assert.AreEqual(0, pr.PaymentsToProcess.First(f => !f.HasFailed).ItemIndex);
            Assert.AreEqual(1, pr.PaymentsToProcess.First(f => f.HasFailed).ItemIndex);
            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_Mark_Duplicates_As_Failed()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>
                {
                    CreatePaymentRequest("1", 0, 1, ""),
                    CreatePaymentRequest("1", 1, 1, ""),
                    CreatePaymentRequest("2", 2, 1, ""),
                    CreatePaymentRequest("1", 3, 1, ""),
                }
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123" } });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });

            pr.Process();
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(3, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            Assert.AreEqual(2, pr.PaymentsToProcess.First(f => !f.HasFailed).ItemIndex);
            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_Mark_DuplicatesFromPayment_As_Failed()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>
                {
                    CreatePaymentRequest("1", 0, 1, ""),
                    CreatePaymentRequest("2", 1, 1, ""),
                    CreatePaymentRequest("3", 2, 1, ""),
                    CreatePaymentRequest("4", 3, 1, ""),
                }
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123" } });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment> { new Payment("2", null) { PaymentStatus = PaymentStatus.Created } });
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });

            pr.Process();
            paymentUpdateFailedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything));
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(3, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual("2", pr.PaymentsToProcess.First(f => f.HasFailed).PaymentId);
            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_Mark_NonExistingCustomerFromPayment_As_Failed()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>
                {
                    CreatePaymentRequest("1", 0, 1, ""),
                    CreatePaymentRequest("2", 1, 1, ""),
                    CreatePaymentRequest("3", 2, 1, ""),
                    CreatePaymentRequest("4", 3, 1, ""),
                }
            };

            var customer = CustomerHelper.Instance.CreateCustomer();
            pr.PaymentsToProcess[0].SetCustomer(customer);
            pr.PaymentsToProcess[1].SetCustomer(customer);
            pr.PaymentsToProcess[2].SetCustomer(customer);
            pr.PaymentsToProcess[3].SetCustomer(customer);

            const string existingPartnerAssignedCustomerId = "do exists";
            pr.PaymentsToProcess[2].PartnerAssignedCustomerId = existingPartnerAssignedCustomerId;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = existingPartnerAssignedCustomerId } });
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            PaymentMapper.Instance.Expect(pm => pm.BulkInsertUpdatePayment(new List<Payment> { Arg<Payment>.Is.Anything }));
            PaymentRequestMapper.Instance.Expect(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });

            pr.Process();

            CustomerBatchMapper.Instance.AssertWasCalled(m => m.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            Assert.AreEqual(3, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual("3", pr.PaymentsToProcess.First(f => !f.HasFailed).PaymentId);

            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_DoesNotSetGenericErrorWhenCustomerDoesNotExist()
        {
            var paymentRequestToProcess = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>
                {
                    CreatePaymentRequest("1", 0, 1, "")
                }
            };

            paymentRequestToProcess.PaymentsToProcess[0].PartnerAssignedCustomerId = "gorilla";
            paymentRequestToProcess.PaymentsToProcess[0].PaymentRequestArchiveDetailId = 1;

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer>());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(paymentRequestToProcess.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();

            Assert.DoesNotThrow(() => paymentRequestToProcess.Process());
            Assert.AreNotEqual(ErrorCode.GenericMassPaymentsServiceError.ToString(), paymentRequestToProcess.PaymentsToProcess[0].Message);
            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void Process_Mark_ExistingCustomerFromPayment_As_Success()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>
                {
                    CreatePaymentRequest("1", 0, 1, ""),
                    CreatePaymentRequest("2", 1, 1, ""),
                    CreatePaymentRequest("3", 2, 1, ""),
                    CreatePaymentRequest("4", 3, 1, ""),
                }
            };

            var customer = CustomerHelper.Instance.CreateCustomer();
            pr.PaymentsToProcess[0].SetCustomer(customer);
            pr.PaymentsToProcess[1].SetCustomer(customer);
            pr.PaymentsToProcess[2].SetCustomer(customer);
            pr.PaymentsToProcess[3].SetCustomer(customer);

            const string existingPartnerAssignedCustomerId = "do exists";
            pr.PaymentsToProcess[2].PartnerAssignedCustomerId = existingPartnerAssignedCustomerId;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { Id = 100, PartnerAssignedCustomerId = existingPartnerAssignedCustomerId } });
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));

            PaymentMapper.Instance.Expect(pm => pm.BulkInsertUpdatePayment(new List<Payment> { Arg<Payment>.Is.Anything }));
            PaymentRequestMapper.Instance.Expect(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });

            pr.Process();

            CustomerBatchMapper.Instance.AssertWasCalled(m => m.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            Assert.AreEqual(3, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual("3", pr.PaymentsToProcess.First(f => !f.HasFailed).PaymentId);
            Assert.AreEqual(100, pr.PaymentsToProcess.First(f => !f.HasFailed).Customer.Id);

            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_And_Archive_With_Status_Processed_Successfully()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { CreatePaymentRequest("1", 0, 1, ""), CreatePaymentRequest("2", 1, 1, "") }
            };

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123" } });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Id= 1,IsThirdPartyRemitterEnabled = false });
            PaymentMapper.Instance.Stub(pm => pm.GetPayments(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(new List<Payment> { new Payment("1", null) { PaymentStatus = PaymentStatus.Committed } });


            pr.Process();

            PaymentMapper.Instance.AssertWasCalled(m => m.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(m => m.ArchivePaymentRequest(pr, FileStatus.Processed, "Pocess Success: 1,2"));
            //Todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(0, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(2, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_And_Archive_InvalidatesCustomerBatchQuote()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment1 = CreatePaymentRequest("1", 0, 1, "");
            var payment2 = CreatePaymentRequest("2", 1, 1, "");
            payment1.ExternalBatchId = customerBatch.ExternalId;
            payment2.ExternalBatchId = customerBatch.ExternalId;
            payment1.PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;
            payment2.PartnerAssignedCustomerId = customer.PartnerAssignedCustomerId;

            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { payment1, payment2 }
            };

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { customer });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false, PaymentModel = PaymentModel.Coupled });

            pr.Process();

            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void Process_And_Archive_With_Status_Processed_Successfully_PaymentToProcess()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { CreatePaymentRequest("1", 0, 1, ""), CreatePaymentRequest("2", 1, 1, "") },
            };

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { SettlementCurrency = Currency.USD, PartnerAssignedCustomerId = "123" } });
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything }));
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { PaymentModel = PaymentModel.Coupled, IsThirdPartyRemitterEnabled = false });

            pr.Process();

            PaymentMapper.Instance.AssertWasCalled(m => m.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(m => m.ArchivePaymentRequest(pr, FileStatus.Processed, "Pocess Success: 1,2"));
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(0, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(2, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_And_Archive_With_Status_Processed_Failed_PaymentToProcess()
        {
            CurrencyCacheMapper.Instance = new TestCurrencyCacheMapper();


            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { CreatePaymentRequest("", 0, 1, ""), CreatePaymentRequest("", 1, 1, "") },
            };
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123" } });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });
            CustomerBatchMapper.Instance.Expect(cbm => cbm.InsertCustomerBatches(null)).IgnoreArguments().Return(new List<CustomerBatch>());

            pr.Process();

            PaymentMapper.Instance.AssertWasCalled(m => m.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(m => m.ArchivePaymentRequest(pr, FileStatus.FailedToProcess, "Process Failed: index:0,index:1"));

            Assert.AreEqual(0, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            Assert.AreEqual(2, pr.PaymentsToProcess.Count(f => f.HasFailed));
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void Process_And_Archive_With_Status_ProcessedWithErrors_Successfully()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { CreatePaymentRequest("1", 0, 1, ""), CreatePaymentRequest("", 1, 1, "") }
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123" } });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequestCustomerBatch(new List<int> { Arg<int>.Is.Anything }, Arg<int>.Is.Anything));
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CustomerBatchMapper.Instance.Expect(pm => pm.InsertCustomerBatches(new List<CustomerBatch> { Arg<CustomerBatch>.Is.Anything })).Return(new List<CustomerBatch> { new CustomerBatch { Id = 1 } });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });

            pr.Process();

            PaymentMapper.Instance.AssertWasCalled(m => m.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(m => m.ArchivePaymentRequest(pr, FileStatus.ProcessedWithError, "Process Failed: index:1 | Pocess Success: 1"));
            //todo:Dip
            //paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_And_Archive_With_Status_FailedToProcess_Successfully()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { CreatePaymentRequest("", 0, 1, ""), CreatePaymentRequest("2", 1, 1, "") }
            };
            pr.PaymentsToProcess[0].PaymentRequestArchiveDetailId = 1;
            pr.PaymentsToProcess[1].PaymentRequestArchiveDetailId = 2;

            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123", SettlementCurrency = Currency.USD } });
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment> { new Payment("2", null) { PaymentStatus = PaymentStatus.Created } });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false });
            CustomerBatchMapper.Instance.Expect(cbm => cbm.InsertCustomerBatches(null)).IgnoreArguments().Return(new List<CustomerBatch>());


            pr.Process();
            paymentUpdateFailedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything));
            PaymentMapper.Instance.AssertWasCalled(m => m.GetPayments(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(m => m.ArchivePaymentRequest(pr, FileStatus.FailedToProcess, "Process Failed: index:0,id:2"));

            Assert.AreEqual(2, pr.PaymentsToProcess.Count(f => f.HasFailed));
            Assert.AreEqual(0, pr.PaymentsToProcess.Count(f => !f.HasFailed));
            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentsMarkAsError_WhenBatchIsCommitted()
        {
            var pr = new PaymentRequestToProcess()
            {
                PaymentsToProcess = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest> { CreatePaymentRequest("1", 0, 1, "") }
            };
            pr.PaymentsToProcess[0].ExternalBatchId = "batchId";
            pr.PaymentsToProcess[0].PaymentRequestArchiveDetailId = 1;
            PaymentRequestMapper.Instance = MockRepository.GenerateMock<IPaymentRequestMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<Customer>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Payment>());
            PaymentRequestMapper.Instance.Expect(pm => pm.GetFailedPaymentRequests(Arg<int>.Is.Anything)).Return(pr.PaymentsToProcess);
            PaymentRequestMapper.Instance.Expect(pm => pm.LogNotAcceptedPayments(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.DeleteAcceptedPaymentsFromLog(null)).IgnoreArguments();
            PaymentRequestMapper.Instance.Expect(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything })).Return(new List<Customer> { new Customer { PartnerAssignedCustomerId = "123", SettlementCurrency = Currency.USD } });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false, PaymentModel = PaymentModel.Decoupled });
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { Id = 111, BatchStatus = CustomerBatchStatus.Committed });
            CustomerBatchCurrencyMapper.Instance.Expect(c => c.GetCustomerBatchCurrencyAggregatesByBatchId(Arg<int>.Is.Anything)).Return(null);
            

            pr.Process();

            Assert.IsTrue(pr.PaymentsToProcess[0].HasFailed);
            Assert.AreEqual("1113", pr.PaymentsToProcess[0].Message);

            CustomerBatchCurrencyMapper.Instance.VerifyAllExpectations();
            //PaymentMapper.Instance.AssertWasCalled(pm => pm.GetPayments(Arg<Customer>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
            CustomerMapper.Instance.AssertWasCalled(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            Assert.AreEqual(1, pr.PaymentsToProcess.Count(f => f.HasFailed));
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
            CurrencyPaymentMethodCacheMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void Process_DoesNothingIfThereAreNoPayments()
        {
            var pr = new PaymentRequestToProcess();
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { IsThirdPartyRemitterEnabled = false, PaymentModel = PaymentModel.Decoupled });
            PaymentRequestMapper.Instance.Expect(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));

            pr.Process();

            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.AssertWasNotCalled(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, new List<string> { Arg<string>.Is.Anything }));
            PaymentRequestMapper.Instance.AssertWasCalled(pm => pm.ArchivePaymentRequest(Arg<PaymentRequestToProcess>.Is.Anything, Arg<FileStatus>.Is.Anything, Arg<string>.Is.Anything));
        }

        [Test]
        public void CommitDecoupledPayments_DoesNotCallBi()
        {
            var partner = new Partner {PaymentModel = PaymentModel.Decoupled};
            var customer = new Customer { PartnerAssignedCustomerId = "abc"};
            var paymentRequest = new MassPayments.Domain.Entities.PaymentRequest.PaymentRequest
            {
                SettlementCurrencyCode = "CAD"
            };

            paymentRequest.SetCustomer(customer);
            var paymentRequests = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>{paymentRequest};
            var paymentRequestToProcess = MockRepository.GeneratePartialMock<PaymentRequestToProcess>();
            paymentRequestToProcess.Stub(p => p.ProcessCustomerInPaymentRequest(Arg<List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>>.Is.Anything,Arg<string>.Is.Anything,Arg<CustomerBatch>.Is.Anything));
            PaymentMapper.Instance.Stub(p => p.BulkInsertUpdatePayment(Arg<List<Payment>>.Is.Anything));
            PaymentMapper.Instance.Stub(p => p.GetPayments(Arg<Customer>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(new List<Payment> { new Payment(1) });
            paymentRequestToProcess.Expect(p => p.PublishAcceptedPayments(Arg<List<Payment>>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<List<Customer>>.Is.Anything));
            paymentStatusUpdatedpublisher.Expect(p => p.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentRequestToProcess.Expect(p => p.ProcessBeneficiaryAndBankAccountInPayments(Arg<int>.Is.Anything, Arg<List<Payment>>.Is.Anything)).Repeat.Never();
            StorageEventPublisher.Instance.Expect(s => s.OnBeneficiariesParsed(Arg<List<BeneficiaryEventArgs>>.Is.Anything)).Repeat.Never();

            paymentRequestToProcess.SetPartnerForProcessing(partner);
            
            paymentRequestToProcess.CommitDecoupledPayments(paymentRequests, new CustomerBatch(), new List<Customer> { customer });
            paymentRequestToProcess.VerifyAllExpectations();
            StorageEventPublisher.Instance.VerifyAllExpectations();
        }

        [Test]
        public void MarkPaymentsWithExistingPaymentIdsAsFailed_RejectAnyExistingPaymentId(
            [Values(true, false)]bool testIsAlreadyFailed,
            [Values(true, false)]bool testIsForBatch, 
            [Values(
                PaymentStatus.Created,
                PaymentStatus.Committed,
                PaymentStatus.SanctionCleared,
                PaymentStatus.Sent,
                PaymentStatus.Released,
                PaymentStatus.Rejected,
                PaymentStatus.SanctionBlocked,
                PaymentStatus.Reconciled,
                PaymentStatus.Cancelled,
                PaymentStatus.Returned
            )] PaymentStatus testPaymentStatus)
        {
            var paymentRequest = new MassPayments.Domain.Entities.PaymentRequest.PaymentRequest
            {
                PaymentId = "123"
            };
            var customer = new Customer{ Id = 1, PartnerAssignedCustomerId = "abc"};
            paymentRequest.SetCustomer(customer);
            var partner = new Partner {Id = 1};
            paymentRequest.SetPartner(partner);
            if (testIsAlreadyFailed)
            {
                paymentRequest.RecordFailedValidation("blah");
            }
            else
            {
                paymentRequest.RecordSuccessfulValidation();
            }
            var paymentRequests = new List<MassPayments.Domain.Entities.PaymentRequest.PaymentRequest>{paymentRequest};

            var fakeBatch = new CustomerBatch();

            if (testIsForBatch)
                PaymentMapper.Instance.Expect(p => p.GetPayments(customer, new List<string> {"123"})).Return(new List<Payment> {new Payment("123", customer.PartnerAssignedCustomerId) {PaymentStatus = testPaymentStatus} });
            else
                PaymentMapper.Instance.Expect(p => p.GetPayments(partner.Id, new List<string> { "123" })).Return(new List<Payment> { new Payment("123", customer.PartnerAssignedCustomerId) { PaymentStatus = testPaymentStatus } });

            PaymentMapper.Instance.Expect(p => p.InsertPaymentUpdateHistory(Arg<PaymentUpdateHistory>.Is.Anything));
            
            var prtp = new PaymentRequestToProcess();
            prtp.SetPartnerForProcessing(partner);
            prtp.MarkPaymentsWithExistingPaymentIdsAsFailed(paymentRequests,testIsForBatch,fakeBatch);

            if (!testIsAlreadyFailed)
            {
                Assert.AreEqual(true, paymentRequest.HasFailed);

                if (!testIsForBatch && testPaymentStatus == PaymentStatus.Cancelled)
                    Assert.AreEqual(((int)ErrorCode.PaymentUpdateForCancelledPayment).ToString(), paymentRequest.Message);
                else
                    Assert.AreEqual(((int)ErrorCode.PaymentUpdateNotAllowed).ToString(), paymentRequest.Message);
            }

            PaymentMapper.Instance.VerifyAllExpectations();

        }

        private MassPayments.Domain.Entities.PaymentRequest.PaymentRequest CreatePaymentRequest(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            var request = new MassPayments.Domain.Entities.PaymentRequest.PaymentRequest
            {
                ItemIndex = itemIndex,
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerAssignedCustomerId = "123",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "ach",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                FixedAmount = 100,
                CurrencyCode = "CAD",
                RemittanceData = new List<RemittanceReference>
                    {
                        new RemittanceReference { Reference = "ref1" },
                        new RemittanceReference { Reference = "ref2" }
                    }
            };

            return request;
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddress(),
                BankAccountOwnerName = "bank account name",
                BankBranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                IntermediaryBank = CreateIntermediaryBank(),
                VersionedOn = "2015-08-23T00:00:00Z"
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

        private IntermediaryBank CreateIntermediaryBank()
        {
            return new IntermediaryBank
            {
                AccountNumber = "acct no",
                Address = CreateAddress(),
                BankCode = "bnk code",
                BankName = "bnk name"
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                VersionedOn = "2015-08-23T00:00:00Z",
                PhoneNumber = "123",
                Type = "individual"
            };
        }

    }
}
