﻿using System;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Entities.PaymentRequest.Validators;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest.Validators
{
    [TestFixture]
    public class PaymentRequiredFieldsValidatorFixture
    {
        [SetUp]
        public void SetUp()
        {
            PaymentValidationCache.Instance.Initialize();
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Success()
        {
            var result = new PaymentRequiredFieldsValidator(CreatePaymentRequest("1", 0, 1, DateTime.UtcNow.ToString())).Validate();
            Assert.IsFalse(result.HasFailed());
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Fails_When_PaymentRequestIsNotProvided()
        {
            var result = new PaymentRequiredFieldsValidator(null).Validate();
            Assert.AreEqual("1003:payment", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Ignores_WhenVersionAndLastUpdatedOn_IsNotProvided()
        {
            var paymentRequest = CreatePaymentRequest("1", 0, 1, DateTime.UtcNow.ToString());
            var result = new PaymentRequiredFieldsValidator(paymentRequest).Validate();            
            Assert.IsFalse(result.HasFailed());
        }

        private MassPayments.Domain.Entities.PaymentRequest.PaymentRequest CreatePaymentRequest(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.PaymentRequest
            {
                ItemIndex = itemIndex,
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerAssignedCustomerId = "123",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "Wire",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                FixedAmount = 100,
                CurrencyCode = "CAD"
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                VersionedOn = DateTime.UtcNow.ToString(),
                PhoneNumber = "123",
                Type = "BUSINESS"
            };
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddress(),
                BankBranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                VersionedOn = DateTime.UtcNow.ToString()
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
