﻿using System;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Entities.PaymentRequest.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest.Validators
{
    [TestFixture]
    public class BankAccountRequiredFieldsValidatorFixture
    {
        [Test]
        public void BankAccountRequiredFieldsValidator_Success()
        {
            var result = new BankAccountRequiredFieldsValidator(CreateBankAccount("1")).Validate();
            Assert.IsFalse(result.HasFailed());
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_BankAccount_IsNotProvided()
        {
            var result = new BankAccountRequiredFieldsValidator(null).Validate();
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_Id_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.Id = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.id", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_VersionedOn_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.VersionedOn = null;
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.versionedOn", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_AccountNo_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.AccountNumber = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.accountNumber", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_BankName_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.BankName = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.bankName", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_BankOrBranchCode_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.BankBranchCode = "";
            bankAccount.BankCode = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1004:bankAccount.bankCode, bankBranchCode", ((PaymentRequestFailedResult<string>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_Address_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.BankAddress = null;
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.address", ((PaymentRequestFailedResult<Address>)result).Message);
            Assert.IsTrue(result.HasFailed());
        }

        private MassPayments.Domain.Entities.PaymentRequest.BankAccount CreateBankAccount(string id)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddress(),
                BankBranchCode = "br code",
                BankCode = "bnk code",
                BankAccountOwnerName = "bank account name",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                VersionedOn = DateTime.UtcNow.ToString(),
            };
        }

        private MassPayments.Domain.Entities.PaymentRequest.Address CreateAddress()
        {
            return new MassPayments.Domain.Entities.PaymentRequest.Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
