﻿using System;
using System.Collections.Generic;
using System.Linq;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Entities.PaymentRequest.Assemblers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using MassPayments.Domain.Enums;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Domain.Entities.PaymentRequest.Assemblers
{
    [TestFixture]
    public class PaymentRequestAssemblerFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
        }

        [Test]
        public void AssemblePayment_Correclty_ForDecoupledModel_NotSettingSettlementCurrency()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            var paymentRequest = CreatePaymentRequest("1", 0, 1, DateTime.UtcNow.ToString("u"));
            paymentRequest.SetCustomer(CustomerHelper.Instance.CreateCustomer());
            var partner = new Partner { Id = 3, PaymentModel = PaymentModel.Decoupled };
            var currencies = SupportedCurrency.GetSupportedCurrency();
            currencies["CAD"].DecimalPlaces = 2;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(currencies);
            var payment = PaymentRequestAssembler.AssemblePayment(paymentRequest, partner, DateTime.UtcNow, PaymentStatus.Committed);
            CurrencyCacheMapper.Instance = null;

            AssertPayment(paymentRequest, payment);
            Assert.AreEqual(PaymentStatus.Committed, payment.PaymentStatus);
            Assert.AreEqual(partner.Id, payment.PaymentSourceId);
            Assert.AreEqual(null, payment.SettlementAmountMoney);
            Assert.AreEqual(paymentRequest.FixedAmount, payment.AmountMoney.Amount);

            AssertRemittance(paymentRequest.RemittanceData, payment.RemittanceData);
        }


        [Test]
        public void AssemblePayment_Correclty_ForCoupledModel()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            var paymentRequest = CreatePaymentRequest("1", 0, 1, DateTime.UtcNow.ToString("u"));
            paymentRequest.SettlementCurrencyCode = "USD";

            paymentRequest.SetCustomer(CustomerHelper.Instance.CreateCustomer());
            var partner = new Partner { Id = 3, PaymentModel = PaymentModel.Coupled };
            var currencies = SupportedCurrency.GetSupportedCurrency();
            currencies["CAD"].DecimalPlaces = 2;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(currencies);
            var payment = PaymentRequestAssembler.AssemblePayment(paymentRequest, partner, DateTime.UtcNow, PaymentStatus.Committed);
            CurrencyCacheMapper.Instance = null;

            AssertPayment(paymentRequest, payment);
            Assert.AreEqual(PaymentStatus.Committed, payment.PaymentStatus);
            Assert.AreEqual(partner.Id, payment.PaymentSourceId);
            Assert.AreEqual("USD", payment.SettlementAmountMoney.Currency.Code);
            Assert.AreEqual(0, payment.SettlementAmountMoney.Amount);
            Assert.AreEqual(paymentRequest.FixedAmount, payment.AmountMoney.Amount);

            AssertRemittance(paymentRequest.RemittanceData, payment.RemittanceData);
        }

        [Test]
        public void AssemblePayment_Correclty_ForCoupledModel_UsingCustomerSettlementCurrency()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            var paymentRequest = CreatePaymentRequest("1", 0, 1, DateTime.UtcNow.ToString("u"));
            paymentRequest.SettlementCurrencyCode = null;

            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.SettlementCurrency = Currency.AUD;
            paymentRequest.SetCustomer(customer);
            var partner = new Partner { Id = 3, PaymentModel = PaymentModel.Coupled };
            var currencies = SupportedCurrency.GetSupportedCurrency();
            currencies["CAD"].DecimalPlaces = 2;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(currencies);
            var payment = PaymentRequestAssembler.AssemblePayment(paymentRequest, partner, DateTime.UtcNow, PaymentStatus.Committed);
            CurrencyCacheMapper.Instance = null;

            AssertPayment(paymentRequest, payment);
            Assert.AreEqual(PaymentStatus.Committed, payment.PaymentStatus);
            Assert.AreEqual(partner.Id, payment.PaymentSourceId);
            Assert.AreEqual(customer.SettlementCurrency, payment.SettlementAmountMoney.Currency);
            Assert.AreEqual(0, payment.SettlementAmountMoney.Amount);
            Assert.AreEqual(paymentRequest.FixedAmount, payment.AmountMoney.Amount);

            AssertRemittance(paymentRequest.RemittanceData, payment.RemittanceData);
        }

        [Test]
        public void AssemblePayment_Correclty_UsingVersionedOn()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            var paymentRequest = CreatePaymentRequest("1", 0, 1, "");
            var partner = new Partner { Id = 3, PaymentModel = PaymentModel.Decoupled };
            paymentRequest.SetCustomer(CustomerHelper.Instance.CreateCustomer());
            var currencies = SupportedCurrency.GetSupportedCurrency();
            currencies["CAD"].DecimalPlaces = 2;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(currencies);
            var payment = PaymentRequestAssembler.AssemblePayment(paymentRequest, partner, DateTime.UtcNow, PaymentStatus.Committed);
            CurrencyCacheMapper.Instance = null;

            AssertPayment(paymentRequest, payment);
            Assert.AreEqual(PaymentStatus.Committed, payment.PaymentStatus);
            Assert.AreEqual(partner.Id, payment.PaymentSourceId);
            Assert.AreEqual(paymentRequest.FixedAmount, payment.AmountMoney.Amount);
            Assert.AreEqual(paymentRequest.BankAccount.VersionedOn, payment.BankAccount.VersionedOn);
            Assert.AreEqual(paymentRequest.Beneficiary.VersionedOn, payment.Beneficiary.VersionedOn);

            AssertRemittance(paymentRequest.RemittanceData, payment.RemittanceData);
        }

        /*[Test]
        public void AssemblePayment_Correclty_UsingLastUpdatedOn()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            var paymentRequest = CreatePaymentRequest("1", 0, 0, DateTime.UtcNow.ToString("u"));
            paymentRequest.Beneficiary.Version = 0;
            paymentRequest.Beneficiary.LastUpdatedOn = "2015-05-05 05:05:05Z";
            paymentRequest.BankAccount.Version = 0;
            paymentRequest.BankAccount.LastUpdatedOn = "2015-11-15 11:11:11Z";
            
            paymentRequest.SetCustomer(CustomerHelper.Instance.CreateCustomer());
            var partner = new Partner { Id = 3, PaymentModel = PaymentModel.Decoupled };

            var currencies = SupportedCurrency.GetSupportedCurrency();
            currencies["CAD"].DecimalPlaces = 2;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(currencies);
            var payment = PaymentRequestAssembler.AssemblePayment(paymentRequest, partner, DateTime.UtcNow, PaymentStatus.Created);
            CurrencyCacheMapper.Instance = null;

            AssertPayment(paymentRequest, payment);
            Assert.AreEqual(PaymentStatus.Created, payment.PaymentStatus);
            Assert.AreEqual(partner.Id, payment.PaymentSourceId);
            Assert.AreEqual(paymentRequest.FixedAmount, payment.AmountMoney.Amount);

            Assert.AreEqual(20150505050505, payment.Beneficiary.Version);
            Assert.AreEqual(20151115111111, payment.BankAccount.Version);

            Assert.AreEqual(paymentRequest.Beneficiary.LastUpdatedOn, payment.Beneficiary.VersionedOn);
            Assert.AreEqual(paymentRequest.BankAccount.LastUpdatedOn, payment.BankAccount.VersionedOn);

            AssertRemittance(paymentRequest.RemittanceData, payment.RemittanceData);
        }*/

        [TestCase("edebit")]
        [TestCase("direct debit")]
        [TestCase("")]
        [TestCase("e-debit")]
        public void AssemblePaymentMethod_ForInvalidRequest_Correclty(string paymentMethodRequest)
        {
            var paymentMethod = PaymentRequestAssembler.AssemblePaymentMethod(paymentMethodRequest);
            Assert.IsFalse(Enum.IsDefined(typeof(PaymentMethod), paymentMethod));
        }

        [TestCase("ach")]
        [TestCase("wire")]
        [TestCase("ACH")]
        [TestCase("Wire")]
        public void AssemblePaymentMethod_ForValidRequest_Correclty(string paymentMethodRequest)
        {
            var paymentMethod = PaymentRequestAssembler.AssemblePaymentMethod(paymentMethodRequest);
            Assert.True(Enum.IsDefined(typeof(PaymentMethod), paymentMethod));
        }

        private void AssertPayment(MassPayments.Domain.Entities.PaymentRequest.PaymentRequest paymentRequest, Payment payment)
        {
            Assert.AreEqual(paymentRequest.CustomerBatchId, payment.CustomerBatchId);
            Assert.AreEqual(paymentRequest.PartnerReference, payment.PartnerReference);
            Assert.AreEqual(paymentRequest.PaymentMethod, payment.PaymentMethod.ToString());
            Assert.AreEqual(paymentRequest.PaymentId, payment.ExternalId);
            
            Assert.AreEqual(paymentRequest.FixedAmount, payment.AmountMoney.Amount);
            Assert.AreEqual(paymentRequest.CurrencyCode, payment.AmountMoney.Currency.Code);
            Assert.AreEqual(paymentRequest.PurposeOfPayment, payment.PurposeOfPayment);
            Assert.AreEqual(paymentRequest.InstructionForBank, payment.InstructionForBank);
            Assert.AreEqual(paymentRequest.InstructionCodeForBank, payment.InstructionCodeForBank);
            Assert.AreEqual(paymentRequest.Customer.TransactionSystemCustomerId, payment.TransactionSystemCustomerId);
            Assert.AreEqual(paymentRequest.Customer.TransactionSystemId, payment.TransactionSystemId);

            Assert.AreEqual(paymentRequest.RemittanceType, payment.RemittanceType.ToString());
            
            AssertBeneficiary(paymentRequest.Beneficiary, payment.Beneficiary, paymentRequest);
            AssertBankAccount(paymentRequest.BankAccount, payment.BankAccount);
            AssertThirdPartyRemitter(paymentRequest.ThirdPartyRemitter, payment.ThirdPartyRemitter);
        }

        private void AssertBeneficiary(MassPayments.Domain.Entities.PaymentRequest.Beneficiary beneficiaryRequest, MassPayments.Domain.Entities.Beneficiary beneficiary, MassPayments.Domain.Entities.PaymentRequest.PaymentRequest paymentRequest)
        {
            Assert.AreEqual(beneficiaryRequest.Id, beneficiary.ExternalId);
            Assert.AreEqual(beneficiaryRequest.VersionedOn, beneficiary.VersionedOn);
            Assert.AreNotEqual(0, beneficiary.Version);
            AssertAddress(beneficiaryRequest.Address, beneficiary.Address);
            AssertIdentification(beneficiaryRequest, beneficiary.Identification);
        }

        private void AssertIdentification(MassPayments.Domain.Entities.PaymentRequest.Beneficiary beneficiaryRequest, MassPayments.Domain.Entities.Identification identification)
        {
            Assert.AreEqual(beneficiaryRequest.EmailAddress, identification.EmailAddress);
            Assert.AreEqual(beneficiaryRequest.Type, identification.EntityType);
            Assert.AreEqual(beneficiaryRequest.FirstName, identification.FirstName);
            Assert.AreEqual(beneficiaryRequest.MiddleName, identification.MiddleName);
            Assert.AreEqual(beneficiaryRequest.LastName, identification.LastName);
            Assert.AreEqual(beneficiaryRequest.PhoneNumber, identification.PhoneNumber);
            Assert.AreEqual(beneficiaryRequest.CellNumber, identification.CellNumber);
            Assert.AreEqual(beneficiaryRequest.DateOfBirth, identification.DateOfBirth);
            Assert.AreEqual(beneficiaryRequest.Gender, identification.Gender);
            Assert.AreEqual(beneficiaryRequest.BusinessName, identification.BusinessName);
            Assert.AreEqual(beneficiaryRequest.BusinessRegistrationNumber, identification.BusinessRegistrationNumber);
            Assert.AreEqual(beneficiaryRequest.BusinessRegistrationCountry, identification.BusinessRegistrationCountry);
            Assert.AreEqual(beneficiaryRequest.BusinessRegistrationStateProv, identification.BusinessRegistrationStateProv);
            Assert.AreEqual(beneficiaryRequest.BusinessContactRole, identification.BusinessContactRole);
            Assert.AreEqual(beneficiaryRequest.Industry, identification.Industry);
        }

        private void AssertBankAccount(MassPayments.Domain.Entities.PaymentRequest.BankAccount bankAccountData, MassPayments.Domain.Entities.BankAccount bankAccount)
        {
            Assert.AreEqual(bankAccountData.Id, bankAccount.ExternalId);
            Assert.AreEqual(bankAccountData.VersionedOn, bankAccount.VersionedOn);
            Assert.AreEqual(bankAccountData.AccountNumber, bankAccount.AccountNumber);
            Assert.AreEqual(bankAccountData.AccountType, bankAccount.AccountPurpose);
            Assert.AreEqual(bankAccountData.BankName, bankAccount.BankName);
            Assert.AreEqual(bankAccountData.BranchName, bankAccount.BranchName);
            Assert.AreEqual(bankAccountData.BankCode, bankAccount.BankCode);
            Assert.AreEqual(bankAccountData.BankBranchCode, bankAccount.BranchCode);
            Assert.AreNotEqual(0, bankAccount.Version);
            AssertAddress(bankAccountData.BankAddress, bankAccount.BankAddress);
            AssertIntermediaryBank(bankAccountData.IntermediaryBank, bankAccount.IntermediaryBankAccount);
        }

        private void AssertAddress(MassPayments.Domain.Entities.PaymentRequest.Address addressRequest, MassPayments.Domain.Entities.Address address)
        {
            Assert.AreEqual(addressRequest.AddressLine1, address.AddressLine1);
            Assert.AreEqual(addressRequest.AddressLine2, address.AddressLine2);
            Assert.AreEqual(addressRequest.AddressLine3, address.AddressLine3);
            Assert.AreEqual(addressRequest.City, address.City);
            Assert.AreEqual(addressRequest.StateOrPovince, address.StateOrProvince);
            Assert.AreEqual(addressRequest.ZipOrPostalCode, address.ZipOrPostalCode);
            Assert.AreEqual(addressRequest.CountryCode, address.CountryCode);
        }

        private void AssertIntermediaryBank(IntermediaryBank intermediaryBankRequest, IntermediaryBankAccount intermediaryBankAccount)
        {
            Assert.AreEqual(intermediaryBankRequest.BankName, intermediaryBankAccount.BankName);
            Assert.AreEqual(intermediaryBankRequest.BankCode, intermediaryBankAccount.BankCode);
            Assert.AreEqual(intermediaryBankRequest.AccountNumber, intermediaryBankAccount.AccountNumber);
            AssertAddress(intermediaryBankRequest.Address, intermediaryBankAccount.BankAddress);
        }

        private void AssertThirdPartyRemitter(MassPayments.Domain.Entities.PaymentRequest.ThirdPartyRemitter thirdPartyRemitterRequest, MassPayments.Domain.Entities.ThirdPartyRemitter thirdPartyRemitter)
        {
            Assert.AreNotEqual(0, thirdPartyRemitter.Version);
            Assert.AreEqual(thirdPartyRemitterRequest.Id, thirdPartyRemitter.Id);
            Assert.AreEqual(thirdPartyRemitterRequest.VersionedOn, thirdPartyRemitter.VersionedOn);
            Assert.AreEqual(thirdPartyRemitterRequest.Type, thirdPartyRemitter.Type);
            Assert.AreEqual(thirdPartyRemitterRequest.BusinessName, thirdPartyRemitter.BusinessName);
            AssertAddress(thirdPartyRemitterRequest.Address, thirdPartyRemitter.Address);
            Assert.AreEqual(thirdPartyRemitterRequest.PhoneNumber, thirdPartyRemitter.PhoneNumber);
            Assert.AreEqual(thirdPartyRemitterRequest.Email, thirdPartyRemitter.Email);
            Assert.AreEqual(thirdPartyRemitterRequest.IdentificationType, thirdPartyRemitter.IdentificationType);
            Assert.AreEqual(thirdPartyRemitterRequest.Identification, thirdPartyRemitter.Identification);
            Assert.AreEqual(thirdPartyRemitterRequest.Industry, thirdPartyRemitter.Industry);
        }

        private void AssertRemittance(List<RemittanceReference> remittanceRequest, List<string> remittances)
        {
            if (remittances != null && remittanceRequest != null)
            {
                Assert.AreEqual(remittanceRequest.Select(i=>i.Reference).Count(), remittances.Count());
                Assert.AreEqual(0, (remittanceRequest.Select(i => i.Reference).ToList().Except(remittances)).Count());
            }            
        }

        private MassPayments.Domain.Entities.PaymentRequest.PaymentRequest CreatePaymentRequest(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.PaymentRequest
            {
                ItemIndex = itemIndex,
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerAssignedCustomerId = "123",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "Wire",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                FixedAmount = 100,
                CurrencyCode = "CAD",
                RemittanceData = new List<RemittanceReference>
                    {
                        new RemittanceReference { Reference = "ref1" }, 
                        new RemittanceReference { Reference = "ref2" }
                    },
                RemittanceType = "CTX",
                ThirdPartyRemitter = CreateThirdPartyRemitter()
            };
        }

        private MassPayments.Domain.Entities.PaymentRequest.BankAccount CreateBankAccount(string id)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddress(),
                BankBranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                IntermediaryBank = CreateIntermediaryBank(),
                VersionedOn = DateTime.UtcNow.ToString()
            };
        }

        private MassPayments.Domain.Entities.PaymentRequest.Address CreateAddress()
        {
            return new MassPayments.Domain.Entities.PaymentRequest.Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

        private MassPayments.Domain.Entities.PaymentRequest.IntermediaryBank CreateIntermediaryBank()
        {
            return new MassPayments.Domain.Entities.PaymentRequest.IntermediaryBank
            {
                AccountNumber = "acct no",
                Address = CreateAddress(),
                BankCode = "bnk code",
                BankName = "bnk name"
            };
        }

        private MassPayments.Domain.Entities.PaymentRequest.ThirdPartyRemitter CreateThirdPartyRemitter()
        {
            return new MassPayments.Domain.Entities.PaymentRequest.ThirdPartyRemitter
            {
                Id = "myid",
                VersionedOn = DateTime.UtcNow.ToString(),
                Type = "corporation",
                BusinessName = "mybusname",
                Address = CreateAddress(),
                PhoneNumber = "some phone",
                Email = "some email",
                IdentificationType = "bus reg no",
                Identification = "bleh",
                Industry = "fi"
            };
        }

        private MassPayments.Domain.Entities.PaymentRequest.Beneficiary CreateBeneficiary(string id)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                VersionedOn = DateTime.UtcNow.ToString(),
                PhoneNumber = "123",
                Type = "I/B"
            };
        }        
    }
}
