﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Services.Pain2MassPaymentsService.Assemblers;
using MassPayments.Services.Pain2MassPaymentsService.DataContracts;
using MassPayments.Tests.Unit.Helpers;
using Newtonsoft.Json;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Services.Pain2MassPaymentsService.Assemblers
{
    [TestFixture]
    public class PainPaymentResultAssemblerFixture
    {
        [Test]
        public void ConvertJsonToDomain_ConvertsStringMessageFromPain_ToPayments()
        {
            
            var jsonRequest = JsonConvert.SerializeObject(new PaymentResultListJson
            {
                Payments = new List<PaymentResultJson>
                {
                    new PaymentResultJson
                    {
                        PaymentId = 123,
                        PaymentStatus = "Accepted",
                        RejectReason = "",
                        PaymentSource = "1",
                        DateProcessedInGPG = DateTime.Now.ToString()
                    },
                    new PaymentResultJson
                    {
                        PaymentId = 456,
                        PaymentStatus = "Rejected",
                        RejectReason = "rejected by GPG",
                        PaymentSource = "1",
                        DateProcessedInGPG = DateTime.Now.ToString()
                    }
                }
                    
            });

            var payments = PainPaymentResultAssembler.ConvertJsonToDomain(jsonRequest);
            Assert.AreEqual(2, payments.Count);
            Assert.AreEqual(PaymentStatus.Released, payments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Rejected, payments[1].PaymentStatus);
        }

        [Test]
        public void ConvertJsonToDomain_ConvertsStringMessageFromPain_ToReturnedPayments()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(m => m.GetCurrencyDictionary()).Return((SupportedCurrency.GetSupportedCurrency()));
            var jsonRequest = JsonConvert.SerializeObject(new PaymentResultListJson
            {
                Payments = new List<PaymentResultJson>
                {
                    new PaymentResultJson
                    {
                        PaymentId = 123,
                        PaymentStatus = "Returned",
                        RejectReason = "returned from bank",
                        PaymentSource = "1",
                        DateProcessedInGPG = DateTime.Now.ToString(),
                        AmountReturned = 50m,
                        ReturnedCurrencyCode = "CAD",
                        UserName = "blah"
                    }
                }

            });

            var payments = PainPaymentResultAssembler.ConvertJsonToDomain(jsonRequest);
            Assert.AreEqual(1, payments.Count);
            Assert.IsInstanceOf<ReturnedPayment>(payments[0]);
            Assert.AreEqual(PaymentStatus.Returned, payments[0].PaymentStatus);
            Assert.AreEqual(50m, ((ReturnedPayment)payments[0]).ReturnAmount.Amount);
            Assert.AreEqual("CAD", ((ReturnedPayment)payments[0]).ReturnAmount.Currency.Code);
            Assert.AreEqual("blah", ((ReturnedPayment)payments[0]).UserName);
            Assert.AreEqual("returned from bank", ((ReturnedPayment)payments[0]).RejectReason);
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
            CurrencyCacheMapper.Instance = null;
        }
    }
}
