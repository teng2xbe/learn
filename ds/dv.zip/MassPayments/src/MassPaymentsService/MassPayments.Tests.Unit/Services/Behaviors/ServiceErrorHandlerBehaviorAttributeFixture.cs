﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using MassPayments.Services.MassPaymentsService.Behaviors;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Services.Behaviors
{
    [TestFixture]
    public class ServiceErrorHandlerBehaviorAttributeFixture
    {
        [Test]
        public void ApplyDispatchBehavior_AddsErrorHandler()
        {
            var host = MockRepository.GenerateStub<ServiceHostBase>();
            var listener = MockRepository.GenerateStub<IChannelListener>();
            var channelDispatcher = new ChannelDispatcher(listener);
            host.ChannelDispatchers.Add(channelDispatcher);
            var errorHandler = new TestErrorHandler();
            
            new ServiceErrorHandlerBehaviorAttribute(errorHandler.GetType()).ApplyDispatchBehavior(host.Description, host);

            Assert.AreEqual(1, host.ChannelDispatchers.Count);
            Assert.AreEqual(1, ((ChannelDispatcher)host.ChannelDispatchers[0]).ErrorHandlers.Count);
            Assert.IsTrue(((ChannelDispatcher)host.ChannelDispatchers[0]).ErrorHandlers[0] is TestErrorHandler);
        }

        [Test]
        public void ApplyDispatchBehavior_ThrowsExceptionIfUsingIncorrectErrorHandler()
        {
            var host = MockRepository.GenerateStub<ServiceHostBase>();
            var listener = MockRepository.GenerateStub<IChannelListener>();
            var channelDispatcher = new ChannelDispatcher(listener);
            host.ChannelDispatchers.Add(channelDispatcher);
            var errorHandler = new TestErrorHandler2("gorilla");
            
            Assert.Throws<ArgumentException>(() => new ServiceErrorHandlerBehaviorAttribute(errorHandler.GetType()).ApplyDispatchBehavior(host.Description, host));
        }

        [Test]
        public void ApplyDispatchBehavior_ThrowsExceptionIfUsingTheWrongErrorType()
        {
            var host = MockRepository.GenerateStub<ServiceHostBase>();
            var listener = MockRepository.GenerateStub<IChannelListener>();
            var channelDispatcher = new ChannelDispatcher(listener);
            host.ChannelDispatchers.Add(channelDispatcher);
            var errorHandler = new TestErrorHandler3();
            
            Assert.Throws<ArgumentException>(() => new ServiceErrorHandlerBehaviorAttribute(errorHandler.GetType()).ApplyDispatchBehavior(host.Description, host));
        }

        [Test]
        public void Validate_DoesNothing()
        {
            Assert.DoesNotThrow(() => new ServiceErrorHandlerBehaviorAttribute(null).Validate(Arg<ServiceDescription>.Is.Anything,
                Arg<ServiceHostBase>.Is.Anything));
        }

        [Test]
        public void AddBindingParameters_DoesNothing()
        {
            Assert.DoesNotThrow(() => new ServiceErrorHandlerBehaviorAttribute(null).AddBindingParameters(Arg<ServiceDescription>.Is.Anything,
                Arg<ServiceHostBase>.Is.Anything, null, Arg<BindingParameterCollection>.Is.Anything));
        }

        private class TestErrorHandler : IErrorHandler
        {
            public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
            {
            }

            public bool HandleError(Exception error)
            {
                return true;
            }
        }

        private class TestErrorHandler2 : IErrorHandler
        {
            public TestErrorHandler2(string aParam)
            {
            }

            public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
            {
            }

            public bool HandleError(Exception error)
            {
                return true;
            }
        }

        private class TestErrorHandler3 { }
    }
}
