﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Services.MassPaymentsService.Exceptions;
using MassPayments.Services.MassPaymentsService.Validators;
using MassPaymentsCommon.WCFContracts.RESTContracts.orders;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Services.MassPayments.Validators
{
    [TestFixture]
    public class OrderBookingRequestValidatorFixture
    {
        [SetUp]
        public void SetUp()
        {
            CurrencyCacheMapper.Instance = new TestCurrencyCacheMapper();
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyCache.Instance = null;
        }

        [Test]
        public void Validate_Should_Not_Throw_For_Successful_Simple_Request()
        {
            var request = CreateBookFundingOrdersRequestData();
            request.OrdersToBook.Add(CreateBookFundingOrderRequestData());
            request.OrdersToBook[0].ItemsToBook.Add(CreateBookFundingOrderRequestItemData());

            Assert.DoesNotThrow(() => OrderBookingRequestValidator.Validate(request));
        }

        [Test]
        public void Validate_Should_Not_Throw_For_Successful_Complex_Request()
        {
            BookFundingOrderRequestData order = null;
            BookFundingOrderRequestItemData item = null;

            var request = CreateBookFundingOrdersRequestData();
            order = CreateBookFundingOrderRequestData();
            item = CreateBookFundingOrderRequestItemData();
            order.ItemsToBook.Add(item);
            request.OrdersToBook.Add(order);

            order = CreateBookFundingOrderRequestData();
            order.SettlementCurrencyCode = "USD";
            item = CreateBookFundingOrderRequestItemData();
            order.ItemsToBook.Add(item);
            item = CreateBookFundingOrderRequestItemData();
            item.TradeCurrencyCode = "CAD";
            order.ItemsToBook.Add(item);
            request.OrdersToBook.Add(order);

            Assert.DoesNotThrow(() => OrderBookingRequestValidator.Validate(request));
        }

        [Test]
        public void Validate_Throws_When_Invalid_SettlementCurrency()
        {
            var request = CreateBookFundingOrdersRequestData();
            var order = CreateBookFundingOrderRequestData();
            order.SettlementCurrencyCode = "ABC";
            request.OrdersToBook.Add(order);
            request.OrdersToBook[0].ItemsToBook.Add(CreateBookFundingOrderRequestItemData());

            Assert.Throws<CurrencyNotRecognizedException>(() => OrderBookingRequestValidator.Validate(request));
        }

        [Test]
        public void Validate_Throws_When_Invalid_TradeCurrency()
        {
            var request = CreateBookFundingOrdersRequestData();
            request.OrdersToBook.Add(CreateBookFundingOrderRequestData());
            var item = CreateBookFundingOrderRequestItemData();
            item.TradeCurrencyCode = "ABC";
            request.OrdersToBook[0].ItemsToBook.Add(item);

            Assert.Throws<CurrencyNotRecognizedException>(() => OrderBookingRequestValidator.Validate(request));
        }

        [Test]
        public void Validate_Throws_When_Invalid_SettlementMethod()
        {
            var request = CreateBookFundingOrdersRequestData();
            var order = CreateBookFundingOrderRequestData();
            order.SettlementMethod = "ABC";
            request.OrdersToBook.Add(order);
            request.OrdersToBook[0].ItemsToBook.Add(CreateBookFundingOrderRequestItemData());

            Assert.Throws<UnsupportedSettlementMethodRequestedException>(() => OrderBookingRequestValidator.Validate(request));
        }


        private BookFundingOrdersRequestData CreateBookFundingOrdersRequestData()
        {
            return new BookFundingOrdersRequestData
            {
                PartnerAssignedCustomerId = "blah",
                QuoteId = "123",
                 OrdersToBook = new List<BookFundingOrderRequestData>()                
            };            
        }

        private BookFundingOrderRequestData CreateBookFundingOrderRequestData()
        {
            return new BookFundingOrderRequestData
            {
                SettlementCurrencyCode = "USD",
                SettlementMethod = "ACH",
                ItemsToBook = new List<BookFundingOrderRequestItemData>()
            };
        }

        private BookFundingOrderRequestItemData CreateBookFundingOrderRequestItemData()
        {
            return new BookFundingOrderRequestItemData
            {
                TradeCurrencyCode = "CAD",
                Amount = 120
            };
        }

        public class TestCurrencyCacheMapper : ICurrencyCacheMapper
        {
            public Dictionary<string, Currency> GetCurrencyDictionary()
            {
                return new Dictionary<string, Currency> { { "CAD", new Currency("CAD") { Status = CurrencyStatus.Enabled } }, { "USD", new Currency("USD") { Status = CurrencyStatus.Enabled } }, { "IDR", new Currency("IDR") { Status = CurrencyStatus.Disabled } } };
            }
        }
    }
}
