﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Services.MassPaymentsService.ErrorHandlers;
using MassPayments.Services.MassPaymentsService.FaultContracts;
using MassPaymentsCommon.WCFContracts.Enums;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Services.MassPayments.ErrorHandlers
{
    [TestFixture]
    public class ExceptionToFaultConverterFixture
    {
        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_DebitLimitExceededException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new DebitLimitExceededException("Debit limit exceeded"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.DebitLimitExceeded, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_InvalidSettlementMethodException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new InvalidSettlementMethodException("Client is not setup for this settlement method"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.SettlementMethodInvalid, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        
        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_GenericOrderValidationException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new GenericOrderValidationException("Generic order validation"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.GenericOrderValidationFailed, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_GenericLineItemValidationException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new GenericLineItemValidationException("Generic line item validation"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.GenericLineItemValidationFailed, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_GenericCoupledLineItemValidationException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new GenericCoupledLineItemValidationException("Generic coupled line item validation"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.GenericCoupledLineItemValidationFailed, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_GenericDecoupledLineItemValidationException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new GenericDecoupledLineItemValidationException("Generic decoupled line item validation"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.GenericDecoupledLineItemValidationFailed, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }
        
        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_MinimumAmountNotMetException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new MinimumAmountNotMetException("Minimum amount not met"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.MinimumAmountNotMet, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_MaximumAmountExceededException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new MaximumAmountExceededException("Maximum amount exceeded"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.MaximumAmountExceeded, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_CurrencyNotCapableOfHoldingException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new CurrencyNotCapableofHoldingException("Cannot used currency for holding"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.CurrencyNotCapableOfHolding, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_SettlementCurrencySettledMultipleTimesException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new SettlementCurrencySettledMultipleTimesException(new List<Currency> {Currency.CAD, Currency.EUR}));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.BatchSettlementCurrencySubmittedMultipleTimes, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_SettlementCurrencyNotUsedForBatchPaymentsException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new SettlementCurrencyNotUsedForBatchPaymentsException(new List<Currency> { Currency.CAD, Currency.EUR }));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.ExtraBatchSettlementCurrencySubmitted, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        [Test]
        public void ConvertExceptionToFaultException_ReturnsProperFaultAndErrorCode_For_UnsupportedSettlementMethodRequestedException()
        {
            var faultException =
                ExceptionToFaultConverter.ConvertExceptionToFaultException(
                    new UnsupportedSettlementMethodRequestedException("banana","settlementMethod"));

            Assert.IsTrue(faultException is FaultException<BadRequestFault>);
            Assert.AreEqual((int)ErrorCode.InvalidValueOrFormat, ((FaultException<BadRequestFault>)faultException).Detail.ErrorCode);
        }

        


    }
}
