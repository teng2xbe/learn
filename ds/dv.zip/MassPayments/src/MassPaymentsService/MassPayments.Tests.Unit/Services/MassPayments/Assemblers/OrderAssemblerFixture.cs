﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Enums;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPaymentsCommon.WCFContracts.RESTContracts.orders;
using NUnit.Framework;
using MassPayments.Domain.Entities;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class OrderAssemblerFixture
    {
        [Test]
        public void AssembleRestfulResult_Correctly()
        {
            var data = new List<Order>
                {
                    new Order
                        {
                            ConfirmationNumber = "TR1234",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Committed,
                            SettlementCurrencyCode = "CAD",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        },
                    new Order
                        {
                            ConfirmationNumber = "TR1235",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Funded,
                            SettlementCurrencyCode = "USD",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        },
                    new Order
                        {
                            ConfirmationNumber = "TR1235",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Received,
                            SettlementCurrencyCode = "MXN",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        }

                };

            var result = OrderAssembler.AssembleRestfulResult(data,null);

            Assert.AreEqual(3, result.BookedOrders.Count);
            AssertStatusResult(data[0], result.BookedOrders[0]);
            AssertStatusResult(data[1], result.BookedOrders[1]);
            AssertStatusResult(data[2], result.BookedOrders[2]);

        }

        [Test]
        public void AssembleRestfulResult_ForNotFound_Correctly()
        {
            var data = new List<Order>
                {
                    new Order
                        {
                            ConfirmationNumber = "TR1234",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.NotFound,
                            SettlementCurrencyCode = "CAD",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        },
                    new Order
                        {
                            ConfirmationNumber = "TR1235",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Funded,
                            SettlementCurrencyCode = "USD",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        },
                    new Order
                        {
                            ConfirmationNumber = "TR1235",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Received,
                            SettlementCurrencyCode = "MXN",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        }

                };

            var result = OrderAssembler.AssembleRestfulResult(data,null);

            Assert.AreEqual(3, result.BookedOrders.Count);
            AssertStatusResult(data[0], result.BookedOrders[0]);
            AssertStatusResult(data[1], result.BookedOrders[1]);
            AssertStatusResult(data[2], result.BookedOrders[2]);

        }

        [Test]
        public void AssembleRestfulResult_ReturnBasedOnStatusFilter()
        {
            var statusFilter = "Received";
            var data = new List<Order>
                {
                    new Order
                        {
                            ConfirmationNumber = "TR1234",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Committed,
                            SettlementCurrencyCode = "CAD",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        },
                    new Order
                        {
                            ConfirmationNumber = "TR1235",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Committed,
                            SettlementCurrencyCode = "USD",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        },
                    new Order
                        {
                            ConfirmationNumber = "TR1235",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.Received,
                            SettlementCurrencyCode = "MXN",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                        }

                };

            var result = OrderAssembler.AssembleRestfulResult(data, statusFilter);

            Assert.AreEqual(1, result.BookedOrders.Count);
            AssertStatusResult(data[2], result.BookedOrders[0]);
        }

        [Test]
        public void AssembleRestfulResultItem_ConvertsForNotFound_Correctly()
        {
            var data = new Order
                        {
                            ConfirmationNumber = "TR1234",
                            LastUpdatedOn = DateTime.UtcNow,
                            OrderStatus = OrderStatus.NotFound,
                            SettlementCurrencyCode = "CAD",
                            PartnerAssignedCustomerId = "TEST_QA",
                            CreatedOn = DateTime.UtcNow,
                };

            var result = OrderAssembler.AssembleRestfulResultItem(data);
            Assert.IsNull(result);
        }

        private static void AssertStatusResult(Order order, GetSingleOrderResultData result)
        {
            if (result.OrderStatus == null)
            {
                Assert.IsNull(result.OrderStatus);
                Assert.AreEqual(order.ConfirmationNumber, result.OrderId);               
                Assert.IsNotNull(result.ErrorCode);
                Assert.IsNull(result.PartnerAssignedCustomerId);
                Assert.IsNull(result.SettlementCurrencyCode);
                Assert.IsNull(result.LastUpdatedOn);
                Assert.IsNull(result.CreatedOn);
            }
            else
            {
                Assert.AreEqual(order.OrderStatus.ToString(), result.OrderStatus);
                Assert.AreEqual(order.PartnerAssignedCustomerId, result.PartnerAssignedCustomerId);
                Assert.AreEqual(order.SettlementCurrencyCode, result.SettlementCurrencyCode);
                Assert.AreEqual(order.ConfirmationNumber, result.OrderId);
                Assert.AreEqual(order.LastUpdatedOn.Value.ToString("yyyy-MM-ddTHH:mm:ssZ"), result.LastUpdatedOn);
                Assert.AreEqual(order.CreatedOn.Value.ToString("yyyy-MM-ddTHH:mm:ssZ"), result.CreatedOn);
                
            }
        }
    }
}
