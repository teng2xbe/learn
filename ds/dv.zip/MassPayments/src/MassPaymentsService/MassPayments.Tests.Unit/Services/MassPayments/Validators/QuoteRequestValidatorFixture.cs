﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Quoting;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Services.MassPaymentsService.Exceptions;
using MassPayments.Services.MassPaymentsService.Validators;
using MassPaymentsCommon.WCFContracts.RESTContracts.quotes;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Services.MassPayments.Validators
{
    [TestFixture]
    public class QuoteRequestValidatorFixture
    {

        [SetUp]
        public void SetUp()
        {
            CurrencyCacheMapper.Instance = new TestCurrencyCacheMapper();
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyCache.Instance = null;
        }


        [Test]
        public void Validator_DoesNotThrow_ForValidRequestWithSettlementAmount()
        {
            var request = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100), FixedTradeMoney = new Money(Currency.USD, 0) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 200), FixedTradeMoney = new Money(Currency.CAD, 0) }
                }
            };
            var request1 = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100), FixedTradeMoney = new Money(Currency.USD, 0) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 200), FixedTradeMoney = new Money(Currency.CAD, 0) }
                }
            };

            Assert.DoesNotThrow(() => QuoteRequestValidator.Validate(request));
            Assert.DoesNotThrow(() => QuoteRequestValidator.Validate(request1));
        }

        [Test]
        public void Validator_Throws_DuplicatedCurrencyPairError()
        {
            var request = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100), FixedTradeMoney = new Money(Currency.USD, 0) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 200), FixedTradeMoney = new Money(Currency.USD, 0) }
                }
            };

            Assert.Throws<InvalidQuoteRequestException>(() => QuoteRequestValidator.Validate(request));
        }

        [Test]
        public void Validator_Throws_ForInvalidRequestWithMixedAmount()
        {
            var request = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem {FixedTradeMoney = new Money(Currency.Null, 100)},
                    new QuoteRequestItem {FixedSettlementMoney = new Money(Currency.Null, 200)},
                }
            };
            var request1 = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem {FixedTradeMoney = new Money(Currency.Null, 100), FixedSettlementMoney = new Money(Currency.Null, 200)},
                    new QuoteRequestItem {FixedSettlementMoney = new Money(Currency.Null, 200)},
                }
            };
            var request2 = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem {FixedTradeMoney = new Money(Currency.Null, 100)},
                    new QuoteRequestItem {FixedTradeMoney = new Money(Currency.Null, 100), FixedSettlementMoney = new Money(Currency.Null, 200)},
                }
            };

            var request3 = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem {FixedTradeMoney = new Money(Currency.Null, 100), FixedSettlementMoney = new Money(Currency.Null, 200)},
                    new QuoteRequestItem {FixedTradeMoney = new Money(Currency.Null, 100), FixedSettlementMoney = new Money(Currency.Null, 200)},
                }
            };

            Assert.Throws<InvalidQuoteRequestException>(() => QuoteRequestValidator.Validate(request));
            Assert.Throws<InvalidQuoteRequestException>(() => QuoteRequestValidator.Validate(request1));
            Assert.Throws<InvalidQuoteRequestException>(() => QuoteRequestValidator.Validate(request2));
            Assert.Throws<InvalidQuoteRequestException>(() => QuoteRequestValidator.Validate(request3));
        }
        
        [Test]
        public void Validate_Throws_SettlementCurrency_NotSupported()
        {
            FundingQuoteRequestData request = new FundingQuoteRequestData
            {
                 PartnerAssignedCustomerId = "blah",
                 QuoteRequestItems = new List<FundingQuoteRequestItemData>()
                 {
                    new FundingQuoteRequestItemData
                    {
                        Amount = 120,
                        SettlementCurrencyCode = "IDR",
                        TradeCurrencyCode = "CAD"
                    }
                 }
            };

            Assert.Throws<CurrencyNotSupportedException>(() => QuoteRequestValidator.Validate(request));
        }

        [Test]
        public void Validate_Throws_SettlementCurrency_NotRecognized()
        {
            FundingQuoteRequestData request = new FundingQuoteRequestData
            {
                PartnerAssignedCustomerId = "blah",
                QuoteRequestItems = new List<FundingQuoteRequestItemData>()
                 {
                    new FundingQuoteRequestItemData
                    {
                        Amount = 120,
                        SettlementCurrencyCode = "XXX",
                        TradeCurrencyCode = "CAD"
                    }
                 }
            };

            Assert.Throws<CurrencyNotRecognizedException>(() => QuoteRequestValidator.Validate(request));
        }

        [Test]
        public void Validate_Throws_TradeCurrency_NotSupported()
        {
            FundingQuoteRequestData request = new FundingQuoteRequestData
            {
                PartnerAssignedCustomerId = "blah",
                QuoteRequestItems = new List<FundingQuoteRequestItemData>()
                 {
                    new FundingQuoteRequestItemData
                    {
                        Amount = 120,
                        SettlementCurrencyCode = "USD",
                        TradeCurrencyCode = "IDR"
                    }
                 }
            };

            Assert.Throws<CurrencyNotSupportedException>(() => QuoteRequestValidator.Validate(request));
        }

        [Test]
        public void Validate_Throws_TradeCurrency_NotRecognized()
        {
            FundingQuoteRequestData request = new FundingQuoteRequestData
            {
                PartnerAssignedCustomerId = "blah",
                QuoteRequestItems = new List<FundingQuoteRequestItemData>()
                 {
                    new FundingQuoteRequestItemData
                    {
                        Amount = 120,
                        SettlementCurrencyCode = "USD",
                        TradeCurrencyCode = "XXX"
                    }
                 }
            };

            Assert.Throws<CurrencyNotRecognizedException>(() => QuoteRequestValidator.Validate(request));
        }            

        [Test]
        public void Validate_Throws_When_MoreThan25_QuoteItem_Is_Provided()
        {
            var request = CreateFundingQuoteRequestData();
            var quoteItems = new List<FundingQuoteRequestItemData>();
            for (var i = 0; i < 26; i++)
            {
                quoteItems.Add(CreaFundingQuoteRequestItemData());
            }
            request.QuoteRequestItems = quoteItems;            
            Assert.Throws<QuoteRequestItemLimitExceededException>(() => QuoteRequestValidator.Validate(request));
        }         

        [Test]
        public void Validate_Throws_When_There_Is_Duplicate_Currency_Pair()
        {
            var request = CreateFundingQuoteRequestData();
            var quoteItem = CreaFundingQuoteRequestItemData();
            request.QuoteRequestItems.Add(quoteItem);
            Assert.Throws<InvalidQuoteRequestException>(() => QuoteRequestValidator.Validate(request));
        }

        [Test]
        public void Validator_ThrowsException_WhenIsBatchParamIsNotProvidedAndQuoteItemsHaveBothCurrencyValues()
        {
            var request = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100), FixedTradeMoney = new Money(Currency.USD, 0) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 0), FixedTradeMoney = new Money(Currency.CAD, 100) }
                }
            };

            Assert.Throws<InvalidQuoteRequestException>(() => QuoteRequestValidator.Validate(request));
        }

        [Test]
        public void Validator_Works_WhenIsBatchParamIsTrueProvidedAndQuoteItemsHaveBothCurrencyValues()
        {
            var request = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.CAD, 100), FixedTradeMoney = new Money(Currency.USD, 0) },
                    new QuoteRequestItem { FixedSettlementMoney = new Money(Currency.USD, 0), FixedTradeMoney = new Money(Currency.CAD, 100) }
                }
            };

            Assert.DoesNotThrow(() => QuoteRequestValidator.Validate(request, true));
        }

        private FundingQuoteRequestData CreateFundingQuoteRequestData()
        {
            return new FundingQuoteRequestData
            {
                PartnerAssignedCustomerId = "blah",
                QuoteRequestItems = new List<FundingQuoteRequestItemData>
                {
                    CreaFundingQuoteRequestItemData()
                }
            };            
        }

        private FundingQuoteRequestItemData CreaFundingQuoteRequestItemData()
        {
            return new FundingQuoteRequestItemData
            {
                Amount = 120,
                SettlementCurrencyCode = "USD",
                TradeCurrencyCode = "CAD"
            };
        }
    }

    public class TestCurrencyCacheMapper : ICurrencyCacheMapper
    {
        public Dictionary<string, Currency> GetCurrencyDictionary()
        {
            return new Dictionary<string, Currency> { { "CAD", Currency.CAD }, { "USD", Currency.USD }, { "IDR", new Currency("IDR") { Status = CurrencyStatus.Disabled }}};
        }
    }
}
