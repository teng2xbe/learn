﻿using System.Collections.Generic;
using MassPayments.Domain.ValueObjects;
using MassPayments.Infrastructure.Caches;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Services.MassPaymentsService.Assemblers;
using NUnit.Framework;
using MassPayments.Mappers;
using Rhino.Mocks;
using MassPayments.Mappers.Interfaces;


namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class HoldingBalanceAssemblerFixture
    {
        [Test]
        public void ConvertHoldingBalanceList_Correctly()
        {
            var holdingBalances = new List<HoldingBalance>
                {
                    new HoldingBalance
                        {
                            Currency = new Currency("USD"),
                            AvailableBalance = new Money(new Currency("USD"), 1000.00m),
                            BookedBalance = new Money(new Currency("USD"), 1200.00m),
                        },
                    new HoldingBalance
                        {
                            Currency = new Currency("CAD"),
                            AvailableBalance = new Money(new Currency("CAD"), 1000.00m),
                            BookedBalance = new Money(new Currency("CAD"), 1200.00m),
                        }
                };

            var data = HoldingBalanceAssembler.Convert(holdingBalances,"MPTEST");

            Assert.AreEqual(2, data.HoldingBalances.Count);

            Assert.AreEqual(holdingBalances[0].Currency.Code, data.HoldingBalances[0].Currency);
            Assert.AreEqual(holdingBalances[1].Currency.Code, data.HoldingBalances[1].Currency);

            Assert.AreEqual(holdingBalances[0].AvailableBalance.NonDecimalAmount, data.HoldingBalances[0].Available);
            Assert.AreEqual(holdingBalances[1].AvailableBalance.NonDecimalAmount, data.HoldingBalances[1].Available);

            Assert.AreEqual(holdingBalances[0].BookedBalance.NonDecimalAmount, data.HoldingBalances[0].Booked);
            Assert.AreEqual(holdingBalances[1].BookedBalance.NonDecimalAmount, data.HoldingBalances[1].Booked);
        }
    }
}
