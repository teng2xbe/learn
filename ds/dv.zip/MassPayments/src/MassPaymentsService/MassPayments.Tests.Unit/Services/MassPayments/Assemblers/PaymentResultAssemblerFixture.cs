﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Query.POCOs;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.Enums;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;
using NUnit.Framework;
using Address = MassPayments.Domain.Entities.Address;
using BankAccount = MassPayments.Domain.Entities.BankAccount;
using Beneficiary = MassPayments.Domain.Entities.Beneficiary;
using ThirdPartyRemitter = MassPayments.Domain.Entities.ThirdPartyRemitter;  

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class PaymentResultAssemblerFixture
    {
        [Test]
        public void AssembleSinglePayment_CorrectlyMapsFieldsFor_AcceptedPayment()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var result = PaymentResultAssembler.AssembleSinglePayment(payment, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.Status);            
            Assert.IsNullOrEmpty(result.ErrorCode);
            Assert.IsNullOrEmpty(result.UpdateErrorCode);
            Assert.IsNullOrEmpty(result.UpdateErrorOn);
            AssertPayments(payment, result);
        }

        [Test]
        public void AssembleSinglePayment_CorrectlyMapsFields_WithLastUpdateError()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.LastUpdateError = new PaymentUpdateHistory {ErrorCode = "1104", PaymentId = payment.Id, PaymentRequestId = 1234, UpdatedOnUtc = DateTime.Today };
            var result = PaymentResultAssembler.AssembleSinglePayment(payment, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual("1104", result.UpdateErrorCode);
            Assert.IsNotNullOrEmpty(result.UpdateErrorOn);
        }

        [Test]
        public void AssembleSinglePayment_CorrectlyMapsFieldsFor_ReturnedPayment()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreateReturnedPayment(customer, customerBatch);
            var amount = new Money(Currency.CAD, 50.00m);
            var reason = "Returned From Bank";
            payment.ReturnAmount = amount;
            payment.RejectReason = reason;

            var result = PaymentResultAssembler.AssembleSinglePayment(payment, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual(PaymentStatusData.Returned.ToString(), result.Status);
            Assert.AreEqual(reason, result.ErrorCode);
            Assert.AreEqual(amount.NonDecimalAmount, result.ReturnAmount);
            Assert.AreEqual(amount.Currency.Code, result.ReturnCurrencyCode);
            AssertPayments(payment, result);
        }

        [Test]
        public void AssembleSinglePaymentForBatch_CorrectlyMapsFieldsFor_AcceptedPayment()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            payment.IsFixedAmountInSettlementCurrency = true;
            payment.SettlementAmountMoney = new Money(Currency.USD, 100.00m);
            payment.AmountMoney = new Money(Currency.AUD, 0.00m);
            var result = PaymentResultAssembler.AssembleSingleBatchPayment(payment, customerBatch,  customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.Status);
            Assert.AreEqual(true, result.IsFixedAmountInSettlementCurrency);
            Assert.AreEqual("AUD", result.TradeCurrencyCode);
            Assert.AreEqual("USD", result.SettlementCurrencyCode);
            Assert.AreEqual(0.00m, result.TradeAmount);
            Assert.AreEqual(10000m, result.SettlementAmount);
            Assert.IsNullOrEmpty(result.ErrorCode);
            Assert.IsNullOrEmpty(result.UpdateErrorCode);
            Assert.IsNullOrEmpty(result.UpdateErrorOn);
            AssertPayments(payment, result);
        }

        [Test]
        public void AssembleSinglePaymentForBatch_CorrectlyMapsFields_WithUpdateError()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.Created;
            payment.LastUpdateError = new PaymentUpdateHistory { ErrorCode = "1104", PaymentRequestId = 1234, PaymentId = payment.Id, UpdatedOnUtc = DateTime.Today };
            var result = PaymentResultAssembler.AssembleSingleBatchPayment(payment, customerBatch, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual("1104", result.UpdateErrorCode);
            Assert.IsNotNullOrEmpty(result.UpdateErrorOn);            
        }

        [Test]
        public void AssembleSinglePaymentForBatch_CorrectlyMapsFields_ForReturnedPayment()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            customerBatch.BatchStatus = CustomerBatchStatus.Processing;
            var payment = PaymentHelper.Instance.CreateReturnedPayment(customer, customerBatch);
            var amount = new Money(Currency.CAD, 50.00m);
            var reason = "Returned From Bank";
            payment.ReturnAmount = amount;
            payment.RejectReason = reason;

            var result = PaymentResultAssembler.AssembleSingleBatchPayment(payment, customerBatch, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual(PaymentStatusData.Returned.ToString(), result.Status);
            Assert.AreEqual(reason, result.ErrorCode);
            Assert.AreEqual(amount.NonDecimalAmount, result.ReturnAmount);
            Assert.AreEqual(amount.Currency.Code, result.ReturnCurrencyCode);
            AssertPayments(payment, result);
        }

        [Test]
        public void AssembleSinglePayment_CorrectlyMapsFieldsFor_AcceptedPayment_WithThirdPartyRemitter()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.ThirdPartyRemitter = new ThirdPartyRemitter
            {
                Id="myid",
                VersionedOn = DateTime.UtcNow.ToString(),
                BusinessName = "mybus",
                Type = "Corporation",
                Address = new Address
                {
                    AddressLine1 = "line 1",
                    AddressLine2 = "line 2",
                    AddressLine3 = "",
                    City = "cty",
                    CountryCode = "US",
                    StateOrProvince = "WA",
                    ZipOrPostalCode = "90210"
                },
                Email = "test@test.ca",
                PhoneNumber = "123",
                IdentificationType = "bus reg no",
                Identification = "11-22",
                Industry = "FI"
            };
            var result = PaymentResultAssembler.AssembleSinglePayment(payment, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.Status);
            Assert.IsNullOrEmpty(result.ErrorCode);
            AssertPayments(payment, result);
        }

        [TestCase(RemittanceType.Undefined, null)]
        [TestCase(RemittanceType.IAT, "IAT")]
        public void AssembleSinglePayment_CorrectlyMapsRemittanceTypes(RemittanceType remittanceType, string expectedValue)
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.RemittanceType = remittanceType;
            var result = PaymentResultAssembler.AssembleSinglePayment(payment, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual(PaymentStatusData.Created.ToString(), result.Status);
            Assert.IsNullOrEmpty(result.ErrorCode);
            Assert.AreEqual(expectedValue, result.RemittanceType);
        }

        [Test]
        public void AssembleSinglePayment_NotAcceptedPayment_Correctly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer(); 
            var payment = new NotAcceptedPayment("1","2") {ErrorCode = "failed validation", PaymentSourceId = customer.PartnerId};
            var result = PaymentResultAssembler.AssembleSinglePayment(payment, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.AreEqual(PaymentStatusData.NotAccepted.ToString(), result.Status);
            Assert.IsNotNullOrEmpty(result.ErrorCode);
        }

        [Test]
        public void AssembleSinglePayment_NotFound_Correctly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var result = PaymentResultAssembler.AssembleSinglePayment(null, customer.PartnerId, customer.PartnerAssignedCustomerId);

            Assert.IsNull(result);
        }

        [Test]
        public void Convert_PaymentsResult_Coupled_Correctly()
        {
            var timestamp = DateTime.UtcNow;

            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch {Id = 123, ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId"};


            var payments = new List<PaymentViewModel>
            {
                new PaymentViewModel
                {
                    ExternalId = "PID001",
                    ExternalCustomerId = customerBatch.ExternalCustomerId,
                    PaymentStatus = PaymentStatus.Returned,
                    Reason = "test reason",
                    ReturnCurrency = "USD",
                    ReturnAmount = 10000,
                    CreatedOnUTC = timestamp,
                    UpdatedOnUTC = timestamp,
                    IsFunded = false,
                    CustomerBatchId = 123,
                    PaymentReference = "TestReferece"
                },
                new PaymentViewModel
                {
                    ExternalId = "PID002",
                    ExternalCustomerId = customerBatch.ExternalCustomerId,
                    PaymentStatus = PaymentStatus.Committed,
                    CreatedOnUTC = timestamp.AddMinutes(-5),
                    UpdatedOnUTC = timestamp.AddMinutes(5),
                    IsFunded = true,
                    CustomerBatchId = 123
                },
                new PaymentViewModel
                {
                    ExternalId = "PID003",
                    ExternalCustomerId = customerBatch.ExternalCustomerId,
                    PaymentStatus = PaymentStatus.Committed,
                    CreatedOnUTC = timestamp.AddMinutes(-5),
                    UpdatedOnUTC = timestamp,
                    IsFunded = false,
                    CustomerBatchId = 123
                }
            };

            var paymentIds = new List<string> {"PID001", "PID002", "PID003"};

            var data = PaymentResultAssembler.AssembleMultiplePayments(paymentIds, payments, null);

            Assert.AreEqual(3, data.PaymentItems.Count);

            Assert.AreEqual(payments[0].ExternalId, data.PaymentItems[0].Id);
            Assert.AreEqual(payments[1].ExternalId, data.PaymentItems[1].Id);
            Assert.AreEqual(payments[2].ExternalId, data.PaymentItems[2].Id);

            Assert.AreEqual(PaymentStatusData.Returned.ToString(), data.PaymentItems[0].Status);
            Assert.AreEqual(timestamp.ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[0].CreatedOnUtc);
            Assert.AreEqual(timestamp.ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[0].LastUpdatedOnUtc);
            Assert.AreEqual(payments[0].Reason, data.PaymentItems[0].ErrorCode);
            Assert.AreEqual(payments[0].ReturnCurrency, data.PaymentItems[0].AmountReturnedCurrency);
            Assert.AreEqual(payments[0].ReturnAmount, data.PaymentItems[0].AmountReturned);

            Assert.AreEqual(PaymentStatusData.Processing.ToString(), data.PaymentItems[1].Status);
            Assert.AreEqual(timestamp.AddMinutes(-5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[1].CreatedOnUtc);
            Assert.AreEqual(timestamp.AddMinutes(5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[1].LastUpdatedOnUtc);

            Assert.AreEqual(PaymentStatusData.Processing.ToString(), data.PaymentItems[2].Status);
            Assert.AreEqual(timestamp.AddMinutes(-5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[2].CreatedOnUtc);
            Assert.AreEqual(timestamp.ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[2].LastUpdatedOnUtc);
           
            AssertResult(payments[0], data.PaymentItems[0]);
            Assert.AreEqual(payments[0].PaymentReference, data.PaymentItems[0].PaymentReference);
            AssertResult(payments[1], data.PaymentItems[1]);
            AssertResult(payments[2], data.PaymentItems[2]);
        }

        [Test]
        public void Convert_PaymentsResult_Decoupled_Correctly()
        {
            var timestamp = DateTime.UtcNow;

            var customer = CustomerHelper.Instance.CreateCustomer();
            //var customerBatch = new CustomerBatch { Id = 123, ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };


            var payments = new List<PaymentViewModel>
            {
                new PaymentViewModel
                {
                    ExternalId = "PID001",
                    ExternalCustomerId = customer.PartnerAssignedCustomerId,
                    PaymentStatus = PaymentStatus.Returned,
                    Reason = "test reason",
                    ReturnCurrency = "USD",
                    ReturnAmount = 10000,
                    CreatedOnUTC = timestamp,
                    UpdatedOnUTC = timestamp,
                    IsFunded = false,
                    CustomerBatchId = 123,
                    PaymentReference = "TestReferece"
                },
                new PaymentViewModel
                {
                    ExternalId = "PID002",
                    ExternalCustomerId = customer.PartnerAssignedCustomerId,
                    PaymentStatus = PaymentStatus.Committed,
                    CreatedOnUTC = timestamp.AddMinutes(-5),
                    UpdatedOnUTC = timestamp.AddMinutes(5),
                    IsFunded = true,
                    CustomerBatchId = 123
                },
                new PaymentViewModel
                {
                    ExternalId = "PID003",
                    ExternalCustomerId = customer.PartnerAssignedCustomerId,
                    PaymentStatus = PaymentStatus.Committed,
                    CreatedOnUTC = timestamp.AddMinutes(-5),
                    UpdatedOnUTC = timestamp,
                    IsFunded = false,
                    CustomerBatchId = 123
                }
            };

            var paymentIds = new List<string> { "PID001", "PID002", "PID003" };

            var data = PaymentResultAssembler.AssembleMultiplePayments(paymentIds, payments);

            Assert.AreEqual(3, data.PaymentItems.Count);

            Assert.AreEqual(payments[0].ExternalId, data.PaymentItems[0].Id);
            Assert.AreEqual(payments[1].ExternalId, data.PaymentItems[1].Id);
            Assert.AreEqual(payments[2].ExternalId, data.PaymentItems[2].Id);

            Assert.AreEqual(PaymentStatusData.Returned.ToString(), data.PaymentItems[0].Status);
            Assert.AreEqual(timestamp.ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[0].CreatedOnUtc);
            Assert.AreEqual(timestamp.ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[0].LastUpdatedOnUtc);
            Assert.AreEqual(payments[0].Reason, data.PaymentItems[0].ErrorCode);
            Assert.AreEqual(payments[0].ReturnCurrency, data.PaymentItems[0].AmountReturnedCurrency);
            Assert.AreEqual(payments[0].ReturnAmount, data.PaymentItems[0].AmountReturned);

            Assert.AreEqual(PaymentStatusData.Processing.ToString(), data.PaymentItems[1].Status);
            Assert.AreEqual(timestamp.AddMinutes(-5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[1].CreatedOnUtc);
            Assert.AreEqual(timestamp.AddMinutes(5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[1].LastUpdatedOnUtc);

            Assert.AreEqual(PaymentStatusData.Created.ToString(), data.PaymentItems[2].Status);
            Assert.AreEqual(timestamp.AddMinutes(-5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[2].CreatedOnUtc);
            Assert.AreEqual(timestamp.ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[2].LastUpdatedOnUtc);

            AssertResult(payments[0], data.PaymentItems[0]);
            Assert.AreEqual(payments[0].PaymentReference, data.PaymentItems[0].PaymentReference);
            AssertResult(payments[1], data.PaymentItems[1]);
            AssertResult(payments[2], data.PaymentItems[2]);
        }

        [Test]
        public void ConvertPaymentStatusResult_WithNotAccepted_Correctly()
        {
            var timestamp = DateTime.UtcNow;
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch {Id = 123, ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId"};

            var payments = new List<PaymentViewModel>
            {
                new PaymentViewModel
                {
                    ExternalId = "PID001",
                    ExternalCustomerId = customerBatch.ExternalCustomerId,
                    PaymentStatus = PaymentStatus.Committed,
                    CreatedOnUTC = timestamp.AddMinutes(-5),
                    UpdatedOnUTC = timestamp,
                    IsFunded = false,
                    CustomerBatchId = customerBatch.Id
                },
                new PaymentViewModel
                {
                    ExternalId = "PID002",
                    ExternalCustomerId = customerBatch.ExternalCustomerId,
                    PaymentStatus = PaymentStatus.Committed,
                    CreatedOnUTC = timestamp.AddMinutes(-5),
                    UpdatedOnUTC = timestamp,
                    IsFunded = true,
                    CustomerBatchId = customerBatch.Id
                },
                new PaymentViewModel
                {
                    ExternalId = "PID005",
                    ExternalCustomerId = customerBatch.ExternalCustomerId,
                    PaymentStatus = PaymentStatus.Undefined,
                    PartnerReference = "blahpartnerref1",
                    ErrorCode = "1002",
                    UpdatedOnUTC = timestamp.AddHours(1)
                },
            };

            var paymentIds = new List<string> {"PID001", "PID002", "PID003", "PID004", "PID005"};

            var data = PaymentResultAssembler.AssembleMultiplePayments(paymentIds, payments, null);

            Assert.AreEqual(5, data.PaymentItems.Count);

            Assert.AreEqual(payments[0].ExternalId, data.PaymentItems[0].Id);
            Assert.AreEqual(payments[1].ExternalId, data.PaymentItems[1].Id);
            Assert.AreEqual(payments[2].ExternalId, data.PaymentItems[2].Id);
            Assert.AreEqual("PID004", data.PaymentItems[4].Id);

            Assert.AreEqual(PaymentStatusData.Processing.ToString(), data.PaymentItems[0].Status);
            Assert.AreEqual(timestamp.AddMinutes(-5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[0].CreatedOnUtc);
            Assert.AreEqual(PaymentStatusData.Processing.ToString(), data.PaymentItems[1].Status);
            Assert.AreEqual(timestamp.AddMinutes(-5).ToString("yyyy-MM-ddTHH:mm:ssZ"), data.PaymentItems[1].CreatedOnUtc);
            Assert.AreEqual(PaymentStatusData.NotAccepted.ToString(), data.PaymentItems[2].Status);

            AssertResult(payments[0], data.PaymentItems[0]);
            AssertResult(payments[1], data.PaymentItems[1]);
            Assert.AreEqual((PaymentStatusData.NotAccepted).ToString(), data.PaymentItems[2].Status);
            Assert.AreEqual(((int)ErrorCode.NotAuthorized).ToString(), data.PaymentItems[2].ErrorCode);
            Assert.AreEqual(((int)ErrorCode.ResourceNotFound).ToString(), data.PaymentItems[3].ErrorCode);
            Assert.AreEqual(((int)ErrorCode.ResourceNotFound).ToString(), data.PaymentItems[4].ErrorCode);
        }

        [Test]
        public void AssembleMultiplePayments_ReturnsAllPaymentsIfIdListIsEmpty()
        {
            var payments = new List<PaymentViewModel>
            {
                new PaymentViewModel
                {
                    ExternalId = "PID002",
                    ExternalCustomerId = null,
                    PaymentStatus = PaymentStatus.SanctionCleared,
                    IsFunded = false
                },
                new PaymentViewModel
                {
                    ExternalId = "PID001",
                    ExternalCustomerId = null,
                    PaymentStatus = PaymentStatus.Committed,
                    IsFunded = true
                },
                new PaymentViewModel
                {
                    ExternalId = "PID004",
                    ExternalCustomerId = null,
                    PaymentStatus = PaymentStatus.Committed,
                    IsFunded = false
                },
                new PaymentViewModel
                {
                    ExternalId = "PID003",
                    ExternalCustomerId = null,
                    ErrorCode = "123",
                }
            };

            var paymentIds = new List<string>();
            var data = PaymentResultAssembler.AssembleMultiplePayments(paymentIds, payments, null);

            Assert.AreEqual(4, data.PaymentItems.Count);
        }

        [Test]
        public void AssembleMultiplePayments_ReturnsAllPaymentsIfIdListIsNull()
        {
            var payments = new List<PaymentViewModel>
            {
                new PaymentViewModel
                {
                    ExternalId = "PID002",
                    ExternalCustomerId = null,
                    PaymentStatus = PaymentStatus.SanctionCleared,
                    IsFunded = false
                },
                new PaymentViewModel
                {
                    ExternalId = "PID001",
                    ExternalCustomerId = null,
                    PaymentStatus = PaymentStatus.Committed,
                    IsFunded = true
                },
                new PaymentViewModel
                {
                    ExternalId = "PID004",
                    ExternalCustomerId = null,
                    PaymentStatus = PaymentStatus.Committed,
                    IsFunded = false
                },
                new PaymentViewModel
                {
                    ExternalId = "PID003",
                    ExternalCustomerId = null,
                    ErrorCode = "123",
                }
            };

            var data = PaymentResultAssembler.AssembleMultiplePayments(null, payments,  null);

            Assert.AreEqual(4, data.PaymentItems.Count);
        }

        private void AssertResult(PaymentViewModel payment, PaymentResultData data)
        {
            Assert.AreEqual(data.LastUpdatedOnUtc, payment.UpdatedOnUTC.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"));
            Assert.AreEqual(data.PartnerReference, payment.PartnerReference);

            if (data.Status == PaymentStatusData.NotAccepted.ToString())
            {
                Assert.AreEqual(data.ErrorCode, payment.ErrorCode);
                Assert.AreEqual(data.Id, payment.ExternalId);
            }
        }
        
        private void AssertPayments(Payment expected, SinglePaymentResultData actual)
        {
            Assert.AreEqual(expected.ExternalId, actual.PaymentId);
            Assert.AreEqual(expected.PartnerReference, actual.PartnerReference);
            Assert.AreEqual(expected.CreatedOnUTC.ToString("yyyy-MM-ddTHH:mm:ssZ"), actual.CreatedOnUTC);
            Assert.AreEqual(expected.UpdatedOnUTC.ToString("yyyy-MM-ddTHH:mm:ssZ"), actual.LastUpdatedOn);
            Assert.AreEqual(expected.AmountMoney.NonDecimalAmount, actual.TradeAmount);
            Assert.AreEqual(expected.AmountMoney.Currency.Code, actual.TradeCurrencyCode);
            AssertBeneficiary(expected.Beneficiary, actual.Beneficiary);
            AssertBeneficiaryBank(expected.BankAccount, actual.BankAccount);
            Assert.AreEqual(expected.PurposeOfPayment, actual.PurposeOfPayment);
            Assert.AreEqual(expected.InstructionForBank, actual.InstructionForBank);
            Assert.AreEqual(expected.InstructionCodeForBank, actual.InstructionCodeForBank);
            Assert.AreEqual(expected.PaymentReference,actual.PaymentReference);
            if (expected.RemittanceType == RemittanceType.Undefined)
                Assert.IsNull(actual.RemittanceType);
            else
            {
                Assert.AreEqual(expected.RemittanceType.ToString(), actual.RemittanceType);                
            }

            AssertRemittanceData(expected.RemittanceData, actual.RemittanceData);
            AssertThirdPartyRemitter(expected.ThirdPartyRemitter, actual.ThirdPartyRemitterData);
        }

        private void AssertBeneficiary(Beneficiary expected, PaymentResultBeneficiaryData actual)
        {
            if (expected == null & actual == null) return;
            Assert.AreEqual(expected.ExternalId, actual.Id);
            AssertVersion(expected.VersionedOn, actual.VersionedOn);
            Assert.AreEqual(expected.Identification.EmailAddress, actual.EmailAddress);
            Assert.AreEqual(expected.Identification.EntityType, actual.Type);
            Assert.AreEqual(expected.Identification.FirstName, actual.FirstName);
            Assert.AreEqual(expected.Identification.MiddleName, actual.MiddleName);
            Assert.AreEqual(expected.Identification.LastName, actual.LastName);
            Assert.AreEqual(expected.Identification.PhoneNumber, actual.PhoneNumber);
            Assert.AreEqual(expected.Identification.CellNumber, actual.CellNumber);
            Assert.AreEqual(expected.Identification.DateOfBirth, actual.DateOfBirth);
            Assert.AreEqual(expected.Identification.Gender, actual.Gender);
            Assert.AreEqual(expected.Identification.BusinessName, actual.BusinessName);
            Assert.AreEqual(expected.Identification.BusinessRegistrationNumber, actual.BusinessRegistrationNumber);
            Assert.AreEqual(expected.Identification.BusinessRegistrationCountry, actual.BusinessRegistrationCountry);
            Assert.AreEqual(expected.Identification.BusinessRegistrationStateProv, actual.BusinessRegistrationStateProv);
            Assert.AreEqual(expected.Identification.Industry, actual.Industry);
            AssertAddress(expected.Address, actual.Address);
        }

        private void AssertBeneficiaryBank(BankAccount expected, PaymentResultBeneficiaryBankAccountData actual)
        {
            if (expected == null & actual == null) return;
            Assert.AreEqual(expected.ExternalId, actual.Id);
            AssertVersion(expected.VersionedOn, actual.VersionedOn);
            Assert.AreEqual(expected.AccountNumber, actual.AccountNumber);
            Assert.AreEqual(expected.AccountPurpose, actual.AccountType);
            Assert.AreEqual(expected.BankName, actual.BankName);
            Assert.AreEqual(expected.BranchName, actual.BranchName);
            Assert.AreEqual(expected.BankCode, actual.BankCode);
            Assert.AreEqual(expected.BranchCode, actual.BankBranchCode);
            AssertAddress(expected.BankAddress, actual.BankAddress);
            AssertIntermediaryBank(expected.IntermediaryBankAccount, actual.IntermediaryBank);
        }


        private void AssertIntermediaryBank(IntermediaryBankAccount expected, IntermediaryBankData actual)
        {
            if (expected == null & actual == null) return;
            Assert.AreEqual(expected.BankName, actual.BankName);
            Assert.AreEqual(expected.BankCode, actual.BankCode);
            Assert.AreEqual(expected.AccountNumber, actual.AccountNumber);
            Assert.AreEqual(expected.BankBranchCode, actual.BankBranchCode);
            AssertAddress(expected.BankAddress, actual.Address);
        }

        private void AssertThirdPartyRemitter(ThirdPartyRemitter expected, ThirdPartyRemitterData actual)
        {
            if (expected == null & actual == null) return;
            Assert.AreEqual(expected.Id, actual.Id);
            Assert.AreEqual(expected.VersionedOn, actual.VersionedOn);
            Assert.AreEqual(expected.Type, actual.Type);
            Assert.AreEqual(expected.BusinessName, actual.BusinessName);
            AssertAddress(expected.Address, actual.Address);
            Assert.AreEqual(expected.Email, actual.Email);
            Assert.AreEqual(expected.PhoneNumber, actual.PhoneNumber);
            Assert.AreEqual(expected.IdentificationType, actual.IdentificationType);
            Assert.AreEqual(expected.Identification, actual.Identification);
            Assert.AreEqual(expected.Industry, actual.Industry);
        }

        private void AssertAddress(Address expected, AddressData actual)
        {
            if (expected == null & actual == null) return;
            Assert.AreEqual(expected.AddressLine1, actual.AddressLine1);
            Assert.AreEqual(expected.AddressLine2, actual.AddressLine2);
            Assert.AreEqual(expected.AddressLine3, actual.AddressLine3);
            Assert.AreEqual(expected.City, actual.City);
            Assert.AreEqual(expected.StateOrProvince, actual.StateOrPovince);
            Assert.AreEqual(expected.ZipOrPostalCode, actual.ZipOrPostalCode);
            Assert.AreEqual(expected.CountryCode, actual.CountryCode);
        }

        private void AssertRemittanceData(List<string> expected, List<RemittanceReferenceData> actual)
        {
            if (expected == null & actual == null) return;
            Assert.AreEqual(actual.Select(i => i.Reference).Count(), expected.Count());
            Assert.AreEqual(0, (actual.Select(i => i.Reference).ToList().Except(expected)).Count());
        }

        private void AssertVersion(string expected, string actual)
        {
            DateTime lastUpdatedOn;
            if (DateTime.TryParseExact(expected, "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out lastUpdatedOn))
            {
                Assert.AreEqual(lastUpdatedOn.ToString("u"), actual);
            }

            Assert.AreEqual(expected.ToString(), actual);
        }

        [Test]
        public void AssembleThirdPartyRemitterData_ReturnsNotNull_WhenParentIsNotNullAndChildIsNull()
        {
            var thirdParty = new ThirdPartyRemitter
            {
                Id = "h",
                Address = new Address
                {
                    AddressLine1 = ""
                }
            };
            Assert.IsNotNull(PaymentResultAssembler.AssembleThirdPartyRemitterData(thirdParty));
        }

        [Test]
        public void AssembleThirdPartyRemitterData_ReturnsNotNull_WhenParentIsNullAndChildIsNotNull()
        {
            var thirdParty = new ThirdPartyRemitter
            {
                Id = "",
                Address = new Address
                {
                    AddressLine1 = "123"
                }
            };
            Assert.IsNotNull(PaymentResultAssembler.AssembleThirdPartyRemitterData(thirdParty));
        }

        [Test]
        public void AssembleThirdPartyRemitterData_ReturnsNull_WhenParentAndChildIsNull()
        {
            var thirdParty = new ThirdPartyRemitter
            {
                Id = "",
                Address = new Address
                {
                    AddressLine1 = ""
                }
            };
            Assert.IsNull(PaymentResultAssembler.AssembleThirdPartyRemitterData(thirdParty));
        }

        [Test]
        public void AssembleThirdPartyRemitterData_ReturnsNotNull_WhenParentAndChildIsNotNull()
        {
            var thirdParty = new ThirdPartyRemitter
            {
                Id = "h",
                Address = new Address
                {
                    AddressLine1 = "123"
                }
            };
            Assert.IsNotNull(PaymentResultAssembler.AssembleThirdPartyRemitterData(thirdParty));
        }
    }
}
