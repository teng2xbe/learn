﻿using System;
using System.Collections.Generic;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Services.MassPaymentsService.Assemblers;
using BookIncomingOrderRequest = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrderRequest;
using BookIncomingOrdersRequest = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrdersRequest;
using BookIncomingOrderRequestItem = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrderRequestItem;
using NUnit.Framework;
using BookAggregateOrdersServiceResult = MassPayments.CCTMassPayments.BookIncomingOrdersResult;
using BookAggregateOrderServiceResult = MassPayments.CCTMassPayments.BookIncomingOrderResult;
using BookAggregateLineItemResultServiceResult = MassPayments.CCTMassPayments.LineItemResult;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class OrderBookingAssemblerFixture
    {
        
    }
}
