﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Query.POCOs;
using MassPayments.Query.ValueObjects;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPayments.Services.MassPaymentsService.Exceptions;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;
using NUnit.Framework;
using Address = MassPayments.Domain.Entities.PaymentRequest.Address;
using BankAccount = MassPayments.Domain.Entities.PaymentRequest.BankAccount;
using Beneficiary = MassPayments.Domain.Entities.PaymentRequest.Beneficiary;
using ThirdPartyRemitter = MassPayments.Domain.Entities.PaymentRequest.ThirdPartyRemitter;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class PaymentRequestAssemblerFixture
    {
        [Test]
        public void AssembleCommitPaymentsRequest_Correctly()
        {
            var request = new CommitPaymentsRequestData
            {
                PaymentsToProcess = new List<UnbatchedPaymentData> { CreatePaymentData("2"), CreatePaymentData("3")  }
            };
            
            var result = PaymentRequestAssembler.AssembleCommitPaymentsRequest(request);

            AssertPayment(request.PaymentsToProcess[0], result.PaymentsToProcess[0]);
            AssertPayment(request.PaymentsToProcess[1], result.PaymentsToProcess[1]);
            Assert.AreEqual(0, result.PaymentsToProcess[0].ItemIndex);
            Assert.AreEqual(1, result.PaymentsToProcess[1].ItemIndex);
        }

        [Test]
        public void AssembleCommitPaymentsRequest_WorksCorrectlyForBatchedPayments()
        {
            var customerId = "1234";
            var request = new CommitBatchPaymentsRequestData
            {
                Payments = new List<BatchedPaymentData> { CreateBatchedPaymentData("2"), CreateBatchedPaymentData("3")  }
            };
            
            var result = PaymentRequestAssembler.AssembleCommitPaymentsRequest(request, customerId);

            AssertPayment(request.Payments[0], result.PaymentsToProcess[0]);
            AssertPayment(request.Payments[1], result.PaymentsToProcess[1]);
            Assert.AreEqual(0, result.PaymentsToProcess[0].ItemIndex);
            Assert.AreEqual(1, result.PaymentsToProcess[1].ItemIndex);

        }

        [Test]
        public void AssembleCommitPaymentsRequest_Correctly_WithThirdPartyRemitter()
        {
            var request = new CommitPaymentsRequestData
            {
                PaymentsToProcess = new List<UnbatchedPaymentData> { CreatePaymentData("2"), CreatePaymentData("3") }
            };

            request.PaymentsToProcess[1].ThirdPartyRemitterData = CreateThirdPartyRemitterData();
            var result = PaymentRequestAssembler.AssembleCommitPaymentsRequest(request);

            AssertPayment(request.PaymentsToProcess[0], result.PaymentsToProcess[0]);
            AssertPayment(request.PaymentsToProcess[1], result.PaymentsToProcess[1]);
            Assert.AreEqual(0, result.PaymentsToProcess[0].ItemIndex);
            Assert.AreEqual(1, result.PaymentsToProcess[1].ItemIndex);
        }

        [Test]
        public void AssembleCommitPaymentsRequest_Correctly_WithEmptyThirdPartyRemitterFields()
        {
            var request = new CommitPaymentsRequestData
            {
                PaymentsToProcess = new List<UnbatchedPaymentData> { CreatePaymentData("2"), CreatePaymentData("3") }
            };

            var emptyRemitter = new ThirdPartyRemitterData
            {
                Id = "",
                Type = "",
                BusinessName = "",
                Address = new AddressData
                {
                    AddressLine1 = "",
                    AddressLine2 = "",
                    AddressLine3 = "",
                    City = "",
                    CountryCode = "",
                    StateOrPovince = "",
                    ZipOrPostalCode = ""
                },
                PhoneNumber = "",
                Email = "",
                IdentificationType = "",
                Identification = "",
                Industry = ""
            };

            request.PaymentsToProcess[1].ThirdPartyRemitterData = emptyRemitter;
            var result = PaymentRequestAssembler.AssembleCommitPaymentsRequest(request);

            AssertThirdPartyRemitter(null, result.PaymentsToProcess[0].ThirdPartyRemitter);
        }
        
        [Test]
        public void AssembleSortBy_WorksAsItShouldForCorrectInput()
        {
            var sortByText = "ColumnName,asc";

            var sortBy = PaymentRequestAssembler.AssembleSortBy(sortByText);

            Assert.AreEqual("ColumnName", sortBy.SortField);
            Assert.AreEqual(SortDirection.ASC, sortBy.Direction);
        }

        [Test]
        public void AssembleSortBy_SetsDescIfDescSpecified()
        {
            var sortByText = "ColumnName,desc";

            var sortBy = PaymentRequestAssembler.AssembleSortBy(sortByText);

            Assert.AreEqual("ColumnName", sortBy.SortField);
            Assert.AreEqual(SortDirection.DESC, sortBy.Direction);
        }

        [Test]
        public void AssembleSortBy_SetsAscIfDirectionIsMissing()
        {
            var sortByText = "ColumnName";

            var sortBy = PaymentRequestAssembler.AssembleSortBy(sortByText);

            Assert.AreEqual("ColumnName", sortBy.SortField);
            Assert.AreEqual(SortDirection.ASC, sortBy.Direction);
        }

        [Test]
        public void AssembleSortBy_SetsDefaultSortingForEmptyInput()
        {
            var sortByText = "";

            var sortBy = PaymentRequestAssembler.AssembleSortBy(sortByText);

            Assert.AreEqual("CreatedOnUTC", sortBy.SortField);
            Assert.AreEqual(SortDirection.DESC, sortBy.Direction);
        }

        [Test]
        public void AssembleSortBy_ThrowsExceptionWhenTooManyColumnsSpecified()
        {
            var sortByText = "ColumnName1,ColumnName2,desc";

            Assert.Throws<InvalidSortExpressionException>(() => PaymentRequestAssembler.AssembleSortBy(sortByText));
        }

        [Test]
        public void AssembleSortBy_ThrowsExceptionWhenDirectionIsInvalid()
        {
            var sortByText = "ColumnName,banana";

            Assert.Throws<InvalidSortExpressionException>(() => PaymentRequestAssembler.AssembleSortBy(sortByText));
        }

        private void AssertPayment(UnbatchedPaymentData paymentData, PaymentRequest paymentRequest)
        {
            Assert.AreEqual(paymentData.PartnerAssignedCustomerId, paymentRequest.PartnerAssignedCustomerId);
            Assert.AreEqual(paymentData.PartnerReference, paymentRequest.PartnerReference);
            Assert.AreEqual(paymentData.PaymentMethod, paymentRequest.PaymentMethod);
            Assert.AreEqual(paymentData.PaymentId, paymentRequest.PaymentId);
            Assert.AreEqual(paymentData.TradeAmount, paymentRequest.FixedAmount);
            Assert.AreEqual(paymentData.TradeCurrencyCode, paymentRequest.CurrencyCode);
            Assert.AreEqual(paymentData.PurposeOfPayment, paymentRequest.PurposeOfPayment);
            Assert.AreEqual(paymentData.InstructionForBank, paymentRequest.InstructionForBank);
            Assert.AreEqual(paymentData.InstructionCodeForBank, paymentRequest.InstructionCodeForBank);

            AssertBeneficiary(paymentData.Beneficiary, paymentRequest.Beneficiary);
            AssertBankAccount(paymentData.BankAccount, paymentRequest.BankAccount);
            AssertRemittanceReferences(paymentData.RemittanceData, paymentRequest.RemittanceData);
            AssertThirdPartyRemitter(paymentData.ThirdPartyRemitterData, paymentRequest.ThirdPartyRemitter);
        }

        private void AssertPayment(BatchedPaymentData paymentData, PaymentRequest paymentRequest)
        {
            Assert.AreEqual(paymentData.PartnerReference, paymentRequest.PartnerReference);
            Assert.AreEqual(paymentData.PaymentMethod, paymentRequest.PaymentMethod);
            Assert.AreEqual(paymentData.PaymentId, paymentRequest.PaymentId);
            Assert.AreEqual(paymentData.TradeAmount, paymentRequest.FixedAmount);
            Assert.AreEqual(paymentData.TradeCurrencyCode, paymentRequest.CurrencyCode);
            Assert.AreEqual(paymentData.PurposeOfPayment, paymentRequest.PurposeOfPayment);
            Assert.AreEqual(paymentData.InstructionForBank, paymentRequest.InstructionForBank);
            Assert.AreEqual(paymentData.InstructionCodeForBank, paymentRequest.InstructionCodeForBank);

            AssertBeneficiary(paymentData.Beneficiary, paymentRequest.Beneficiary);
            AssertBankAccount(paymentData.BankAccount, paymentRequest.BankAccount);
            AssertRemittanceReferences(paymentData.RemittanceData, paymentRequest.RemittanceData);
            AssertThirdPartyRemitter(paymentData.ThirdPartyRemitterData, paymentRequest.ThirdPartyRemitter);
        }

        private void AssertBeneficiary(BeneficiaryData beneficiaryData, Beneficiary beneficiary)
        {
            Assert.AreEqual(beneficiaryData.Id, beneficiary.Id);
            Assert.AreEqual(beneficiaryData.EmailAddress, beneficiary.EmailAddress);
            Assert.AreEqual(beneficiaryData.Type, beneficiary.Type);
            Assert.AreEqual(beneficiaryData.FirstName, beneficiary.FirstName);
            Assert.AreEqual(beneficiaryData.MiddleName, beneficiary.MiddleName);
            Assert.AreEqual(beneficiaryData.LastName, beneficiary.LastName);
            Assert.AreEqual(beneficiaryData.PhoneNumber, beneficiary.PhoneNumber);
            Assert.AreEqual(beneficiaryData.CellNumber, beneficiary.CellNumber);
            Assert.AreEqual(beneficiaryData.DateOfBirth, beneficiary.DateOfBirth);
            Assert.AreEqual(beneficiaryData.Gender, beneficiary.Gender);
            Assert.AreEqual(beneficiaryData.BusinessName, beneficiary.BusinessName);
            Assert.AreEqual(beneficiaryData.BusinessRegistrationNumber, beneficiary.BusinessRegistrationNumber);
            Assert.AreEqual(beneficiaryData.BusinessRegistrationCountry, beneficiary.BusinessRegistrationCountry);
            Assert.AreEqual(beneficiaryData.BusinessRegistrationStateProv, beneficiary.BusinessRegistrationStateProv);
            Assert.AreEqual(beneficiaryData.Industry, beneficiary.Industry);
            AssertAddress(beneficiaryData.Address, beneficiary.Address);
        }

        private void AssertBankAccount(BeneficiaryBankAccountData bankAccountData, BankAccount bankAccount)
        {
            Assert.AreEqual(bankAccountData.Id, bankAccount.Id);
            Assert.AreEqual(bankAccountData.VersionedOn, bankAccount.VersionedOn);
            Assert.AreEqual(bankAccountData.AccountNumber, bankAccount.AccountNumber);
            Assert.AreEqual(bankAccountData.AccountType, bankAccount.AccountType);
            Assert.AreEqual(bankAccountData.BankName, bankAccount.BankName);
            Assert.AreEqual(bankAccountData.BranchName, bankAccount.BranchName);
            Assert.AreEqual(bankAccountData.BankCode, bankAccount.BankCode);
            Assert.AreEqual(bankAccountData.BankBranchCode, bankAccount.BankBranchCode);
            AssertAddress(bankAccountData.BankAddress, bankAccount.BankAddress);
            AssertIntermediaryBank(bankAccountData.IntermediaryBank, bankAccount.IntermediaryBank);
        }

        private void AssertAddress(AddressData addressData, Address address)
        {
            Assert.AreEqual(addressData.AddressLine1, address.AddressLine1);
            Assert.AreEqual(addressData.AddressLine2, address.AddressLine2);
            Assert.AreEqual(addressData.AddressLine3, address.AddressLine3);
            Assert.AreEqual(addressData.City, address.City);
            Assert.AreEqual(addressData.StateOrPovince, address.StateOrPovince);
            Assert.AreEqual(addressData.ZipOrPostalCode, address.ZipOrPostalCode);
            Assert.AreEqual(addressData.CountryCode, address.CountryCode);
        }

        private void AssertIntermediaryBank(IntermediaryBankData intermediaryBankData, IntermediaryBank intermediaryBank)
        {
            Assert.AreEqual(intermediaryBankData.BankName, intermediaryBank.BankName);
            Assert.AreEqual(intermediaryBankData.BankCode, intermediaryBank.BankCode);
            Assert.AreEqual(intermediaryBankData.AccountNumber, intermediaryBank.AccountNumber);
            Assert.AreEqual(intermediaryBankData.BankBranchCode, intermediaryBank.BankBranchCode);
            AssertAddress(intermediaryBankData.Address, intermediaryBank.Address);
        }

        private void AssertThirdPartyRemitter(ThirdPartyRemitterData thirdPartyRemitterData, ThirdPartyRemitter thirdPartyRemitter)
        {
            if (thirdPartyRemitterData == null & thirdPartyRemitter == null) return;

            Assert.AreEqual(thirdPartyRemitterData.Id, thirdPartyRemitter.Id);
            Assert.AreEqual(thirdPartyRemitterData.VersionedOn, thirdPartyRemitter.VersionedOn);
            Assert.AreEqual(thirdPartyRemitterData.Type, thirdPartyRemitter.Type);
            Assert.AreEqual(thirdPartyRemitterData.BusinessName, thirdPartyRemitter.BusinessName);
            AssertAddress(thirdPartyRemitterData.Address, thirdPartyRemitter.Address);
            Assert.AreEqual(thirdPartyRemitterData.PhoneNumber, thirdPartyRemitter.PhoneNumber);
            Assert.AreEqual(thirdPartyRemitterData.Email, thirdPartyRemitter.Email);
            Assert.AreEqual(thirdPartyRemitterData.IdentificationType, thirdPartyRemitter.IdentificationType);
            Assert.AreEqual(thirdPartyRemitterData.Identification, thirdPartyRemitter.Identification);
            Assert.AreEqual(thirdPartyRemitterData.Industry, thirdPartyRemitter.Industry);
        }

        private void AssertRemittanceReferences(List<RemittanceReferenceData> referencesData, List<RemittanceReference> references)
        {
            if (referencesData == null & references == null) return;
            for (var i = 0; i < references.Count; i++)
            {
                AssertRemittanceReference(referencesData[i], references[i]);    
            }
        }

        private void AssertRemittanceReference(RemittanceReferenceData referenceData, RemittanceReference reference)
        {
            if ((referenceData != null) && (reference != null))
                Assert.AreEqual(referenceData.Reference, reference.Reference);
        }

        private UnbatchedPaymentData CreatePaymentData(string externalPaymentId)
        {
            return new UnbatchedPaymentData
            {
                BankAccount = CreateBankAccountData("1"),
                Beneficiary = CreateBeneficiaryData("1"),
                PartnerAssignedCustomerId = "123",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "pymt mtd",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                TradeAmount = 10,
                TradeCurrencyCode = "CAD",
                RemittanceData = new List<RemittanceReferenceData>
                {
                    new RemittanceReferenceData {Reference = "ref1"},
                    new RemittanceReferenceData {Reference = "ref2"}
                }
            };
        }

        private BatchedPaymentData CreateBatchedPaymentData(string externalPaymentId)
        {
            return new BatchedPaymentData
            {
                BankAccount = CreateBankAccountData("1"),
                Beneficiary = CreateBeneficiaryData("1"),
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "pymt mtd",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                TradeAmount = 10,
                TradeCurrencyCode = "CAD",
                RemittanceData = new List<RemittanceReferenceData>
                {
                    new RemittanceReferenceData {Reference = "ref1"},
                    new RemittanceReferenceData {Reference = "ref2"}
                }
            };
        }

        private BeneficiaryBankAccountData CreateBankAccountData(string id)
        {
            return new BeneficiaryBankAccountData
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddressData(),
                BankBranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                IntermediaryBank = CreateIntermediaryBankData(),
                VersionedOn = DateTime.UtcNow.ToString("u")
            };
        }

        private AddressData CreateAddressData()
        {
            return new AddressData
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

        private IntermediaryBankData CreateIntermediaryBankData()
        {
            return new IntermediaryBankData
            {
                AccountNumber = "acct no",
                Address = CreateAddressData(),
                BankCode = "bnk code",
                BankName = "bnk name",
                BankBranchCode = "1234"
            };
        }

        private ThirdPartyRemitterData CreateThirdPartyRemitterData()
        {
            return new ThirdPartyRemitterData
            {
                Id = "myid",
                Type = "corporation",
                BusinessName = "mybusname",
                Address = CreateAddressData(),
                PhoneNumber = "some phone",
                Email = "some email",
                IdentificationType = "bus reg no",
                Identification = "bleh",
                Industry = "fi",
                VersionedOn = DateTime.UtcNow.ToString("u")
            };
        }

        private BeneficiaryData CreateBeneficiaryData(string id)
        {
            return new BeneficiaryData
            {
                Id = id,
                Address = CreateAddressData(),
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                PhoneNumber = "123",
                Type = "I/B",
                VersionedOn = DateTime.UtcNow.ToString("u")
            };
        }
    }
}
