﻿using System;
using MassPayments.CCTEntityManagement;
using MassPayments.Domain.ValueObjects;
using MassPayments.Services.MassPaymentsService.Assemblers;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class BankAccountAssemblerFixture
    {
        [Test]
        public void ConvertBankAccountResult_ReturnsCorrectData()
        {
            var bankAccountInfo = new BankAccountInfo
            {
                Id = "888",
                AccountNumber = "111",
                AccountType = "Savings",
                AddressLine1 = "address line 1",
                AddressLine2 = "address line 2",
                BankName = "a bank name",
                City = "a city",
                AccountHolderName = "a client name",
                CountryCode = "Canada",
                CurrencyCode = "CAD",
                IsDirectDebit = true,
                LastUpdatedOn = new DateTime(2015, 2, 22).ToLocalTime(),
                ZipOrPostalCode = "a postal code",
                RoutingCode = "222",
                SwiftCode = "33334444",
                Status = BankAccountStatus.Active.ToString()
            };

            var clientBankAccountData = BankAccountAssembler.AssembleBankAccountData(bankAccountInfo);

            Assert.AreEqual("888", clientBankAccountData.Id);
            Assert.AreEqual("111", clientBankAccountData.AccountNumber);
            Assert.AreEqual("Savings", clientBankAccountData.AccountType);
            Assert.AreEqual("address line 1", clientBankAccountData.BankAddress.AddressLine1);
            Assert.AreEqual("address line 2", clientBankAccountData.BankAddress.AddressLine2);
            Assert.AreEqual("a bank name", clientBankAccountData.BankName);
            Assert.AreEqual("a city", clientBankAccountData.BankAddress.City);
            Assert.AreEqual("a client name", clientBankAccountData.AccountHolderName);
            Assert.AreEqual("Canada", clientBankAccountData.BankAddress.CountryCode);
            Assert.AreEqual("CAD", clientBankAccountData.CurrencyCode);
            Assert.AreEqual(true, clientBankAccountData.IsDirectDebit);
            Assert.AreEqual("2015-02-22T00:00:00Z", clientBankAccountData.LastUpdatedOn);
            Assert.AreEqual("a postal code", clientBankAccountData.BankAddress.ZipOrPostalCode);
            Assert.AreEqual("222", clientBankAccountData.RoutingCode);
            Assert.AreEqual("33334444", clientBankAccountData.SwiftCode);
            Assert.AreEqual("Active", clientBankAccountData.Status);
        }
    }
}
