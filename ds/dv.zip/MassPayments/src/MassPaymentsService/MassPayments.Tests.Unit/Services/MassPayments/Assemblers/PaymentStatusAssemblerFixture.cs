﻿using MassPayments.Domain.Enums;
using MassPayments.Query.ValueObjects;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPayments.Services.MassPaymentsService.Exceptions;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class PaymentStatusAssemblerFixture
    {
        [Test]
        public void GetDecoupledPaymentStatusFilters_ReturnsCorrectPaymentStatusFilters()
        {
            var cancelledFilters = PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("Cancelled");
            Assert.AreEqual(2, cancelledFilters.Count);
            Assert.AreEqual(PaymentStatus.Cancelled, cancelledFilters[0].PaymentStatus);
            Assert.AreEqual(true, cancelledFilters[0].IsFunded);
            Assert.AreEqual(PaymentStatus.Cancelled, cancelledFilters[1].PaymentStatus);
            Assert.AreEqual(false, cancelledFilters[1].IsFunded);

            var processingFilters = PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("Processing");
            Assert.AreEqual(5, processingFilters.Count);
            Assert.AreEqual(PaymentStatus.Committed, processingFilters[0].PaymentStatus);
            Assert.AreEqual(true, processingFilters[0].IsFunded);
            Assert.AreEqual(PaymentStatus.Sent, processingFilters[1].PaymentStatus);
            Assert.AreEqual(true, processingFilters[1].IsFunded);
            Assert.AreEqual(PaymentStatus.Sent, processingFilters[2].PaymentStatus);
            Assert.AreEqual(false, processingFilters[2].IsFunded);
            Assert.AreEqual(PaymentStatus.SanctionBlocked, processingFilters[3].PaymentStatus);
            Assert.AreEqual(true, processingFilters[3].IsFunded);
            Assert.AreEqual(PaymentStatus.SanctionBlocked, processingFilters[4].PaymentStatus);
            Assert.AreEqual(false, processingFilters[4].IsFunded);

            var releasedFilters = PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("Released");
            Assert.AreEqual(2, releasedFilters.Count);
            Assert.AreEqual(PaymentStatus.Released, releasedFilters[0].PaymentStatus);
            Assert.AreEqual(true, releasedFilters[0].IsFunded);
            Assert.AreEqual(PaymentStatus.Released, releasedFilters[1].PaymentStatus);
            Assert.AreEqual(false, releasedFilters[1].IsFunded);

            var rejectedFilters = PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("Rejected");
            Assert.AreEqual(2, rejectedFilters.Count);
            Assert.AreEqual(PaymentStatus.Rejected, rejectedFilters[0].PaymentStatus);
            Assert.AreEqual(true, rejectedFilters[0].IsFunded);
            Assert.AreEqual(PaymentStatus.Rejected, rejectedFilters[1].PaymentStatus);
            Assert.AreEqual(false, rejectedFilters[1].IsFunded);

            var returnedFilters = PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("Returned");
            Assert.AreEqual(2, returnedFilters.Count);
            Assert.AreEqual(PaymentStatus.Returned, returnedFilters[0].PaymentStatus);
            Assert.AreEqual(true, returnedFilters[0].IsFunded);
            Assert.AreEqual(PaymentStatus.Returned, returnedFilters[1].PaymentStatus);
            Assert.AreEqual(false, returnedFilters[1].IsFunded);

            var createdFilters = PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("Created");
            Assert.AreEqual(3, createdFilters.Count);
            Assert.AreEqual(PaymentStatus.Committed, createdFilters[0].PaymentStatus);
            Assert.AreEqual(false, createdFilters[0].IsFunded);
            Assert.AreEqual(PaymentStatus.SanctionCleared, createdFilters[1].PaymentStatus);
            Assert.AreEqual(true, createdFilters[1].IsFunded);
            Assert.AreEqual(PaymentStatus.SanctionCleared, createdFilters[2].PaymentStatus);
            Assert.AreEqual(false, createdFilters[2].IsFunded);

            var notAcceptedFilters = PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("NotAccepted");
            Assert.AreEqual(2, notAcceptedFilters.Count);
            Assert.AreEqual(PaymentStatus.Undefined, notAcceptedFilters[0].PaymentStatus);
            Assert.AreEqual(true, notAcceptedFilters[0].IsFunded);
            Assert.AreEqual(PaymentStatus.Undefined, notAcceptedFilters[1].PaymentStatus);
            Assert.AreEqual(false, notAcceptedFilters[1].IsFunded);
        }

        [Test]
        public void GetCoupledPaymentStatusFilters_ReturnsCorrectPaymentStatusFilters()
        {
            var cancelledFilters = PaymentStatusAssembler.GetCoupledPaymentStatusFilters("Cancelled");
            Assert.AreEqual(1, cancelledFilters.Count);
            Assert.AreEqual(PaymentStatus.Cancelled, cancelledFilters[0].PaymentStatus);

            var processingFilters = PaymentStatusAssembler.GetCoupledPaymentStatusFilters("Processing");
            Assert.AreEqual(4, processingFilters.Count);
            Assert.AreEqual(PaymentStatus.Committed, processingFilters[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Sent, processingFilters[1].PaymentStatus);
            Assert.AreEqual(PaymentStatus.SanctionBlocked, processingFilters[2].PaymentStatus);
            Assert.AreEqual(PaymentStatus.SanctionCleared, processingFilters[3].PaymentStatus);

            var releasedFilters = PaymentStatusAssembler.GetCoupledPaymentStatusFilters("Released");
            Assert.AreEqual(1, releasedFilters.Count);
            Assert.AreEqual(PaymentStatus.Released, releasedFilters[0].PaymentStatus);

            var rejectedFilters = PaymentStatusAssembler.GetCoupledPaymentStatusFilters("Rejected");
            Assert.AreEqual(1, rejectedFilters.Count);
            Assert.AreEqual(PaymentStatus.Rejected, rejectedFilters[0].PaymentStatus);

            var returnedFilters = PaymentStatusAssembler.GetCoupledPaymentStatusFilters("Returned");
            Assert.AreEqual(1, returnedFilters.Count);
            Assert.AreEqual(PaymentStatus.Returned, returnedFilters[0].PaymentStatus);

            var createdFilters = PaymentStatusAssembler.GetCoupledPaymentStatusFilters("Created");
            Assert.AreEqual(1, createdFilters.Count);
            Assert.AreEqual(PaymentStatus.Created, createdFilters[0].PaymentStatus);

            var notAcceptedFilters = PaymentStatusAssembler.GetCoupledPaymentStatusFilters("NotAccepted");
            Assert.AreEqual(1, notAcceptedFilters.Count);
            Assert.AreEqual(PaymentStatus.Undefined, notAcceptedFilters[0].PaymentStatus);
        }

        [Test]
        public void GetDecoupledPaymentStatusData_ReturnsCorrectPaymentStatusData()
        {
            Assert.AreEqual(PaymentStatusData.Cancelled, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.Cancelled}));
            Assert.AreEqual(PaymentStatusData.Cancelled, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.Cancelled}));

            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.Committed}));
            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.Sent}));
            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.Sent}));
            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.SanctionBlocked}));
            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.SanctionBlocked}));

            Assert.AreEqual(PaymentStatusData.Released, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.Released}));
            Assert.AreEqual(PaymentStatusData.Released, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.Released}));

            Assert.AreEqual(PaymentStatusData.Rejected, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.Rejected}));
            Assert.AreEqual(PaymentStatusData.Rejected, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.Rejected}));

            Assert.AreEqual(PaymentStatusData.Created, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.Committed}));
            Assert.AreEqual(PaymentStatusData.Created, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.SanctionCleared}));
            Assert.AreEqual(PaymentStatusData.Created, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.SanctionCleared}));

            Assert.AreEqual(PaymentStatusData.NotAccepted, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = true, PaymentStatus = PaymentStatus.Undefined}));
            Assert.AreEqual(PaymentStatusData.NotAccepted, PaymentStatusAssembler.GetDecoupledPaymentStatusData(
                new DecoupledPaymentStatusFilter {IsFunded = false, PaymentStatus = PaymentStatus.Undefined}));
        }

        [Test]
        public void GetCoupledPaymentStatusData_ReturnsCorrectPaymentStatusData()
        {
            Assert.AreEqual(PaymentStatusData.Cancelled, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter { PaymentStatus = PaymentStatus.Cancelled }, false));

            Assert.AreEqual(PaymentStatusData.Cancelled, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Cancelled}, true));

            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Committed}, false));
            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Sent}, false));
            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.SanctionBlocked}, false));
            Assert.AreEqual(PaymentStatusData.Processing, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.SanctionCleared}, false));

            Assert.AreEqual(PaymentStatusData.Released, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Released}, false));

            Assert.AreEqual(PaymentStatusData.Rejected, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Rejected}, false));

            Assert.AreEqual(PaymentStatusData.Created, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Created}, false));

            Assert.AreEqual(PaymentStatusData.NotAccepted, PaymentStatusAssembler.GetCoupledPaymentStatusData(
                new CoupledPaymentStatusFilter {PaymentStatus = PaymentStatus.Undefined}, false));

            Assert.AreEqual(PaymentStatusData.Created, PaymentStatusAssembler.GetCoupledPaymentStatusData(null, true));
        }

        [Test]
        public void GetDecoupledPaymentStatusFilters_ThrowsExceptionForInvalidPaymentStatus()
        {
            Assert.Throws<InvalidPaymentStatusFilterException>(() => PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("garbage"));
            Assert.Throws<InvalidPaymentStatusFilterException>(() => PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("Funded"));
            Assert.Throws<InvalidPaymentStatusFilterException>(() => PaymentStatusAssembler.GetDecoupledPaymentStatusFilters("NotFound"));
        }

        [Test]
        public void GetCoupledPaymentStatusFilters_ThrowsExceptionForInvalidPaymentStatus()
        {
            Assert.Throws<InvalidPaymentStatusFilterException>(() => PaymentStatusAssembler.GetCoupledPaymentStatusFilters("garbage"));
            Assert.Throws<InvalidPaymentStatusFilterException>(() => PaymentStatusAssembler.GetCoupledPaymentStatusFilters("Funded"));
            Assert.Throws<InvalidPaymentStatusFilterException>(() => PaymentStatusAssembler.GetCoupledPaymentStatusFilters("NotFound"));
        }
    }
}
