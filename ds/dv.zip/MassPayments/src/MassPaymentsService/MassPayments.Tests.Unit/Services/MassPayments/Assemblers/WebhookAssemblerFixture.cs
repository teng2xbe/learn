﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPaymentsCommon.WCFContracts.RESTContracts.subscriptions;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class WebhookAssemblerFixture
    {
        [Test]
        public void ConvertWebhookToResult_Works()
        {
            var now = DateTime.UtcNow;
            var webhook = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = true,
                UpdatedOnUtc = now,
                CreatedOnUtc = now,
                Uri = "http://a.url",
                SecurityToken = "BlahToken",
                LastPushedEvent = new WebhookPushedEvent
                {
                    Status = "Failed",
                    EventType = "ping",
                    PushedOnUtc = now
                }
            };

            var result = WebhookAssembler.Convert(webhook);
            Assert.AreEqual(typeof(GetWebhookResultData), result.GetType());
            Assert.AreEqual(webhook.Id.ToString().ToUpper(), result.Id);
            Assert.AreEqual(webhook.IsPrimary, result.IsPrimary);
            Assert.AreEqual(webhook.UpdatedOnUtc.ToShortDateString(), result.UpdatedOnUtc.ToShortDateString());
            Assert.AreEqual(webhook.CreatedOnUtc.ToShortDateString(), result.CreatedOnUtc.ToShortDateString());
            Assert.AreEqual(webhook.Uri, result.Uri);
            Assert.AreEqual(webhook.LastPushedEvent.EventType, result.LastPushedEvent.EventType);
            Assert.AreEqual(webhook.LastPushedEvent.Status, result.LastPushedEvent.Status);
            Assert.AreEqual(webhook.LastPushedEvent.PushedOnUtc.ToShortDateString(), result.LastPushedEvent.PushedOnUtc.ToShortDateString());
        }
        [Test]
        public void ConvertWebhooksToResults_Works()
        {
            var now = DateTime.UtcNow;
            var webhooks = new List<Webhook>
            {
                new Webhook
                {
                    Id = Guid.NewGuid(),
                    IsPrimary = true,
                    UpdatedOnUtc = now,
                    CreatedOnUtc = now,
                    Uri = "http://a.url",
                    SecurityToken = "BlahToken",
                    LastPushedEvent = new WebhookPushedEvent
                    {
                        Status = "Failed",
                        EventType = "ping",
                        PushedOnUtc = now
                    }
                }
            };

            var result = WebhookAssembler.Convert(webhooks);
            Assert.AreEqual(typeof(GetWebhooksResultData), result.GetType());
            Assert.AreEqual(webhooks[0].Id.ToString().ToUpper(), result.Webhooks[0].Id);
            Assert.AreEqual(webhooks[0].IsPrimary, result.Webhooks[0].IsPrimary);
            Assert.AreEqual(webhooks[0].UpdatedOnUtc.ToShortDateString(), result.Webhooks[0].UpdatedOnUtc.ToShortDateString());
            Assert.AreEqual(webhooks[0].CreatedOnUtc.ToShortDateString(), result.Webhooks[0].CreatedOnUtc.ToShortDateString());
            Assert.AreEqual(webhooks[0].Uri, result.Webhooks[0].Uri);
            Assert.AreEqual(webhooks[0].LastPushedEvent.EventType, result.Webhooks[0].LastPushedEvent.EventType);
            Assert.AreEqual(webhooks[0].LastPushedEvent.Status, result.Webhooks[0].LastPushedEvent.Status);
            Assert.AreEqual(webhooks[0].LastPushedEvent.PushedOnUtc.ToShortDateString(), result.Webhooks[0].LastPushedEvent.PushedOnUtc.ToShortDateString());
        }

        [Test]
        public void ConvertGuidToResponse_Works()
        {
            var guid = new Guid();

            var result = WebhookAssembler.ConvertGuidToResponse(guid);

            Assert.AreEqual(guid.ToString(), result.Id);
        }

        [Test]
        public void CreateWebhook_CreatesAWebhook()
        {
            var request = new AddWebhookRequestData
            {
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };

            var partner = new Partner
            {
                Id = 123,
                SecurityToken = "aToken"
            };

            var webhook = WebhookAssembler.CreateWebhook(request, partner);

            Assert.AreEqual(true, webhook.IsPrimary);
            Assert.AreEqual("https://gorilla.com", webhook.Uri);
            Assert.AreEqual(partner.SecurityToken, webhook.SecurityToken);
        }

        [Test]
        public void CreateWebhookForUpdate_CreatesAWebhook()
        {
            var id = Guid.NewGuid();
            var request = new UpdateWebhookRequestData
            {
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };

            var partner = new Partner
            {
                Id = 123,
                SecurityToken = "aToken"
            };

            var webhook = WebhookAssembler.CreateWebhookForUpdate(id, request, partner);

            Assert.AreEqual(true, webhook.IsPrimary);
            Assert.AreEqual("https://gorilla.com", webhook.Uri);
            Assert.AreEqual(partner.SecurityToken, webhook.SecurityToken);
            Assert.AreEqual(id, webhook.Id);
        }

        [Test]
        public void CreateWebhookForDelete_CreatesAWebhook()
        {
            var id = Guid.NewGuid();
            var webhook = WebhookAssembler.CreateWebhookForDelete(id, new Partner());

            Assert.AreEqual(id, webhook.Id);
        }
    }
}
