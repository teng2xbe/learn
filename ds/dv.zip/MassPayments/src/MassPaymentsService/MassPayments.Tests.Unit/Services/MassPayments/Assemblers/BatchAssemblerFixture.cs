﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Services.MassPaymentsService.Assemblers;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class BatchAssemblerFixture
    {
        [Test]
        public void ConvertToBatchResult_ReturnCreatedFlagTrue()
        {
            var batchCreated = new CustomerBatch
            {
                ExternalId = "dogs",
                CreatedOnUTC = DateTime.UtcNow,
                UpdatedOnUTC = DateTime.UtcNow
            };

            var batchResult = BatchAssembler.ConvertToBatchResult(batchCreated);

            Assert.AreEqual(true,batchResult.Created);
            Assert.AreEqual("dogs", batchResult.ExternalBatchId);

        }

        [Test]
        public void ConvertToBatchResult_ReturnCreatedFlagFalse()
        {
            var batchCreated = new CustomerBatch
            {
                ExternalId = "dogs",
                CreatedOnUTC = DateTime.UtcNow,
                UpdatedOnUTC = DateTime.UtcNow.AddMilliseconds(20)
            };

            var batchResult = BatchAssembler.ConvertToBatchResult(batchCreated);

            Assert.AreEqual(false, batchResult.Created);
            Assert.AreEqual("dogs", batchResult.ExternalBatchId);

        }
    }
}
