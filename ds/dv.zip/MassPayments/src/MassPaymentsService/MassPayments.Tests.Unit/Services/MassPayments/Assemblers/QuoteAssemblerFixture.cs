﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Quoting;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPayments.Services.MassPaymentsService.Assemblers.Utility;
using MassPayments.Services.MassPaymentsService.DataContracts.Transaction;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts.quotes;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class QuoteAssemblerFixture
    {
        [SetUp]
        public void SetUp()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
        }
        
        [Test]
        public void AssembleRequest_FromData_Correctly()
        {
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());

            var data = new QuoteRequestData
            {
                CustomerExternalId = "asdf",
                FundingId = "aaa",
                ItemsToQuote = new List<QuoteRequestItemData>
                { new QuoteRequestItemData
                    {
                        FixedSettlementAmount = 1,
                        FixedTradeAmount = 1,
                        SettlementCurrencyCode = "USD",
                        TradeCurrencyCode = "CAD",
                        ValueDate = DateTime.Now
                    },
                    new QuoteRequestItemData
                    {
                        FixedSettlementAmount = 2,
                        FixedTradeAmount = 2,
                        SettlementCurrencyCode = "USD",
                        TradeCurrencyCode = "CAD",
                        ValueDate = DateTime.Now
                    }
                }
            };

            var domain = QuoteAssembler.AssembleNonFundingRequest(data);
            
            Assert.AreEqual(2, domain.ItemsToQuote.Count);
            AssertRequestDetail(data.ItemsToQuote[0], domain.ItemsToQuote[0]);
            AssertRequestDetail(data.ItemsToQuote[1], domain.ItemsToQuote[1]);
        }

        [Test]
        public void AssembleResult_Correctly()
        {
            var domain = new Quote
            {
                Id = 1,
                DurationInSec = 60,
                QuotedItems = new List<QuotedItem>
                { 
                    new QuotedItem
                    {
                        
                        IsDirect = true,
                        NumberOfDecimalsDirect = 2,
                        NumberOfDecimalsIndirect = 2,
                        RateValue = 0.9876m,
                        RateValueInverted = 1.1234m,
                        SettlementMoney = new Money(Currency.USD, 100),
                        TradeMoney = new Money(Currency.EUR, 123),
                        ValueDate = DateTime.Now 
                    },
                    new QuotedItem
                    {
                        IsDirect = true,
                        NumberOfDecimalsDirect = 2,
                        NumberOfDecimalsIndirect = 2,
                        RateValue = 0.9876m,
                        RateValueInverted = 1.1234m,
                        SettlementMoney = new Money(Currency.USD, 100),
                        TradeMoney = new Money(Currency.EUR, 123),
                        ValueDate = DateTime.Now 
                    }
                }
            };

            var data = QuoteAssembler.AssembleNonFundingResult(domain);

            Assert.AreEqual(2, data.QuotedItems.Count);
        }

        [Test]
        public void AssembleRequest_Works()
        {
            var requestData = new FundingQuoteRequestData
            {
                PartnerAssignedCustomerId = "2345",
                PartnerReference = "abc",
                QuoteRequestItems = new List<FundingQuoteRequestItemData>
                {
                    new FundingQuoteRequestItemData
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        IsAmountInSettlementCurrency = true,
                        Amount = 100
                    }
                }
            };

            var domain = QuoteAssembler.AssembleRequest(requestData);

            Assert.AreEqual(requestData.PartnerReference, domain.PartnerReference);
            Assert.AreEqual(requestData.QuoteRequestItems.Count, domain.ItemsToQuote.Count);
            Assert.AreEqual(requestData.QuoteRequestItems[0].Amount, domain.ItemsToQuote[0].FixedSettlementMoney.Amount);
            Assert.AreEqual(0, domain.ItemsToQuote[0].FixedTradeMoney.Amount);
            Assert.AreEqual(requestData.QuoteRequestItems[0].SettlementCurrencyCode, domain.ItemsToQuote[0].FixedSettlementMoney.Currency.Code);
            Assert.AreEqual(requestData.QuoteRequestItems[0].TradeCurrencyCode, domain.ItemsToQuote[0].FixedTradeMoney.Currency.Code);
        }

        [Test]
        public void AssembleRequest_WorksWhenIsAmountInSettlementCurrencyIsFalse()
        {
            var requestData = new FundingQuoteRequestData
            {
                PartnerAssignedCustomerId = "2345",
                PartnerReference = "abc",
                QuoteRequestItems = new List<FundingQuoteRequestItemData>
                {
                    new FundingQuoteRequestItemData
                    {
                        SettlementCurrencyCode = "CAD",
                        TradeCurrencyCode = "USD",
                        IsAmountInSettlementCurrency = false,
                        Amount = 100
                    }
                }
            };

            var domain = QuoteAssembler.AssembleRequest(requestData);

            Assert.AreEqual(requestData.PartnerReference, domain.PartnerReference);
            Assert.AreEqual(requestData.QuoteRequestItems.Count, domain.ItemsToQuote.Count);
            Assert.AreEqual(0, domain.ItemsToQuote[0].FixedSettlementMoney.Amount);
            Assert.AreEqual(requestData.QuoteRequestItems[0].Amount, domain.ItemsToQuote[0].FixedTradeMoney.Amount);
            Assert.AreEqual(requestData.QuoteRequestItems[0].SettlementCurrencyCode, domain.ItemsToQuote[0].FixedSettlementMoney.Currency.Code);
            Assert.AreEqual(requestData.QuoteRequestItems[0].TradeCurrencyCode, domain.ItemsToQuote[0].FixedTradeMoney.Currency.Code);
        }

        [Test]
        public void AssembleResult_Works()
        {
            var customerId = "123";
            var now = DateTime.UtcNow;

            var domain = new Quote
            {
                Id = 1,
                QuoteGuid = Guid.NewGuid().ToString(),
                DurationInSec = 60,
                RequestTimeUtc = now,
                ExpirationTimeUtc = now,
                Status = QuoteRequestStatus.Committed,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {

                        IsDirect = true,
                        NumberOfDecimalsDirect = 2,
                        NumberOfDecimalsIndirect = 2,
                        RateValue = 0.9876m,
                        RateValueInverted = 1.1234m,
                        SettlementMoney = new Money(Currency.USD, 100),
                        TradeMoney = new Money(Currency.EUR, 123),
                        ValueDate = DateTime.Now
                    },
                    new QuotedItem
                    {
                        IsDirect = true,
                        NumberOfDecimalsDirect = 2,
                        NumberOfDecimalsIndirect = 2,
                        RateValue = 0.9876m,
                        RateValueInverted = 1.1234m,
                        SettlementMoney = new Money(Currency.USD, 100),
                        TradeMoney = new Money(Currency.EUR, 123),
                        ValueDate = DateTime.Now
                    }
                }
            };

            var data = QuoteAssembler.AssembleResult(domain, customerId);

            Assert.AreEqual(2, data.QuotedItems.Count);
            Assert.AreEqual(domain.QuoteGuid.ToUpper(), data.QuoteId);
            Assert.AreEqual(customerId, data.PartnerAssignedCustomerId);
            Assert.AreEqual(domain.PartnerReference, data.PartnerReference);
            Assert.AreEqual(domain.DurationInSec, data.ExpirationIntervalInSeconds);
            Assert.AreEqual(DateTimeFormatter.FormatAsISO8601(domain.RequestTimeUtc), data.CreatedOn);
            Assert.AreEqual(DateTimeFormatter.FormatAsISO8601(domain.LastUpdatedOnUtc), data.LastUpdatedOn);
            Assert.AreEqual(domain.Status.ToString(), data.QuoteStatus);
            Assert.AreEqual(domain.QuotedItems.Count, data.QuotedItems.Count);
            AssertResultDetail(domain.QuotedItems[0], data.QuotedItems[0]);
            AssertResultDetail(domain.QuotedItems[1], data.QuotedItems[1]);
        }

        private static void AssertResultDetail(QuotedItem quotedItem, FundingQuoteResultItemData data)
        {
            Assert.AreEqual(quotedItem.TradeMoney.NonDecimalAmount, data.TradeAmount);
            Assert.AreEqual(quotedItem.TradeMoney.Currency.Code, data.TradeCurrencyCode);
            Assert.AreEqual(quotedItem.SettlementMoney.NonDecimalAmount, data.SettlementAmount);
            Assert.AreEqual(quotedItem.SettlementMoney.Currency.Code, data.SettlementCurrencyCode);
            Assert.AreEqual(quotedItem.IsDirect, data.IsDirect);
            Assert.AreEqual(quotedItem.RateValue, data.RateValue);
            Assert.AreEqual(quotedItem.RateValueInverted, data.RateValueInverted);
            Assert.AreEqual(quotedItem.NumberOfDecimalsDirect, data.NumberOfDecimalsDirect);
            Assert.AreEqual(quotedItem.NumberOfDecimalsIndirect, data.NumberOfDecimalsIndirect);
        }

        private static void AssertRequestDetail(QuoteRequestItemData quoteRequestItemData, QuoteRequestItem quoteRequestItem)
        {
            Assert.AreEqual(quoteRequestItemData.FixedSettlementAmount, quoteRequestItem.FixedSettlementMoney.Amount);
            Assert.AreEqual(quoteRequestItemData.FixedTradeAmount, quoteRequestItem.FixedTradeMoney.Amount);
            Assert.AreEqual(quoteRequestItemData.SettlementCurrencyCode, quoteRequestItem.FixedSettlementMoney.Currency.Code);
            Assert.AreEqual(quoteRequestItemData.TradeCurrencyCode, quoteRequestItem.FixedTradeMoney.Currency.Code);
            Assert.AreEqual(quoteRequestItemData.ValueDate, quoteRequestItem.ValueDate);
        }
    }
}
