﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Batches;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Services.MassPaymentsService.Assemblers;
using MassPayments.Services.MassPaymentsService.Assemblers.Utility;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts.orders;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class CommitBatchAssemblerFixture
    {
        [SetUp]
        public void SetUp()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyCache.Instance.Reinitialize();

        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyCache.Instance = null;
        }

        [Test]
        public void AssembleResult_UsesCorrectDateFormat()
        {
            DateTime createdOnDateTime = DateTime.Now;
            DateTime updatedOnDateTime = createdOnDateTime.AddHours(2);

            var expectedCreatedFormat = DateTimeFormatter.FormatAsISO8601(createdOnDateTime);
            var expectedUpdatedFormat = DateTimeFormatter.FormatAsISO8601(updatedOnDateTime);

            var result = new CommitBatchResult
            {
                Orders = new List<CommitBatchOrderResult>
                {
                    new CommitBatchOrderResult
                    {
                        CreatedOn = createdOnDateTime,
                        LastUpdatedOn = updatedOnDateTime,
                        OrderId = "N234",
                        OrderStatus = OrderStatus.Committed,
                        SettlementCurrency = Currency.CAD,
                        SettlementMethod = "banana"
                    }
                }
            };

            var resultData = CommitBatchAssembler.AssembleResult(result);

            Assert.AreEqual(1, resultData.BookedOrders.Count);
            Assert.AreEqual(expectedCreatedFormat, resultData.BookedOrders[0].CreatedOn);
            Assert.AreEqual(expectedUpdatedFormat, resultData.BookedOrders[0].LastUpdatedOn);
        }

        [Test]
        public void AssembleResult_ReturnsNullIfThereAreNoOrders()
        {
            var result = new CommitBatchResult();
            CommitBatchResultData resultData = null;

            Assert.DoesNotThrow(() => resultData = CommitBatchAssembler.AssembleResult(result));
            Assert.IsNull(resultData);
        }

        [Test]
        public void AssembleRequest_Throws_ForInvalidSettlementMethod()
        {
            var customerBatch = new CustomerBatch {ExternalId = "cats"};

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode= "CAD",
                        SettlementMethod = "banana"
                    }
                }
            };

            Assert.Throws<UnsupportedSettlementMethodRequestedException>(() => CommitBatchAssembler.AssembleRequest(request, customerBatch));
        }

        [Test]
        public void AssembleRequest_SettlementDataWithNothingInItShouldNotFail()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData()
                }
            };

            var result = CommitBatchAssembler.AssembleRequest(request, customerBatch);

            Assert.AreEqual(0, result.Settlements.Count);
        }

        [Test]
        public void AssembleRequest_ReturnsUndefinedSettlementMethod()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode= "CAD"
                    }
                }
            };

            var result = CommitBatchAssembler.AssembleRequest(request, customerBatch);

            Assert.AreEqual(SettlementPaymentMethod.Undefined, result.Settlements[0].SettlementMethod);
        }

        [Test]
        public void AssembleRequest_ReturnsEmptySettlementListWhenRequestIsNULL()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            var result = CommitBatchAssembler.AssembleRequest(null, customerBatch);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Settlements.Count);
        }

        [Test]
        public void AssembleRequest_ReturnsWireSettlementMethod()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode= "CAD",
                        SettlementMethod = "wire"
                    }
                }
            };

            var result = CommitBatchAssembler.AssembleRequest(request, customerBatch);

            Assert.AreEqual(SettlementPaymentMethod.Wire, result.Settlements[0].SettlementMethod);
        }

        [Test]
        public void AssembleRequest_ReturnsACHSettlementMethod()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode= "CAD",
                        SettlementMethod = "ach"
                    }
                }
            };

            var result = CommitBatchAssembler.AssembleRequest(request, customerBatch);

            Assert.AreEqual(SettlementPaymentMethod.ACH, result.Settlements[0].SettlementMethod);
        }

        [Test]
        public void AssembleRequest_SetsBatchProperly()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode= "CAD"
                    }
                }
            };

            var result = CommitBatchAssembler.AssembleRequest(request, customerBatch);

            Assert.AreEqual(customerBatch, result.CustomerBatch);
        }

        [Test]
        public void AssembleRequest_ThrowCurrencyNotRecognized()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode= "BLAH"
                    }
                }
            };

            Assert.Throws<CurrencyNotRecognizedException>(() => CommitBatchAssembler.AssembleRequest(request, customerBatch));
        }

        [Test]
        public void AssembleRequest_ThrowCurrencyNotSupported()
        {
            var customerBatch = new CustomerBatch { ExternalId = "cats" };

            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetDisabledCurrency());
            CurrencyCache.Instance.Reinitialize();

            var request = new CommitBatchRequestData
            {
                Settlements = new List<CommitBatchSettlementRequestData>
                {
                    new CommitBatchSettlementRequestData
                    {
                        SettlementCurrencyCode= "USD"
                    }
                }
            };

            Assert.Throws<CurrencyNotSupportedException>(() => CommitBatchAssembler.AssembleRequest(request, customerBatch));
        }

    }
}
