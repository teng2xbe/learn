﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.Gateways.Invoice.Assemblers;
using MassPayments.Gateways.Invoice.Entities;
using MassPayments.ResourceAccess.ClientRA;
using MassPayments.ResourceAccess.ClientRA.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;
using LineItem = MassPayments.Gateways.Invoice.Entities.LineItem;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class OutOfHoldingReportAssemblerFixture
    {
        [SetUp]
        public void SetUp()
        {
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(
                sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .Return(CustomerHelper.GetCustomerFromClientProvider());
            ClientProviderFactory.InjectedClientProviderInterface.Expect(
                sp => sp.GetClientDetailById(Arg<int>.Is.Anything)).Return(CustomerHelper.GetClientDetailsForInvoice());
        }

        [TearDown]
        public void TearDown()
        {
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        [Test]
        public void PrintHeaderDateTimeIsFormattedCorrectly()
        {
            var currentDate = new DateTime(1971, 02, 26, 1, 1, 1, 150, DateTimeKind.Unspecified);
            var timeZone = TimeZone.CurrentTimeZone.GetUtcOffset(currentDate);
            var formattedTimeZone = timeZone.ToString(@"hh\:mm");
            var isNegative = timeZone.Hours < 0;

            Assert.AreEqual(string.Format("1971-02-26T01:01:01.15{0}{1}", isNegative ? "-" : "+", formattedTimeZone), OutOfHoldingReportAssembler.FormatDate(currentDate));
        }

        [Test]
        public void ToAggregatedInvoice_MapsFieldsCorrectly()
        {
            var bookIncomingOrders = new List<OutOfHoldingOrder>();
            bookIncomingOrders.Add(CreateOutOfHoldingOrder());
            bookIncomingOrders[0].LineItems.Add(CreateLineItemResult());

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(1234);

            var aggregateInvoice = OutOfHoldingReportAssembler.ToOutOfHoldingReport(bookIncomingOrders, clientInfo);

            AssertHeaders(clientInfo, aggregateInvoice);
            AssertOrderDetail(bookIncomingOrders[0], aggregateInvoice.OrderDetails[0]);
            AssertItems(bookIncomingOrders[0].LineItems[0], aggregateInvoice.OrderDetails[0].Items[0]);
        }

        [Test]
        public void ToAggregatedInvoice_MapsFieldsCorrectly_ForMultipleOrders()
        {
            var bookIncomingOrders = new List<OutOfHoldingOrder>();
            bookIncomingOrders.Add(CreateOutOfHoldingOrder());
            bookIncomingOrders[0].LineItems.Add(CreateLineItemResult());
            bookIncomingOrders[0].LineItems.Add(CreateLineItemResult());
            bookIncomingOrders.Add(CreateOutOfHoldingOrder());
            bookIncomingOrders[1].LineItems.Add(CreateLineItemResult());
            bookIncomingOrders[1].LineItems.Add(CreateLineItemResult());

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(1234);

            var aggregateInvoice = OutOfHoldingReportAssembler.ToOutOfHoldingReport(bookIncomingOrders, clientInfo);

            AssertHeaders(clientInfo, aggregateInvoice);
            AssertOrderDetail(bookIncomingOrders[0], aggregateInvoice.OrderDetails[0]);
            AssertOrderDetail(bookIncomingOrders[1], aggregateInvoice.OrderDetails[1]);
            AssertItems(bookIncomingOrders[0].LineItems[0], aggregateInvoice.OrderDetails[0].Items[0]);
            AssertItems(bookIncomingOrders[0].LineItems[1], aggregateInvoice.OrderDetails[0].Items[1]);
            AssertItems(bookIncomingOrders[1].LineItems[0], aggregateInvoice.OrderDetails[0].Items[0]);
            AssertItems(bookIncomingOrders[1].LineItems[1], aggregateInvoice.OrderDetails[0].Items[1]);
        }

        [Test]
        public void ToAggregatedInvoice_MapsFieldsCorrectly_ForBlankSettlementInstructions()
        {
            var bookIncomingOrder = new List<OutOfHoldingOrder>();
            bookIncomingOrder.Add(CreateOutOfHoldingOrder());
            bookIncomingOrder[0].LineItems.Add(CreateLineItemResult());

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(1234);

            var aggregateInvoice = OutOfHoldingReportAssembler.ToOutOfHoldingReport(bookIncomingOrder, clientInfo);

            AssertHeaders(clientInfo, aggregateInvoice);
            AssertOrderDetail(bookIncomingOrder[0], aggregateInvoice.OrderDetails[0]);
            AssertItems(bookIncomingOrder[0].LineItems[0], aggregateInvoice.OrderDetails[0].Items[0]);
        }

        private static void AssertHeaders(ClientDetailInfo clientInfo, AggregateInvoice aggregateInvoice)
        {

            Assert.AreEqual(clientInfo.OfficeFaxNumber, aggregateInvoice.OfficeDetail.MainOfficeFaxNumber);
            Assert.AreEqual(clientInfo.OfficeAddress, aggregateInvoice.OfficeDetail.OfficeAddress);
            Assert.AreEqual(clientInfo.OfficePhoneNumber, aggregateInvoice.OfficeDetail.OfficePhone);
            Assert.AreEqual(clientInfo.OfficeId, aggregateInvoice.OfficeDetail.Id);

            Assert.AreEqual(clientInfo.OfficeLegalEntityLongName, aggregateInvoice.OrderHeader.EntityName);
            Assert.AreEqual(clientInfo.OfficeLegalEntityLicenseNumber, aggregateInvoice.OrderHeader.LicenseNo);
            Assert.AreEqual(clientInfo.InvoiceLanguageCode, aggregateInvoice.OrderHeader.Language);
            Assert.AreEqual("MassPay", aggregateInvoice.OrderHeader.OrderCaptureSystem);
            Assert.AreEqual("Aggregate Payment Receipt", aggregateInvoice.OrderHeader.OrderType);

            Assert.AreEqual(clientInfo.AccountNumber, aggregateInvoice.ClientDetail.ClientAccount);
            Assert.AreEqual(clientInfo.AddressLine1, aggregateInvoice.ClientDetail.ClientAddressLine1);
            Assert.AreEqual(clientInfo.AddressLine2, aggregateInvoice.ClientDetail.ClientAddressLine2);
            Assert.AreEqual(clientInfo.AddressLine3, aggregateInvoice.ClientDetail.ClientAddressLine3);
            Assert.AreEqual(clientInfo.City, aggregateInvoice.ClientDetail.ClientCity);
            Assert.AreEqual(clientInfo.CountryCode, aggregateInvoice.ClientDetail.ClientCountry);
            Assert.AreEqual(clientInfo.CompanyName, aggregateInvoice.ClientDetail.ClientName);
            Assert.AreEqual(clientInfo.PostalCode, aggregateInvoice.ClientDetail.ClientPostalCode);
            Assert.AreEqual(clientInfo.State, aggregateInvoice.ClientDetail.ClientProvince);
            Assert.AreEqual(clientInfo.ProcessCenterCode, aggregateInvoice.ClientDetail.ProcessCenter);
            
            Assert.AreEqual("test-filecopyconnector", aggregateInvoice.PrintHeader.FileCopyConnector);
        }

        private static void AssertOrderDetail(OutOfHoldingOrder bookedOrders, OrderDetail orderDetail)
        {
            Assert.AreEqual(bookedOrders.OrderNumber, orderDetail.ConfirmationNo);
            Assert.AreEqual("Out Of Holding", orderDetail.Product);
        }

        private static void AssertItems(OutOfHoldingOrderItem lineItemResult, LineItem lineItem)
        {
            Assert.AreEqual(lineItemResult.SettlementCurrencyCode, lineItem.SettlementCurrency);
            Assert.AreEqual(lineItemResult.Amount, lineItem.TradeAmount);
            Assert.AreEqual(1, lineItem.Rate);
            Assert.AreEqual(lineItemResult.Amount, lineItem.SettlementAmount);
            Assert.AreEqual(lineItemResult.TradeCurrencyCode, lineItem.TradeCurrency);
            Assert.AreEqual("Out Of Holding", lineItem.Description);
            Assert.AreEqual(0, lineItem.Fee);
        }

        private static OutOfHoldingOrder CreateOutOfHoldingOrder()
        {
            return new OutOfHoldingOrder
            {
                OrderNumber = "banana",
                Id = 1234,
                CreatedOnUTC = DateTime.Now,
                CustomerId = 123,
                PartnerId = 1,
                ReportId = 1,
                LineItems = new List<OutOfHoldingOrderItem>()
            };
        }

        private static OutOfHoldingOrderItem CreateLineItemResult()
        {
            return new OutOfHoldingOrderItem
            {
                
                Id = 111,
                Amount = 4000.00m,
                TradeCurrencyCode = "USD",
                OrderId = 1234,
                SettlementCurrencyCode = "CAD"
            };
        }
    }
}
