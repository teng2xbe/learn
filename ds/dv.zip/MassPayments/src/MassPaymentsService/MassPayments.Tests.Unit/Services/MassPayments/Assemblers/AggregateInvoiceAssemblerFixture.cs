﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Gateways.Invoice.Assemblers;
using MassPayments.Gateways.Invoice.Entities;
using MassPayments.ResourceAccess.ClientRA;
using MassPayments.ResourceAccess.ClientRA.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;
using SettlementPaymentMethod = MassPayments.CCTMassPayments.SettlementPaymentMethod;
using LineItem = MassPayments.Gateways.Invoice.Entities.LineItem;

namespace MassPayments.Tests.Unit.Services.MassPayments.Assemblers
{
    [TestFixture]
    public class AggregateInvoiceAssemblerFixture
    {
        [SetUp]
        public void SetUp()
        {
            ClientProviderFactory.InjectedClientProviderInterface = MockRepository.GenerateMock<IClientProvider>();
            ClientProviderFactory.InjectedClientProviderInterface.Expect(
                sp => sp.GetCustomerByExternalId(Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .Return(CustomerHelper.GetCustomerFromClientProvider());
            ClientProviderFactory.InjectedClientProviderInterface.Expect(
                sp => sp.GetClientDetailById(Arg<int>.Is.Anything)).Return(CustomerHelper.GetClientDetailsForInvoice());
        }

        [TearDown]
        public void TearDown()
        {
            ClientProviderFactory.InjectedClientProviderInterface = null;
        }

        [Test]
        public void PrintHeaderDateTimeIsFormattedCorrectly()
        {
            var currentDate = new DateTime(1971, 02, 26, 1, 1, 1, 150, DateTimeKind.Unspecified);
            var timeZone = TimeZone.CurrentTimeZone.GetUtcOffset(currentDate);
            var formattedTimeZone = timeZone.ToString(@"hh\:mm");
            var isNegative = timeZone.Hours < 0;

            Assert.AreEqual(string.Format("1971-02-26T01:01:01.15{0}{1}", isNegative ? "-" : "+", formattedTimeZone),
                AggregateInvoiceAssembler.FormatDate(currentDate));
        }

        [Test]
        public void ToAggregatedInvoice_MapsFieldsCorrectly()
        {
            var bookIncomingOrders = new List<BookedIncomingOrder>();
            bookIncomingOrders.Add(CreateBookIncomingOrderResult(SettlementPaymentMethod.Edebit,
                CreateSettlementBankAccountResult()));
            bookIncomingOrders[0].LineItems.Add(CreateLineItemResult(1));

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(1234);

            var aggregateInvoice = AggregateInvoiceAssembler.ToAggregateInvoice(bookIncomingOrders, clientInfo);

            AssertHeaders(clientInfo, aggregateInvoice);
            AssertOrderDetail(bookIncomingOrders[0], aggregateInvoice.OrderDetails[0]);
            AssertItems(bookIncomingOrders[0], bookIncomingOrders[0].LineItems[0],
                aggregateInvoice.OrderDetails[0].Items[0]);
        }

        [Test]
        public void ToAggregatedInvoice_MapsFieldsCorrectly_ForMultipleOrders()
        {
            var bookIncomingOrders = new List<BookedIncomingOrder>();
            bookIncomingOrders.Add(CreateBookIncomingOrderResult(SettlementPaymentMethod.Wire,
                CreateSettlementBankAccountResult()));
            bookIncomingOrders[0].LineItems.Add(CreateLineItemResult(1));
            bookIncomingOrders[0].LineItems.Add(CreateLineItemResult(2));
            bookIncomingOrders.Add(CreateBookIncomingOrderResult(SettlementPaymentMethod.Edebit,
                new BookedIncomingOrderBankAccount()));
            bookIncomingOrders[1].LineItems.Add(CreateLineItemResult(1));
            bookIncomingOrders[1].LineItems.Add(CreateLineItemResult(2));

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(1234);

            var aggregateInvoice = AggregateInvoiceAssembler.ToAggregateInvoice(bookIncomingOrders, clientInfo);

            AssertHeaders(clientInfo, aggregateInvoice);
            AssertOrderDetail(bookIncomingOrders[0], aggregateInvoice.OrderDetails[0]);
            AssertOrderDetail(bookIncomingOrders[1], aggregateInvoice.OrderDetails[1]);
            AssertItems(bookIncomingOrders[0], bookIncomingOrders[0].LineItems[0],
                aggregateInvoice.OrderDetails[0].Items[0]);
            AssertItems(bookIncomingOrders[0], bookIncomingOrders[0].LineItems[1],
                aggregateInvoice.OrderDetails[0].Items[1]);
            AssertItems(bookIncomingOrders[1], bookIncomingOrders[1].LineItems[0],
                aggregateInvoice.OrderDetails[0].Items[0]);
            AssertItems(bookIncomingOrders[1], bookIncomingOrders[1].LineItems[1],
                aggregateInvoice.OrderDetails[0].Items[1]);
        }

        [Test]
        public void ToAggregatedInvoice_MapsFieldsCorrectly_ForBlankSettlementInstructions()
        {
            var bookIncomingOrder = new List<BookedIncomingOrder>();
            bookIncomingOrder.Add(CreateBookIncomingOrderResult(SettlementPaymentMethod.Edebit,
                new BookedIncomingOrderBankAccount()));
            bookIncomingOrder[0].LineItems.Add(CreateLineItemResult(1));

            var clientInfo = ClientProviderFactory.GetClientProvider().GetClientDetailById(1234);

            var aggregateInvoice = AggregateInvoiceAssembler.ToAggregateInvoice(bookIncomingOrder, clientInfo);

            AssertHeaders(clientInfo, aggregateInvoice);
            AssertOrderDetail(bookIncomingOrder[0], aggregateInvoice.OrderDetails[0]);
            AssertItems(bookIncomingOrder[0], bookIncomingOrder[0].LineItems[0],
                aggregateInvoice.OrderDetails[0].Items[0]);
        }

        private static void AssertHeaders(ClientDetailInfo clientInfo, AggregateInvoice aggregateInvoice)
        {

            Assert.AreEqual(clientInfo.OfficeFaxNumber, aggregateInvoice.OfficeDetail.MainOfficeFaxNumber);
            Assert.AreEqual(clientInfo.OfficeAddress, aggregateInvoice.OfficeDetail.OfficeAddress);
            Assert.AreEqual(clientInfo.OfficePhoneNumber, aggregateInvoice.OfficeDetail.OfficePhone);
            Assert.AreEqual(clientInfo.OfficeId, aggregateInvoice.OfficeDetail.Id);

            Assert.AreEqual(clientInfo.OfficeLegalEntityLongName, aggregateInvoice.OrderHeader.EntityName);
            Assert.AreEqual(clientInfo.OfficeLegalEntityLicenseNumber, aggregateInvoice.OrderHeader.LicenseNo);
            Assert.AreEqual(clientInfo.InvoiceLanguageCode, aggregateInvoice.OrderHeader.Language);
            Assert.AreEqual("MassPay", aggregateInvoice.OrderHeader.OrderCaptureSystem);
            Assert.AreEqual("Aggregate Payment", aggregateInvoice.OrderHeader.OrderType);

            Assert.AreEqual(clientInfo.AccountNumber, aggregateInvoice.ClientDetail.ClientAccount);
            Assert.AreEqual(clientInfo.AddressLine1, aggregateInvoice.ClientDetail.ClientAddressLine1);
            Assert.AreEqual(clientInfo.AddressLine2, aggregateInvoice.ClientDetail.ClientAddressLine2);
            Assert.AreEqual(clientInfo.AddressLine3, aggregateInvoice.ClientDetail.ClientAddressLine3);
            Assert.AreEqual(clientInfo.City, aggregateInvoice.ClientDetail.ClientCity);
            Assert.AreEqual(clientInfo.CountryCode, aggregateInvoice.ClientDetail.ClientCountry);
            Assert.AreEqual(clientInfo.CompanyName, aggregateInvoice.ClientDetail.ClientName);
            Assert.AreEqual(clientInfo.PostalCode, aggregateInvoice.ClientDetail.ClientPostalCode);
            Assert.AreEqual(clientInfo.State, aggregateInvoice.ClientDetail.ClientProvince);
            Assert.AreEqual(clientInfo.ProcessCenterCode, aggregateInvoice.ClientDetail.ProcessCenter);

            Assert.AreEqual("test-filecopyconnector", aggregateInvoice.PrintHeader.FileCopyConnector);
        }

        private static void AssertOrderDetail(BookedIncomingOrder bookedOrders, OrderDetail orderDetail)
        {
            Assert.AreEqual(bookedOrders.ConfirmationNumber, orderDetail.ConfirmationNo);
            Assert.AreEqual("Into Holding", orderDetail.Product);
            Assert.AreEqual(bookedOrders.SettlementPaymentMethod, orderDetail.SettlementDetails.SettlementMethod);
            Assert.AreEqual(bookedOrders.SettlementBankAccount.AccountNumber,
                orderDetail.SettlementDetails.OurBankDetails.CreditBankDetails.CreditAccountId);
            Assert.AreEqual(bookedOrders.SettlementBankAccount.BankAccountOwnerName,
                orderDetail.SettlementDetails.OurBankDetails.CreditBankDetails.CreditAccountName);
            Assert.AreEqual(bookedOrders.SettlementBankAccount.BankName,
                orderDetail.SettlementDetails.OurBankDetails.CreditBankDetails.CreditBankName);
            Assert.AreEqual(bookedOrders.SettlementBankAccount.SWIFTCode,
                orderDetail.SettlementDetails.OurBankDetails.CreditBankDetails.CreditBankSwift);
            Assert.AreEqual(bookedOrders.SettlementBankAccount.RoutingCode,
                orderDetail.SettlementDetails.OurBankDetails.CreditBankDetails.CreditRoutingCode);
        }

        private static void AssertItems(BookedIncomingOrder bookedOrders, BookedIncomingOrderItem lineItemResult,
            LineItem lineItem)
        {
            Assert.AreEqual(bookedOrders.SettlementCurrencyCode, lineItem.SettlementCurrency);
            Assert.AreEqual(lineItemResult.TradeAmount, lineItem.TradeAmount);
            Assert.AreEqual(lineItemResult.RateValue, lineItem.Rate);
            Assert.AreEqual(lineItemResult.SettlementAmount, lineItem.SettlementAmount);
            Assert.AreEqual(lineItemResult.TradeCurrencyCode, lineItem.TradeCurrency);
            Assert.AreEqual("Into Holding", lineItem.Description);
            Assert.AreEqual(lineItemResult.Fee, lineItem.Fee);
            Assert.AreEqual(lineItemResult.Number, lineItem.ItemNo);
        }

        private static BookedIncomingOrder CreateBookIncomingOrderResult(
            SettlementPaymentMethod settlementPaymentMethod, BookedIncomingOrderBankAccount settlementBankAccount)
        {
            return new BookedIncomingOrder
            {
                ConfirmationNumber = "banana",
                OrderId = 1234,
                SettlementCurrencyCode = "CAD",
                SettlementPaymentMethod = settlementPaymentMethod.ToString(),
                SettlementBankAccount = settlementBankAccount,
                LineItems = new List<BookedIncomingOrderItem>()
            };
        }

        private static BookedIncomingOrderItem CreateLineItemResult(int itemNo)
        {
            return new BookedIncomingOrderItem
            {
                ItemId = 111,
                RateValue = 1.2345m,
                TradeAmount = 4000.00m,
                SettlementAmount = 3000.00m,
                TradeCurrencyCode = "USD",
                Number = itemNo,
            };
        }

        private static BookedIncomingOrderBankAccount CreateSettlementBankAccountResult()
        {
            return new BookedIncomingOrderBankAccount
            {
                AccountNumber = "123",
                BankAccountOwnerName = "name",
                BankName = "bank",
                SWIFTCode = "swift",
                RoutingCode = "blah"
            };
        }
    }
}
