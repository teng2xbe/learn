﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Unit.Helpers
{
    public class PaymentHelper
    {
        private static PaymentHelper instance;
        
        public static PaymentHelper Instance
        {
            get { return instance ?? (instance = new PaymentHelper()); }
            set { instance = value; }
        }

        private Random randomSeed;

        private PaymentHelper()
        {
            randomSeed = new Random(Guid.NewGuid().GetHashCode());
        }
    
        public string GetRandomString()
        {
            return randomSeed.Next(1, 100000).ToString();
        }

        public Payment CreatePayment(Customer customer, string externalId, CustomerBatch customerBatch)
        {
            var bene = CustomerHelper.Instance.CreateBeneficiary(customer);
            return new Payment(externalId, customerBatch.ExternalCustomerId)
            {
                CustomerBatchId = customerBatch.Id,
                AmountMoney = new Money(Currency.CAD, 100.00m),
                Beneficiary = bene,
                BankAccount = CustomerHelper.Instance.CreateBankAccount(bene),
                PaymentMethod = PaymentMethod.Draft,
                PaymentStatus = PaymentStatus.Committed,
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                CreatedOnUTC = DateTime.UtcNow.AddDays(-20),
                SettlementAmountMoney = new Money(Currency.USD, 0),
                PaymentSourceId = customer.PartnerId,
                PaymentReference = "TestReferece",
                ThirdPartyRemitter = ThirdPartyRemitterHelper.Instance.CreatePartyRemitter()
            };
        }

        public Payment CreatePayment(Customer customer, CustomerBatch customerBatch)
        {
            return CreatePayment(customer, GetRandomString(), customerBatch);
        }

        public ReturnedPayment CreateReturnedPayment(Customer customer, CustomerBatch customerBatch)
        {
            var bene = CustomerHelper.Instance.CreateBeneficiary(customer);
            return new ReturnedPayment(GetRandomString(), customerBatch.ExternalCustomerId)
            {
                CustomerBatchId = customerBatch.Id,
                AmountMoney = new Money(Currency.CAD, 100.00m),
                Beneficiary = bene,
                BankAccount = CustomerHelper.Instance.CreateBankAccount(bene),
                PaymentMethod = PaymentMethod.Draft,
                PaymentStatus = PaymentStatus.Returned,
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                CreatedOnUTC = DateTime.UtcNow.AddDays(-20),
                SettlementAmountMoney = new Money(Currency.USD, 0),
                PaymentSourceId = customer.PartnerId,
                PaymentReference = "TestReferece"
            };
        }
    }
}
