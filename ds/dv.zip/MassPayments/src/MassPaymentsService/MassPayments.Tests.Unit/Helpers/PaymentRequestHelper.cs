﻿using MassPayments.Domain.Entities;

namespace MassPayments.Tests.Unit.Helpers
{
    public static class PaymentRequestHelper
    {
        public static MassPayments.Domain.Entities.PaymentRequest.PaymentRequest CreatePaymentRequest(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            var paymentRequest = new MassPayments.Domain.Entities.PaymentRequest.PaymentRequest
            {
                ItemIndex = itemIndex,
                BankAccount = CreateBankAccount("1", lastUpdatedOn),
                Beneficiary = CreateBeneficiary("1", lastUpdatedOn),
                PartnerAssignedCustomerId = "123",
                PartnerReference = "123",
                PaymentId = externalPaymentId,
                PaymentMethod = "Wire",
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                FixedAmount = 100,
                CurrencyCode = "CAD"
            };
            paymentRequest.SetCustomer(new Customer { Id = 1, CountryCode = "US" });
            return paymentRequest;
        }

        private static MassPayments.Domain.Entities.PaymentRequest.Beneficiary CreateBeneficiary(string id, string versionedOn)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.Beneficiary
            {
                Id = id,
                Address = CreateAddress(),
                BusinessContactRole = "bus role",
                BusinessName = "bus nm",
                BusinessRegistrationCountry = "bus reg ctry",
                BusinessRegistrationNumber = "bus reg no",
                BusinessRegistrationStateProv = "bus prov",
                CellNumber = "celno",
                DateOfBirth = "dob",
                EmailAddress = "a@abc.d",
                FirstName = "fn",
                MiddleName = "mn",
                LastName = "ln",
                Gender = "M/F",
                Industry = "IT",
                VersionedOn = versionedOn,
                PhoneNumber = "123",
                Type = "BUSINESS"
            };
        }

        private static MassPayments.Domain.Entities.PaymentRequest.BankAccount CreateBankAccount(string id, string versionedOn)
        {
            return new MassPayments.Domain.Entities.PaymentRequest.BankAccount
            {
                AccountNumber = "acct no",
                AccountType = "checking",
                BankAddress = CreateAddress(),
                BankBranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                Id = id,
                VersionedOn = versionedOn
            };
        }

        private static MassPayments.Domain.Entities.PaymentRequest.Address CreateAddress()
        {
            return new MassPayments.Domain.Entities.PaymentRequest.Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrPovince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
