﻿using System.Collections.Generic;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Unit.Helpers
{
    public static class SupportedExternalPaymentMethod
    {
        public static Dictionary<string, PaymentMethod> GetSupportedExternalPaymentDictionary()
        {
            var dic = new Dictionary<string, PaymentMethod>();
            dic.Add("BLAH_BMO", PaymentMethod.ACH);
            return dic;
        } 
    }
}
