﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Providers.StorageProvider.EventArguments;
using MassPayments.Providers.StorageProvider.Interfaces;

namespace MassPayments.Tests.Unit.Helpers
{
    public class TestBeneficiaryStorageProvider : IBeneficiaryStorageProvider
    {
        public int BeneCount { get; set; }
        public int BankCount { get; set; }
        public List<Beneficiary> Beneficiaries;
        public List<BankAccount> BankAccounts; 

        public TestBeneficiaryStorageProvider()
        {
            BeneCount = 0;
            BankCount = 0;
            Beneficiaries = new List<Beneficiary>();
            BankAccounts = new List<BankAccount>();
        }
        public void HandleBeneficiaryInsertOrUpdate(object sender,BeneficiaryEventArgs args)
        {
            if(args.Beneficiary != null)
                BeneCount++;

            if (args.BankAccounts != null)
            {
                foreach (BankAccount ba in args.BankAccounts)
                {
                    BankCount++;
                }
            }

            
        }

        public void HandleBeneficiariesInsertOrUpdate(object sender, List<BeneficiaryEventArgs> args)
        {
            foreach (var arg in args)
            {
                if (arg.Beneficiary != null)
                    BeneCount++;

                if (arg.BankAccounts != null)
                {
                    foreach (BankAccount ba in arg.BankAccounts)
                    {
                        BankCount++;
                    }
                }
            }
        }
    }
}
