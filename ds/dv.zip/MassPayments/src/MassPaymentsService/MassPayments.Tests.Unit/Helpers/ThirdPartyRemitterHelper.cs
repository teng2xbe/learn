﻿using MassPayments.Domain.Entities;

namespace MassPayments.Tests.Unit.Helpers
{
    public class ThirdPartyRemitterHelper
    {
        private static ThirdPartyRemitterHelper instance;

        public static ThirdPartyRemitterHelper Instance
        {
            get { return instance ?? (instance = new ThirdPartyRemitterHelper()); }
            set { instance = value; }
        }

        public ThirdPartyRemitter CreatePartyRemitter()
        {
            var address = new Address
            {
                City = "Vancouver",
                StateOrProvince = "BC",
                ZipOrPostalCode = "1W1W1W",
                CountryCode = "CA",
                AddressLine1 = "Test11",
                AddressLine2 = "Test12",
                AddressLine3 = "Test13"
            };

            return new ThirdPartyRemitter
            {
                Id = "id",
                Identification = "test",
                Address = address,
                VersionedOn = "now",
                Version = 1,
                BusinessName = "business name",
                PhoneNumber = "phone number",
                Email = "email",
                Industry = "industry",
                IdentificationType = "id type",
                Type = "type"
            };
        }
    }
}
