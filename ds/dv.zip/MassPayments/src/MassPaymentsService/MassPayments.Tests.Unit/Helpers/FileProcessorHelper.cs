﻿using System;
using System.Collections.Generic;
using System.Text;
using MassPayments.Domain.Entities;

namespace MassPayments.Tests.Unit.Helpers
{
    public static class FileProcessorHelper
    {
        public static string GetClientBatchString(Customer customer, CustomerBatch customerBatch, Payment payment)
        {
            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            var bank = CustomerHelper.Instance.CreateBankAccount(beneficiary);

            var paymentdetail = GetPaymentDetailString(payment, beneficiary, bank);
            var clientBatchString = string.Format(
                SampleClientbatchString,
                customerBatch.ExternalId,
                customerBatch.BatchReference,
                customerBatch.ExternalCustomerId,
                beneficiary.CustomerBeneId,
                paymentdetail
                );
            return string.Format(SamplePaymentBatchString, clientBatchString);
        }

        public static string GetClientBatchStringWithOneBatchAndMultiplePayment(Customer customer, CustomerBatch customerBatch, List<Payment> payments)
        {
            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            var bank = CustomerHelper.Instance.CreateBankAccount(beneficiary);

            var paymentDetails = new StringBuilder();
            int count = payments.Count;
            foreach (Payment payment in payments)
            {
                paymentDetails.Append(GetPaymentDetailString(payment, beneficiary, bank));
                if (count != 1)
                    paymentDetails.Append(",");
                count--;
            }
            var clientBatchString = string.Format(
                SampleClientbatchString,
                customerBatch.ExternalId,
                customerBatch.BatchReference,
                customerBatch.ExternalCustomerId,
                beneficiary.CustomerBeneId,
                paymentDetails
                );
            return string.Format(SamplePaymentBatchString, clientBatchString);
        }

        public static string GetClientBatchStringWithMultipleBatchAndMultiplePayment(Customer customer, List<CustomerBatch> customerBatches, Dictionary<string, List<Payment>> payments)
        {
            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            var bank = CustomerHelper.Instance.CreateBankAccount(beneficiary);
            var clientBatchesString = new StringBuilder();

            int batchCount = customerBatches.Count;
            foreach (CustomerBatch customerBatch in customerBatches)
            {
                var paymentDetails = new StringBuilder();
            
                var paymentList = payments[customerBatch.ExternalId];
                int paymentCount = paymentList.Count;
                foreach (Payment payment in paymentList)
                {
                    paymentDetails.Append(GetPaymentDetailString(payment, beneficiary, bank));
                    if (paymentCount != 1)
                        paymentDetails.Append(",");
                    paymentCount--;
                }

                var batch = string.Format(
                   SampleClientbatchString,
                   customerBatch.ExternalId,
                   customerBatch.BatchReference,
                   customerBatch.ExternalCustomerId,
                   beneficiary.CustomerBeneId,
                   paymentDetails
                   );

                clientBatchesString.Append(batch);
                if (batchCount != 1)
                    clientBatchesString.Append(",");
                batchCount--;
            } 

            return string.Format(SamplePaymentBatchString, clientBatchesString);
        }

        public static string GetCashoutString(Customer customer, CustomerBatch customerBatch, Payment payment)
        {
            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            var bank = CustomerHelper.Instance.CreateBankAccount(beneficiary);
            
            var orginatingBatch = string.Format(
                SamplePaymentOriginatingBatch,
                customerBatch.ExternalId,
                customerBatch.BatchReference,
                customerBatch.ExternalCustomerId
                );
            var paymentDetail = GetPaymentDetailString(payment, beneficiary, bank);

            var cashoutString = string.Format(SamplePaymentCashout, orginatingBatch,paymentDetail);
            return string.Format(SamplePaymentCashoutString, cashoutString);
        }

        public static string GetMultipleCashoutString(Customer customer, List<CustomerBatch> customerBatches, Dictionary<string, Payment> payments)
        {
            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            var bank = CustomerHelper.Instance.CreateBankAccount(beneficiary);
            var multipleCashoutString = new StringBuilder();
            int count = customerBatches.Count;
            foreach (CustomerBatch customerBatch in customerBatches)
            {
                var payment = payments[customerBatch.ExternalId];
                var orginatingBatch = string.Format(
                   SamplePaymentOriginatingBatch,
                   customerBatch.ExternalId,
                   customerBatch.BatchReference,
                   customerBatch.ExternalCustomerId
                   );
                var paymentDetail = GetPaymentDetailString(payment, beneficiary, bank);
                var cashoutString = string.Format(SamplePaymentCashout, orginatingBatch, paymentDetail);
                multipleCashoutString.Append(cashoutString);
                if (count != 1)
                {
                    multipleCashoutString.Append(",");
                }
                count++;
            }
            return string.Format(SamplePaymentCashoutString, multipleCashoutString);
        }

        public static string GetReturnedPayment(Customer customer, CustomerBatch customerBatch, Payment payment)
        {
            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            var bank = CustomerHelper.Instance.CreateBankAccount(beneficiary);
            var paymentDetail = GetPaymentDetailString(payment, beneficiary, bank);
            return string.Format(SampleReturnedPaymentString, paymentDetail);
        }

        public static string GetMultipleReturnedPaymentString(Customer customer, List<Payment> payments)
        {
            var beneficiary = CustomerHelper.Instance.CreateBeneficiary(customer);
            var bank = CustomerHelper.Instance.CreateBankAccount(beneficiary);
            var multipleReturnPayment = new StringBuilder();
            int count = payments.Count;
            foreach (Payment payment in payments)
            {
                var paymentDetail = GetPaymentDetailString(payment, beneficiary, bank);
                multipleReturnPayment.AppendLine(paymentDetail);
                if (count != 1)
                {
                    multipleReturnPayment.Append(",");
                }
                count++;
            }

            return string.Format(SampleReturnedPaymentString, multipleReturnPayment);
        }

        private static string GetPaymentDetailString(Payment payment, Beneficiary beneficiary, BankAccount bankAccount)
        {
            return string.Format(
                SamplePaymentDetailString,
                beneficiary.CustomerBeneId,
                beneficiary.ExternalId,
                payment.ExternalId,
                string.Empty,
                string.Empty,
                string.Empty,
                string.Empty,
                string.Empty,
                payment.AmountMoney.Amount,
                payment.AmountMoney.Currency.Code,
                beneficiary.Version,
                beneficiary.Identification != null ? beneficiary.Identification.EntityType : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.FirstName : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.MiddleName : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.LastName : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.PhoneNumber : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.CellNumber : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.DateOfBirth : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.Gender : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.BusinessName : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.BusinessRegistrationNumber : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.BusinessRegistrationCountry : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.BusinessRegistrationStateProv : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.BusinessContactRole : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.Industry : string.Empty,
                beneficiary.Identification != null ? beneficiary.Identification.EmailAddress : string.Empty,
                beneficiary.Address != null ? beneficiary.Address.AddressLine1 : string.Empty,
                beneficiary.Address != null ? beneficiary.Address.AddressLine2 : string.Empty,
                beneficiary.Address != null ? beneficiary.Address.AddressLine3 : string.Empty,
                beneficiary.Address != null ? beneficiary.Address.City : string.Empty,
                beneficiary.Address != null ? beneficiary.Address.StateOrProvince : string.Empty,
                beneficiary.Address != null ? beneficiary.Address.ZipOrPostalCode : string.Empty,
                beneficiary.Address != null ? beneficiary.Address.CountryCode : string.Empty,
                bankAccount.ExternalId,                            
                bankAccount.Version,                           
                bankAccount.ExternalAccountType,                              
                bankAccount.AccountPurpose,                               
                bankAccount.CurrencyCode,                             
                bankAccount.BankName,                             
                bankAccount.BranchName,                               
                bankAccount.BankAddress != null ? bankAccount.BankAddress.AddressLine1 : string.Empty,
                bankAccount.BankAddress != null ? bankAccount.BankAddress.AddressLine2 : string.Empty,
                bankAccount.BankAddress != null ? bankAccount.BankAddress.AddressLine3 : string.Empty,
                bankAccount.BankAddress != null ? bankAccount.BankAddress.City : string.Empty,
                bankAccount.BankAddress != null ? bankAccount.BankAddress.StateOrProvince : string.Empty,
                bankAccount.BankAddress != null ? bankAccount.BankAddress.ZipOrPostalCode : string.Empty,
                bankAccount.BankAddress != null ? bankAccount.BankAddress.CountryCode : string.Empty,                  
                bankAccount.BankCode,
                bankAccount.BranchCode,
                bankAccount.AccountNumber,
                bankAccount.DisplayName,
                "BLAH_BMO",
                DateTime.Now.ToString("yyyy-MM-dd"),
                payment.TransactionSystemId,
                payment.SettlementCurrencyCode
                );
        }

        private const string SamplePaymentDetailString = @"{{
                                                'clientCustomerId': '{0}',
                                                'walletNumber': '{1}',
                                                'paymentId': '{2}',       
                                                'clientReferenceNumber': '{3}',
                                                'programId': '{4}',
                                                'description': 'description',
                                                'memo':'description',
                                                'transferId': '{5}',
                                                'bankBatchId': '{6}',                                                                     
                                                'clientBankBatchId': '{7}',
                                                'amount': '{8}',
                                                'currency': '{9}',
                                                'profile': {{
                                                    'versionNumber': '{10}',
                                                    'identification': {{
                                                        'entityType': '{11}',
                                                        'firstName': '{12}',
                                                        'middleName': '{13}',
                                                        'lastName': '{14}',
                                                        'phoneNumber': '{15}',
                                                        'mobileNumber': '{16}',
                                                        'dateOfBirth': '{17}',
                                                        'gender': '{18}',
                                                        'businessName': '{19}',
                                                        'businessRegistrationNumber': '{20}',
                                                        'businessRegistrationCountry': '{21}',
                                                        'businessRegistrationStateProv': '{22}',
                                                        'businessContactRole': '{23}',
                                                        'industry': '{24}',
                                                        'emailAddress': '{25}'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '{26}',
                                                        'addressLine2': '{27}',
                                                        'addressLine3': '{28}',
                                                        'city': '{29}',
                                                        'stateProv': '{30}',
                                                        'postCode': '{31}',
                                                        'countryCode': '{32}'
                                                    }}
                                                }},
                                                'bankAccount': {{
                                                    'externalAccountId': '{33}',
                                                    'versionNumber': '{34}',
                                                    'externalAccountType': '{35}',
                                                    'accountPurpose': '{36}',
                                                    'currencyCode': '{37}',
                                                    'bankName': '{38}',
                                                    'branchName': '{39}',
                                                    'bankAddress': {{
                                                        'addressLine1': '{40}',
                                                        'addressLine2': '{41}',
                                                        'addressLine3': '{42}',
                                                        'city': '{43}',
                                                        'stateProv': '{44}',
                                                        'postCode': '{45}',
                                                        'countryCode': '{46}'
                                                    }},
                                                    'bankCode': '{47}',
                                                    'branchCode': '{48}',
                                                    'accountNumber': '{49}',
                                                    'displayName': '{50}',
                                                }},
                                                'dispensationType': '{51}',
                                                'valueDate' : '{52}',
                                                'transactionSystemId':'{53}',
                                                'settlementCurrencyCode' : '{54}'
                                            }}";

        private const string SampleClientbatchString = @"{{
                                        'batchId': '{0}',
                                        'clientBatchId': '{1}',
                                        'clientProgramId' : '{2}',
                                        'programId' : '{3}',
                                        'paymentDetails': [
                                            {4}
                                        ]
                                    }}";

        private const string SamplePaymentBatchString = @"
                              {{
                                'clientBatches': [
                                    {0}
                                ]
                            }}";
        private const string SamplePaymentCashoutString = @"{{
                                'pendingBankTransfers' : [
                                   {0}
                                ]
                            }}";

        private const string SamplePaymentCashout = @"{{
                                'originatingBatch': {0},
                                'paymentDetail' : {1} 
                            }}";

        private const string SampleReturnedPaymentString = @"{{
                                'returnedPaymentDetails' : [
                                    {0}    
                                ]            
                            }}";

        private const string SamplePaymentOriginatingBatch = @"{{
                                'batchId' : '{0}',
                                'clientBatchId' : '{1}',
                                'clientProgramId' : '{2}',
                                'programId' : '{3}'
                            }}";
    }
}
