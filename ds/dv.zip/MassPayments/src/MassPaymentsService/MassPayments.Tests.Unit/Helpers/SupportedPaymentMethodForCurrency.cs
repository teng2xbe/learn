﻿using System.Collections.Generic;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Unit.Helpers
{
    public static class SupportedPaymentMethodForCurrency
    {
        public static Dictionary<string, List<PaymentMethod>> GetSupportedPaymentMethodForCurrency()
        {
            var dic = new Dictionary<string, List<PaymentMethod>>();
            dic.Add("USD", new List<PaymentMethod>{PaymentMethod.ACH});
            dic.Add("CAD", new List<PaymentMethod>{PaymentMethod.ACH});
            return dic;
        } 
    }
}
