﻿using MassPayments.Domain.Entities;
using MassPayments.Managers.FileProcessing;

namespace MassPayments.Tests.Unit.Helpers
{
    public class TestFileProcessor : FileProcessor
    {
        public TestFileProcessor(File file) : base(file)
        {
        }

        protected override string GetFileJsonSchema()
        {
            return "MEOW";
        }
    }
}
