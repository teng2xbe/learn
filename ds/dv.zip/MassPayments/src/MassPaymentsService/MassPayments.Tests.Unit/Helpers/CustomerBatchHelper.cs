﻿using System;
using MassPayments.Domain.Entities;

namespace MassPayments.Tests.Unit.Helpers
{
    public class CustomerBatchHelper
    {
        private static CustomerBatchHelper instance;
        
        public static CustomerBatchHelper Instance
        {
            get { return instance ?? (instance = new CustomerBatchHelper()); }
            set { instance = value; }
        }

        private readonly Random randomSeed;

        private CustomerBatchHelper()
        {
            randomSeed = new Random(Guid.NewGuid().GetHashCode());
        }

        private string GetRandomString()
        {
            return randomSeed.Next(1, 100000).ToString();
        }

        private int GetRandomInt()
        {
            return randomSeed.Next(1, 100000);
        }

        public CustomerBatch CreateCustomerBatch(Customer customer)
        {
            return new CustomerBatch
            {   Id = GetRandomInt(),
                ExternalId = GetRandomString(),
                CustomerId = customer.Id,
                BatchReference = GetRandomString(),
                CreatedOnUTC = DateTime.UtcNow.AddDays(-20),
                ExternalCustomerId =  "TCUST"
            };
        }
    }
}
