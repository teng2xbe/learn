﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;

namespace MassPayments.Tests.Unit.Helpers
{
    public static class SupportedCurrency
    {
        public static Dictionary<string, Currency> GetSupportedCurrency()
        {
            return new Dictionary<string, Currency>
            {
                {"USD", new Currency("USD") {Status = CurrencyStatus.Enabled}}, 
                {"CAD", new Currency("CAD") {Status = CurrencyStatus.Enabled}}
            };
        }

        public static Dictionary<string, Currency> GetDisabledCurrency()
        {
            return new Dictionary<string, Currency>
            {
                {"USD", new Currency("USD") {Status = CurrencyStatus.Disabled}}, 
                {"CAD", new Currency("CAD") {Status = CurrencyStatus.Disabled}}
            };
        }
    }
}
