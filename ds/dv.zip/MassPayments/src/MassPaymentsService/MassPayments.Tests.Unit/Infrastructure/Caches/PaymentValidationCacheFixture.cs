﻿using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.Caches
{
    [TestFixture]
    public class PaymentValidationCacheFixture
    {
        [Test]
        public void PaymentValidationCacheGetsLoadedCorrectly()
        {
            var paymentData = new PaymentRequest();
            PaymentValidationCache.Instance.Initialize();

            Assert.AreEqual("id", PaymentValidationCache.Instance.GetById(() => paymentData.PaymentId));
            Assert.AreEqual("customerId", PaymentValidationCache.Instance.GetById(() => paymentData.PartnerAssignedCustomerId));
            Assert.AreEqual("paymentMethod", PaymentValidationCache.Instance.GetById(() => paymentData.PaymentMethod));
            Assert.AreEqual("beneficiary", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary));
            Assert.AreEqual("beneficiary.id", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Id));
            Assert.AreEqual("beneficiary.versionedOn", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.VersionedOn));
            Assert.AreEqual("beneficiary.type", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Type));
            Assert.AreEqual("beneficiary.firstName", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.FirstName));
            Assert.AreEqual("beneficiary.lastName", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.LastName));
            Assert.AreEqual("beneficiary.businessName", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.BusinessName));
            Assert.AreEqual("beneficiary.address", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Address));
            Assert.AreEqual("address.line1", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Address.AddressLine1));
            Assert.AreEqual("address.city", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Address.City));
            Assert.AreEqual("address.zipOrPostal", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Address.ZipOrPostalCode));
            Assert.AreEqual("address.stateOrProv", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Address.StateOrPovince));
            Assert.AreEqual("address.countryCode", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Address.CountryCode));
            Assert.AreEqual("beneficiary.address", PaymentValidationCache.Instance.GetById(() => paymentData.Beneficiary.Address));
        }
    }
}