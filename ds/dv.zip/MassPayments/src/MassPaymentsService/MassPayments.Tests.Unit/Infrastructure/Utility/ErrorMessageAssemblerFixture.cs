﻿using System;
using MassPayments.Infrastructure.Utility;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.Utility
{
    [TestFixture]
    public class ErrorMessageAssemblerFixture
    {
        [Test]
        public void ErrorMessageAssembler_works()
        {
            var ex = new Exception("test");

            var msg = ErrorMessageAssembler.GetErrorMessageFromException(ex);
            Assert.AreEqual("test\r\n\r\n", msg);

            msg = ErrorMessageAssembler.GetErrorMessageFromException(ex,"I go as first line");
            Assert.AreEqual("I go as first line\r\ntest\r\n\r\n", msg);
        }
    }
}
