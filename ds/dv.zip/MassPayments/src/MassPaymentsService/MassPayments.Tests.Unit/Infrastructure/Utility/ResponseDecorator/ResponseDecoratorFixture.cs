﻿using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.Utility.ResponseDecorator
{
    [TestFixture]
    public class ResponseDecoratorFixture
    {
        [Test]
        public void ResponseDecorator_MakeCorrectCalls()
        {
            
        }
    }
}
