﻿using MassPayments.Infrastructure.ServiceContext;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.ServiceContext
{
    [TestFixture]
    public class ServiceContextManagerFixture
    {
        [Test]
        public void ServiceContextManager_Return_Correctly()
        {
            var context = ServiceContextManager.Instance.CurrentContext;
            Assert.IsNotNullOrEmpty(context.Guid);
            Assert.IsNotNullOrEmpty(context.HostName);
        }
    }
}
