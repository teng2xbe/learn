﻿using System;
using MassPayments.Infrastructure.ProcessingMonitors;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.ProcessingMonitors
{
    [TestFixture]
    public class ProcessingMonitorEnumBasedFixture
    {
        [Test, ExpectedException(typeof(ArgumentException))]
        public void EnumCannotContainNegativeValues()
        {
            var processingMonitor = new ProcessingMonitorEnumBased<EnumContainingNegativeValue>("Test ProcessingMonitor");
        }

        [Test, ExpectedException(typeof(ArgumentException))]
        public void EnumShouldStartWithZero()
        {
            var processingMonitor = new ProcessingMonitorEnumBased<EnumNotStartingWithZero>("Test ProcessingMonitor");
        }

        [Test, ExpectedException(typeof(ArgumentException))]
        public void EnumCannotContainGaps()
        {
            var processingMonitor = new ProcessingMonitorEnumBased<EnumContainingGaps>("Test ProcessingMonitor");
        }

        [Test]
        public void EnumIsCorrect()
        {
            var processingMonitor = new ProcessingMonitorEnumBased<CorrectEnum>("Test ProcessingMonitor");
            Assert.AreEqual("Value1", processingMonitor.GetLevelName(0));
            Assert.AreEqual("Value2", processingMonitor.GetLevelName(1));
            Assert.AreEqual("Value3", processingMonitor.GetLevelName(2));

            Assert.DoesNotThrow((() =>
            {
                processingMonitor.StartLevel(CorrectEnum.Value1);
                processingMonitor.StartLevel(1);
                processingMonitor.StopLevel(CorrectEnum.Value2);
                processingMonitor.StopLevel(0);
            }));
        }

        [Test]
        public void EnumsWithImplicitValuesAreCorrect()
        {
            var processingMonitor = new ProcessingMonitorEnumBased<EnumWithImplicitValues>("Test ProcessingMonitor");
            Assert.AreEqual("Value1", processingMonitor.GetLevelName(0));
            Assert.AreEqual("Value2", processingMonitor.GetLevelName(1));
            Assert.AreEqual("Value3", processingMonitor.GetLevelName(2));

            Assert.DoesNotThrow((() =>
            {
                processingMonitor.StartLevel(EnumWithImplicitValues.Value1);
                processingMonitor.StartLevel(1);
                processingMonitor.StopLevel(EnumWithImplicitValues.Value2);
                processingMonitor.StopLevel(0);
            }));
        }

        private enum EnumContainingNegativeValue
        {
            Value1 = -1,
            Value2 = 0,
            Value3 = 1
        }

        private enum EnumNotStartingWithZero
        {
            Value1 = 1,
            Value2 = 2,
            Value3 = 3
        }

        private enum EnumContainingGaps
        {
            Value1 = 0,
            Value2 = 1,
            Value3 = 3
        }

        private enum CorrectEnum
        {
            Value1 = 0,
            Value2 = 1,
            Value3 = 2
        }

        private enum EnumWithImplicitValues
        {
            Value1,
            Value2,
            Value3
        }
    }
}
