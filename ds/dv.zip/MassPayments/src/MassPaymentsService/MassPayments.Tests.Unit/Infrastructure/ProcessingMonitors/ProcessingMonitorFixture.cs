﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using MassPayments.Infrastructure.ProcessingMonitors;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.ProcessingMonitors
{
    [TestFixture]
    public class ProcessingMonitorFixture
    {
        private ProcessingMonitor processingMonitor;
        private DateTime? now;

        private DateTime Now()
        {
            return this.now ?? DateTime.Now;
        }

        private void Sleep(int milliseconds)
        {
            if (this.now == null)
                Thread.Sleep(milliseconds);
            else
                now = now.Value.AddMilliseconds(milliseconds);
        }

        private void ReturnToRealTimerFromFakeOne()
        {
            this.now = null;
        }

        [SetUp]
        public void SetUp()
        {
            now = DateTime.Now;
            processingMonitor = new ProcessingMonitorWithExternalTimer("Test ProcessingMonitor", this.Now);
        }

        [TearDown]
        public void TearDown()
        {
            processingMonitor.StopWatching();
            processingMonitor = null;
            now = null;
        }

        class ProcessingMonitorWithExternalTimer : ProcessingMonitor
        {
            private readonly Func<DateTime> now;
            public ProcessingMonitorWithExternalTimer(string processName, Func<DateTime> now)
                : base(processName)
            {
                this.now = now;
            }

            protected override DateTime Now()
            {
                return now();
            }
        }


        #region Start-Stop arithmetics
        [Test]
        public void StartNegative()
        {
            Assert.Throws<ArgumentException>(() => processingMonitor.StartLevel(-1));
        }

        [Test]
        public void StopNegative()
        {
            Assert.Throws<ArgumentException>(() => processingMonitor.StopLevel(-2));
        }

        [Test]
        public void StartStarted()
        {
            processingMonitor.StartLevel(0);
            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StartLevel(0));
        }

        [Test]
        public void StopStopped()
        {
            processingMonitor.StopLevel(0);
            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StopLevel(0));
        }

        [Test]
        public void StopStartedStopped()
        {
            processingMonitor.StopLevel(0);
            processingMonitor.StartLevel(0);
            processingMonitor.StopLevel(0);

            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StopLevel(0));
        }

        [Test]
        public void StartStoppedStarted()
        {
            processingMonitor.StartLevel(0);
            processingMonitor.StopLevel(0);
            processingMonitor.StartLevel(0);

            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StartLevel(0));
        }

        [Test]
        public void StartOverLevel()
        {
            processingMonitor.StartLevel(0);
            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StartLevel(2));
        }

        [Test]
        public void StopOverLevel()
        {
            processingMonitor.StartLevel(0);
            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StopLevel(2));
        }

        [Test]
        public void StartWhenParentIsStopped()
        {
            processingMonitor.StopLevel(0);
            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StartLevel(1));
        }

        [Test]
        public void StartWhenParentIsStarted()
        {
            Assert.DoesNotThrow(() =>
            {
                processingMonitor.StartLevel(0);
                processingMonitor.StartLevel(1);
            });
        }

        [Test]
        public void StopWhenParentIsStopped()
        {
            Assert.DoesNotThrow(() =>
            {
                processingMonitor.StopLevel(0);
                processingMonitor.StopLevel(1);
            });
        }

        [Test]
        public void StopWhenParentIsStarted()
        {
            Assert.DoesNotThrow(() =>
            {
                processingMonitor.StartLevel(0);
                processingMonitor.StopLevel(1);
            });
        }

        [Test]
        public void StopParentWhenChildIsStarted()
        {
            processingMonitor.StartLevel(0);
            processingMonitor.StartLevel(1);
            Assert.Throws<ProcessingMonitorLevelsException>(() => processingMonitor.StopLevel(0));
        }

        [Test]
        public void StartParentWhenChildIsStopped()
        {
            Assert.DoesNotThrow(() =>
            {
                processingMonitor.StopLevel(0);
                processingMonitor.StopLevel(1);
                processingMonitor.StopLevel(2);
                processingMonitor.StartLevel(0);
                processingMonitor.StartLevel(1);
                processingMonitor.StopLevel(1);
            });
        }

        [Test]
        public void StartingLevelOnlyWhenParentsAreStartedAndStoppingOnlyWhenChildrenAreStoppedIsCorrectBehavior()
        {
            Assert.DoesNotThrow(() =>
            {
                processingMonitor.StartLevel(0);
                processingMonitor.StartLevel(1);
                processingMonitor.StopLevel(1);
                processingMonitor.StartLevel(1);
                processingMonitor.StopLevel(2);
                processingMonitor.StartLevel(2);
                processingMonitor.StopLevel(2);
                processingMonitor.StopLevel(1);
                processingMonitor.StopLevel(0);
            });
        }

        [Test]
        public void CheckInLevel()
        {
            Assert.DoesNotThrow(() =>
            {
                using (processingMonitor.InLevel(0))
                {
                }

                using (processingMonitor.InLevel(0))
                {
                    using (processingMonitor.InLevel(1))
                    {
                        processingMonitor.StartLevel(2);
                        processingMonitor.StopLevel(2);
                    }
                }
            });
        }
        #endregion


        #region CheckTimes
        [Test]
        public void CheckTimeout()
        {
            processingMonitor.StartLevel(0);
            this.Sleep(5);
            Assert.True(processingMonitor.CheckTimes(10, res => { }));
            this.Sleep(15);
            Assert.False(processingMonitor.CheckTimes(10, res => { }));
        }

        [Test]
        public void CheckRun0Run1Stop1LatestIs1()
        {
            processingMonitor.StartLevel(0);
            processingMonitor.StartLevel(1);
            this.Sleep(20);
            processingMonitor.StopLevel(1);
            Assert.True(processingMonitor.CheckTimes(10, null));
        }

        [Test]
        public void CheckRun0Run1Stop1Stop0Run0LatestIs0()
        {
            processingMonitor.StartLevel(0);
            processingMonitor.StartLevel(1);
            processingMonitor.StopLevel(1);
            processingMonitor.StopLevel(0);
            this.Sleep(20);
            processingMonitor.StartLevel(0);
            Assert.True(processingMonitor.CheckTimes(10, null));
        }
        #endregion

        #region Watching thread
        [Test]
        public void WatchingTimeoutAndThreshoudShouldBePositive()
        {
            var watchingParams = new ProcessingMonitorParams() { TimeoutBetweenChecksMs = 0, ThresholdToReportMs = 50 };
            Assert.Throws<ArgumentException>(() => processingMonitor.StartWatching(watchingParams, true, null));
            watchingParams = new ProcessingMonitorParams() { TimeoutBetweenChecksMs = -1, ThresholdToReportMs = 50 };
            Assert.Throws<ArgumentException>(() => processingMonitor.StartWatching(watchingParams, true, null));
            watchingParams = new ProcessingMonitorParams() { TimeoutBetweenChecksMs = 10, ThresholdToReportMs = 0 };
            Assert.Throws<ArgumentException>(() => processingMonitor.StartWatching(watchingParams, true, null));
            watchingParams = new ProcessingMonitorParams() { TimeoutBetweenChecksMs = 10, ThresholdToReportMs = -1 };
            Assert.Throws<ArgumentException>(() => processingMonitor.StartWatching(watchingParams, true, null));
        }

        [Test]
        public void StartStopWatchingThread()
        {
            var watchingParams = new ProcessingMonitorParams() { TimeoutBetweenChecksMs = 10, ThresholdToReportMs = 50 };
            Assert.True(processingMonitor.StartWatching(watchingParams, true, null));
            Assert.False(processingMonitor.StartWatching(watchingParams, false, null), "Thread should be already started");
            Assert.True(processingMonitor.StopWatching());
            Assert.False(processingMonitor.StopWatching(), "Thread should be already started");
            Assert.True(processingMonitor.StartWatching(watchingParams, false, null));
        }

        private void CheckResultsWereChangedOnce(List<ProcessingMonitorCheckResult> results, bool fromTrueToFalse)
        {
            Assert.AreEqual(1, results.Count(res => !string.IsNullOrEmpty(res.StatusChangeMessage)));
            var changedAt = results.FindIndex(res => !string.IsNullOrEmpty(res.StatusChangeMessage));
            Assert.True(results.Take(changedAt).ToList().TrueForAll(res => (res.IsOk == fromTrueToFalse)));
            Assert.True(results.Skip(changedAt).ToList().TrueForAll(res => (!res.IsOk == fromTrueToFalse)));
        }

        private void WatchingThreadNoEvents(bool needInitialization)
        {
            var watchingParams = new ProcessingMonitorParams() { TimeoutBetweenChecksMs = 10, ThresholdToReportMs = 50 };
            var results = new List<ProcessingMonitorCheckResult>();
            Assert.True(processingMonitor.StartWatching(watchingParams, needInitialization, results.Add));
            this.Sleep(100);
            Assert.True(processingMonitor.StopWatching());

            // the next check is not reliable on timeouts like 10 ms, and I don't want to make these tests slow
            //Assert.True((9 <= results.Count && results.Count <= 11));

            if (needInitialization)
            {
                // was initialized (i.e. event happened) on creation; looking for events 50+ ms ago, 100 ms passed
                CheckResultsWereChangedOnce(results, true);
            }
            else
            {
                // not initialized; not levels exist at all; everything is ok
                Assert.True(results.TrueForAll(res => res.IsOk));
                Assert.True(results.TrueForAll(res => string.IsNullOrEmpty(res.StatusChangeMessage)));
            }
        }

        // this test includes races between watching thread and main thread; 
        //can be falsely positive on small timeouts in loaded environments, like continuous integration servers
        [Test, Explicit]
        public void WatchingThreadNoEventsInitialized()
        {
            ReturnToRealTimerFromFakeOne(); // this test checks races between watching thread and main thread; cannot use fake timer
            WatchingThreadNoEvents(true);
        }

        [Test]
        public void WatchingThreadNoEventsNonInitialized()
        {
            ReturnToRealTimerFromFakeOne(); // this test checks races between watching thread and main thread; cannot use fake timer
            WatchingThreadNoEvents(false);
        }

        // this test includes races between watching thread and main thread; 
        //can be falsely positive on small timeouts in loaded environments, like continuous integration servers
        [Test, Explicit]
        public void WatchingThreadCatchesFailedAndRestored()
        {
            ReturnToRealTimerFromFakeOne(); // this test checks races between watching thread and main thread; cannot use fake timer
            var results = new List<ProcessingMonitorCheckResult>();
            var watchingParams = new ProcessingMonitorParams() { TimeoutBetweenChecksMs = 10, ThresholdToReportMs = 50 };

            Assert.True(processingMonitor.StartWatching(watchingParams, true, results.Add));
            processingMonitor.StartLevel(0);
            this.Sleep(20);
            Assert.True(processingMonitor.StopWatching());

            Assert.True(results.Count > 0);
            Assert.AreEqual(0, results.Count(res => !res.IsOk)); // looking for events 50+ ms ago, but only 20 ms passed
            Assert.AreEqual(0, results.Count(res => !string.IsNullOrEmpty(res.StatusChangeMessage))); // looking for events 50+ ms ago, but only 20 ms passed

            Assert.True(processingMonitor.StartWatching(watchingParams, true, results.Add));
            this.Sleep(40);
            Assert.True(processingMonitor.StopWatching());

            CheckResultsWereChangedOnce(results, true);  // looking for events 50+ ms ago, 60 ms passed

            results.Clear();

            Assert.True(processingMonitor.StartWatching(watchingParams, true, results.Add));
            this.Sleep(20);
            processingMonitor.StopLevel(0);
            this.Sleep(20);
            Assert.True(processingMonitor.StopWatching());

            Assert.IsFalse(results.First().IsOk);
            Assert.IsTrue(results.Last().IsOk);

            CheckResultsWereChangedOnce(results, false); // process looked stopped, but now is working again
        }
        #endregion
    }
}
