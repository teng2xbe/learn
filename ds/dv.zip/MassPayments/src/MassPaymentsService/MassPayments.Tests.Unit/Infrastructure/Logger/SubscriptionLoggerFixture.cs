﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.Subscription;
using MassPayments.Infrastructure.Logger;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Infrastructure.Logger
{
    [TestFixture]
    public class SubscriptionLoggerFixture
    {
        [SetUp]
        public void Setup()
        {
            SubscriptionLogMapper.Instance = MockRepository.GenerateMock<ISubscriptionLogMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            SubscriptionLogMapper.Instance = null;
        }

        [Test]
        public void LogRequest_MakeCorrectCalls()
        {
            var subscription = new ApiChannelSubscription
            {
                Id = 123
            };
            
            SubscriptionLogMapper.Instance.Expect(slm => slm.Insert(Arg<SubscriptionLog>.Is.Anything));
            SubscriptionLogger.Instance.LogRequest(subscription,"test");

            SubscriptionLogMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void LogResponse_MakeCorrectCalls()
        {
            var subscription = new ApiChannelSubscription
            {
                Id = 123
            };

            SubscriptionLogMapper.Instance.Expect(slm => slm.Insert(Arg<SubscriptionLog>.Is.Anything));
            SubscriptionLogger.Instance.LogResponse(subscription, "test");

            SubscriptionLogMapper.Instance.VerifyAllExpectations();
        }
    }
}
