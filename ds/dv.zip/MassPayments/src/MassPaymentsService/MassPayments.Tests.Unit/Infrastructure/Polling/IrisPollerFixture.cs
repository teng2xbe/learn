﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using MassPayments.ActionHandlers;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Gateways.Iris;
using MassPayments.Gateways.Iris.Mappers;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.Polling;
using MassPayments.Managers.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MockHttp.MockHttp;
using NUnit.Framework;
using Rhino.Mocks;
using SharedUtilities;

namespace MassPayments.Tests.Unit.Infrastructure.Polling
{
    [TestFixture]
    public class IrisPollerFixture
    {
        private IPublisher<Payment, CustomerBatch, Customer> publisher;

        [SetUp]
        public void Setup()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            PaymentStatusMapper.Instance = MockRepository.GenerateMock<IPaymentStatusMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            publisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentStatusUpdatedPublisher),publisher);
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
            PaymentStatusMapper.Instance = null;
            EventLogger.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            CustomerBatchMapper.Instance = null;
            PartnerMapper.Instance = null;
            CustomerMapper.Instance = null;
        }

        [Test]
        public void CallIrisQueue_MakeCorrectCalls()
        {
            var statusChanges = new List<PaymentStatusChange>
            {
                new PaymentStatusChange
                {
                    PaymentId = 1,
                    Status = 0
                }
            };

            PaymentStatusMapper.Instance.Expect(psm => psm.GetPaymentStatusChanges()).Return(statusChanges);
            PaymentMapper.Instance.Expect(pm => pm.UpdatePaymentStatus(1, PaymentStatus.SanctionCleared));
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<List<int>>.Is.Anything)).Return(new List<Payment> {new Payment(1) {CustomerBatchId = 1} });
            PaymentStatusMapper.Instance.Expect(psm => psm.MovePaymentStatusChangeToArchive(Arg<int>.Is.Anything));
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch());
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            CustomerMapper.Instance.Expect(c => c.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(new List<Customer> { new Customer()});
            publisher.Expect(p => p.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            IrisQueuePoller.Instance.CallIris();

            PaymentStatusMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            publisher.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void IrisPollerConstructPaymentIdStrings_Correctly()
        {
            var dic = new Dictionary<string, List<int>>
            {
                { "test" , new List<int> { 1,2,3}},
                { "test1" , new List<int> { 4,5,6}}
            };
            Assert.AreEqual(new List<string> { "MPtest-1", "MPtest-2", "MPtest-3", "MPtest1-4", "MPtest1-5", "MPtest1-6" }, IrisWsPoller.CreatePaymentIdList(dic));

            dic = new Dictionary<string, List<int>>();
            Assert.AreEqual(new List<string> { }, IrisWsPoller.CreatePaymentIdList(dic));

            dic = null;
            Assert.AreEqual(new List<string> { }, IrisWsPoller.CreatePaymentIdList(dic));

        }

        [Test]
        public void CallIrisQueue_Errors_MakeCorrectCalls()
        {
            var statusChanges = new List<PaymentStatusChange>
            {
                new PaymentStatusChange
                {
                    PaymentId = 1,
                    Status = 0
                }
            };

            PaymentStatusMapper.Instance.Expect(psm => psm.GetPaymentStatusChanges()).Return(statusChanges);
            PaymentMapper.Instance.Expect(pm => pm.UpdatePaymentStatus(1, PaymentStatus.SanctionCleared)).Throw(new Exception());
            PaymentStatusMapper.Instance.Expect(psm => psm.MovePaymentStatusChangeToError(Arg<int>.Is.Anything, Arg<string>.Is.Anything));

            IrisQueuePoller.Instance.CallIris();

            PaymentStatusMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void ResponseFromIrisGetsPassedToPaymentManager()
        {
            var mockHttp = new MockHttpMessageHandler();
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            var uri = new Uri(Settings.GetStringValue("IRIS.StatusPath"));

            mockHttp.When(uri.GetLeftPart(UriPartial.Path))
                    .Respond("application/json", "{'GetPaymentStatusResult':{'Message':'Success','PaymentBlockMessage':[{'Id':'MPHyperWallet-11','Status':0},{'Id':'MPHyperWallet-22','Status':1},{'Id':'MPHyperWallet-33','Status':2},{'Id':'MPHyperWallet-44','Status':3}]}}");

            var irisPoller = new IrisWsPoller(mockHttp, paymentManager);
            var paymentIds = new List<int> { 11, 22, 33, 44 };
            var returnResult = new Dictionary<string, List<int>>();
            returnResult.Add("HyperWallet", paymentIds);
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentIdsAndPartnerCodesByStatus(PaymentStatus.Committed)).Return(returnResult);

            irisPoller.CallIris();

            var args = paymentManager.GetArgumentsForCallsMadeOn(pm => pm.UpdatePaymentBlockStatuses(Arg<List<PaymentBlockMessage>>.Is.Anything));
            var paymentBlockMessages = (List<PaymentBlockMessage>)args[0][0];

            Assert.AreEqual(args.Count, 1);
            Assert.AreEqual(4, paymentBlockMessages.Count);
            Assert.AreEqual("MPHyperWallet-11", paymentBlockMessages[0].Id);
            Assert.AreEqual(IrisPaymentStatus.Unblock, paymentBlockMessages[0].Status);
            Assert.AreEqual("MPHyperWallet-22", paymentBlockMessages[1].Id);
            Assert.AreEqual(IrisPaymentStatus.Block, paymentBlockMessages[1].Status);
            Assert.AreEqual("MPHyperWallet-33", paymentBlockMessages[2].Id);
            Assert.AreEqual(IrisPaymentStatus.Unknown, paymentBlockMessages[2].Status);
            Assert.AreEqual("MPHyperWallet-44", paymentBlockMessages[3].Id);
            Assert.AreEqual(IrisPaymentStatus.PermanentBlock, paymentBlockMessages[3].Status);
        }

        [Test]
        public void ResponseFromIrisGets_Logged_WhenNotSuccessfull()
        {
            var mockHttp = new MockHttpMessageHandler();
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            var uri = new Uri(Settings.GetStringValue("IRIS.StatusPath"));

            mockHttp.When(uri.GetLeftPart(UriPartial.Path))
                    .Respond("application/json", "{'GetPaymentStatusResult':{'Message':'NotSuccess','PaymentBlockMessage':[{'Id':'MPHyperWallet-11','Status':0},{'Id':'MPHyperWallet-22','Status':1},{'Id':'MPHyperWallet-33','Status':2},{'Id':'MPHyperWallet-44','Status':3}]}}");

            var irisPoller = new IrisWsPoller(mockHttp, paymentManager);
            var paymentIds = new List<int> { 11, 22, 33, 44 };
            var returnResult = new Dictionary<string, List<int>>();
            returnResult.Add("HyperWallet", paymentIds);
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentIdsAndPartnerCodesByStatus(PaymentStatus.Committed)).Return(returnResult);
            irisPoller.CallIris();

            paymentManager.Expect(pm => pm.UpdatePaymentBlockStatuses(Arg<List<PaymentBlockMessage>>.Is.Anything)).Repeat.Never();
            EventLogger.Instance.Expect(
                el => el.WriteExceptionToEventLog(Arg<Exception>.Is.Anything, Arg<string>.Matches(s => s == "IrisPoller"), Arg<string>.Is.Anything));
        }

        [Test]
        public void ShortQueryStringWillMakeSingleCall()
        {
            var mockHttp = new MockHttpMessageHandler();
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            var uri = new Uri(Settings.GetStringValue("IRIS.StatusPath"));

            mockHttp.When(uri.GetLeftPart(UriPartial.Path))
                  .Respond("application/json", "{'GetPaymentStatusResult':{'Message':'Success','PaymentBlockMessage':[{'Id':'MPHyperWallet-11','Status':0},{'Id':'MPHyperWallet-22','Status':1},{'Id':'MPHyperWallet-33','Status':2},{'Id':'MPHyperWallet-44','Status':3}]}}");

            var irisPoller = new IrisWsPoller(mockHttp, paymentManager);
            var paymentIds = new List<int> { 11, 22, 33, 44 };
            var returnResult = new Dictionary<string, List<int>>();
            returnResult.Add("HyperWallet", paymentIds);
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentIdsAndPartnerCodesByStatus(PaymentStatus.Committed)).Return(returnResult);


            irisPoller.CallIris();

            paymentManager.AssertWasCalled(pm => pm.UpdatePaymentBlockStatuses(null), options => options.Repeat.Once().IgnoreArguments());
        }

        [Test]
        public void LongQueryStringWillMakeMultipleCalls()
        {
            var mockHttp = new MockHttpMessageHandler();
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            var uri = new Uri(Settings.GetStringValue("IRIS.StatusPath"));

            mockHttp.When(uri.GetLeftPart(UriPartial.Path))
                 .Respond("application/json", "{'GetPaymentStatusResult':{'Message':'Success','PaymentBlockMessage':[{'Id':'MPHyperWallet-11','Status':0},{'Id':'MPHyperWallet-22','Status':1},{'Id':'MPHyperWallet-33','Status':2},{'Id':'MPHyperWallet-44','Status':3}]}}");

            var irisPoller = new IrisWsPoller(mockHttp, paymentManager);
            var paymentIds = new List<int>();

            for (var i = 1; i < 20000; i++)
                paymentIds.Add(i);
            var returnResult = new Dictionary<string, List<int>>();
            returnResult.Add("HyperWallet", paymentIds);
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentIdsAndPartnerCodesByStatus(PaymentStatus.Committed)).Return(returnResult);

            irisPoller.CallIris();
            paymentManager.AssertWasCalled(pm => pm.UpdatePaymentBlockStatuses(Arg<List<PaymentBlockMessage>>.Is.Anything),
                options => options.Repeat.Times(8).IgnoreArguments());
        }

        [Test]
        public void MakeMultipleCallsWhenResponseStatusIs_414()
        {
            var mockHttp = new MockedHttpMessagehandler();
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            var uri = new Uri(Settings.GetStringValue("IRIS.StatusPath"));

            var irisPoller = new IrisWsPoller(mockHttp, paymentManager);
            var paymentIds = new List<int>();

            for (var i = 1; i < 6; i++)
                paymentIds.Add(i);
            var returnResult = new Dictionary<string, List<int>>();
            returnResult.Add("HyperWallet", paymentIds);
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentIdsAndPartnerCodesByStatus(PaymentStatus.Committed)).Return(returnResult);

            irisPoller.CallIris();
            Assert.AreEqual(9, mockHttp.TimesCalled); 
        }

        public class MockedHttpMessagehandler : HttpMessageHandler
        {
            private int timesCalled;

            public MockedHttpMessagehandler()
            {
                timesCalled = 0;
            }

            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
            {
                timesCalled ++;
                return Task.FromResult(new HttpResponseMessage(HttpStatusCode.RequestUriTooLong));
            }

            public int TimesCalled { get { return timesCalled; } }
        }
    }
}
