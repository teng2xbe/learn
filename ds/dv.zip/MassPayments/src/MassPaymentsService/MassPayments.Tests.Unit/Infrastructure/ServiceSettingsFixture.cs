﻿using System.Runtime.Remoting;
using MassPayments.Infrastructure;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;
using SettingsManager.Interfaces;

namespace MassPayments.Tests.Unit.Infrastructure
{
    [TestFixture]
    public class ServiceSettingsFixture
    {
        private SettingsManager.Interfaces.IServiceSettings mockedSetting;
        private SettingsManager.Interfaces.ICctServiceSecurityTokenSettings mockedTokenSetting;
        [SetUp]
        public void SetUp()
        {
            mockedTokenSetting = MockRepository.GenerateMock<SettingsManager.Interfaces.ICctServiceSecurityTokenSettings>();
            mockedSetting = MockRepository.GenerateMock<SettingsManager.Interfaces.IServiceSettings>();
            ServiceSettings.Instance = new ServiceSettings(mockedSetting, mockedTokenSetting);
        }

        [TearDown]
        public void TearDown()
        {
            ServiceSettings.Instance = null;
            mockedSetting = null;
            mockedTokenSetting = null;
        }

        [Test]
        public void GetCctServiceSecurityToken_MakeCorrectCalls()
        {
            mockedTokenSetting.Expect(s => s.GetActiveSecurityToken()).Return("abc");

            ServiceSettings.Instance.GetCctServiceSecurityToken();

            mockedTokenSetting.VerifyAllExpectations();
        }

        [Test]
        public void GetIntValue_makeCorrectCalls()
        {
            mockedSetting.Expect(s => s.GetIntValue(Arg<string>.Is.Anything)).Return(1);
            ServiceSettings.Instance.GetIntValue("key");
            mockedSetting.VerifyAllExpectations();
        }
        [Test]
        public void GetStringValue_makeCorrectCalls()
        {
            mockedSetting.Expect(s => s.GetStringValue(Arg<string>.Is.Anything)).Return("value");
            ServiceSettings.Instance.GetStringValue("key");
            mockedSetting.VerifyAllExpectations();
        }
        [Test]
        public void GetbooleanValue_makeCorrectCalls()
        {
            mockedSetting.Expect(s => s.GetBooleanValue(Arg<string>.Is.Anything)).Return(true);
            ServiceSettings.Instance.GetBooleanValue("key");
            mockedSetting.VerifyAllExpectations();
        }

        [Test]
        public void GetIntValueWithDefault_makeCorrectCalls()
        {
            mockedSetting.Expect(s => s.GetIntValue(Arg<string>.Is.Anything,Arg<int>.Is.Anything)).Return(1);
            ServiceSettings.Instance.GetIntValue("key",1);
            mockedSetting.VerifyAllExpectations();
        }
        [Test]
        public void GetStringValueWithDefault_makeCorrectCalls()
        {
            mockedSetting.Expect(s => s.GetStringValue(Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return("value");
            ServiceSettings.Instance.GetStringValue("key","defaultValue");
            mockedSetting.VerifyAllExpectations();
        }
        [Test]
        public void GetbooleanValueWithDefault_makeCorrectCalls()
        {
            mockedSetting.Expect(s => s.GetBooleanValue(Arg<string>.Is.Anything,Arg<bool>.Is.Anything)).Return(true);
            ServiceSettings.Instance.GetBooleanValue("key",true);
            mockedSetting.VerifyAllExpectations();
        }
    }
}
