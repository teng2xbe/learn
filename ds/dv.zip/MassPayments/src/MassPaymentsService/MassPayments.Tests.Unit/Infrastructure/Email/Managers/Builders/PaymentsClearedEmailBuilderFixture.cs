﻿using System.Collections.Generic;
using MassPayments.Infrastructure.Email.Domain;
using MassPayments.Infrastructure.Email.Enums;
using MassPayments.Infrastructure.Email.Managers;
using MassPayments.Infrastructure.Email.Managers.Builders;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.Email.Managers.Builders
{
    [TestFixture]
    public class PaymentsClearedEmailBuilderFixture
    {
        [Test]
        public void BuildEmail_ConstructsEmailProperly()
        {
            var emailTemplate = new EmailTemplateManager().GetEmailTemplate(EmailType.PaymentsCleared);

            var dataParams = new TemplateDataParameters
            {
                {"@PAYMENT_METHOD", "Cat-fax"},
                {"@NUM_AGGREGATED_PAYMENTS", "17"},
                {"@CUSTOMER_ID", "1234ABC"},
                {"@CURRENCY_CODE", "CAD"},
                {"@AGGREGATED_AMOUNT", "100.20"}
            };

            var toAddresses = new List<string> {"customer@email.com", "blah@blah.com"};

            var populatedEmail = new PaymentsClearedEmailBuilder().BuildEmail(emailTemplate, toAddresses, dataParams);

            Assert.That(populatedEmail.Body, Contains.Substring("Please book a CAD"));
            Assert.That(populatedEmail.Body, Contains.Substring("Cat-fax"));
            Assert.That(populatedEmail.Body, Contains.Substring("17"));
            Assert.That(populatedEmail.Body, Contains.Substring("100.20"));
            Assert.That(populatedEmail.Body, Contains.Substring("1234ABC"));
            Assert.That(populatedEmail.Body, Contains.Substring("CAD"));
            Assert.IsFalse(populatedEmail.IsBodyHtml);
            Assert.AreEqual("customer@email.com", populatedEmail.To[0].Address);
            Assert.AreEqual("blah@blah.com", populatedEmail.To[1].Address);
            Assert.AreEqual("Meowmeow Env: WUMassPayments OutOfHolding Order for 1234ABC", populatedEmail.Subject);
        }
    }
}
