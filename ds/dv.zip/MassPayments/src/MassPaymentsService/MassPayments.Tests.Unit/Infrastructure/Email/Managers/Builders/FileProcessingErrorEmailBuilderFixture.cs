﻿using System.Collections.Generic;
using MassPayments.Infrastructure.Email.Domain;
using MassPayments.Infrastructure.Email.Enums;
using MassPayments.Infrastructure.Email.Managers;
using MassPayments.Infrastructure.Email.Managers.Builders;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.Email.Managers.Builders
{
    [TestFixture]
    public class FileProcessingErrorEmailBuilderFixture
    {
        [Test]
        public void BuildEmail_ConstructsEmailProperly()
        {
            var emailTemplate = new EmailTemplateManager().GetEmailTemplate(EmailType.FileProcessingError);

            var dataParams = new TemplateDataParameters
            {
                {"@FILENAME", "meow.cat"},
                {"@ERROR_MESSAGE", "UH OH!!"},
                {"@ERROR_DETAILS", "Stuff done bad"},
                {"@ERROR_TIMESTAMP", "2015 some time"}
            };

            var toAddresses = new List<string> {"customer@email.com", "blah@blah.com"};

            var populatedEmail = new FileProcessingErrorEmailBuilder().BuildEmail(emailTemplate, toAddresses, dataParams);

            Assert.That(populatedEmail.Body, Contains.Substring("MPS has  encountered error parsing a file"));
            Assert.That(populatedEmail.Body, Contains.Substring("meow.cat"));
            Assert.That(populatedEmail.Body, Contains.Substring("UH OH!!"));
            Assert.That(populatedEmail.Body, Contains.Substring("Stuff done bad"));
            Assert.That(populatedEmail.Body, Contains.Substring("2015 some time"));
            Assert.IsFalse(populatedEmail.IsBodyHtml);
            Assert.AreEqual("customer@email.com", populatedEmail.To[0].Address);
            Assert.AreEqual("blah@blah.com", populatedEmail.To[1].Address);
            Assert.AreEqual("Meowmeow Env: Mass Payment Service Errors for meow.cat", populatedEmail.Subject);
        }
    }
}
