﻿using System;
using System.ComponentModel;
using MassPayments.Infrastructure.Email.Domain;
using MassPayments.Infrastructure.Email.Enums;
using MassPayments.Infrastructure.Email.Managers;
using MassPayments.Infrastructure.Email.Providers;
using MassPayments.Infrastructure.Email.Providers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Infrastructure.Email.Managers
{
    [TestFixture]
    public class EmailTemplateManagerFixture
    {
        [SetUp]
        public void SetUp()
        {
            EmailTemplateManager.EnvironmentName = null;
        }

        [TearDown]
        public void TearDown()
        {
            EmailTemplateManager.EnvironmentName = null;
        }

        [Test]
        public void GetEmailTemplate_Throws_ForUnknownEmailType()
        {
            Assert.Throws<InvalidEnumArgumentException>(() => new EmailTemplateManager().GetEmailTemplate((EmailType) 999));
        }

        [Test]
        public void GetEmailTemplate_ReturnsCorrectContent_ForPaymentsClearedEmail()
        {
            EmailTemplate confirmationEmail = new EmailTemplateManager().GetEmailTemplate(EmailType.PaymentsCleared);

            Assert.That(confirmationEmail.Body, Is.StringStarting("Please book a"));
            Assert.That(confirmationEmail.Body, Contains.Substring("Instructions:"));
            Assert.That(confirmationEmail.FromAddress, Is.EqualTo("WUMassPayments_noreply@westernunion.com"));
            Assert.That(confirmationEmail.FromName, Is.EqualTo("WUMassPayments - Do Not Reply"));
            Assert.That(confirmationEmail.Subject, Is.EqualTo("Meowmeow Env: WUMassPayments OutOfHolding Order for @CUSTOMER_ID"));
        }

        [Test]
        public void GetEmailTemplate_ReturnsCorrectContent_ForFileProcessingErrorEmail()
        {
            EmailTemplate errorEmail = new EmailTemplateManager().GetEmailTemplate(EmailType.FileProcessingError);

            Assert.That(errorEmail.Body, Is.StringStarting("MPS has  encountered error parsing a file @FILENAME."));
            Assert.That(errorEmail.Body, Contains.Substring("Error Timestamp: @ERROR_TIMESTAMP"));
            Assert.That(errorEmail.FromAddress, Is.EqualTo("wumasspaymentsNA@westernunion.com"));
            Assert.That(errorEmail.FromName, Is.EqualTo("Mass Payment Service - Do Not Reply"));
            Assert.That(errorEmail.Subject, Is.EqualTo("Meowmeow Env: Mass Payment Service Errors for @FILENAME"));
        }

        [Test]
        public void GetEmailTemplate_ReturnsCorrectContent_ForRebookOutOfHoldingFailedEmail()
        {
            EmailTemplate errorEmail = new EmailTemplateManager().GetEmailTemplate(EmailType.RebookOutOfHoldingFailed);

            Assert.That(errorEmail.Body, Is.StringStarting("The mass payment out of holding order failed to book for customer"));
            Assert.That(errorEmail.Body, Contains.Substring("Amount = @AGGREGATE_AMOUNT @CURRENCY"));
            Assert.That(errorEmail.FromAddress, Is.EqualTo("WUMassPayments_noreply@westernunion.com"));
            Assert.That(errorEmail.FromName, Is.EqualTo("WUMassPayments - Do Not Reply"));
            Assert.That(errorEmail.Subject, Is.EqualTo("Meowmeow Env: WU Mass Payments – order failed to book for customer @CUSTOMER_ID"));
        }

        [Test]
        public void GetEmailTemplate_ReturnsCorrectSubject_WhenEnvironmentNameMissing()
        {
            EmailTemplateManager.EnvironmentName = string.Empty;

            EmailTemplate errorEmail = new EmailTemplateManager().GetEmailTemplate(EmailType.RebookOutOfHoldingFailed);
            Assert.That(errorEmail.Subject, Is.EqualTo("WU Mass Payments – order failed to book for customer @CUSTOMER_ID"));
        }

        [Test]
        public void GetEmailTemplate_ThrowsExceptionIfBodyIsEmpty()
        {
            ResourceProvider.Instance = MockRepository.GenerateMock<IResourceProvider>();
            ResourceProvider.Instance.Expect(r => r.GetResourceString(Arg<string>.Is.Anything)).Return("");

            Assert.Throws<ArgumentException>(() => new EmailTemplateManager().GetEmailTemplate(EmailType.RebookOutOfHoldingFailed));
        }
    }
}
