﻿using System;
using System.Collections.Generic;
using System.Linq;
using MassPayments.Infrastructure.Email.Domain;
using MassPayments.Infrastructure.Email.Enums;
using MassPayments.Infrastructure.Email.Managers;
using MassPayments.Infrastructure.Email.Managers.Builders;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Infrastructure.Email.Managers.Builders
{
    [TestFixture]
    public class RebookOutOfHoldingFailedBuilderFixture
    {
        [Test]
        public void BuildEmail_ConstructsEmailProperly()
        {
            var emailTemplate = new EmailTemplateManager().GetEmailTemplate(EmailType.RebookOutOfHoldingFailed);

            var dataParams = new TemplateDataParameters
            {
                {"@CUSTOMER_ID", "1234"},
                {"@ERROR_MESSAGE", "Blah Message"},
                {"@CUSTOMER_NAME", "Blah Customer"},
                {"@AGGREGATE_AMOUNT", "123.00"},
                {"@CURRENCY", "CAD"},
                {"@NUMBER_OF_PAYMENTS", "10"}
            };

            var toAddresses = new List<string> { "customer@email.com", "blah@blah.com" };

            var populatedEmail = new PaymentsClearedEmailBuilder().BuildEmail(emailTemplate, toAddresses, dataParams);

            Assert.That(populatedEmail.Body, Contains.Substring("1234"));
            Assert.That(populatedEmail.Body, Contains.Substring("Blah Message"));
            Assert.That(populatedEmail.Body, Contains.Substring("Blah Customer"));
            Assert.That(populatedEmail.Body, Contains.Substring("123.00"));
            Assert.That(populatedEmail.Body, Contains.Substring("CAD"));
            Assert.That(populatedEmail.Body, Contains.Substring("10"));
            Assert.IsFalse(populatedEmail.IsBodyHtml);
            Assert.AreEqual("customer@email.com", populatedEmail.To[0].Address);
            Assert.AreEqual("blah@blah.com", populatedEmail.To[1].Address);
            Assert.AreEqual("Meowmeow Env: WU Mass Payments – order failed to book for customer 1234", populatedEmail.Subject);
        }
    }
}
