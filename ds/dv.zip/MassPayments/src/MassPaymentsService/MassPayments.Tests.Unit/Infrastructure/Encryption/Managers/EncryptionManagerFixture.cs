﻿using System;
using System.IO;
using System.Text;
using System.Threading;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Encryption.Exceptions;
using MassPayments.Infrastructure.Encryption.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;
using File = System.IO.File;

namespace MassPayments.Tests.Unit.Infrastructure.Encryption.Managers
{
    [TestFixture]
    public class EncryptionManagerFixture
    {
        private Partner partner;
        
        [SetUp]
        public void SetUp()
        {
            CryptographyMapper.Instance = MockRepository.GenerateMock<ICryptograpyMapper>();
            partner = CreatePartner(1);
        }

        [TearDown]
        public void TearDown()
        {
            // Reset in case any of the tests decide to hard-code a value.
            CryptographyMapper.Instance = null;            
        }

        [Test]
        public void DecryptFileContents_Decrypts_Correctly()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");

            string decryptedContent = encryptionManager.DecryptFileContents("encryptedTestFile.json.asc", partner);

            Assert.AreEqual("decrypted string", decryptedContent);
            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test, Explicit("uat setup")]
        public void DecryptFileContents_Decrypts_Correctly_for_UAT()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("welcome1");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("mpstestprivatekey.asc");
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("HWpublickeytest.asc");

            //HPWL_clientBatches_27_20141211.json.pgp ; bankBatches_33_2014-12-09.json.asc
            string decryptedContent = encryptionManager.DecryptFileContents("HPWL_beneficiaryChanges_40448_20150102.json.pgp", partner);

            Assert.IsTrue(decryptedContent.Contains("wallets"));
            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void DecryptFileContents_ThrowsDecryptionFailedException_ForFailedFileDecryption()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = new EncryptionManager();

            // Attempting to decrypt unencrypted file.
            Assert.Throws<DecryptionFailedException>(() => encryptionManager.DecryptFileContents("largeTestjsonFile.txt", partner));
        }

        [Test]
        public void DecryptString_Decrypts_Correctly()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            const string encryptedContents = @"-----BEGIN PGP MESSAGE-----
Version: GnuPG v2

hQEMA0dN/DYoP5AqAQf+JfPYF3BrbUHdOqZCqQnkEB7curIFBHJ4sfcTIDJ+9rbe
On+v9R7NcLU4Hn+3YOyKkJIklnE603QLtZqCC72WIQOe2q207//zRCGz9+kq4E2A
oETzktQVRi9oMASWtJ1Qqrpbf0Go3pF4yLwtpOHNvO4O9/MzFt2I75L/wj901NUE
Eb3lCjsgSkL9rTjsgrbKnlF/UpGxFUTbfEIo1EWIZrsK2l8IgpAGCl2khJ56K7xP
uqJBNSGfkr/5W3XuXnhmk/B9XMa5M11HHhnS62oAgg9uYff8mQ0652TX7fcY2tII
G58gG72uIRRMOjx928ZK0UfoLezZau89uv8CDGxXn9JOATvtWDZEiCdjLV8mjTeG
KVlc59BJ3ePSEE1lYBt4h9NREf4Oz3WPFQoYhf8PSP4jHdZ0JYjzR7OYNDQroNR7
JAliZMYxuQG2Tk6ioL4k
=SO6r
-----END PGP MESSAGE-----
";

            string decryptedContent = encryptionManager.DecryptString(encryptedContents, partner);

            Assert.AreEqual("decrypted string", decryptedContent);
            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void DecryptString_ThrowsDecryptionFailedException_ForFailedStringDecryption()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = new EncryptionManager();

            // Attempting to decrypt unencrypted string.
            Assert.Throws<DecryptionFailedException>(() => encryptionManager.DecryptString("this is not an encrypted string!!", partner));
        }

        [Test]
        public void EncryptString_EncryptsCorrectly_WithoutCompression_ForSmallString()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            const string plainText = "THIS SHOULD GET ENCRYPTED AND THEN DECRYPTED AND THEN EVERYTHING IS BACK TO NORMAL!!!!#)(R*()#*$(#*$";

            string encryptedString = encryptionManager.EncryptString(partner, plainText, false);

            Assert.IsTrue(encryptedString.StartsWith("-----BEGIN PGP MESSAGE-----"));

            string decryptedString = encryptionManager.DecryptString(encryptedString, partner);

            Assert.AreEqual(plainText, decryptedString);
            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void EncryptString_EncryptsCorrectly_WithCompression_ForSmallString()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            const string plainText = "THIS SHOULD GET ENCRYPTED AND THEN DECRYPTED AND THEN EVERYTHING IS BACK TO NORMAL!!!!#)(R*()#*$(#*$";

            string encryptedString = encryptionManager.EncryptString(partner, plainText, true);

            Assert.IsTrue(encryptedString.StartsWith("-----BEGIN PGP MESSAGE-----"));

            string decryptedString = encryptionManager.DecryptString(encryptedString, partner);

            Assert.AreEqual(plainText, decryptedString);
            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void EncryptString_EncryptsCorrectly_WithCompression_ForLargeString()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            string hugePlaintext = File.ReadAllText("largeTestjsonFile.txt");

            string encryptedString = encryptionManager.EncryptString(partner, hugePlaintext, true);

            Assert.IsTrue(encryptedString.StartsWith("-----BEGIN PGP MESSAGE-----"));

            string decryptedString = encryptionManager.DecryptString(encryptedString, partner);

            Assert.AreEqual(hugePlaintext, decryptedString);
            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void EncryptString_YieldsSmallerEncryptedString_WhenCompressionUsedOnLargeString()
        {
            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            string hugePlaintext = File.ReadAllText("largeTestjsonFile.txt");

            string uncompressedEncryptedString = encryptionManager.EncryptString(partner, hugePlaintext, false);
            string compressedEncryptedString = encryptionManager.EncryptString(partner, hugePlaintext, true);

            // Let's assert that compressed content is at most half the size of the uncompressed content.
            Assert.IsTrue(uncompressedEncryptedString.Length > (compressedEncryptedString.Length*2));
        }

        [Test]
        public void EncryptString_ThrowsEncryptionFailedException_ForFailedStringEncryption()
        {
            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("C:\\this\\does\\not\\exist\\publickey.asc");

            Assert.Throws<EncryptionFailedException>(() => encryptionManager.EncryptString(partner, "content", true));
        }

        [Test]
        public void DoesContentLookEncrypted_ReturnsTrue_WhenContentBeginsWithAcsiiGuardHeader()
        {
            const string content = "-----BEGIN PGP MESSAGE-----\r\nBLAHBLAHBLAHBLAH";

            Assert.IsTrue(new EncryptionManager().DoesContentLookEncrypted(content));
        }

        [Test]
        public void DoesContentLookEncrypted_ReturnsFalse_WhenContentDoesNotBeginWithAcsiiGuardHeader()
        {
            const string content = "this is just regular content.";

            Assert.IsFalse(new EncryptionManager().DoesContentLookEncrypted(content));
        }

        [Test(Description = "Note that keys have validUntil property - currently used set till 2015-12-08")]
        public void EncryptString_DoesEncryptPDFFileWithValidPublicKey()
        {
            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKeyUAT.asc");

            var content = File.ReadAllText("UATTestFile.pdf");
            string encryptedContent = "";
            Assert.DoesNotThrow(() => encryptedContent = encryptionManager.EncryptString(partner, content, false));

            Assert.IsTrue(new EncryptionManager().DoesContentLookEncrypted(encryptedContent));
        }

        [Test(Description = "Note that keys have validUntil property - currently used set till 2015-12-08 ")]
        public void EncryptString_Throws_WithInvalidPublicKey()
        {
            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKeyInvalid.asc");

            var content = File.ReadAllText("UATTestFile.pdf");
            string encryptedContent = "";
            Assert.Throws<EncryptionFailedException>(() => encryptedContent = encryptionManager.EncryptString(partner, content, false));
        }

        [Test(Description = "Note that keys have validUntil property - currently used set till 2015-12-08")]
        public void EncryptPDFAsString_AndDecrypt_Works()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            var content = File.ReadAllBytes("UATTestFile.pdf");
            byte[] encryptedContent = {};
            Assert.DoesNotThrow(() => encryptedContent = encryptionManager.EncryptBytes(partner, content, false));

            byte[] decryptedContent = {};
            Assert.DoesNotThrow(() => decryptedContent = encryptionManager.DecryptBytes(encryptedContent, partner));
            Assert.AreEqual(content, decryptedContent);

            File.WriteAllBytes("test_encrypted.pdf",encryptedContent);
        }

        [Test]
        public void DecryptBytes_Decrypts_Correctly()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            const string encryptedContents = @"-----BEGIN PGP MESSAGE-----
Version: GnuPG v2

hQEMA0dN/DYoP5AqAQf+JfPYF3BrbUHdOqZCqQnkEB7curIFBHJ4sfcTIDJ+9rbe
On+v9R7NcLU4Hn+3YOyKkJIklnE603QLtZqCC72WIQOe2q207//zRCGz9+kq4E2A
oETzktQVRi9oMASWtJ1Qqrpbf0Go3pF4yLwtpOHNvO4O9/MzFt2I75L/wj901NUE
Eb3lCjsgSkL9rTjsgrbKnlF/UpGxFUTbfEIo1EWIZrsK2l8IgpAGCl2khJ56K7xP
uqJBNSGfkr/5W3XuXnhmk/B9XMa5M11HHhnS62oAgg9uYff8mQ0652TX7fcY2tII
G58gG72uIRRMOjx928ZK0UfoLezZau89uv8CDGxXn9JOATvtWDZEiCdjLV8mjTeG
KVlc59BJ3ePSEE1lYBt4h9NREf4Oz3WPFQoYhf8PSP4jHdZ0JYjzR7OYNDQroNR7
JAliZMYxuQG2Tk6ioL4k
=SO6r
-----END PGP MESSAGE-----
";

            var encryptedBytes = Encoding.UTF8.GetBytes(encryptedContents);
            var decryptedBytes = encryptionManager.DecryptBytes(encryptedBytes, partner);
            Assert.AreEqual("decrypted string", Encoding.UTF8.GetString(decryptedBytes,3,decryptedBytes.Length-3)); //omit the byte order mark (BOM)

            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void EncryptFile_EncryptsCorrectly_WithoutCompression()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            string filePath = "largeTestJsonFile.txt";
            string encryptedString = encryptionManager.EncryptFileContent(partner, filePath, false);

            Assert.IsTrue(encryptedString.StartsWith("-----BEGIN PGP MESSAGE-----"));

            string decryptedString = encryptionManager.DecryptString(encryptedString, partner);

            var fileContent = File.ReadAllText(filePath);

            Assert.AreEqual(fileContent, decryptedString);
            CryptographyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetPublicKeyPathForPartner_Works()
        {
            var gpgRoot = @"gpgRoot";
            var keyDirectory = Path.Combine(gpgRoot, @"test\public");
            if (!Directory.Exists(keyDirectory))
            {
                Directory.CreateDirectory(keyDirectory);
            }

            var keyPath = Path.Combine(keyDirectory, "test.asc");
            if (!File.Exists(keyPath))
            {
                File.CreateText(keyPath);
            }

            var encryptionManager = new EncryptionManager();

            string loadedkeyPath = encryptionManager.GetPublicKeyPathForPartner(new Partner { Code = "test" });
            Assert.AreEqual(keyPath, loadedkeyPath);

            int retry = 0;
            while (File.Exists(keyPath))
            {
                if (retry > 2)
                    break;

                try
                {
                    Directory.Delete(gpgRoot, true);
                }
                catch (Exception)
                {
                    Thread.Sleep(100);
                }
                retry++;
            }
        }

        [Test]
        public void GetPrivateKeyPathForPartner_Works()
        {
            var gpgRoot = @"gpgRoot";
            var keyDirectory = Path.Combine(gpgRoot, @"test\private");
            if (!Directory.Exists(keyDirectory))
            {
                Directory.CreateDirectory(keyDirectory);
            }

            var keyPath = Path.Combine(keyDirectory, "test1.asc");
            if (!File.Exists(keyPath))
            {
                File.CreateText(keyPath);
            }

            var encryptionManager = new EncryptionManager();

            string loadedkeyPath = encryptionManager.GetPrivateKeyPathForPartner(new Partner { Code = "test" });
            Assert.AreEqual(keyPath, loadedkeyPath);

            int retry = 0;
            while (File.Exists(keyPath))
            {
                if (retry > 2)
                    break;

                try
                {
                    Directory.Delete(gpgRoot, true);
                }
                catch (Exception)
                {
                    Thread.Sleep(100);
                }
                retry ++;
            }
        }

        private Partner CreatePartner(int partnerId)
        {
            return new Partner
            {
                Id = partnerId,
                Code = "HPWL",
                FilePrefix = "HPWL"
            };
        }
    }
}

