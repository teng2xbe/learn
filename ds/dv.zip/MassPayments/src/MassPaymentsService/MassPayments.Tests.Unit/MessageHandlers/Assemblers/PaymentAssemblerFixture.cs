﻿using System;
using System.Collections.Generic;
using Common.Contracts.PAIN.Messages.Events;
using Common.Contracts.PAIN.Messages.ValueObjects;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.MessageHandlers.Assemblers;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.MessageHandlers.Assemblers
{
    [TestFixture]
    public class PaymentAssemblerFixture
    {
        [Test]
        public void AssembleReturnedPayment_ReturnsCorrectPayment_WhenPaymentReturnedByBrokerEvent_IsProvided()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(m => m.GetCurrencyDictionary())
                .Return((SupportedCurrency.GetSupportedCurrency()));

            var paymentEvent = new PaymentReturnedByBrokerEvent
            {
                PaymentId = 1,
                AmountReturned = 1m,
                AmountReturnedCurrency = "CAD",
                Reason = "returned by bank",
                UserName = "blah"
            };

            var result = PaymentAssembler.AssembleReturnedPayment(paymentEvent);

            Assert.IsInstanceOf<ReturnedPayment>(result);
            Assert.AreEqual(PaymentStatus.Returned, result.PaymentStatus);
            Assert.AreEqual(paymentEvent.PaymentId, result.Id);
            Assert.AreEqual(paymentEvent.Reason, result.RejectReason);
            Assert.AreEqual(paymentEvent.AmountReturned, ((ReturnedPayment) result).ReturnAmount.Amount);
            Assert.AreEqual(paymentEvent.AmountReturnedCurrency, ((ReturnedPayment) result).ReturnAmount.Currency.Code);
            Assert.AreEqual(paymentEvent.UserName, ((ReturnedPayment) result).UserName);
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
            CurrencyCacheMapper.Instance = null;
        }

        [Test]
        public void AssemblePainGenerationFailedPayments_ReturnsCorrectPayment()
        {
            var failEvent = new PaymentsPainFileGenerationFailedEvent
            {
                FailedPaymentInfos = new List<PaymentInfo>
                {
                    new PaymentInfo
                    {
                        PaymentId = 123,
                        RejectReason = "TestReason",
                        PaymentStatus = "Rejected",
                        DateProcessedInGPG = DateTime.MinValue
                    }
                }
            };
            var assembledPayments = PaymentAssembler.AssemblePainGenerationFailedPayments(failEvent);
            Assert.AreEqual(1, assembledPayments.Count);
            Assert.AreEqual(failEvent.FailedPaymentInfos[0].PaymentId, assembledPayments[0].Id);
            Assert.AreEqual(failEvent.FailedPaymentInfos[0].RejectReason, assembledPayments[0].RejectReason);
            Assert.AreEqual(PaymentStatus.Rejected, assembledPayments[0].PaymentStatus);
            Assert.AreEqual(failEvent.FailedPaymentInfos[0].DateProcessedInGPG.ToShortDateString(), assembledPayments[0].GPGProcessedUTC.Value.ToShortDateString());
        }

        [Test]
        public void AssembleFromPaymentsUpdatedByGpgEvent_Maps_Correctly()
        {
            var message = new PaymentsUpdatedByGpgEvent
            {
                Payments = new List<PaymentInfo>
                {
                    new PaymentInfo
                    {
                        DateProcessedInGPG = DateTime.Parse("2016-09-13"),
                        PaymentId = 1,
                        PaymentStatus = "Rejected",
                        RejectReason = "999 : rejected by bank",
                        PaymentSource = "1"
                    },
                    new PaymentInfo
                    {
                        DateProcessedInGPG = DateTime.Parse("2016-09-13"),
                        PaymentId = 2,
                        PaymentStatus = "Accepted",
                        PaymentSource = "2"
                    }
                }
            };

            var result = PaymentAssembler.AssembleFromPaymentsUpdatedByGpgEvent(message);

            Assert.AreEqual(2, result.Count);

            Assert.AreEqual(PaymentStatus.Rejected, result[0].PaymentStatus);
            Assert.AreEqual(message.Payments[0].PaymentId, result[0].Id);
            Assert.AreEqual(message.Payments[0].DateProcessedInGPG, result[0].GPGProcessedUTC);
            Assert.AreEqual(message.Payments[0].RejectReason, result[0].RejectReason);

            Assert.AreEqual(PaymentStatus.Released, result[1].PaymentStatus);
            Assert.AreEqual(message.Payments[1].PaymentId, result[1].Id);
            Assert.AreEqual(message.Payments[1].DateProcessedInGPG, result[1].GPGProcessedUTC);
        }
    }
}
