﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Common.Contracts.PAIN.Messages.Events;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.LocalMessages.Commands;
using MassPayments.Managers.Interfaces;
using MassPayments.MessageHandlers.PainFileGeneration;
using NServiceBus;
using NServiceBus.Logging;
using NServiceBus.Testing;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.MessageHandlers.PainFileGeneration
{
    [TestFixture]
    public class PainGenerationSuccessEventHandlerFixture
    {
        private ILog loggerMock;
        private IBus busMock;
        private IPaymentManager paymentManagerMock;

        [TestFixtureSetUp]
        public void SetupFixture()
        {
            Test.Initialize(b =>
            {
                b.Conventions().DefiningEventsAs(x => x.Namespace.Contains("PAIN.Messages.Events"));
                b.AssembliesToScan(GetAssembliesToScan());
            });
        }

        private static IEnumerable<Assembly> GetAssembliesToScan()
        {
            return new[]
            {
                Assembly.LoadFrom("PAIN.Messages.dll"),
                Assembly.LoadFrom("NServiceBus.Testing.dll")
            };
        }


        [Test]
        public void MessageHandler_MakeCorrectCalls()
        {
            var failEvent = new PaymentsPainFileGeneratedEvent
            {
                PaymentIds = new List<int> { 123}
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painGenerationSuccessEventHandler = new PainGenerationSuccessEventHandler(paymentManagerMock, busMock, loggerMock);

            paymentManagerMock.Expect(m => m.UpdatePaymentStatusesBasedOnPainGeneration(Arg<List<Payment>>.Is.Anything, Arg<PaymentStatus>.Is.Anything));
            Test.Handler(bus => painGenerationSuccessEventHandler).OnMessage(failEvent);
            paymentManagerMock.VerifyAllExpectations();
        }

        [Test]
        public void MessageHandler_MakeCorrectCalls_WhenPaymentIds_IsEmpty()
        {
            var failEvent = new PaymentsPainFileGeneratedEvent
            {
                PaymentIds = new List<int> ()
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painGenerationSuccessEventHandler = new PainGenerationSuccessEventHandler(paymentManagerMock, busMock, loggerMock);

            Test.Handler(bus => painGenerationSuccessEventHandler).OnMessage(failEvent);

            loggerMock.AssertWasCalled(m=>m.Info(Arg<string>.Is.Anything));
            busMock.AssertWasNotCalled(m=>m.SendLocal(Arg<UpdatePaymentStatusToSentCommand>.Is.TypeOf));
            paymentManagerMock.AssertWasNotCalled(m => m.UpdatePaymentStatusesBasedOnPainGeneration(Arg<List<Payment>>.Is.Anything, Arg<PaymentStatus>.Is.Anything));
            paymentManagerMock.VerifyAllExpectations();
            loggerMock.VerifyAllExpectations();
            busMock.VerifyAllExpectations();
        }

        [Test]
        public void MessageHandler_MakeCorrectCalls_When_BatchProcessing_Fails()
        {
            var failEvent = new PaymentsPainFileGeneratedEvent
            {
                PaymentIds = new List<int> {1234}
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            paymentManagerMock.Expect(m => m.UpdatePaymentStatusesBasedOnPainGeneration(Arg<List<Payment>>.Is.Anything, Arg<PaymentStatus>.Is.Anything))
                .Throw(new Exception("something bad happens handling batch of payments. handling it individually."));

            var painGenerationSuccessEventHandler = new PainGenerationSuccessEventHandler(paymentManagerMock, busMock, loggerMock);

            Test.Handler(bus => painGenerationSuccessEventHandler).OnMessage(failEvent);

            loggerMock.AssertWasNotCalled(m => m.Info(Arg<string>.Is.Anything));
            paymentManagerMock.AssertWasCalled(m => m.UpdatePaymentStatusesBasedOnPainGeneration(Arg<List<Payment>>.Is.Anything, Arg<PaymentStatus>.Is.Anything));

            loggerMock.AssertWasCalled(m => m.ErrorFormat(Arg<string>.Is.Anything, Arg<object>.Is.Anything));
            busMock.AssertWasCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToSentCommand>.Is.TypeOf));
            
            paymentManagerMock.VerifyAllExpectations();
            loggerMock.VerifyAllExpectations();
            busMock.VerifyAllExpectations();
        }
    }
}
