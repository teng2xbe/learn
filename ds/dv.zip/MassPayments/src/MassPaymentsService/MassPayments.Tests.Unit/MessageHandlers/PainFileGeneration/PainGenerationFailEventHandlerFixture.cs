﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Common.Contracts.PAIN.Messages.Events;
using Common.Contracts.PAIN.Messages.ValueObjects;
using MassPayments.Domain.Entities;
using MassPayments.LocalMessages.Commands;
using MassPayments.Managers.Interfaces;
using MassPayments.MessageHandlers.PainFileGeneration;
using NServiceBus;
using NServiceBus.Logging;
using NServiceBus.Testing;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.MessageHandlers.PainFileGeneration
{
    [TestFixture]
    public class PainGenerationFailEventHandlerFixture
    {
        private ILog loggerMock;
        private IBus busMock;
        private IPaymentManager paymentManagerMock;

        [TestFixtureSetUp]
        public void SetupFixture()
        {
            Test.Initialize(b =>
            {
                b.Conventions().DefiningEventsAs(x => x.Namespace.Contains("PAIN.Messages.Events"));
                b.AssembliesToScan(GetAssembliesToScan());
            });
        }

        private static IEnumerable<Assembly> GetAssembliesToScan()
        {
            return new[]
            {
                Assembly.LoadFrom("PAIN.Messages.dll"),
                Assembly.LoadFrom("NServiceBus.Testing.dll")
            };
        }


        [Test]
        public void MessageHandler_MakeCorrectCalls()
        {
            var failEvent = new PaymentsPainFileGenerationFailedEvent
            {
                FailedPaymentInfos = new List<PaymentInfo>
                {
                    new PaymentInfo
                    {
                        PaymentId = 123,
                        RejectReason = "TestReason",
                        PaymentStatus = "Rejected",
                        DateProcessedInGPG = DateTime.MinValue
                    }
                }
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painGenerationFailEventHandler = new PainGenerationFailEventHandler(paymentManagerMock, busMock, loggerMock);

            paymentManagerMock.Expect(m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            Test.Handler(bus => painGenerationFailEventHandler).OnMessage(failEvent);

            paymentManagerMock.AssertWasCalled(m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            loggerMock.AssertWasNotCalled(m => m.ErrorFormat(Arg<string>.Is.Anything, Arg<object>.Is.Anything));
            busMock.AssertWasNotCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToRejectedCommand>.Is.TypeOf));

            paymentManagerMock.VerifyAllExpectations();
            busMock.VerifyAllExpectations();
            loggerMock.VerifyAllExpectations();
        }

        [Test]
        public void MessageHandler_MakeCorrectCalls_WhenExceptionOccurs()
        {
            var failEvent = new PaymentsPainFileGenerationFailedEvent
            {
                FailedPaymentInfos = new List<PaymentInfo>
                {
                    new PaymentInfo
                    {
                        PaymentId = 123,
                        RejectReason = "TestReason",
                        PaymentStatus = "Rejected",
                        DateProcessedInGPG = DateTime.MinValue
                    }
                }
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painGenerationFailEventHandler = new PainGenerationFailEventHandler(paymentManagerMock, busMock, loggerMock);

            paymentManagerMock.Expect(m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything))
                .Throw(new Exception("something bad happens handling batch of payments. handling it individually."));

            Test.Handler(bus => painGenerationFailEventHandler).OnMessage(failEvent);

            paymentManagerMock.AssertWasCalled(m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            loggerMock.AssertWasCalled(m => m.ErrorFormat(Arg<string>.Is.Anything, Arg<object>.Is.Anything));
            busMock.AssertWasCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToRejectedCommand>.Is.TypeOf));

            paymentManagerMock.VerifyAllExpectations();
            busMock.VerifyAllExpectations();
            loggerMock.VerifyAllExpectations();
        }
    }
}
