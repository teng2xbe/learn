﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Common.Contracts.PAIN.Messages.Events;
using Common.Contracts.PAIN.Messages.ValueObjects;
using MassPayments.Domain.Entities;
using MassPayments.LocalMessages.Commands;
using MassPayments.Managers.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.MessageHandlers.Pain;
using MassPayments.Tests.Unit.Helpers;
using NServiceBus;
using NServiceBus.Logging;
using NServiceBus.Testing;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.MessageHandlers.Pain
{
    [TestFixture]
    public class PainMessageHandlerFixture
    {
        private ILog loggerMock;
        private IBus busMock;
        private IPaymentManager paymentManagerMock;
         
        [TestFixtureSetUp]
        public void SetupFixture()
        {
            Test.Initialize(b =>
            {
                b.Conventions().DefiningEventsAs(x => x.Namespace.Contains("PAIN.Messages.Events"));
                b.AssembliesToScan(GetAssembliesToScan());
            });
        }

        private static IEnumerable<Assembly> GetAssembliesToScan()
        {
            return new[]
            {
                Assembly.LoadFrom("PAIN.Messages.dll"),
                Assembly.LoadFrom("NServiceBus.Testing.dll")
            };
        }

        [TestFixtureTearDown]
        public void TearDownFixture()
        {
            loggerMock = null;
            busMock = null;
            paymentManagerMock = null;
        }

        [Test]
        public void Handles_PaymentReturnedByBrokerEvent_Correctly()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(m => m.GetCurrencyDictionary())
                .Return((SupportedCurrency.GetSupportedCurrency()));

            var message = new PaymentReturnedByBrokerEvent
            {
                PaymentId = 1,
                AmountReturned = 5m,
                AmountReturnedCurrency = "CAD",
                Reason = "returned by bank",
                UserName = "blah"
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();

            var painMessageHandler = new PainMessageHandler(busMock, paymentManagerMock, loggerMock);

            Test.Handler(bus => painMessageHandler).OnMessage(message);

            paymentManagerMock.AssertWasCalled(m => m.UpdateReturnedPaymentsFromPain(Arg<List<Payment>>.Is.Anything));
            paymentManagerMock.VerifyAllExpectations();
            CurrencyCacheMapper.Instance.VerifyAllExpectations();
            loggerMock = null;
            busMock = null;
            paymentManagerMock = null;
        }

        [Test]
        public void Handles_PaymentsUpdatedByGpgEvent_Correctly()
        {
            var message = new PaymentsUpdatedByGpgEvent { Payments = new List<PaymentInfo> { new PaymentInfo() } };

            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painMessageHandler = new PainMessageHandler(busMock, paymentManagerMock, loggerMock);

            Test.Handler(bus => painMessageHandler).OnMessage(message);

            paymentManagerMock.AssertWasCalled(
                m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            paymentManagerMock.VerifyAllExpectations();
            loggerMock = null;
            busMock = null;
            paymentManagerMock = null;
        }

        [Test]
        public void Handles_PaymentsUpdatedByGpgEvent_ThrowsException_Then_ReprocessIndividually_ForRejected()
        {
            var message = new PaymentsUpdatedByGpgEvent { Payments = new List<PaymentInfo> { new PaymentInfo { PaymentStatus = "Rejected" } } };

            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painMessageHandler = new PainMessageHandler(busMock, paymentManagerMock, loggerMock);

            paymentManagerMock.Expect(m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything))
                .Throw(new Exception("something bad happens handling batch of payments. handling it individually."));

            Test.Handler(bus => painMessageHandler).OnMessage(message);

            paymentManagerMock.AssertWasCalled(
                m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            busMock.AssertWasCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToRejectedCommand>.Is.TypeOf));
            busMock.AssertWasNotCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToReleasedCommand>.Is.TypeOf));
            loggerMock.AssertWasCalled(m => m.ErrorFormat(Arg<string>.Is.Anything, Arg<object>.Is.Anything));

            loggerMock.VerifyAllExpectations();
            busMock.VerifyAllExpectations();
            paymentManagerMock.VerifyAllExpectations();
            loggerMock = null;
            busMock = null;
            paymentManagerMock = null;
        }

        [Test]
        public void Handles_PaymentsUpdatedByGpgEvent_ThrowsException_Then_ReprocessIndividually_ForReleased()
        {
            var message = new PaymentsUpdatedByGpgEvent { Payments = new List<PaymentInfo> { new PaymentInfo { PaymentStatus = "Accepted" } } };

            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painMessageHandler = new PainMessageHandler(busMock, paymentManagerMock, loggerMock);

            paymentManagerMock.Expect(m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything))
                .Throw(new Exception("something bad happens handling batch of payments. handling it individually."));

            Test.Handler(bus => painMessageHandler).OnMessage(message);

            paymentManagerMock.AssertWasCalled(
                m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            busMock.AssertWasNotCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToRejectedCommand>.Is.TypeOf));
            busMock.AssertWasCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToReleasedCommand>.Is.TypeOf));
            loggerMock.AssertWasCalled(m => m.ErrorFormat(Arg<string>.Is.Anything, Arg<object>.Is.Anything));

            loggerMock.VerifyAllExpectations();
            busMock.VerifyAllExpectations();
            paymentManagerMock.VerifyAllExpectations();
            loggerMock = null;
            busMock = null;
            paymentManagerMock = null;
        }

        [Test]
        public void Handles_PaymentsUpdatedByGpgEvent_ThrowsException_Then_ReprocessIndividually_ForMultiple()
        {
            var message = new PaymentsUpdatedByGpgEvent
            {
                Payments = new List<PaymentInfo>
                {
                    new PaymentInfo { PaymentStatus = "Rejected" },
                    new PaymentInfo { PaymentStatus = "Accepted" }
                }
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painMessageHandler = new PainMessageHandler(busMock, paymentManagerMock, loggerMock);

            paymentManagerMock.Expect(m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything))
                .Throw(new Exception("something bad happens handling batch of payments. handling it individually."));

            Test.Handler(bus => painMessageHandler).OnMessage(message);

            paymentManagerMock.AssertWasCalled(
                m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            busMock.AssertWasCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToRejectedCommand>.Is.TypeOf));
            busMock.AssertWasCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToReleasedCommand>.Is.TypeOf));
            loggerMock.AssertWasCalled(m => m.ErrorFormat(Arg<string>.Is.Anything, Arg<object>.Is.Anything));

            busMock.VerifyAllExpectations();
            paymentManagerMock.VerifyAllExpectations();
            loggerMock.VerifyAllExpectations();
            loggerMock = null;
            busMock = null;
            paymentManagerMock = null;
        }

        [Test]
        public void Handles_PaymentsUpdatedByGpgEvent_ShouldNotReprocessIndividually_WhenNoException()
        {
            var message = new PaymentsUpdatedByGpgEvent
            {
                Payments = new List<PaymentInfo>
                {
                    new PaymentInfo { PaymentStatus = "Rejected" },
                    new PaymentInfo { PaymentStatus = "Accepted" }
                }
            };
            loggerMock = MockRepository.GenerateMock<ILog>();
            busMock = MockRepository.GenerateMock<IBus>();
            paymentManagerMock = MockRepository.GenerateMock<IPaymentManager>();
            var painMessageHandler = new PainMessageHandler(busMock, paymentManagerMock, loggerMock);

            Test.Handler(bus => painMessageHandler).OnMessage(message);

            paymentManagerMock.AssertWasCalled(
                m => m.UpdatePaymentStatusBasedOnGPGAcceptance(Arg<List<Payment>>.Is.Anything));
            busMock.AssertWasNotCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToRejectedCommand>.Is.TypeOf));
            busMock.AssertWasNotCalled(m => m.SendLocal(Arg<UpdatePaymentStatusToReleasedCommand>.Is.TypeOf));
            loggerMock.AssertWasNotCalled(m=>m.ErrorFormat(Arg<string>.Is.Anything, Arg<object>.Is.Anything));
            busMock.VerifyAllExpectations();
            paymentManagerMock.VerifyAllExpectations();
            loggerMock.VerifyAllExpectations();

            loggerMock = null;
            busMock = null;
            paymentManagerMock = null;
        }
    }
}
