﻿using MassPayments.Domain.Entities;
using MassPayments.LocalMessages.Commands;
using MassPayments.Managers.BatchManaging;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.MessageHandlers.PaymentsJobs;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.MessageHandlers
{
    [TestFixture]
    public class PaymentCommandHandlerFixture
    {
        [SetUp]
        public void Setup()
        {
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CustomerBatchMapper.Instance = null;
        }

        [Test]
        public void PaymentCommandHandlers_Handles_UpdateBatchAndPaymentsAfterBookingCommand()
        {
            var customerBatchAmountManager = MockRepository.GenerateMock<ICustomerBatchAmountManager>();
            var customerBatchOrderManager = MockRepository.GenerateMock<ICustomerBatchOrderManager>();
            var handler = new PaymentCommandHandler(customerBatchAmountManager, customerBatchOrderManager);
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch());
            customerBatchAmountManager.Expect(c => c.AdjustBatchAmountAfterbooking(Arg<CustomerBatch>.Is.Anything));
            customerBatchOrderManager.Expect(c => c.UpdatePaymentsAfterBatchIsBooked(Arg<CustomerBatch>.Is.Anything));

            handler.Handle(new UpdateBatchAndPaymentsAfterBookingCommand());

            customerBatchAmountManager.VerifyAllExpectations();
            customerBatchOrderManager.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
        }
    }
}
