﻿using System;
using System.Collections.Generic;
using System.Reflection;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.LocalMessages.Commands;
using MassPayments.Managers.Interfaces;
using MassPayments.MessageHandlers.LocalMessagesHandler;
using NServiceBus.Testing;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.MessageHandlers.LocalMessagesHandler
{
    [TestFixture]
    public class UpdatePaymentStatusHandlerFixture
    {
        [TestFixtureSetUp]
        public void SetupFixture()
        {
            Test.Initialize(b =>
            {
                b.Conventions().DefiningCommandsAs(x => x.Namespace.Contains("MassPayments.LocalMessages.Commands"));
                b.AssembliesToScan(GetAssembliesToScan());
            });
        }

        private static IEnumerable<Assembly> GetAssembliesToScan()
        {
            return new[]
            {
                Assembly.LoadFrom("NServiceBus.Testing.dll")
            };
        }

        [Test]
        public void Handles_UpdatePaymentStatusToReleasedCommand_Correctly()
        {
        
            var message = new UpdatePaymentStatusToReleasedCommand
            {
                PaymentId = 1,
                DateProcessedInGpg = DateTime.Parse("2016-09-30")
            };
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            Test.Handler(bus => new UpdatePaymentStatusHandler(paymentManager)).OnMessage(message);

            paymentManager.AssertWasCalled
            (
                m => m.UpdatePaymentStatusBasedOnGPGAcceptance
                (
                    Arg<List<Payment>>.Matches
                    (
                        p => p[0].Id == message.PaymentId && p[0].GPGProcessedUTC == message.DateProcessedInGpg && p[0].PaymentStatus == PaymentStatus.Released
                    )
                )
            );
            paymentManager.VerifyAllExpectations();
        }

        [Test]
        public void Handles_UpdatePaymentStatusToRejectedCommand_Correctly()
        {

            var message = new UpdatePaymentStatusToRejectedCommand
            {
                PaymentId = 1,
                DateProcessedInGpg = DateTime.Parse("2016-09-30"),
                RejectReason = "blah"
            };
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            Test.Handler(bus => new UpdatePaymentStatusHandler(paymentManager)).OnMessage(message);

            paymentManager.AssertWasCalled
            (
                m => m.UpdatePaymentStatusBasedOnGPGAcceptance
                (
                    Arg<List<Payment>>.Matches
                    (
                        p => p[0].Id == message.PaymentId && p[0].GPGProcessedUTC == message.DateProcessedInGpg && 
                        p[0].PaymentStatus == PaymentStatus.Rejected && p[0].RejectReason == message.RejectReason
                    )
                )
            );
            paymentManager.VerifyAllExpectations();
        }

        [Test]
        public void Handles_UpdatePaymentStatusToSentCommand_Correctly()
        {

            var message = new UpdatePaymentStatusToSentCommand {PaymentId = 1};
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            Test.Handler(bus => new UpdatePaymentStatusHandler(paymentManager)).OnMessage(message);

            paymentManager.AssertWasCalled
            (
                m => m.UpdatePaymentStatusesBasedOnPainGeneration
                (
                    Arg<List<Payment>>.Matches(p => p[0].Id == message.PaymentId),
                    Arg<PaymentStatus>.Is.Equal(PaymentStatus.Sent)
                )
            );
            paymentManager.VerifyAllExpectations();
        }
    }
}
