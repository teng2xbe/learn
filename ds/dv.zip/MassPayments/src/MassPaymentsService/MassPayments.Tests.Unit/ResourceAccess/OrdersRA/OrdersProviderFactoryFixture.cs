﻿using MassPayments.Infrastructure;
using MassPayments.ResourceAccess.OrdersRA;
using NUnit.Framework;
using System.Configuration;
using SharedUtilities;

namespace MassPayments.Tests.Unit.ResourceAccess.OrdersRA
{
    [TestFixture]
    public class OrdersProviderFactoryFixture
    {

        [SetUp]
        public void Setup()
        {

        }

        [TearDown]
        public void TearDown()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.OrdersProvider"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        [Test]
        public void GetOrdersProvider_ReturnsSimulator_WhenSettingIsTrue()
        {
            var isSimulatorOn = Settings.GetBooleanValue("Simulator.OrdersProvider", false);
            Assert.IsTrue(isSimulatorOn);

            var provider = OrdersProviderFactory.GetOrdersProvider();
            Assert.AreEqual(typeof(OrdersProviderSimulator), provider.GetType());
        }

        [Test]
        public void GetOrdersProvider_ReturnsProvider_WhenSettingIsFalse()
        {

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.OrdersProvider"].Value = "false";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var isSimulatorOn = Settings.GetBooleanValue("Simulator.OrdersProvider", false);
            Assert.IsFalse(isSimulatorOn);

            var provider = OrdersProviderFactory.GetOrdersProvider();
            Assert.AreEqual(typeof(OrdersProvider), provider.GetType());
        }

    }
}
