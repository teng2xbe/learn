﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.ValueObjects;
using MassPayments.ResourceAccess.OrdersRA;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.ResourceAccess.OrdersRA
{
    [TestFixture]
    public class OrdersProviderSimulatorFixture
    {
        [Test]
        public void GetOrdersFundedStatus_ReportsResutls_ForValidOrderIds()
        {
            var request = new List<string>
            {
                "1234",
                "",
                "12",
                "1234456",
                "53466"
            };

            OrdersFundedStatusResult result = null;
            Assert.DoesNotThrow(() => result = new OrdersProviderSimulator().GetOrdersFundedStatus(request));

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Orders);
            Assert.AreEqual(5, result.Orders.Count);

            var result1 = result.Orders.Find(o => o.OrderId == "1234");
            Assert.AreEqual("1234", result1.OrderId);
            Assert.AreEqual(true, result1.IsOrderFound);
            Assert.AreEqual(false, result1.IsFunded);
            Assert.AreEqual(DateTime.MinValue, result1.FundedOnUtc);

            var result2 = result.Orders.Find(o => o.OrderId == "");
            Assert.AreEqual("", result2.OrderId);
            Assert.AreEqual(false, result2.IsFunded);
            Assert.AreEqual(false, result2.IsOrderFound);
            Assert.AreEqual(DateTime.MinValue, result2.FundedOnUtc);

            var result3 = result.Orders.Find(o => o.OrderId == "12");
            Assert.AreEqual("12", result3.OrderId);
            Assert.AreEqual(false, result3.IsFunded);
            Assert.AreEqual(false, result3.IsOrderFound);
            Assert.AreEqual(DateTime.MinValue, result3.FundedOnUtc);


            var result4 = result.Orders.Find(o => o.OrderId == "1234456");
            Assert.AreEqual("1234456", result4.OrderId);
            Assert.AreEqual(true, result4.IsFunded);
            Assert.AreEqual(true, result4.IsOrderFound);
            Assert.IsTrue(result4.FundedOnUtc > DateTime.MinValue);

            var result5 = result.Orders.Find(o => o.OrderId == "53466");
            Assert.AreEqual("53466", result5.OrderId);
            Assert.AreEqual(true, result5.IsOrderFound);
            Assert.AreEqual(false, result5.IsFunded);
            Assert.AreEqual(DateTime.MinValue, result5.FundedOnUtc);

        }

        [Test]
        public void GetOrderFundedStatus_ReturnsEmptyList_ForInvalidOrderId()
        {
            OrdersFundedStatusResult result = null;
            Assert.DoesNotThrow(() => result = new OrdersProviderSimulator().GetOrdersFundedStatus(new List<string>()));

            Assert.IsNotNull(result);
            Assert.IsNotNull(result.Orders);
            Assert.AreEqual(0, result.Orders.Count);
        }
    }
}
