﻿using MassPayments.ResourceAccess.BankInfoRA;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.ResourceAccess.BankAccountRA
{
    [TestFixture]
    public class ClientProviderSimulatorFixture
    {
        [Test]
        public void GetClientDetailById_ReturnValidClientDetailInfo()
        {
            var targetBankAccountId = "abc";
            var targetPartnerCode = "def";
            var simulatedProvider = BankInfoProviderFactory.GetBankInfoProvider();
            var bankAccountInfo = simulatedProvider.GetBankAccountById(targetBankAccountId, targetPartnerCode);
            Assert.IsNotNullOrEmpty(bankAccountInfo.Id);
            Assert.IsNotNullOrEmpty(bankAccountInfo.Status);
            Assert.IsNotNull(bankAccountInfo.LastUpdatedOn);
            Assert.IsNotNullOrEmpty(bankAccountInfo.AccountNumber);
            Assert.IsNotNullOrEmpty(bankAccountInfo.AccountType);
            Assert.IsNotNullOrEmpty(bankAccountInfo.BankName);
            Assert.IsNotNullOrEmpty(bankAccountInfo.CurrencyCode);
            Assert.IsNotNullOrEmpty(bankAccountInfo.RoutingCode);
            Assert.IsNotNullOrEmpty(bankAccountInfo.SwiftCode);
            Assert.IsNotNullOrEmpty(bankAccountInfo.AccountHolderName);
            Assert.True(bankAccountInfo.IsDirectDebit);
            Assert.IsNotNullOrEmpty(bankAccountInfo.AddressLine1);
            Assert.IsNotNullOrEmpty(bankAccountInfo.AddressLine2);
            Assert.IsNotNullOrEmpty(bankAccountInfo.AddressLine3);
            Assert.IsNotNullOrEmpty(bankAccountInfo.StateOrProvince);
            Assert.IsNotNullOrEmpty(bankAccountInfo.City);
            Assert.IsNotNullOrEmpty(bankAccountInfo.ZipOrPostalCode);
            Assert.IsNotNullOrEmpty(bankAccountInfo.CountryCode);
        }
    }
}
