﻿using System.Configuration;
using MassPayments.Infrastructure;
using MassPayments.ResourceAccess.BankInfoRA;
using NUnit.Framework;
using SharedUtilities;

namespace MassPayments.Tests.Unit.ResourceAccess.BankAccountRA
{
    [TestFixture]
    public class BankAccountProviderFactoryFixture
    {

        [SetUp]
        public void Setup()
        {

        }

        [TearDown]
        public void TearDown()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.BankInfoProvider"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        [Test]
        public void BankInfoProvider_ReturnsSimulator_WhenSettingIsTrue()
        {
            var isSimulatorOn = Settings.GetBooleanValue("Simulator.BankInfoProvider", false);
            Assert.IsTrue(isSimulatorOn);

            var provider = BankInfoProviderFactory.GetBankInfoProvider();
            Assert.AreEqual(typeof(BankInfoProviderSimulator), provider.GetType());
        }

        [Test]
        public void BankInfoProvider_ReturnsProvider_WhenSettingIsFalse()
        {

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.BankInfoProvider"].Value = "false";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var isSimulatorOn = Settings.GetBooleanValue("Simulator.BankInfoProvider", false);
            Assert.IsFalse(isSimulatorOn);

            var provider = BankInfoProviderFactory.GetBankInfoProvider();
            Assert.AreEqual(typeof(BankInfoProvider), provider.GetType());
        }

    }
}
