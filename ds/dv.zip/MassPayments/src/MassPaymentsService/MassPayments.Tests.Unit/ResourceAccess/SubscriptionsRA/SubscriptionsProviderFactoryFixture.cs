﻿using System.Configuration;
using MassPayments.Infrastructure;
using MassPayments.ResourceAccess.SubscriptionsRA;
using NUnit.Framework;
using SharedUtilities;

namespace MassPayments.Tests.Unit.ResourceAccess.SubscriptionsRA
{
    [TestFixture]
    public class SubscriptionsProviderFactoryFixture
    {

        [SetUp]
        public void Setup()
        {

        }

        [TearDown]
        public void TearDown()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.SubscriptionsProvider"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        [Test]
        public void GetSubscriptionsProvider_ReturnsSimulator_WhenSettingIsTrue()
        {
            var isSimulatorOn = Settings.GetBooleanValue("Simulator.SubscriptionsProvider", false);
            Assert.IsTrue(isSimulatorOn);

            var provider = SubscriptionsProviderFactory.GetSubscriptionsProvider();
            Assert.AreEqual(typeof(SubscriptionsProviderSimulator), provider.GetType());
        }

        [Test]
        public void GetSubscriptionsProvider_ReturnsProvider_WhenSettingIsFalse()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.SubscriptionsProvider"].Value = "false";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var isSimulatorOn = Settings.GetBooleanValue("Simulator.SubscriptionsProvider", false);
            Assert.IsFalse(isSimulatorOn);

            var provider = SubscriptionsProviderFactory.GetSubscriptionsProvider();
            Assert.AreEqual(typeof(SubscriptionsProvider), provider.GetType());
        }
    }
}
