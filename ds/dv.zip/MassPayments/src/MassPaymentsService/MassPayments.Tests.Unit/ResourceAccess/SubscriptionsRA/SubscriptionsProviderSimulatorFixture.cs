﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.ResourceAccess.SubscriptionsRA;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.ResourceAccess.SubscriptionsRA
{
    [TestFixture]
    public class SubscriptionsProviderSimulatorFixture
    {
        [Test]
        public void GetDomainEvent_ReturnsEvent()
        {
            PublishedNotification result = null;
            Assert.DoesNotThrow(() => result = new SubscriptionsProviderSimulator().GetPublishedNotification(Guid.Parse("377BABE9-F9FC-E511-B68C-847BEB04EBA9"), new Partner() { Id = 1 }));

            Assert.IsNotNull(result);
        }

        [Test]
        public void GetOrderFundedStatus_ReturnsEmptyList_ForInvalidOrderId()
        {
            PublishedNotification result = null;
            Assert.DoesNotThrow(() => result = new SubscriptionsProviderSimulator().GetPublishedNotification(Guid.Empty, new Partner() { Id = 1 }));

            Assert.IsNull(result);
        }
    }
}
