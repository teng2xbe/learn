﻿using System.Configuration;
using MassPayments.Infrastructure;
using MassPayments.ResourceAccess.ClientRA;
using NUnit.Framework;
using SharedUtilities;

namespace MassPayments.Tests.Unit.ResourceAccess.ClientRA
{
    [TestFixture]
    public class ClientProviderFactoryFixture
    {

        [SetUp]
        public void Setup()
        {

        }

        [TearDown]
        public void TearDown()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.ClientProvider"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        [Test]
        public void GetOrdersProvider_ReturnsSimulator_WhenSettingIsTrue()
        {
            var isSimulatorOn = Settings.GetBooleanValue("Simulator.ClientProvider", false);
            Assert.IsTrue(isSimulatorOn);

            var provider = ClientProviderFactory.GetClientProvider();
            Assert.AreEqual(typeof(ClientProviderSimulator), provider.GetType());
        }

        [Test]
        public void GetOrdersProvider_ReturnsProvider_WhenSettingIsFalse()
        {

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.ClientProvider"].Value = "false";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var isSimulatorOn = Settings.GetBooleanValue("Simulator.ClientProvider", false);
            Assert.IsFalse(isSimulatorOn);

            var provider = ClientProviderFactory.GetClientProvider();
            Assert.AreEqual(typeof(ClientProvider), provider.GetType());
        }

    }
}
