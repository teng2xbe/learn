﻿using MassPayments.ResourceAccess.ClientRA;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.ResourceAccess.ClientRA
{
    [TestFixture]
    public class BankAccountProviderSimulatorFixture
    {
        [Test]
        public void GetClientDetailById_ReturnValidClientDetailInfo()
        {
            var targetClientId = 1;
            var simulatedProvider = ClientProviderFactory.GetClientProvider();
            var clientDetailInfo = simulatedProvider.GetClientDetailById(targetClientId);
            Assert.AreEqual(targetClientId, clientDetailInfo.Id);
            Assert.IsNotNullOrEmpty(clientDetailInfo.AccountNumber);
            Assert.IsNotNullOrEmpty(clientDetailInfo.AddressLine1);
            Assert.IsNotNullOrEmpty(clientDetailInfo.AddressLine2);
            Assert.IsNotNullOrEmpty(clientDetailInfo.AddressLine3);
            Assert.IsNotNullOrEmpty(clientDetailInfo.City);
            Assert.IsNotNullOrEmpty(clientDetailInfo.CompanyName);
            Assert.IsNotNullOrEmpty(clientDetailInfo.CountryCode);
            Assert.IsNotNullOrEmpty(clientDetailInfo.DefaultUserName);
            Assert.IsNotNullOrEmpty(clientDetailInfo.InvoiceLanguageCode);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficeAddress);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficeFaxNumber);
            Assert.True(clientDetailInfo.OfficeId > 0);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficeLegalEntityLicenseNumber);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficeLegalEntityLongName);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficeLegalEntityShortName);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficeName);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficePhoneNumber);
            Assert.IsNotNullOrEmpty(clientDetailInfo.OfficeTollFreePhoneNumber);
            Assert.IsNotNullOrEmpty(clientDetailInfo.PostalCode);
            Assert.IsNotNullOrEmpty(clientDetailInfo.ProcessCenterCode);
            Assert.True(clientDetailInfo.ProcessCenterId > 0);
            Assert.IsNotNullOrEmpty(clientDetailInfo.State);
        }

        [Test]
        public void GetCustomerByExternalId_ReturnValidCustomer()
        {
            var targetClientExternalId = "TestId";
            var targetPartnerCode = "TestPartnerCode";
            var simulatedProvider = ClientProviderFactory.GetClientProvider();
            var customer = simulatedProvider.GetCustomerByExternalId(targetClientExternalId, targetPartnerCode);

            Assert.AreEqual(targetClientExternalId, customer.PartnerAssignedCustomerId);
            Assert.IsNotNullOrEmpty(customer.TransactionSystemCustomerExternalId);
            Assert.IsNotNullOrEmpty(customer.Name);
            Assert.IsNotNullOrEmpty(customer.CountryCode);
            Assert.IsNotNull(customer.SettlementCurrency);
            Assert.IsTrue(customer.TransactionSystemCustomerId > 0);
            Assert.IsTrue(customer.TransactionSystemId > 0);
        }
    }
}
