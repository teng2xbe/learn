﻿using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.ServiceProviders.CCTTMassPayments.Assemblers;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Batches;
using BookIncomingOrderRequest = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrderRequest;
using BookIncomingOrderRequestItem = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrderRequestItem;
using BookIncomingOrdersRequest = MassPayments.Domain.ValueObjects.Booking.BookIncomingOrdersRequest;
using DomainSettlementPaymentMethod = MassPayments.Domain.Enums.SettlementPaymentMethod;

namespace MassPayments.Tests.Unit.ServiceProviders.CCTTMassPayments.Assemblers
{
    [TestFixture]
    class OrderBookingAssemblerFixture
    {
        [Test]
        public void GetOrdersFromBookedIncomingOrder_MapsFieldsCorrectly()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new BookIncomingOrdersRequest
            {
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(Currency.USD, 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };
            var serviceRequest = OrderBookingAssembler.AssembleBookIncomingOrdersRequest(requestData, quoteRequest, customer);

            Assert.AreEqual(999, serviceRequest.ClientId);
            Assert.AreEqual("USD", serviceRequest.OrdersToBook[0].SettlementCurrencyCode);
            Assert.AreEqual(101.01m, serviceRequest.OrdersToBook[0].ItemsToBook[0].Amount);
            Assert.AreEqual(true, serviceRequest.OrdersToBook[0].ItemsToBook[0].IsAmountInSettlementCurrency);
            Assert.AreEqual(1234, serviceRequest.OrdersToBook[0].ItemsToBook[0].QuoteId);
            Assert.AreEqual("CAD", serviceRequest.OrdersToBook[0].ItemsToBook[0].TradeCurrencyCode);
        }

        [Test]
        public void CreateIncomingAggregateOrderBookResult_ThrowsIfMultipleOrderWithSameCurrencyPairExists()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new BookIncomingOrdersRequest
            {
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(Currency.USD, 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    },
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(Currency.USD, 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };

            Assert.Throws<UnaggregatedBookingRequestException>(() => OrderBookingAssembler.AssembleBookIncomingOrdersRequest(requestData, quoteRequest, customer));
        }

        [Test]
        public void CreateIncomingAggregateOrderBookRequest_ParsesSettlementMethodIfDoesNotExist()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new BookIncomingOrdersRequest
            {
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = "",
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(Currency.USD, 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };

            var serviceRequest = OrderBookingAssembler.AssembleBookIncomingOrdersRequest(requestData, quoteRequest, customer);

            Assert.AreEqual(SettlementPaymentMethod.Undefined, serviceRequest.OrdersToBook[0].SettlementMethod);
        }

        [Test]
        public void CreateIncomingAggregateOrderBookRequest_MapsACHToEDebit()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new BookIncomingOrdersRequest
            {
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = "ACH",
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(Currency.USD, 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };

            var serviceRequest = OrderBookingAssembler.AssembleBookIncomingOrdersRequest(requestData, quoteRequest, customer);

            Assert.AreEqual(SettlementPaymentMethod.Edebit, serviceRequest.OrdersToBook[0].SettlementMethod);
        }

        [Test]
        public void CreateIncomingAggregateOrderBookRequest_ThrowsWhenSettlementMethodIsGarbage()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new BookIncomingOrdersRequest
            {
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = "Garbage",
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(Currency.USD, 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };

            Assert.Throws<ArgumentException>(() => OrderBookingAssembler.AssembleBookIncomingOrdersRequest(requestData, quoteRequest, customer));
        }

        [Test]
        public void GetBatchOrdersFromBookedIncomingOrder_MapsFieldsCorrectly()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new CommitBatchRequest
            {
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = DomainSettlementPaymentMethod.Wire
                    }
                }
            };

            var batchItems = new List<PaymentAmount>
            {
                new PaymentAmount
                {
                    Money = new Money(Currency.CAD, 0),
                    SettlementMoney = new Money(Currency.USD, 101.01m)
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0),
                        IsAmountInSettlementCurrency = true
                    }
                }
            };
            var serviceRequest = OrderBookingAssembler.AssembleBookIncomingOrdersRequest(requestData, batchItems, quoteRequest, customer);

            Assert.AreEqual(999, serviceRequest.ClientId);
            Assert.AreEqual("USD", serviceRequest.OrdersToBook[0].SettlementCurrencyCode);
            Assert.AreEqual(101.01m, serviceRequest.OrdersToBook[0].ItemsToBook[0].Amount);
            Assert.AreEqual(true, serviceRequest.OrdersToBook[0].ItemsToBook[0].IsAmountInSettlementCurrency);
            Assert.AreEqual(1234, serviceRequest.OrdersToBook[0].ItemsToBook[0].QuoteId);
            Assert.AreEqual("CAD", serviceRequest.OrdersToBook[0].ItemsToBook[0].TradeCurrencyCode);
        }

        [Test]
        public void GetBatchOrdersFromBookedIncomingOrder_MapsFieldsCorrectlyForMultipleOrders()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new CommitBatchRequest
            {
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = DomainSettlementPaymentMethod.Wire
                    },
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.JPY,
                        SettlementMethod = DomainSettlementPaymentMethod.ACH
                    }
                }
            };

            var batchItems = new List<PaymentAmount>
            {
                new PaymentAmount
                {
                    Money = new Money(Currency.CAD, 0),
                    SettlementMoney = new Money(Currency.USD, 101.01m)
                },
                new PaymentAmount
                {
                    Money = new Money(Currency.EUR, 202.02m),
                    SettlementMoney = new Money(Currency.JPY, 0)
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0),
                        IsAmountInSettlementCurrency = true
                    },
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 5678,
                        SettlementMoney = new Money(Currency.JPY, 0),
                        TradeMoney = new Money(Currency.EUR, 0),
                        IsAmountInSettlementCurrency = false
                    }
                }
            };
            var serviceRequest = OrderBookingAssembler.AssembleBookIncomingOrdersRequest(requestData, batchItems, quoteRequest, customer);

            Assert.AreEqual(999, serviceRequest.ClientId);
            Assert.AreEqual("USD", serviceRequest.OrdersToBook[0].SettlementCurrencyCode);
            Assert.AreEqual(SettlementPaymentMethod.Wire, serviceRequest.OrdersToBook[0].SettlementMethod);
            Assert.AreEqual(101.01m, serviceRequest.OrdersToBook[0].ItemsToBook[0].Amount);
            Assert.AreEqual(true, serviceRequest.OrdersToBook[0].ItemsToBook[0].IsAmountInSettlementCurrency);
            Assert.AreEqual(1234, serviceRequest.OrdersToBook[0].ItemsToBook[0].QuoteId);
            Assert.AreEqual("CAD", serviceRequest.OrdersToBook[0].ItemsToBook[0].TradeCurrencyCode);
            Assert.AreEqual("JPY", serviceRequest.OrdersToBook[1].SettlementCurrencyCode);
            Assert.AreEqual(SettlementPaymentMethod.Edebit, serviceRequest.OrdersToBook[1].SettlementMethod);
            Assert.AreEqual(202.02m, serviceRequest.OrdersToBook[1].ItemsToBook[0].Amount);
            Assert.AreEqual(false, serviceRequest.OrdersToBook[1].ItemsToBook[0].IsAmountInSettlementCurrency);
            Assert.AreEqual(5678, serviceRequest.OrdersToBook[1].ItemsToBook[0].QuoteId);
            Assert.AreEqual("EUR", serviceRequest.OrdersToBook[1].ItemsToBook[0].TradeCurrencyCode);
        }
    }
}
