﻿using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.ServiceProviders.WUBSHoldingEngine.Assemblers;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.ServiceProviders.WUBSHoldingEngine.Assemblers
{
    public class HoldingBalanceAssemblerFixture
    {
        [Test]
        public void AssembleHoldingBalance_MapsCorrectly()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            var data = HoldingBalanceAssembler.AssembleHoldingBalance("USD", 100.00m, 200.00m);

            Assert.AreEqual("USD", data.Currency.Code);
            Assert.AreEqual("USD", data.AvailableBalance.Currency.Code);
            Assert.AreEqual("USD", data.BookedBalance.Currency.Code);
            Assert.AreEqual(100.00m, data.AvailableBalance.Amount);
            Assert.AreEqual(200.00m, data.BookedBalance.Amount);
            CurrencyCacheMapper.Instance = null;
        }

    }
}
