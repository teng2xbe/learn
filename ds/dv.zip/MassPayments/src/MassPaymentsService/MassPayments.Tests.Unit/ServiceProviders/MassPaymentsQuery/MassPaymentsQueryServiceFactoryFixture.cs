﻿using System.Configuration;
using MassPayments.MassPaymentsQuery;
using MassPayments.ServiceProviders.MassPaymentsQuery;
using NUnit.Framework;
using Rhino.Mocks;
using SharedUtilities;

namespace MassPayments.Tests.Unit.ServiceProviders.MassPaymentsQuery
{
    [TestFixture]
    public class MassPaymentsQueryServiceFactoryFixture
    {
        [SetUp]
        public void Setup()
        {

        }

        [TearDown]
        public void TearDown()
        {
           
        }

        [Test]
        public void GetService_ReturnsInjectedService()
        {
            var mockedService = MockRepository.GenerateMock<IMassPaymentsQueryService>();
            MassPaymentsQueryServiceFactory.InjectedServiceInterface = mockedService;

            var serviceClient = MassPaymentsQueryServiceFactory.GetService();

            Assert.AreEqual(mockedService, serviceClient);

            MassPaymentsQueryServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void GetService_ReturnsSimulator()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["Simulator.MassPaymentsQueryService"].Value = "true";
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            var serviceClient = MassPaymentsQueryServiceFactory.GetService();

            Assert.IsInstanceOf<SimulatedMassPaymentsQueryService>(serviceClient);
        }
    }
}
