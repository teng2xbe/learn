﻿using MassPayments.ServiceProviders.CCTEntityManagement.Assemblers;
using MassPayments.CCTEntityManagement;
using NUnit.Framework;
using DomainSettlementPaymentMethod = MassPayments.Domain.Enums.SettlementPaymentMethod;

namespace MassPayments.Tests.Unit.ServiceProviders.CCTEntityManagement.Assemblers
{
    [TestFixture]
    public class SettlementPaymentMethodAssemblerFixture
    {
        [TestCase(SettlementPaymentMethod.Wire, DomainSettlementPaymentMethod.Wire)]
        [TestCase(SettlementPaymentMethod.Edebit, DomainSettlementPaymentMethod.ACH)]
        [TestCase(SettlementPaymentMethod.AnotherNotExplicitlySupportedByMassPay, DomainSettlementPaymentMethod.OtherDefault)]
        [TestCase(SettlementPaymentMethod.Undefined, DomainSettlementPaymentMethod.Undefined)]
        public void ConvertToSettlementPaymentMethodDataContract_WorksCorrectly(SettlementPaymentMethod paymentMethodDataContract,
             DomainSettlementPaymentMethod expectedDomainMethod)
        {
            Assert.AreEqual(expectedDomainMethod, SettlementPaymentMethodAssembler.ConvertToDomainSettlementPaymentMethod(paymentMethodDataContract));
        }
    }
}
