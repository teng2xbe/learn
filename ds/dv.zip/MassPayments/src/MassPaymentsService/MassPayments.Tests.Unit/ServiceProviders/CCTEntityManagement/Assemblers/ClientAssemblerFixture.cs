﻿using MassPayments.ServiceProviders.CCTEntityManagement;
using MassPayments.ServiceProviders.CCTEntityManagement.Assemblers;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.ServiceProviders.CCTEntityManagement.Assemblers
{
    [TestFixture]
    public class ClientAssemblerFixture
    {
        [Test]
        public void ConvertClientDetailInfo_Works()
        {
            var targetClientId = 1;
            var serviceSimulator = new SimulatedEntityManagementService();
            var cctemClientInfo = serviceSimulator.GetClientDetailsForInvoice(targetClientId);
            var domainClientDetailInfo = CustomerEntityAssembler.Convert(cctemClientInfo);

            Assert.AreEqual(cctemClientInfo.Id, domainClientDetailInfo.Id);
            Assert.AreEqual(cctemClientInfo.AccountNumber, domainClientDetailInfo.AccountNumber);
            Assert.AreEqual(cctemClientInfo.AddressLine1, domainClientDetailInfo.AddressLine1);
            Assert.AreEqual(cctemClientInfo.AddressLine2, domainClientDetailInfo.AddressLine2);
            Assert.AreEqual(cctemClientInfo.AddressLine3, domainClientDetailInfo.AddressLine3);
            Assert.AreEqual(cctemClientInfo.City, domainClientDetailInfo.City);
            Assert.AreEqual(cctemClientInfo.CompanyName, domainClientDetailInfo.CompanyName);
            Assert.AreEqual(cctemClientInfo.CountryCode, domainClientDetailInfo.CountryCode);
            Assert.AreEqual(cctemClientInfo.DefaultUserName, domainClientDetailInfo.DefaultUserName);
            Assert.AreEqual(cctemClientInfo.InvoiceLanguageCode, domainClientDetailInfo.InvoiceLanguageCode);
            Assert.AreEqual(cctemClientInfo.OfficeAddress, domainClientDetailInfo.OfficeAddress);
            Assert.AreEqual(cctemClientInfo.OfficeFaxNumber, domainClientDetailInfo.OfficeFaxNumber);
            Assert.AreEqual(cctemClientInfo.OfficeId, domainClientDetailInfo.OfficeId);
            Assert.AreEqual(cctemClientInfo.OfficeLegalEntityLicenseNumber, domainClientDetailInfo.OfficeLegalEntityLicenseNumber);
            Assert.AreEqual(cctemClientInfo.OfficeLegalEntityLongName, domainClientDetailInfo.OfficeLegalEntityLongName);
            Assert.AreEqual(cctemClientInfo.OfficeLegalEntityShortName, domainClientDetailInfo.OfficeLegalEntityShortName);
            Assert.AreEqual(cctemClientInfo.OfficeName, domainClientDetailInfo.OfficeName);
            Assert.AreEqual(cctemClientInfo.OfficePhoneNumber, domainClientDetailInfo.OfficePhoneNumber);
            Assert.AreEqual(cctemClientInfo.OfficeTollFreePhoneNumber, domainClientDetailInfo.OfficeTollFreePhoneNumber);
            Assert.AreEqual(cctemClientInfo.PostalCode, domainClientDetailInfo.PostalCode);
            Assert.AreEqual(cctemClientInfo.ProcessCenterCode, domainClientDetailInfo.ProcessCenterCode);
            Assert.AreEqual(cctemClientInfo.ProcessCenterId, domainClientDetailInfo.ProcessCenterId);
            Assert.AreEqual(cctemClientInfo.State, domainClientDetailInfo.State);

        }

        [Test]
        public void AssembleGetMassPayClientRequest_Works()
        {
            var targetClientExternalId = "externalId";
            var targetPartnerCode = "partnerCode";
            var request = CustomerEntityAssembler.AssembleGetMassPayClientRequest(targetClientExternalId, targetPartnerCode);
            Assert.AreEqual(targetClientExternalId, request.ExternalId);
            Assert.AreEqual(targetPartnerCode, request.PartnerCode);
        }

        [Test]
        public void ConvertToDomainCustomer_Works()
        {
            var targetClientExternalId = "externalId";
            var targetPartnerCode = "partnerCode";
            var serviceSimulator = new SimulatedEntityManagementService();
            var cctemMassPayClientInfo = serviceSimulator.GetMassPayClient(CustomerEntityAssembler.AssembleGetMassPayClientRequest(targetClientExternalId, targetPartnerCode));
            var customer = CustomerEntityAssembler.ConvertToDomainCustomer(cctemMassPayClientInfo);

            Assert.AreEqual(customer.TransactionSystemCustomerId, cctemMassPayClientInfo.Id);
            Assert.AreEqual(customer.TransactionSystemCustomerExternalId, cctemMassPayClientInfo.AccountNumber);
            Assert.AreEqual(customer.Name, cctemMassPayClientInfo.CompanyName);
            Assert.AreEqual(customer.PartnerAssignedCustomerId, cctemMassPayClientInfo.ExternalId);
            Assert.AreEqual(10, customer.TransactionSystemId);
            Assert.AreEqual(cctemMassPayClientInfo.CountryCode, customer.CountryCode);
            Assert.AreEqual(cctemMassPayClientInfo.DefaultSettlementCurrencyCode, customer.SettlementCurrency.Code);
            //TODO: add settlement method

        }
    }
}
