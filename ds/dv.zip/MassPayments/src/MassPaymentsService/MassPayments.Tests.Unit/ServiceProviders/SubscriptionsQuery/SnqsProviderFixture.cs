﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.ServiceProviders.SubscriptionsQuery;
using MassPayments.SubscriptionsQuery;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.ServiceProviders.SubscriptionsQuery
{
    [TestFixture]
    public class SnqsProviderFixture
    {
        [SetUp]
        public void Setup()
        {
            SubscriptionsQueryServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<ISubscriptionsQueryService>();
        }

        [TearDown]
        public void TearDown()
        {
            SubscriptionsQueryServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void GetPublishedNotification_Returns()
        {
            var result = new PublishedNotificationResultData
            {
                Payload = "gorilla"
            };

            SubscriptionsQueryServiceFactory.InjectedServiceInterface.Expect(s => s.GetPublishedNotification(Arg<string>.Is.Anything, Arg<Guid>.Is.Anything)).Return(result);

            var notification = SnqsProvider.Instance.GetPublishedNotification(Guid.NewGuid(), new Partner() {Id = 1});

            Assert.AreEqual("gorilla", notification.Payload);
            SubscriptionsQueryServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        [Test]
        public void GetDomainEvent_ReturnsNullWhenServiceReturnsNull()
        {
            SubscriptionsQueryServiceFactory.InjectedServiceInterface.Expect(s => s.GetPublishedNotification(Arg<string>.Is.Anything, Arg<Guid>.Is.Anything)).Return(null);

            var domainEvent = SnqsProvider.Instance.GetPublishedNotification(Guid.NewGuid(), new Partner() { Id = 1 });

            Assert.IsNull(domainEvent);
            SubscriptionsQueryServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        [Test]
        public void GetWebhooksJsonData_ReturnsWebhook()
        {
            SubscriptionsQueryServiceFactory.InjectedServiceInterface.Expect(s => s.GetWebhook(Arg<string>.Is.Anything, Arg<Guid>.Is.Anything)).Return(new GetWebhookResultData());

            var result = SnqsProvider.Instance.GetWebhook(new Partner { Id = 1 }, Guid.NewGuid());
            Assert.IsNotNull(result);
            SubscriptionsQueryServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        [Test]
        public void GetWebhooksJsonData_ReturnsWebhooks()
        {
            SubscriptionsQueryServiceFactory.InjectedServiceInterface.Expect(s => s.GetWebhooks(Arg<string>.Is.Anything)).Return(new GetWebhooksResultData());

            var result = SnqsProvider.Instance.GetWebhooks(new Partner { Id = 1 });
            Assert.IsNotNull(result);
            SubscriptionsQueryServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }
    }
}
