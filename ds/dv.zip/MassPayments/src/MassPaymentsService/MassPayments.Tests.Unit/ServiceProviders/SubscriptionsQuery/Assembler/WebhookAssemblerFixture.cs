﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.ValueObjects;
using MassPayments.ServiceProviders.SubscriptionsQuery.Assemblers;
using MassPayments.SubscriptionsQuery;
using NUnit.Framework;
using WebhookPushedEvent = MassPayments.SubscriptionsQuery.WebhookPushedEvent;

namespace MassPayments.Tests.Unit.ServiceProviders.SubscriptionsQuery.Assembler
{
    public class WebhookAssemblerFixture
    {
        [Test]
        public void ConvertWebhook_DoesNotThrowWithNullInput()
        {
            Webhook result = new Webhook();
            Assert.DoesNotThrow(() => result = WebhookAssembler.ConvertGetWebhookResultData(null));
            Assert.IsNull(result);
        }

        [Test]
        public void ConvertWebhooks_DoesNotThrowWithNullInput()
        {
            List<Webhook> results = new List<Webhook> {new Webhook()};
            Assert.DoesNotThrow(() => results = WebhookAssembler.ConvertGetWebhooksResultData(null));
            Assert.AreEqual(0, results.Count);
        }

        [Test]
        public void Convert_CreatesAWebhook()
        {
            var id = Guid.NewGuid();
            var now = DateTime.UtcNow;

            var webhookResult = new GetWebhookResultData
            {
                Id = id,
                Uri = "https://gorilla.com",
                IsPrimary = true,
                SecurityToken = "aToken",
                CreatedOnUtc = now,
                UpdatedOnUtc = now,
                LastPushedEvent = new WebhookPushedEvent
                {
                    EventType = "banana",
                    Status = "allgood",
                    PushedOnUtc = now
                }
            };

            var webhook = WebhookAssembler.ConvertGetWebhookResultData(webhookResult);

            Assert.AreEqual(id, webhook.Id);
            Assert.AreEqual("https://gorilla.com", webhook.Uri);
            Assert.AreEqual(true, webhook.IsPrimary);
            Assert.AreEqual("aToken", webhook.SecurityToken);
            Assert.AreEqual(now, webhook.CreatedOnUtc);
            Assert.AreEqual(now, webhook.UpdatedOnUtc);
            Assert.AreEqual("banana", webhook.LastPushedEvent.EventType);
            Assert.AreEqual("allgood", webhook.LastPushedEvent.Status);
            Assert.AreEqual(now, webhook.LastPushedEvent.PushedOnUtc);
        }

        [Test]
        public void Convert_CreatesListOfWebhooks()
        {
            var id1 = Guid.NewGuid();
            var id2 = Guid.NewGuid();
            var now = DateTime.UtcNow;

            var webhookResult = new GetWebhooksResultData
            {
                Webhooks = new List<GetWebhookResultData>
                {
                    new GetWebhookResultData
                    {
                        Id = id1,
                        Uri = "https://gorilla1.com",
                        IsPrimary = true,
                        SecurityToken = "aToken1",
                        CreatedOnUtc = now,
                        UpdatedOnUtc = now,
                        LastPushedEvent = new WebhookPushedEvent
                        {
                            EventType = "banana1",
                            Status = "allgood1",
                            PushedOnUtc = now
                        }
                    },
                    new GetWebhookResultData
                    {
                        Id = id2,
                        Uri = "https://gorilla2.com",
                        IsPrimary = true,
                        SecurityToken = "aToken2",
                        CreatedOnUtc = now,
                        UpdatedOnUtc = now,
                        LastPushedEvent = new WebhookPushedEvent
                        {
                            EventType = "banana2",
                            Status = "allgood2",
                            PushedOnUtc = now
                        }
                    }
                }
            };

            var webhooks = WebhookAssembler.ConvertGetWebhooksResultData(webhookResult);

            Assert.AreEqual(id1, webhooks[0].Id);
            Assert.AreEqual("https://gorilla1.com", webhooks[0].Uri);
            Assert.AreEqual(true, webhooks[0].IsPrimary);
            Assert.AreEqual("aToken1", webhooks[0].SecurityToken);
            Assert.AreEqual(now, webhooks[0].CreatedOnUtc);
            Assert.AreEqual(now, webhooks[0].UpdatedOnUtc);
            Assert.AreEqual("banana1", webhooks[0].LastPushedEvent.EventType);
            Assert.AreEqual("allgood1", webhooks[0].LastPushedEvent.Status);
            Assert.AreEqual(now, webhooks[0].LastPushedEvent.PushedOnUtc);
            Assert.AreEqual(id2, webhooks[1].Id);
            Assert.AreEqual("https://gorilla2.com", webhooks[1].Uri);
            Assert.AreEqual(true, webhooks[1].IsPrimary);
            Assert.AreEqual("aToken2", webhooks[1].SecurityToken);
            Assert.AreEqual(now, webhooks[1].CreatedOnUtc);
            Assert.AreEqual(now, webhooks[1].UpdatedOnUtc);
            Assert.AreEqual("banana2", webhooks[1].LastPushedEvent.EventType);
            Assert.AreEqual("allgood2", webhooks[1].LastPushedEvent.Status);
            Assert.AreEqual(now, webhooks[1].LastPushedEvent.PushedOnUtc);
        }
    }
}
