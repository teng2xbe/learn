﻿using System;
using MassPayments.Domain.ValueObjects;
using MassPayments.ServiceProviders.SubscriptionsQuery.Assemblers;
using MassPayments.SubscriptionsQuery;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.ServiceProviders.SubscriptionsQuery.Assembler
{
    [TestFixture]
    public class PublishedNotificationAssemblerFixture
    {
        [Test]
        public void Convert_FromPublishedNotificationResultData_DoesNotThrowWithNullInput()
        {
            PublishedNotification result = new PublishedNotification();
            Assert.DoesNotThrow(() => result = PublishedNotificationAssembler.ConvertPublishedNotification(null));
            Assert.IsNull(result);
        }

        [Test]
        public void Convert_FromPublishedNotificationResultData_Works()
        {
            var resultData = new PublishedNotificationResultData
            {
                Id = Guid.NewGuid(),
                DomainEventId = Guid.NewGuid(),
                Payload = "123",
                PublishedOnUtc = DateTime.UtcNow,
                SubscriberApplicationId = 1,
                SubscriberCode = "Test",
                WebhookId = Guid.NewGuid(),
                WebhookUrl = "https://a.url"
            };

            PublishedNotification result = null;

            Assert.DoesNotThrow(() => result = PublishedNotificationAssembler.ConvertPublishedNotification(resultData));
            Assert.AreEqual(resultData.Id, result.Id);
            Assert.AreEqual(resultData.DomainEventId, result.DomainEventId);
            Assert.AreEqual(resultData.Payload, result.Payload);
            Assert.AreEqual(resultData.PublishedOnUtc.ToShortTimeString(), result.PublishedOnUtc.ToShortTimeString());
            Assert.AreEqual(resultData.SubscriberApplicationId, result.SubscriberApplicationId);
            Assert.AreEqual(resultData.SubscriberCode, result.SubscriberCode);
            Assert.AreEqual(resultData.WebhookId, result.WebhookId);
            Assert.AreEqual(resultData.WebhookUrl, result.WebhookUrl);
        }
    }
}
