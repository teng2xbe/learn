﻿using Common.Contracts.MassPayments.Messages.Enums;
using Common.Contracts.MassPayments.Messages.Events;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Bus;
using MassPayments.Publishers;
using MassPayments.Tests.Unit.Helpers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Publishers
{
    [TestFixture]
    public class PaymentStatusUpdatedPublisherFixture
    {
        [SetUp]
        public void Setup()
        {
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
        }

        [TearDown]
        public void TearDown()
        {
            MassPayBus.Instance = null;
        }

        [Test]
        public void Publish_Publishes_ExpectedEventTypes()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var partner = new Partner { Id = 222, Code = "111" };

            MassPayBus.Instance.Expect(b => b.Publish(Arg<PaymentStatusUpdatedEvent>.Matches(e =>
                e.SubscriberCode == partner.Code &&
                e.Application == Application.MassPayments &&
                e.PaymentPartialDetails.Id == payment.ExternalId))).Repeat.Once();
            MassPayBus.Instance.Expect(b => b.Publish(Arg<PaymentStatusUpdatedWithFullDetailsEvent>.Matches(e =>
                e.PaymentFullDetails.ExternalId == payment.ExternalId))).Repeat.Once();

            Assert.DoesNotThrow(() => new PaymentStatusUpdatedPublisher(partner).Publish(payment, customerBatch, customer));

            MassPayBus.Instance.VerifyAllExpectations();
        }
    }
}
