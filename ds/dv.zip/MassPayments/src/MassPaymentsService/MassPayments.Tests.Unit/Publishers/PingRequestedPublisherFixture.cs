﻿using Common.Contracts.MassPayments.Messages.Enums;
using Common.Contracts.MassPayments.Messages.Events;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Bus;
using MassPayments.Publishers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Publishers
{
    [TestFixture]
    public class PingRequestedPublisherFixture
    {
        [SetUp]
        public void Setup()
        {
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
        }

        [TearDown]
        public void TearDown()
        {
            MassPayBus.Instance = null;
        }

        [Test]
        public void Publish_Publishes_ExpectedEventTypes()
        {
            var partner = new Partner { Id = 222, Code = "111" };

            MassPayBus.Instance.Expect(b => b.Publish(Arg<PingRequestedEvent>.Matches(e =>
                e.SubscriberCode == partner.Code &&
                e.Application == Application.MassPayments))).Repeat.Once();

            Assert.DoesNotThrow(() => new PingRequestedPublisher(partner).Publish(null));

            MassPayBus.Instance.VerifyAllExpectations();

        }
    }
}
