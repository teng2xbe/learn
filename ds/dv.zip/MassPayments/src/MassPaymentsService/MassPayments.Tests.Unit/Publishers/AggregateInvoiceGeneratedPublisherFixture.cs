﻿using System;
using System.Collections.Generic;
using Common.Contracts.MassPayments.Messages.Events;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Bus;
using MassPayments.Publishers;
using MassPayments.Services.MassPaymentsService.Assemblers.Utility;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;
using Order = MassPayments.Domain.Entities.Order;

namespace MassPayments.Tests.Unit.Publishers
{
    [TestFixture]
    public class AggregateInvoiceGeneratedPublisherFixture
    {
        [SetUp]
        public void Setup()
        {
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
        }

        [TearDown]
        public void TearDown()
        {
            MassPayBus.Instance = null;
        }

        [Test]
        public void Publish_Publishes_ExpectedEventType()
        {
            var timestampUtc = DateTime.UtcNow;
            var invoiceFile = new AggregateInvoiceFile
            {
                Partner = new Partner { Id = 33 },
                CreatedOnUTC = timestampUtc,
                InvoiceFileName = "invoice_123_4234.pdf",
                Orders = new List<Order> { new Order { ConfirmationNumber = "TER12323    " } }
            };

            MassPayBus.Instance.Expect(b => b.Publish(Arg<FundingOrderInvoiceGeneratedEvent>.Is.Anything)).Repeat.Once();
            Assert.DoesNotThrow(()=> new AggregateInvoiceGeneratedPublisher(new Partner()).Publish(invoiceFile));
            MassPayBus.Instance.VerifyAllExpectations();
        }

        [Test]
        public void AssembleOrderStatusUpdatedEvent_WorksCorrectly_SIngleOrder()
        {
            var timestampUtc = DateTime.UtcNow;
            var parnter = new Partner {Id = 33,Code = "Blahlah"};
            var invoiceFile = new AggregateInvoiceFile
            {
                Partner = parnter,
                CreatedOnUTC = timestampUtc,
                InvoiceFileName = "invoice_123_4234.pdf",
                Orders = new List<Order> {new Order {ConfirmationNumber = "TER12323    "}}
            };
            var assembledEvent = new AggregateInvoiceGeneratedPublisher(parnter).AssembleOrderStatusUpdatedEvent(invoiceFile);

            Assert.AreEqual(parnter.Code, assembledEvent.SubscriberCode);
            Assert.AreEqual("invoice_123_4234.pdf", assembledEvent.Invoice.InvoiceFileName);
            Assert.AreEqual("TER12323", assembledEvent.Invoice.OrderIds);

        }

        [Test]
        public void AssembleOrderStatusUpdatedEvent_WorksCorrectly_MultipleOrders()
        {
            var partner = new Partner() {Id = 355, Code = "Blahlah"};
            var invoiceFile = new AggregateInvoiceFile
            {
                Partner = partner,
                InvoiceFileName = "invoice_5456.pdf",
                Orders = new List<Order> { new Order { ConfirmationNumber = "TER12323    " }, new Order { ConfirmationNumber = "we45654" } }
            };
            var assembledEvent = new AggregateInvoiceGeneratedPublisher(partner).AssembleOrderStatusUpdatedEvent(invoiceFile);

            Assert.AreEqual(partner.Code, assembledEvent.SubscriberCode);
            Assert.AreEqual("invoice_5456.pdf", assembledEvent.Invoice.InvoiceFileName);
            Assert.AreEqual("TER12323,we45654", assembledEvent.Invoice.OrderIds);

        }

    }
}
