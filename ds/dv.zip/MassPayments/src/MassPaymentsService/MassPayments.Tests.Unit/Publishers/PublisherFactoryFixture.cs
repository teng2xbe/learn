﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Publishers
{
    [TestFixture]
    public class PublisherFactoryFixture
    {
        [SetUp]
        public void Setup()
        {

        }

        [TearDown]
        public void TearDown()
        {
            PublisherFactory.CleanAllInjectedPublishers();
        }

        [Test]
        public void GetPublisher_ReturnsInjectedPublisher()
        {
            var publisher = new AggregateInvoiceGeneratedPublisher(new Partner());
            Assert.DoesNotThrow(()=> PublisherFactory.InjectPublisherForTesting(publisher.GetType(), publisher));
            var injectedPublisher = PublisherFactory.GetPublisher(typeof (AggregateInvoiceGeneratedPublisher), new Partner());

            Assert.AreEqual(publisher, injectedPublisher);
        }

        [Test]
        public void GetPublisher_RemovesInjectedPublisher()
        {
            var publisher = new AggregateInvoiceGeneratedPublisher(new Partner());
            Assert.DoesNotThrow(() => PublisherFactory.InjectPublisherForTesting(publisher.GetType(), publisher));
            PublisherFactory.InjectPublisherForTesting(typeof(AggregateInvoiceGeneratedPublisher), null);

            var newPublisher = PublisherFactory.GetPublisher(typeof(AggregateInvoiceGeneratedPublisher), new Partner());

            Assert.IsNotNull(newPublisher);
            Assert.AreNotEqual(publisher, newPublisher);
            Assert.IsTrue(newPublisher is AggregateInvoiceGeneratedPublisher);
        }

        [TestCase(typeof(AggregateInvoiceGeneratedPublisher))]
        [TestCase(typeof(OrderStatusUpdatedPublisher))]
        [TestCase(typeof(PaymentNotAcceptedPublisher))]
        [TestCase(typeof(PaymentStatusUpdatedPublisher))]
        [TestCase(typeof(PaymentUpdateFailedPublisher))]
        [TestCase(typeof(PingRequestedPublisher))]
        public void GetPublisher_Returns_ProperPublisher(Type expectedType)
        {
            var newPublisher = PublisherFactory.GetPublisher(expectedType, new Partner());

            Assert.IsNotNull(newPublisher);
            Assert.IsTrue(newPublisher.GetType() == expectedType);
        }

        [Test]
        public void GetPublisher_CanBeCasted()
        {
            var newPublisher = PublisherFactory.GetPublisher(typeof(AggregateInvoiceGeneratedPublisher), new Partner());
            Assert.IsNotNull(newPublisher);
            var castedPublisher = (IPublisher<AggregateInvoiceFile>)newPublisher;
            Assert.IsNotNull(castedPublisher);

        }

        [Test]
        public void GetPublisher_PaymentStatusUpdatedPublisherCanBeCasted()
        {
            var newPublisher = PublisherFactory.GetPublisher(typeof(PaymentStatusUpdatedPublisher), new Partner());
            Assert.IsNotNull(newPublisher);
            var castedPublisher = (IPublisher<Payment, CustomerBatch, Customer>)newPublisher;
            Assert.IsNotNull(castedPublisher);
        }
    }
}
