﻿using System;
using Common.Contracts.MassPayments.Messages.Events;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Bus;
using MassPayments.Publishers;
using MassPayments.Tests.Unit.Helpers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;



namespace MassPayments.Tests.Unit.Publishers

{
    [TestFixture]
    public class PaymentUpdateFailedPublisherFixture
    {
        [SetUp]
        public void Setup()
        {
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
        }

        [TearDown]
        public void TearDown()
        {
            MassPayBus.Instance = null;
        }

        [Test]
        public void Publish_Publishes_ExpectedEventType()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            MassPayBus.Instance.Expect(b => b.Publish(Arg<PaymentUpdateFailedEvent>.Is.Anything)).Repeat.Once();
            Assert.DoesNotThrow(()=> new PaymentUpdateFailedPublisher(new Partner()).Publish(payment,customerBatch));
            MassPayBus.Instance.VerifyAllExpectations();
        }

        [Test]
        public void AssemblePaymentUpdatedFailedEvent_WorksCorrectly()
        {
            var ISODateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ";
            var updateFailedUtc = DateTime.UtcNow;
            var externalPaymentId = "cats&dogs";
            var customer = CustomerHelper.Instance.CreateCustomer();
            var partner = new Partner {Id = 2, Code = "Blahlah"};
            customer.PartnerId = partner.Id;
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, externalPaymentId, customerBatch);
            payment.PaymentSourceId = partner.Id;
            payment.LastUpdateError = new PaymentUpdateHistory
            {
                ErrorCode = "1104",
                PaymentId = payment.Id,
                PaymentRequestId = 1234,
                UpdatedOnUtc = updateFailedUtc
            };

            var assembledPaymentFailedEvent = new PaymentUpdateFailedPublisher(partner).AssemblePaymentUpdatedFailedEvent(payment, customerBatch);
        
            Assert.AreEqual(externalPaymentId,assembledPaymentFailedEvent.PaymentPartialDetails.Id);
            Assert.AreEqual(partner.Code, assembledPaymentFailedEvent.SubscriberCode);
            Assert.AreEqual(updateFailedUtc.ToString(ISODateTimeFormat),assembledPaymentFailedEvent.PaymentPartialDetails.UpdateErrorOnUtc);
        }

    }
}