﻿using MassPayments.Publishers.Assemblers;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Publishers.Assemblers
{
    [TestFixture]
    public class CustomerAssemblerFixture
    {
        [Test]
        public void CustomerAssembler_AssemblesCustomer()
        {
            var domainCustomer = CustomerHelper.Instance.CreateCustomer();

            var customer = CustomerAssembler.AssembleCustomer(domainCustomer);

            Assert.AreEqual(domainCustomer.Id, customer.Id);
            Assert.AreEqual(domainCustomer.CountryCode, customer.CountryCode);
            Assert.AreEqual(domainCustomer.Name, customer.Name);
            Assert.AreEqual(domainCustomer.NotificationEmails, customer.NotificationEmails);
            Assert.AreEqual(domainCustomer.PartnerAssignedCustomerId, customer.PartnerAssignedCustomerId);
            Assert.AreEqual(domainCustomer.PartnerId, customer.PartnerId);
            Assert.AreEqual(domainCustomer.SettlementCurrency.Code, customer.SettlementCurrencyCode);
            Assert.AreEqual((int)domainCustomer.Status, customer.Status);
            Assert.AreEqual(domainCustomer.TTLExpiration, customer.TTLExpiration);
            Assert.AreEqual(domainCustomer.TransactionSystemCustomerExternalId, customer.TransactionSystemCustomerExternalId);
            Assert.AreEqual(domainCustomer.TransactionSystemCustomerId, customer.TransactionSystemCustomerId);
            Assert.AreEqual(domainCustomer.TransactionSystemId, customer.TransactionSystemId);
        }
    }
}
