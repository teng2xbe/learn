﻿
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Publishers.Assemblers;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts.payments;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using Common.Contracts.MassPayments.Messages.Entities.Payment;
using Customer = MassPayments.Domain.Entities.Customer;
using Partner = MassPayments.Domain.Entities.Partner;

namespace MassPayments.Tests.Unit.Publishers.Assemblers
{
    [TestFixture]
    public class PaymentAssemblerFixture
    {
        private DateTime timeStamp;

        [SetUp]
        public void Setup()
        {
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp,
                new Partner { Id = 2, Name = "Concur" });
        }

        [TearDown]
        public void Teardown()
        {
            ServiceCallContextManager.Instance = null;
        }

        [Test, Description("Tests for assembler when payment status of batch payment is created")]
        public void AssemblePayment_Returns_CorrectMessagingPaymentForStatusChange()
        {
            var ISODateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ";
            var createdOnUtc = DateTime.UtcNow;
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);

            var payment = new Payment("cats&dogs", "banana")
            {

                PaymentReference = "Unit test",
                PartnerReference = "cats",
                CreatedOnUTC = createdOnUtc,
                UpdatedOnUTC = createdOnUtc.AddHours(1),
                PaymentStatus = PaymentStatus.Created
            };

            var messagingPayment = PaymentAssembler.AssemblePayment(payment, customerBatch);
            Assert.AreEqual(payment.PaymentReference, messagingPayment.PaymentReference);
            Assert.AreEqual(payment.PartnerReference, messagingPayment.PartnerReference);
            Assert.AreEqual("cats&dogs", messagingPayment.Id);
            Assert.AreEqual(createdOnUtc.ToString(ISODateTimeFormat), messagingPayment.CreatedOnUtc);
            Assert.AreEqual("Created", messagingPayment.Status);
            Assert.AreEqual("banana", messagingPayment.CustomerId);
        }

        [Test]
        public void AssemblePayment_Returns_CorrectPaymentStatusForBatchPayment()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            customerBatch.BatchStatus = CustomerBatchStatus.Committed;
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var payment2 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var payment3 = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentStatus = PaymentStatus.Committed;
            payment2.PaymentStatus = PaymentStatus.Released;
            payment3.PaymentStatus = PaymentStatus.Rejected;

            var messagingPayment = PaymentAssembler.AssemblePayment(payment, customerBatch);
            Assert.AreEqual("Processing", messagingPayment.Status);

            messagingPayment = PaymentAssembler.AssemblePayment(payment2, customerBatch);
            Assert.AreEqual("Released", messagingPayment.Status);

            messagingPayment = PaymentAssembler.AssemblePayment(payment3, customerBatch);
            Assert.AreEqual("Rejected", messagingPayment.Status);
        }

        [Test, Description("Tests for assembler when payment is not accepted")]
        public void AssemblePayment_Returns_CorrectMessagingPaymentForNotAccepted()
        {
            var notAcceptedPayment = new NotAcceptedPayment("PID003", null)
            {
                PaymentStatus = PaymentStatus.Undefined,
                PaymentSourceId = 1,
                PartnerReference = "blahpartnerref1",
                ErrorCode = "1001:bene is required",
            };

            var messagingPayment = PaymentAssembler.AssemblePayment(notAcceptedPayment, null);
            Assert.AreEqual("1001:bene is required", messagingPayment.ErrorCode);
            Assert.AreEqual(PaymentStatusData.NotAccepted.ToString(), messagingPayment.Status);
            Assert.AreEqual("PID003", messagingPayment.Id);
            Assert.AreEqual(null, messagingPayment.CustomerId);
        }

        [Test, Description("Tests for assembler when payment update fails")]
        public void AssemblePayment_Returns_CorrectMessagingPaymentForUpdateFailure()
        {
            var ISODateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ";
            var updateFailedUtc = DateTime.UtcNow;
            var externalPaymentId = "cats&dogs";
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.PartnerId = 2;
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, externalPaymentId, customerBatch);
            payment.LastUpdateError = new PaymentUpdateHistory
            {
                ErrorCode = "1104",
                PaymentId = payment.Id,
                PaymentRequestId = 1234,
                UpdatedOnUtc = updateFailedUtc
            };

            var messagingPayment = PaymentAssembler.AssemblePayment(payment, customerBatch);

            Assert.AreEqual(externalPaymentId, messagingPayment.Id);
            Assert.AreEqual(updateFailedUtc.ToString(ISODateTimeFormat), messagingPayment.UpdateErrorOnUtc);
            Assert.AreEqual("1104", messagingPayment.ErrorCode);
            Assert.AreEqual("Created", messagingPayment.Status);
            Assert.AreEqual(customerBatch.ExternalCustomerId, messagingPayment.CustomerId);
        }

        [Test]
        public void AssemblePayment_Returns_CorrectErrorCodeForRejected()
        {
            var payment = new Payment(1)
            {
                PaymentStatus = PaymentStatus.Rejected,
                RejectReason = "Rejected by GPG"
            };

            var result = PaymentAssembler.AssemblePayment(payment, new CustomerBatch());
            Assert.AreEqual(payment.RejectReason, result.ErrorCode);
        }

        [Test]
        public void AssemblePayment_Returns_CorrectErrorCodeForReturned()
        {
            var payment = new Payment(1)
            {
                PaymentStatus = PaymentStatus.Returned,
                RejectReason = "returned by bank"
            };

            var result = PaymentAssembler.AssemblePayment(payment, new CustomerBatch());
            Assert.AreEqual(payment.RejectReason, result.ErrorCode);
        }

        [Test]
        public void AssemblePayment_AssemblesPaymentFullDetails()
        {
            var partner = new Partner
            {
                Id = 111,
                Description = "desc",
                FilePrefix = "filepref",
                Code = "code",
                BankRefPrefix = "bankfilepref",
                Name = "name",
                SecurityToken = "sectok",
                InvoiceTypeId = 1,
                IsActive = true,
                PaymentModel = PaymentModel.Coupled,
                IsThirdPartyRemitterEnabled = true
            };

            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);

            var fullPayment = PaymentAssembler.AssemblePayment(payment, customer, partner);

            AssertPaymentAreEqual(payment, customer, partner, fullPayment);
        }

        private void AssertPaymentAreEqual(Payment payment, Customer customer, Partner partner, PaymentFullDetails paymentFullDetails)
        {
            Assert.AreEqual(payment.CustomerBatchId, paymentFullDetails.CustomerBatchId);
            Assert.AreEqual((int?) payment.PaymentMethod, paymentFullDetails.PaymentMethod);
            Assert.AreEqual((int) payment.PaymentStatus, paymentFullDetails.PaymentStatus);
            Assert.AreEqual(payment.ExternalId, paymentFullDetails.ExternalId);
            Assert.AreEqual(payment.AmountMoney.Amount, paymentFullDetails.Amount);
            Assert.AreEqual(payment.AmountMoney.Currency.Code, paymentFullDetails.Currency);
            Assert.AreEqual(payment.ExternalCustomerId, paymentFullDetails.ExternalCustomerId);
            Assert.AreEqual(payment.Beneficiary.ExternalId, paymentFullDetails.ExternalBeneId);
            Assert.AreEqual(payment.Beneficiary.Version, paymentFullDetails.BeneVersion);
            Assert.AreEqual(payment.Beneficiary.CustomerBeneId, paymentFullDetails.CustomerBeneId);
            Assert.AreEqual(payment.Beneficiary.VersionedOn, paymentFullDetails.BeneVersionedOn);
            Assert.AreEqual(payment.Beneficiary.Identification.FirstName, paymentFullDetails.BeneFirstName);
            Assert.AreEqual(payment.Beneficiary.Identification.MiddleName, paymentFullDetails.BeneMiddleName);
            Assert.AreEqual(payment.Beneficiary.Identification.LastName, paymentFullDetails.BeneLastName);
            Assert.AreEqual(payment.Beneficiary.Identification.PhoneNumber, paymentFullDetails.BenePhoneNumber);
            Assert.AreEqual(payment.Beneficiary.Identification.CellNumber, paymentFullDetails.BeneCellNumber);
            Assert.AreEqual(payment.Beneficiary.Identification.DateOfBirth, paymentFullDetails.BeneDateOfBirth);
            Assert.AreEqual(payment.Beneficiary.Identification.Gender, paymentFullDetails.BeneGender);
            Assert.AreEqual(payment.Beneficiary.Identification.EntityType, paymentFullDetails.BeneEntityType);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessName, paymentFullDetails.BeneBusinessName);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessRegistrationNumber, paymentFullDetails.BeneBusinessRegistrationNumber);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessRegistrationCountry, paymentFullDetails.BeneBusinessRegistrationCountry);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessRegistrationStateProv, paymentFullDetails.BeneBusinessRegistrationStateProv);
            Assert.AreEqual(payment.Beneficiary.Identification.BusinessContactRole, paymentFullDetails.BeneBusinessContactRole);
            Assert.AreEqual(payment.Beneficiary.Identification.Industry, paymentFullDetails.BeneIndustry);
            Assert.AreEqual(payment.Beneficiary.Identification.EmailAddress, paymentFullDetails.BeneEmailAddress);
            Assert.AreEqual(payment.Beneficiary.Address.AddressLine1, paymentFullDetails.BeneAddressLine1);
            Assert.AreEqual(payment.Beneficiary.Address.AddressLine2, paymentFullDetails.BeneAddressLine2);
            Assert.AreEqual(payment.Beneficiary.Address.AddressLine3, paymentFullDetails.BeneAddressLine3);
            Assert.AreEqual(payment.Beneficiary.Address.City, paymentFullDetails.BeneCity);
            Assert.AreEqual(payment.Beneficiary.Address.StateOrProvince, paymentFullDetails.BeneStateOrProv);
            Assert.AreEqual(payment.Beneficiary.Address.ZipOrPostalCode, paymentFullDetails.BeneZipOrPostal);
            Assert.AreEqual(payment.Beneficiary.Address.CountryCode, paymentFullDetails.BeneCountryCode);
            Assert.AreEqual(payment.BankAccount.AccountNumber, paymentFullDetails.BankAccountNumber);
            Assert.AreEqual(payment.BankAccount.ExternalAccountType, paymentFullDetails.ExternalBankAccountType);
            Assert.AreEqual(payment.BankAccount.AccountPurpose, paymentFullDetails.BankAccountPurpose);
            Assert.AreEqual(payment.BankAccount.BankName, paymentFullDetails.BankName);
            Assert.AreEqual(payment.BankAccount.BranchName, paymentFullDetails.BankBranchName);
            Assert.AreEqual(payment.BankAccount.BankCode, paymentFullDetails.BankCode);
            Assert.AreEqual(payment.BankAccount.BranchCode, paymentFullDetails.BankBranchCode);
            Assert.AreEqual(payment.BankAccount.DisplayName, paymentFullDetails.ExternalBankAccountDisplayName);
            Assert.AreEqual(payment.BankAccount.BankAddress.AddressLine1, paymentFullDetails.BankAddressLine1);
            Assert.AreEqual(payment.BankAccount.BankAddress.AddressLine2, paymentFullDetails.BankAddressLine2);
            Assert.AreEqual(payment.BankAccount.BankAddress.AddressLine3, paymentFullDetails.BankAddressLine3);
            Assert.AreEqual(payment.BankAccount.BankAddress.City, paymentFullDetails.BankCity);
            Assert.AreEqual(payment.BankAccount.BankAddress.StateOrProvince, paymentFullDetails.BankStateOrProv);
            Assert.AreEqual(payment.BankAccount.BankAddress.ZipOrPostalCode, paymentFullDetails.BankZipOrPostal);
            Assert.AreEqual(payment.BankAccount.BankAddress.CountryCode, paymentFullDetails.BankCountryCode);
            Assert.AreEqual(payment.BankAccount.ExternalId, paymentFullDetails.ExternalBankAccountId);
            Assert.AreEqual(payment.BankAccount.Version, paymentFullDetails.BankAccountVersion);
            Assert.AreEqual(payment.BankAccount.VersionedOn, paymentFullDetails.BankAccountVersionedOn);
            Assert.That(payment.CreatedOnUTC, Is.EqualTo(paymentFullDetails.CreatedOnUTC).Within(1).Seconds);
            Assert.That(payment.UpdatedOnUTC, Is.EqualTo(paymentFullDetails.UpdatedOnUTC).Within(1).Seconds);
            Assert.AreEqual(payment.TransactionSystemCustomerId, paymentFullDetails.TransactionSystemCustomerId);
            Assert.AreEqual(payment.TransactionSystemId, paymentFullDetails.TransactionSystemId);
            Assert.AreEqual(payment.PaymentSourceId, paymentFullDetails.PaymentSourceId);
            Assert.AreEqual(payment.TransactionSystemOrderId, paymentFullDetails.TransactionSystemOrderId);
            Assert.AreEqual(payment.TransactionSystemOrderNumber, paymentFullDetails.TransactionSystemOrderNumber);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderId, paymentFullDetails.TransactionSystemIncomingOrderId);
            Assert.AreEqual(payment.TransactionSystemIncomingOrderNumber, paymentFullDetails.TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(payment.RequestedReleaseDate, paymentFullDetails.RequestedReleaseDate);
            Assert.AreEqual(payment.PaymentReference, paymentFullDetails.PaymentReference);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankName, paymentFullDetails.IntermediaryBankName);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankCode, paymentFullDetails.IntermediaryBankCode);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.AddressLine1, paymentFullDetails.IntermediaryBankAddressLine1);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.AddressLine2, paymentFullDetails.IntermediaryBankAddressLine2);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.AddressLine3, paymentFullDetails.IntermediaryBankAddressLine3);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.City, paymentFullDetails.IntermediaryBankCity);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.StateOrProvince, paymentFullDetails.IntermediaryBankStateOrProv);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.ZipOrPostalCode, paymentFullDetails.IntermediaryBankZipOrPostal);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.CountryCode, paymentFullDetails.IntermediaryBankCountryCode);
            Assert.AreEqual(payment.SettlementCurrencyCode, paymentFullDetails.SettlementCurrency);
            Assert.AreEqual(payment.InstructionCodeForBank, paymentFullDetails.InstructionCodeForBank);
            Assert.AreEqual(payment.InstructionForBank, paymentFullDetails.InstructionForBank);
            Assert.AreEqual(payment.PurposeOfPayment, paymentFullDetails.PurposeOfPayment);
            Assert.AreEqual((int) payment.PainFileGenerationStatus, paymentFullDetails.PainFileGenerationStatus);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.AccountNumber, paymentFullDetails.IntermediaryBankAccountNumber);
            Assert.AreEqual(null, paymentFullDetails.RemittanceType);
            Assert.AreEqual(payment.BankAccount.BankAccountOwnerName, paymentFullDetails.BankAccountOwnerName);
            Assert.AreEqual(payment.ThirdPartyRemitter.Id, paymentFullDetails.ThirdPartyRemitterId);
            Assert.AreEqual(payment.ThirdPartyRemitter.Version, paymentFullDetails.ThirdPartyRemitterVersion);
            Assert.AreEqual(payment.ThirdPartyRemitter.VersionedOn, paymentFullDetails.ThirdPartyRemitterVersionedOn);
            Assert.AreEqual(payment.ThirdPartyRemitter.Type, paymentFullDetails.ThirdPartyRemitterType);
            Assert.AreEqual(payment.ThirdPartyRemitter.BusinessName, paymentFullDetails.ThirdPartyRemitterBusinessName);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine1, paymentFullDetails.ThirdPartyRemitterAddressLine1);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine2, paymentFullDetails.ThirdPartyRemitterAddressLine2);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine3, paymentFullDetails.ThirdPartyRemitterAddressLine3);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.City, paymentFullDetails.ThirdPartyRemitterCity);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.StateOrProvince, paymentFullDetails.ThirdPartyRemitterStateOrProv);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.ZipOrPostalCode, paymentFullDetails.ThirdPartyRemitterZipOrPostal);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.CountryCode, paymentFullDetails.ThirdPartyRemitterCountryCode);
            Assert.AreEqual(payment.ThirdPartyRemitter.PhoneNumber, paymentFullDetails.ThirdPartyRemitterPhoneNumber);
            Assert.AreEqual(payment.ThirdPartyRemitter.Email, paymentFullDetails.ThirdPartyRemitterEmailAddress);
            Assert.AreEqual(payment.ThirdPartyRemitter.IdentificationType, paymentFullDetails.ThirdPartyRemitterIdentificationType);
            Assert.AreEqual(payment.ThirdPartyRemitter.Identification, paymentFullDetails.ThirdPartyRemitterIdentification);
            Assert.AreEqual(payment.ThirdPartyRemitter.Industry, paymentFullDetails.ThirdPartyRemitterIndustry);
            Assert.AreEqual(payment.GPGProcessedUTC, paymentFullDetails.GPGProcessedUTC);
            Assert.AreEqual(payment.IsFixedAmountInSettlementCurrency, paymentFullDetails.IsFixedAmountInSettlementCurrency);
            Assert.AreEqual(payment.SettlementAmountMoney.Amount, paymentFullDetails.SettlementAmount);
            Assert.AreEqual(payment.SanctionScanStatus, paymentFullDetails.SanctionScanStatus);
            Assert.AreEqual(payment.SanctionScanStatusUpdatedOnUtc, paymentFullDetails.SanctionScanStatusUpdatedOnUtc);
            Assert.AreEqual(payment.IsFunded, paymentFullDetails.IsFunded);
            Assert.AreEqual(payment.PartnerReference, paymentFullDetails.PartnerReference);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankBranchCode, paymentFullDetails.IntermediaryBankBranchCode);
            Assert.IsEmpty(paymentFullDetails.ExternalBatchId);
            Assert.IsEmpty(paymentFullDetails.CustomerReferenceNumber);
            Assert.IsEmpty(paymentFullDetails.ExternalDescription);
            Assert.IsEmpty(paymentFullDetails.ExternalPaymentMethod);
            Assert.IsNull(paymentFullDetails.IsFundedOn);
            Assert.IsEmpty(paymentFullDetails.RemittanceInformation1);
            Assert.IsEmpty(paymentFullDetails.RemittanceInformation2);
            Assert.IsEmpty(paymentFullDetails.WUBSBankBatchId);

            Assert.AreEqual((int) customer.Status, paymentFullDetails.CustomerStatus);
            Assert.AreEqual(customer.Name, paymentFullDetails.CustomerName);
            Assert.AreEqual(customer.NotificationEmails, paymentFullDetails.CustomerNotificationEmails);
            Assert.AreEqual(customer.TTLExpiration, paymentFullDetails.CustomerTTLExpiration);
            Assert.AreEqual(customer.PartnerAssignedCustomerId, paymentFullDetails.PartnerAssignedCustomerId);
            Assert.AreEqual(customer.TransactionSystemCustomerExternalId, paymentFullDetails.TransactionSystemCustomerExternalId);
            Assert.AreEqual(customer.CountryCode, paymentFullDetails.CustomerCountryCode);
            Assert.AreEqual(partner.Description, paymentFullDetails.PartnerDescription);
            Assert.AreEqual(partner.FilePrefix, paymentFullDetails.PartnerFilePrefix);
            Assert.AreEqual(partner.BankRefPrefix, paymentFullDetails.PartnerBankRefPrefix);
            Assert.AreEqual(partner.IsActive, paymentFullDetails.PartnerIsActive);
            Assert.AreEqual(partner.Name, paymentFullDetails.PartnerCommonName);
            Assert.AreEqual(partner.Code, paymentFullDetails.PartnerCode);
            Assert.AreEqual(partner.IsThirdPartyRemitterEnabled, paymentFullDetails.PartnerHasThirdPartyRemitterEnabled);
            Assert.AreEqual((int) partner.PaymentModel, paymentFullDetails.PaymentModelId);
            Assert.AreEqual(partner.SecurityToken, paymentFullDetails.PartnerSecurityToken);
            Assert.AreEqual(partner.InvoiceTypeId, paymentFullDetails.PartnerInvoiceTypeId);
        }
    }
}
