﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Publishers.Assemblers;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Publishers.Assemblers
{
    [TestFixture]
    public class PartnerAssemblerFixture
    {
        [Test]
        public void PartnerAssembler_AssemblesPartner()
        {
            var domainPartner = new Partner
            {
                Id = 111,
                Description = "a partner",
                Code = "code",
                Name = "name",
                IsActive = true,
                FilePrefix = "file prefix",
                SecurityToken = "security token",
                InvoiceTypeId = 2,
                BankRefPrefix = "bank ref prefix",
                PaymentModel = PaymentModel.Coupled,
                IsThirdPartyRemitterEnabled = true
            };

            var partner = PartnerAssembler.AssemblePartner(domainPartner);

            Assert.AreEqual(domainPartner.Id, partner.Id);
            Assert.AreEqual(domainPartner.Description, partner.Description);
            Assert.AreEqual(domainPartner.Code, partner.Code);
            Assert.AreEqual(domainPartner.Name, partner.CommonName);
            Assert.AreEqual(domainPartner.IsActive, partner.Active);
            Assert.AreEqual(domainPartner.FilePrefix, partner.FilePrefix);
            Assert.AreEqual(domainPartner.SecurityToken, partner.SecurityToken);
            Assert.AreEqual(domainPartner.InvoiceTypeId, partner.InvoiceTypeId);
            Assert.AreEqual(domainPartner.BankRefPrefix, partner.BankRefPrefix);
            Assert.AreEqual((int)domainPartner.PaymentModel, partner.PaymentModelId);
            Assert.AreEqual(domainPartner.IsThirdPartyRemitterEnabled, partner.ThirdPartyRemitterEnabled);
        }
    }
}
