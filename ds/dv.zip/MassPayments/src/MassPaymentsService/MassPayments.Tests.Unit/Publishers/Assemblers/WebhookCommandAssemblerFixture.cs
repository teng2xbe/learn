﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Publishers.Assemblers;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using Common.Contracts.MassPayments.Messages.Enums;

namespace MassPayments.Tests.Unit.Publishers.Assemblers
{
    [TestFixture]
    public class WebhookCommandAssemblerFixture
    {
        private DateTime timeStamp;

        [SetUp]
        public void Setup()
        {
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });
        }

        [TearDown]
        public void Teardown()
        {
            ServiceCallContextManager.Instance = null;
        }

        [Test]
        public void AssembleCreateCommand_Returns_ExpectedCreateCommand()
        {
            var whObject = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = false,
                Uri = "call_me.php",
                SecurityToken = "aToken"
            };
            var partner = new Partner {Code = "Blahlah"};
            var whCommand = WebhookCommandAssembler.AssembleCreateCommand(whObject, partner);

            Assert.IsNotNull(whCommand);
            Assert.AreEqual(partner.Code, whCommand.SubscriberCode);
            Assert.AreEqual(Application.MassPayments, whCommand.Application);
            Assert.AreEqual(false, whCommand.IsPrimary);
            Assert.AreEqual("call_me.php", whCommand.Uri);
            Assert.AreEqual(whObject.Id, whCommand.WebhookId);
            Assert.AreEqual(timeStamp.ToUniversalTime(), whCommand.RequestedOnUtc);
            Assert.AreEqual("aToken", whCommand.SecurityToken);
        }

        [Test]
        public void AssembleUpdateCommand_Returns_ExpectedUpdateCommand()
        {
            var whObject = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = false,
                Uri = "call_me.php",
                SecurityToken = "aToken"
            };

            var partner = new Partner { Code = "Blahlah" };
            var whCommand = WebhookCommandAssembler.AssembleUpdateCommand(whObject,partner);

            Assert.IsNotNull(whCommand);
            Assert.AreEqual(partner.Code, whCommand.SubscriberCode);
            Assert.AreEqual(Application.MassPayments, whCommand.Application);
            Assert.AreEqual(false, whCommand.IsPrimary);
            Assert.AreEqual("call_me.php", whCommand.Uri);
            Assert.AreEqual(whObject.Id, whCommand.WebhookId);
            Assert.AreEqual(timeStamp.ToUniversalTime(), whCommand.RequestedOnUtc);
        }
    }
}
