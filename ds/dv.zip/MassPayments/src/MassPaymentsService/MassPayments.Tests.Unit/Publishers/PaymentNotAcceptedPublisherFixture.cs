﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Contracts.MassPayments.Messages.Events;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Infrastructure.Bus;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Publishers;
using MassPayments.Tests.Unit.Helpers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Publishers
{
    [TestFixture]
    public class PaymentNotAcceptedPublisherFixture
    {
        [SetUp]
        public void Setup()
        {
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
         }

        [TearDown]
        public void TearDown()
        {
            MassPayBus.Instance = null;
        }

        [Test]
        public void Publish_Publishes_ExpectedEventType()
        {
            var failedPayments = new List<PaymentRequest> { new PaymentRequest { PaymentId = "PID004", PartnerId = 1, PartnerAssignedCustomerId = "cust1", Message = "1004:failed"} };

            MassPayBus.Instance.Expect(b => b.Publish(Arg<PaymentNotAcceptedEvent>.Is.Anything)).Repeat.Once();
            Assert.DoesNotThrow(() => new PaymentNotAcceptedPublisher(new Partner()).Publish(failedPayments));
            MassPayBus.Instance.VerifyAllExpectations();
        }

        [Test]
        public void Publish_Publishes_MessageWithExpectedValues()
        {
            var failedPayments = new List<PaymentRequest> { new PaymentRequest { PaymentId = "PID004", PartnerId = 1, PartnerAssignedCustomerId = "cust1", Message = "1004:failed" } };
            var partner = new Partner {Code = "Blahlah"};
            var publisher = new PaymentNotAcceptedPublisher(partner);
            //TODO: investigate why published not set to use PartnerId from paymentRequest
        
            MassPayBus.Instance.Expect(b => b.Publish(Arg<PaymentNotAcceptedEvent>.Matches(e =>e.SubscriberCode == partner.Code && 
                    e.NotAcceptedPayments != null && 
                    e.NotAcceptedPayments.Count == 1 && 
                    e.NotAcceptedPayments[0].CustomerId == "cust1" &&
                    e.NotAcceptedPayments[0].Id == "PID004" &&
                    e.NotAcceptedPayments[0].NotAcceptedReason == "1004:failed"))).Repeat.Once();
            Assert.DoesNotThrow(() => publisher.Publish(failedPayments));
            MassPayBus.Instance.VerifyAllExpectations();
        }
    }
}
