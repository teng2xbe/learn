﻿using System;
using Common.Contracts.MassPayments.Messages.Commands;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.Infrastructure.Bus;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Publishers.WebhookCommandPublishers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Publishers
{
    [TestFixture]
    public class WebhookCommandSenderFixture
    {
        private DateTime timeStamp;

        [SetUp]
        public void Setup()
        {
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });

            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
        }

        [TearDown]
        public void Teardown()
        {
            ServiceCallContextManager.Instance = null;
            MassPayBus.Instance = null;
        }

        [Test]
        public void PublishCreateCommand_CallsBus_WithExpectedCommand()
        {
            var whObject = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = false,
                Uri = "call_me.php"
            };
            var partner = new Partner {Code = "Blahlah"};
            MassPayBus.Instance.Expect(b => b.Send(Arg<CreateWebhookCommand>.Is.TypeOf)).Repeat.Once();
            Assert.DoesNotThrow(() => new CreateWebhookCommandPublisher(partner).Publish(whObject));
            MassPayBus.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PublishUpdateCommand_CallsBus_WithExpectedCommand()
        {
            var whObject = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = false,
                Uri = "call_me.php"
            };

            var partner = new Partner { Code = "Blahlah" };
            MassPayBus.Instance.Expect(b => b.Send(Arg<UpdateWebhookCommand>.Is.TypeOf)).Repeat.Once();
            Assert.DoesNotThrow(() => new UpdateWebhookCommandPublisher(partner).Publish(whObject));
            MassPayBus.Instance.VerifyAllExpectations();
        }
    }
}
