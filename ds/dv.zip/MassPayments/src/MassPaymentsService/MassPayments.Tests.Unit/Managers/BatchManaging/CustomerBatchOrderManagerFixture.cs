﻿using System;
using System.Collections.Generic;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Batches;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Bus;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Infrastructure.Polling;
using MassPayments.Infrastructure.Polling.Interfaces;
using MassPayments.Managers;
using MassPayments.Managers.BatchManaging;
using MassPayments.Managers.Interfaces;
using MassPayments.Managers.Subscription.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.ResourceAccess.OrdersRA;
using MassPayments.ResourceAccess.OrdersRA.Interfaces;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Tests.Unit.Helpers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;
using DomainSettlementPaymentMethod = MassPayments.Domain.Enums.SettlementPaymentMethod;
using Order = MassPayments.Domain.Entities.Order;

namespace MassPayments.Tests.Unit.Managers.BatchManaging
{
    [TestFixture]
    public class CustomerBatchOrderManagerFixture
    {
        private DateTime timeStamp;
        private IPublisher<Order> orderStatusUpdatedPublisher;

        [SetUp]
        public void Setup()
        {
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();

            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            PaymentBatchMapper.Instance = MockRepository.GenerateMock<IPaymentBatchMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            PaymentPoller.Instance = MockRepository.GenerateMock<IPaymentPoller>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            OrdersProviderFactory.InjectedOrdersProviderInterface = MockRepository.GenerateMock<IOrdersProvider>();
            orderStatusUpdatedPublisher = MockRepository.GenerateMock<IPublisher<Order>>();
            PublisherFactory.InjectPublisherForTesting(typeof(OrderStatusUpdatedPublisher), orderStatusUpdatedPublisher);

            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyCache.Instance.Reinitialize();

            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
            CustomerMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            PaymentBatchMapper.Instance = null;
            EventLogger.Instance = null;
            PaymentPoller.Instance = null;
            QuoteMapper.Instance = null;
            PartnerMapper.Instance = null;
            OrderMapper.Instance = null;
            OrdersProviderFactory.InjectedOrdersProviderInterface = null;
            ServiceCallContextManager.Instance = null;
            orderStatusUpdatedPublisher = null;
            ServiceCallContextManager.Instance = null;
            MassPayBus.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            ServiceCallContextManager.Instance = null;
            CurrencyCacheMapper.Instance = null;
            ////EventLogger.Instance = null;
            /// 
            ServiceSettings.Instance = null;
        }

        [Test]
        public void GetQuoteForBatch_MakeCorrectCalls()
        {
            var batch = new CustomerBatch
            {
                ActiveQuoteRequestId = 1
            };
            var quoteManager = MockRepository.GenerateMock<IQuoteManager>();
            var manager = new CustomerBatchOrderManager(quoteManager, new BookIncomingManager());
            quoteManager.Expect(qm => qm.GetQuote(1));
            manager.GetQuoteForBatch(batch);
            quoteManager.VerifyAllExpectations();

            batch.ActiveQuoteRequestId = 0;
            var quote = manager.GetQuoteForBatch(batch);
            Assert.IsNull(quote);
        }

        [Test]
        public void CreateQuoteForBatch_ThrowsExceptionWhenBatchIsAlreadyCommitted()
        {
            var customer = new Customer { Id = 1111, PartnerAssignedCustomerId = "1111" };
            Assert.Throws<OrderSubmittedForBatchException>(() => new CustomerBatchOrderManager(new QuoteManager(), new BookIncomingManager()).CreateQuoteForBatch(new CustomerBatch { BatchReference = "VIKINGS", BatchStatus = CustomerBatchStatus.Committed}, customer));
            CustomerBatchMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BookBatch_CallsBatchSettlementValidator()
        {
            var request = new CommitBatchRequest
            {
                CustomerBatch = new CustomerBatch { ExternalId = "cats" ,ActiveQuoteRequestId = 1},
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = new Currency("CAD"),
                        SettlementMethod = DomainSettlementPaymentMethod.Wire
                    }
                }
            };

            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999,
                PartnerId = 2
            };

            var quote = new Quote
            {
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        SettlementMoney = new Money(Currency.CAD, 100.00m),
                        TradeMoney = new Money(Currency.USD, 0m)
                    }
                }
            };
            var batchItems = new List<PaymentAmount>
            {
              new PaymentAmount {SettlementMoney = new Money(Currency.CAD, 0), Money = new Money (Currency.USD, 100m) }
            };
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatchAmounts(Arg<CustomerBatch>.Is.Anything))
                .Return(batchItems)
                .Repeat.Once();
            
            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.BookBatch(request, batchItems, quote, customer))
                .IgnoreArguments()
                .Return(new List<BookedIncomingOrder>
                {
                    new BookedIncomingOrder
                    {
                        SettlementCurrencyCode = "CAD",
                        SettlementPaymentMethod = "WIRE",
                        ConfirmationNumber = "abcd",
                        OrderId = 111,
                        OrderDate = new DateTime(2016, 4, 28),
                        LineItems = new List<BookedIncomingOrderItem>
                        {
                            new BookedIncomingOrderItem
                            {
                                TradeCurrencyCode = "USD",
                                TradeAmount = 100,
                                SettlementAmount = 0
                            }
                        }
                    }
                });

            var payments = new List<Payment>
            {
                new Payment(111) {PaymentStatus = PaymentStatus.Created}
            };
            PaymentMapper.Instance.Expect(m => m.GetPayments(Arg<CustomerBatch>.Is.Anything)).Return(payments);

            var bookIncomingManager = MockRepository.GenerateMock<IBookIncomingManager>();
            bookIncomingManager.Expect(
                bm =>
                    bm.HandleSuccessfulBooking(Arg<Customer>.Is.Anything, Arg<List<BookedIncomingOrder>>.Is.Anything,
                        Arg<Quote>.Is.Anything, Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new List<Order> {new Order
                        {
                            CreatedOn = DateTime.Now,
                            LastUpdatedOn = DateTime.Now,
                            SettlementCurrencyCode = "CAD"
                        } });
            var quoteManager = MockRepository.GenerateMock<IQuoteManager>();
            var customerBatchOrderManager = MockRepository.GeneratePartialMock<CustomerBatchOrderManager>(quoteManager, bookIncomingManager);
            customerBatchOrderManager.Expect(c => c.ValidateBatchForCommitting(Arg<CustomerBatch>.Is.Anything, Arg<CommitBatchRequest>.Is.Anything)).Repeat.Once();

            customerBatchOrderManager.Expect(q => q.GetQuoteForBatch(request.CustomerBatch)).Return(quote);

            var result = customerBatchOrderManager.BookBatch(request, customer, new Partner());

            Assert.AreEqual(1, result.Orders.Count);

            PaymentMapper.Instance.VerifyAllExpectations();
            bookIncomingManager.VerifyAllExpectations();
            quoteManager.VerifyAllExpectations();
            customerBatchOrderManager.VerifyAllExpectations();


        }


        [Test]
        public void BookBatch_ReturnsCorrectResults()
        {
            var request = new CommitBatchRequest
            {
                CustomerBatch = new CustomerBatch { ExternalId = "cats"},
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = new Currency("CAD"),
                        SettlementMethod = DomainSettlementPaymentMethod.Wire
                    }
                }
            };

            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999,
                PartnerId = 2
            };

            //TODO: is it really expected and verified?
            //CustomerBatchMapper.Instance.Expect(m => m.GetCustomerBatchByCustomerAndBatchId(customer.Id, request.BatchId));
            var quoteManager = MockRepository.GenerateMock<IQuoteManager>();
            var quote = new Quote
            {
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        SettlementMoney = new Money(Currency.CAD, 100.00m),
                        TradeMoney = new Money(Currency.USD, 0m)
                    }
                }
            };
            var customerBatchManager = MockRepository.GenerateMock<ICustomerBatchManager>();
            var batchItems = new List<PaymentAmount>
            {
              new PaymentAmount {SettlementMoney = new Money(Currency.CAD, 0), Money = new Money (Currency.USD, 100m) }
            };
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatchAmounts(Arg<CustomerBatch>.Is.Anything))
                .Return(batchItems)
                .Repeat.Once();
           
            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.BookBatch(request, batchItems, quote, customer))
                .IgnoreArguments()
                .Return(new List<BookedIncomingOrder>
                {
                    new BookedIncomingOrder
                    {
                        SettlementCurrencyCode = "CAD",
                        SettlementPaymentMethod = "WIRE",
                        ConfirmationNumber = "abcd",
                        OrderId = 111,
                        OrderDate = new DateTime(2016, 4, 28),
                        LineItems = new List<BookedIncomingOrderItem>
                        {
                            new BookedIncomingOrderItem
                            {
                                TradeCurrencyCode = "USD",
                                TradeAmount = 100,
                                SettlementAmount = 0
                            }
                        }
                    }
                });

            var payments = new List<Payment>
            {
                new Payment(111) {PaymentStatus = PaymentStatus.Created}
            };
            PaymentMapper.Instance.Expect(m => m.GetPayments(Arg<CustomerBatch>.Is.Anything)).Return(payments);

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            subscriptionManager.Expect(s => s.IsPartnerRegistered(Arg<int>.Is.Anything, Arg<SubscriptionType>.Is.Anything)).Return(false);

            var bookIncomingManager = MockRepository.GenerateMock<IBookIncomingManager>();
            bookIncomingManager.Expect(
               bm =>
                   bm.HandleSuccessfulBooking(Arg<Customer>.Is.Anything, Arg<List<BookedIncomingOrder>>.Is.Anything,
                       Arg<Quote>.Is.Anything, Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new List<Order> {new Order
                        {
                            CreatedOn = DateTime.Now,
                            LastUpdatedOn = DateTime.Now,
                            SettlementCurrencyCode = "CAD"
                        } });
            var customerBatchOrderManager = MockRepository.GeneratePartialMock<CustomerBatchOrderManager>(quoteManager, bookIncomingManager);
            customerBatchOrderManager.Expect(c => c.ValidateBatchForCommitting(Arg<CustomerBatch>.Is.Anything, Arg<CommitBatchRequest>.Is.Anything)).Repeat.Once();
            customerBatchOrderManager.Expect(q => q.GetQuoteForBatch(Arg<CustomerBatch>.Is.Anything)).Return(quote);
            var result = customerBatchOrderManager.BookBatch(request, customer,new Partner());

            Assert.AreEqual(1, result.Orders.Count);
            customerBatchManager.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            bookIncomingManager.VerifyAllExpectations();
            quoteManager.VerifyAllExpectations();
            customerBatchOrderManager.VerifyAllExpectations();
        }


        [Test]
        public void CreateQuoteForBatch_MakeCorrectCalls()
        {
            var customer = new Customer { Id = 1111, PartnerAssignedCustomerId = "1111" };
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();

            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(x => x.Quote(Arg<CCTMassPayments.QuoteRequest>.Is.Anything)).Return(
                new QuoteResult { QuotedItems = new List<QuoteResultItem>() });

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<CustomerBatch>.Is.Anything)).
                Return(new List<Payment> {
                    new Payment(1) { PaymentStatus = PaymentStatus.Created, AmountMoney = new Money(Currency.CAD, 100.00m), SettlementAmountMoney = new Money(Currency.USD, 0.00m), IsFixedAmountInSettlementCurrency = false}
                });
          
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(1)).IgnoreArguments().Return(new Quote
            {
                CustomerId = 4,
                RequestTimeUtc = timeStamp.AddMilliseconds(-10),
                PartnerId = 2,
                Id = 123456,
                ExpirationTimeUtc = timeStamp.AddMinutes(5),
                DurationInSec = 600,
                CustomerBatchExternalId = "VIKING4"
            });
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatchAmounts(Arg<CustomerBatch>.Is.Anything))
                .Return(new List<PaymentAmount>())
                .Repeat.Once();
            Assert.DoesNotThrow(() => new CustomerBatchOrderManager().CreateQuoteForBatch(
                new CustomerBatch
                {
                    BatchReference = "VIKINGS",
                    BatchStatus = CustomerBatchStatus.Created
                }, customer));

            PaymentMapper.Instance.VerifyAllExpectations();
            OrderMapper.Instance.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            paymentManager.VerifyAllExpectations();
            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        [Test]
        public void UpdatePaymentsAfterBatchIsBooked_UpdatesFieldsCorrectly()
        {
            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    SettlementAmountMoney = new Money(Currency.CAD, 100)
                },
                new Payment(2)
                {
                    SettlementAmountMoney = new Money(Currency.USD, 100)
                }

            };

            var orders = new List<Order>
            {
                new Order
                {
                    OrderId = 1,
                    ConfirmationNumber = "Blah1",
                    SettlementCurrencyCode = "CAD"
                },
                new Order
                {
                    OrderId = 2,
                    ConfirmationNumber = "Blah2",
                    SettlementCurrencyCode = "USD"
                }
            };
            PaymentMapper.Instance.Expect(
                p => p.UpdatePaymentStatusesAndIncomingOrderInfo(Arg<List<Payment>>.Is.Anything));
            PaymentMapper.Instance.Expect(p => p.GetAcceptedPaymentsByCustomerBatchId(Arg<int>.Is.Anything)).Return(payments);
            PaymentMapper.Instance.Expect(p => p.InsertPaymentStatusHistories(Arg<List<Payment>>.Is.Anything));

            OrderMapper.Instance.Expect(o => o.GetOrdersByQuoteRequest(Arg<int>.Is.Anything)).Return(orders);

            var manager = new CustomerBatchOrderManager();
            manager.UpdatePaymentsAfterBatchIsBooked(new CustomerBatch { Id = 1, ActiveQuoteRequestId = 1 });

            Assert.AreEqual(PaymentStatus.Committed, payments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Committed, payments[1].PaymentStatus);
            Assert.AreEqual(orders[0].OrderId, payments[0].TransactionSystemIncomingOrderId);
            Assert.AreEqual(orders[1].OrderId, payments[1].TransactionSystemIncomingOrderId);
            Assert.AreEqual(orders[0].ConfirmationNumber, payments[0].TransactionSystemIncomingOrderNumber);
            Assert.AreEqual(orders[1].ConfirmationNumber, payments[1].TransactionSystemIncomingOrderNumber);

            PaymentMapper.Instance.VerifyAllExpectations();
            OrderMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void UpdatePaymentsAfterBatchIsBooked_LogsCorrectlyForPaymentsWhichDoesNotFindMatchingOrders()
        {
            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    SettlementAmountMoney = new Money(Currency.CAD, 100)
                },
                new Payment(2)
                {
                    SettlementAmountMoney = new Money(Currency.USD, 100)
                }

            };

            PaymentMapper.Instance.Expect(
                p => p.UpdatePaymentStatusesAndIncomingOrderInfo(Arg<List<Payment>>.Is.Anything));
            PaymentMapper.Instance.Expect(p => p.GetAcceptedPaymentsByCustomerBatchId(Arg<int>.Is.Anything)).Return(payments);

            OrderMapper.Instance.Expect(o => o.GetOrdersByQuoteRequest(Arg<int>.Is.Anything)).Return(new List<Order>());
            EventLogger.Instance.Expect(e => e.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything))
                .Repeat.Once();
            var manager = new CustomerBatchOrderManager();
            manager.UpdatePaymentsAfterBatchIsBooked(new CustomerBatch { Id = 1, ActiveQuoteRequestId = 1 });

            var loggedMessage =
               (string) EventLogger.Instance.GetArgumentsForCallsMadeOn(
                    e => e.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything))[0][0];

            Assert.AreEqual("Could not update booked incoming order info for the following payments 1, 2 because orders were not found.", loggedMessage);

            Assert.AreEqual(PaymentStatus.Committed, payments[0].PaymentStatus);
            Assert.AreEqual(PaymentStatus.Committed, payments[1].PaymentStatus);

            PaymentMapper.Instance.VerifyAllExpectations();
            OrderMapper.Instance.VerifyAllExpectations();
            EventLogger.Instance.VerifyAllExpectations();
        }

    }
}
