﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Batches;
using MassPayments.Exceptions;
using MassPayments.Managers.BatchManaging.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.BatchManaging.Validators
{
    [TestFixture]
    public class BatchSettlementsValidatorFixture
    {
        [Test]
        public void Validate_Throws_ForExtraSettlementCurrency()
        {
            var batch = new CustomerBatch
            {
                Id = 11,
                ExternalId = "P233",
                AggregateAmounts = new List<CustomerBatchCurrencyAggregates>
                {
                    new CustomerBatchCurrencyAggregates
                    {
                        TotalPaymentsSettlementMoney = new Money(Currency.AUD, 122.00m)
                    },
                    new CustomerBatchCurrencyAggregates
                    {
                        TotalPaymentsSettlementMoney = new Money(Currency.CAD, 222.00m)
                    },

                }
            };

            var request = new CommitBatchRequest
            {
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = SettlementPaymentMethod.ACH
                    },

                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.CAD,
                        SettlementMethod = SettlementPaymentMethod.Wire
                    }

                }
            };

            var validator = new BatchSettlementsValidator(batch, request);
            Assert.Throws<SettlementCurrencyNotUsedForBatchPaymentsException>(() => validator.Validate());
        }

        [Test]
        public void Validate_Throws_ForOneSameSettlementCurrency()
        {
            var batch = new CustomerBatch
            {
                Id = 11,
                ExternalId = "P233"
            };

            var request = new CommitBatchRequest
            {
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = SettlementPaymentMethod.ACH
                    },

                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = SettlementPaymentMethod.Wire
                    }

                }
            };

            var validator = new BatchSettlementsValidator(batch, request);
            Assert.Throws<SettlementCurrencySettledMultipleTimesException>(() => validator.Validate());
        }

        [Test]
        public void Validate_Throws_ForMultipleSameSettlementCurrency()
        {
            var batch = new CustomerBatch
            {
                Id = 11,
                ExternalId = "P233"
            };

            var request = new CommitBatchRequest
            {
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = SettlementPaymentMethod.ACH
                    },

                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = SettlementPaymentMethod.Wire
                    },
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.CAD,
                        SettlementMethod = SettlementPaymentMethod.ACH
                    },

                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.CAD,
                        SettlementMethod = SettlementPaymentMethod.Wire
                    },
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.GBP,
                        SettlementMethod = SettlementPaymentMethod.Wire
                    }

                }
            };

            var validator = new BatchSettlementsValidator(batch, request);
            Assert.Throws<SettlementCurrencySettledMultipleTimesException>(() => validator.Validate());
        }

        [Test]
        public void Validate_DoesNotThrow_ForEmptySettlements()
        {
            var batch = new CustomerBatch
            {
                Id = 11,
                ExternalId = "P233"
            };

            var request = new CommitBatchRequest
            {
            };

            var validator = new BatchSettlementsValidator(batch, request);
            Assert.DoesNotThrow(() => validator.Validate());
        }

        [Test]
        public void Validate_DoesNotThrow_ForValidSettlements()
        {
            var batch = new CustomerBatch
            {
                Id = 11,
                ExternalId = "P233",
                AggregateAmounts = new List<CustomerBatchCurrencyAggregates>
                {
                    new CustomerBatchCurrencyAggregates
                    {
                        TotalPaymentsSettlementMoney = new Money(Currency.USD, 122.00m)
                    },
                    new CustomerBatchCurrencyAggregates
                    {
                        TotalPaymentsSettlementMoney = new Money(Currency.CAD, 222.00m)
                    },

                }
            };

            var request = new CommitBatchRequest
            {
                Settlements = new List<CommitBatchSettlementRequest>
                {
                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.USD,
                        SettlementMethod = SettlementPaymentMethod.ACH
                    },

                    new CommitBatchSettlementRequest
                    {
                        SettlementCurrency = Currency.CAD,
                        SettlementMethod = SettlementPaymentMethod.Wire
                    }

                }
            };

            var validator = new BatchSettlementsValidator(batch, request);
            Assert.DoesNotThrow(() => validator.Validate());
        }

        [Test]
        public void GetInvalidFields_ThowsException()
        {
            Assert.Throws<NotImplementedException>(() => new BatchSettlementsValidator(null, null).GetInvalidFields());
        }
    }
}
