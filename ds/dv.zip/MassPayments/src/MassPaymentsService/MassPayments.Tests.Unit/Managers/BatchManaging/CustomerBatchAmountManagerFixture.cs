﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Managers.BatchManaging;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.BatchManaging
{
    [TestFixture]
    public class CustomerBatchAmountManagerFixture
    {
        private IPublisher<Payment, CustomerBatch, Customer> paymentStatusUpdatedpublisher;
        [SetUp]
        public void Setup()
        {
            CustomerBatchCurrencyMapper.Instance = MockRepository.GenerateMock<ICustomerBatchCurrencyMapper>();
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(c => c.GetCurrencyDictionary()).Return(new Dictionary<string, Currency>
            {
                {"CAD", Currency.CAD},
                {"AUD", Currency.AUD},
                {"EUR", Currency.EUR},
                {"USD", Currency.USD},
                {"GBP", Currency.GBP}
            });
            CurrencyCache.Instance.Reinitialize();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            paymentStatusUpdatedpublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentStatusUpdatedPublisher), paymentStatusUpdatedpublisher);
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CustomerBatchCurrencyMapper.Instance = null;
            PaymentMapper.Instance = null;
            QuoteMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyCache.Instance = null;
            EventLogger.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            paymentStatusUpdatedpublisher = null;
            PartnerMapper.Instance = null;
            CustomerMapper.Instance = null;
        }

        [Test]
        public void AdjustBatchAmountAfterbooking_MakeCorrectCalls()
        {
            var batch = new CustomerBatch
            {
                ActiveQuoteRequestId = 1,
                Id = 1
            };

            var batchAggregates = new List<CustomerBatchCurrencyAggregates>
            {
                new CustomerBatchCurrencyAggregates
                {
                    IsFixedAmountInSettlementCurrency= true,
                    TotalPaymentsMoney = new Money(Currency.CAD,0m),
                    TotalPaymentsSettlementMoney = new Money(Currency.USD, 2.00m)
                }
            };

            var quote = new Quote
            {
                Id = 1,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = true,
                        TradeMoney = new Money(Currency.CAD, 1.00m),
                        SettlementMoney = new Money(Currency.USD, 2.00m)
                    }
                }
            };

            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.CAD, 0.51m),
                    SettlementAmountMoney = new Money(Currency.USD, 1.00m)
                }
            };

            QuoteMapper.Instance.Expect(qm => qm.GetQuote(batch.ActiveQuoteRequestId)).Return(quote);
            CustomerBatchCurrencyMapper.Instance.Expect(c => c.GetCustomerBatchCurrencyAggregatesByBatchId(batch.Id)).Return(batchAggregates);
            CustomerBatchCurrencyMapper.Instance.Expect(
                c => c.InsertCustomerBatchCurrency(Arg<int>.Is.Anything, Arg<Money>.Is.Anything,
                    Arg<Money>.Is.Anything, Arg<Money>.Is.Anything, Arg<bool>.Is.Anything)).Repeat.Times(1);
            PaymentMapper.Instance.Expect(p => p.GetPayments(Arg<CustomerBatch>.Is.Anything)).Return(payments);
            PaymentMapper.Instance.Expect(p => p.UpdatePaymentsAmount(Arg<List<Payment>>.Is.Anything));
            PaymentMapper.Instance.Expect(p => p.BulkInsertPaymentAmountAdjustmentHistory(Arg<List<PaymentAmountAdjustmentHistory>>.Is.Anything));

            var manager = new CustomerBatchAmountManager();
            Assert.DoesNotThrow(() => manager.AdjustBatchAmountAfterbooking(batch));

            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchCurrencyMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void AdjustAndUpdateBatchCurrencyAmounts_MakeCorrectCalls()
        {
            var quote = new Quote
            {
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = true,
                        TradeMoney = new Money(Currency.CAD, 1.00m),
                        SettlementMoney = new Money(Currency.USD, 2.00m)
                    },
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = false,
                        TradeMoney = new Money(Currency.CAD, 1.00m),
                        SettlementMoney = new Money(Currency.AUD, 2.00m)
                    }
                }
            };

            var batchAggregates = new List<CustomerBatchCurrencyAggregates>
            {
                new CustomerBatchCurrencyAggregates
                { 
                    IsFixedAmountInSettlementCurrency= true,
                    TotalPaymentsMoney = new Money(Currency.CAD,0m),
                    TotalPaymentsSettlementMoney = new Money(Currency.USD, 2.00m)
                },
                new CustomerBatchCurrencyAggregates
                {
                    IsFixedAmountInSettlementCurrency = false,
                    TotalPaymentsMoney = new Money(Currency.CAD, 1.00m),
                    TotalPaymentsSettlementMoney = new Money(Currency.AUD, 0m)
                }
            };

            var manager = new CustomerBatchAmountManager();
            Assert.DoesNotThrow(() => manager.AdjustAndUpdateBatchCurrencyAmounts(batchAggregates, quote));
            var args =
                CustomerBatchCurrencyMapper.Instance.GetArgumentsForCallsMadeOn(
                    c =>
                        c.InsertCustomerBatchCurrency(Arg<int>.Is.Anything, Arg<Money>.Is.Anything,
                            Arg<Money>.Is.Anything, Arg<Money>.Is.Anything, Arg<bool>.Is.Anything));
            
            Assert.AreEqual(2, args.Count);
            Assert.AreEqual(quote.QuotedItems[0].TradeMoney.Amount, ((Money)args[0][1]).Amount);
            Assert.AreEqual(quote.QuotedItems[0].TradeMoney.Amount, batchAggregates[0].TotalPaymentsMoney.Amount);
            Assert.AreEqual(0, ((Money)args[0][2]).Amount);
            Assert.AreEqual(0, ((Money)args[1][1]).Amount);
            Assert.AreEqual(quote.QuotedItems[1].SettlementMoney.Amount, ((Money)args[1][2]).Amount);
            Assert.AreEqual(quote.QuotedItems[1].SettlementMoney.Amount, batchAggregates[1].TotalPaymentsSettlementMoney.Amount);
        }

        [Test]
        public void CalculateAndUpdatePaymentAmounts_MakeCorrectCalls()
        {
            var batch = new CustomerBatch
            {
                ActiveQuoteRequestId = 1,
                Id = 1
            };

            var quote = new Quote
            {
                Id = 1,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = true,
                        IsDirect = true,
                        RateValueInverted = 1.200m,
                        TradeMoney = new Money(Currency.CAD, 1.00m),
                        SettlementMoney = new Money(Currency.USD, 2.00m)
                    },
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = true,
                        IsDirect = false,
                        RateValue = 0.800m,
                        TradeMoney = new Money(Currency.AUD, 1.00m),
                        SettlementMoney = new Money(Currency.USD, 2.00m)
                    },
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = false,
                        IsDirect = true,
                        RateValue = 1.200m,
                        TradeMoney = new Money(Currency.CAD, 1.00m),
                        SettlementMoney = new Money(Currency.AUD, 2.00m)
                    },
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = false,
                        IsDirect = false,
                        RateValueInverted = 0.800m,
                        TradeMoney = new Money(Currency.GBP, 1.00m),
                        SettlementMoney = new Money(Currency.AUD, 2.00m)
                    }
                }
            };

            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.CAD, 0.00m),
                    SettlementAmountMoney = new Money(Currency.USD, 2.00m)
                },
                new Payment(2)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.AUD, 0.00m),
                    SettlementAmountMoney = new Money(Currency.USD, 2.00m)
                },
                new Payment(3)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.CAD, 1.00m),
                    SettlementAmountMoney = new Money(Currency.AUD, 0.00m)
                },
                new Payment(4)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.GBP, 1.00m),
                    SettlementAmountMoney = new Money(Currency.AUD, 0.00m)
                }
            };

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<CustomerBatch>.Is.Anything)).Return(payments);

            var manager = new CustomerBatchAmountManager();
            Assert.DoesNotThrow(() => manager.CalculatePaymentAmounts(batch,quote));

            Assert.AreEqual(
                new Money(payments[0].AmountMoney.Currency, 
                    quote.QuotedItems[0].RateValueInverted * payments[0].SettlementAmountMoney.Amount //formula for calculating payment amount
                ).Amount 
                ,payments[0].AmountMoney.Amount);

            Assert.AreEqual(
                new Money(payments[1].AmountMoney.Currency,
                    quote.QuotedItems[1].RateValue * payments[1].SettlementAmountMoney.Amount //formula for calculating payment amount
                ).Amount
                , payments[1].AmountMoney.Amount);

            Assert.AreEqual(
                new Money(payments[2].SettlementAmountMoney.Currency,
                    quote.QuotedItems[2].RateValue * payments[2].AmountMoney.Amount //formula for calculating payment amount
                ).Amount
                , payments[2].SettlementAmountMoney.Amount);

            Assert.AreEqual(
                new Money(payments[3].SettlementAmountMoney.Currency,
                    quote.QuotedItems[3].RateValueInverted * payments[3].AmountMoney.Amount //formula for calculating payment amount
                ).Amount
                , payments[3].SettlementAmountMoney.Amount);

            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void AdjustAndUpdatePaymentAmounts_MakeCorrectCalls()
        {
            var partner = new Partner {Id = 2};
            var customer = new Customer {Id = 2};
            var batch = new CustomerBatch {Id = 2,CustomerId = 2};
            var batchAggregates = new List<CustomerBatchCurrencyAggregates>
            {
                new CustomerBatchCurrencyAggregates
                {
                    IsFixedAmountInSettlementCurrency= true,
                    TotalPaymentsMoney = new Money(Currency.CAD,1.00m),
                    TotalPaymentsSettlementMoney = new Money(Currency.USD, 2.00m)
                },
                new CustomerBatchCurrencyAggregates
                {
                    IsFixedAmountInSettlementCurrency = false,
                    TotalPaymentsMoney = new Money(Currency.CAD, 3.00m),
                    TotalPaymentsSettlementMoney = new Money(Currency.AUD, 4.00m)
                }
            };

            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.CAD, 0.51m),
                    SettlementAmountMoney = new Money(Currency.USD, 1.00m)
                },
                new Payment(2)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.CAD, 0.47m),
                    SettlementAmountMoney = new Money(Currency.USD, 1.00m)
                },
                new Payment(3)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.CAD, 1.50m),
                    SettlementAmountMoney = new Money(Currency.AUD, 2.02m)
                },
                new Payment(4)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.CAD, 1.50m),
                    SettlementAmountMoney = new Money(Currency.AUD, 2.00m)
                }
            };
            
            var manager = new CustomerBatchAmountManager();
            Assert.DoesNotThrow(() => manager.AdjustAndUpdatePaymentAmounts(batchAggregates, payments, partner, customer, batch));


            var args =
               PaymentMapper.Instance.GetArgumentsForCallsMadeOn(
                   pm =>
                       pm.BulkInsertPaymentAmountAdjustmentHistory(
                           Arg<List<PaymentAmountAdjustmentHistory>>.Is.Anything));
            
            var insertedHistories = (List< PaymentAmountAdjustmentHistory>)args[0][0];

            Assert.AreEqual(4, insertedHistories.Count);
            Assert.AreEqual(0.51m, insertedHistories[0].OldAmount);
            Assert.AreEqual(0.52m, insertedHistories[0].NewAmount);

            Assert.AreEqual(0.47m, insertedHistories[1].OldAmount);
            Assert.AreEqual(0.48m, insertedHistories[1].NewAmount);

            Assert.AreEqual(2.02m, insertedHistories[2].OldSettlementAmount);
            Assert.AreEqual(2.01m, insertedHistories[2].NewSettlementAmount);

            Assert.AreEqual(2.00m, insertedHistories[3].OldSettlementAmount);
            Assert.AreEqual(1.99m, insertedHistories[3].NewSettlementAmount);


            args = PaymentMapper.Instance.GetArgumentsForCallsMadeOn(
                    pm => pm.UpdatePaymentsAmount(Arg<List<Payment>>.Is.Anything));

            var updatedPayments = (List<Payment>)args[0][0];
            Assert.AreEqual(4, updatedPayments.Count);
            Assert.AreEqual(insertedHistories[0].NewAmount, updatedPayments[0].AmountMoney.Amount);
            Assert.AreEqual(insertedHistories[1].NewAmount, updatedPayments[1].AmountMoney.Amount);
            Assert.AreEqual(insertedHistories[2].NewSettlementAmount, updatedPayments[2].SettlementAmountMoney.Amount);
            Assert.AreEqual(insertedHistories[3].NewSettlementAmount, updatedPayments[3].SettlementAmountMoney.Amount);

            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
        }

        [Test]
        public void AdjustAndUpdatePaymentAmounts_DoesntErrorOut_WhenSavingHistoryFails()
        {
            var partner = new Partner { Id = 2 };
            var customer = new Customer { Id = 2 };
            var batch = new CustomerBatch { Id = 2, CustomerId = 2 };
            var batchAggregates = new List<CustomerBatchCurrencyAggregates>
            {
                new CustomerBatchCurrencyAggregates
                {
                    IsFixedAmountInSettlementCurrency= true,
                    TotalPaymentsMoney = new Money(Currency.CAD,1.00m),
                    TotalPaymentsSettlementMoney = new Money(Currency.USD, 2.00m)
                },
                new CustomerBatchCurrencyAggregates
                {
                    IsFixedAmountInSettlementCurrency = false,
                    TotalPaymentsMoney = new Money(Currency.CAD, 3.00m),
                    TotalPaymentsSettlementMoney = new Money(Currency.AUD, 4.00m)
                }
            };

            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.CAD, 0.51m),
                    SettlementAmountMoney = new Money(Currency.USD, 1.00m)
                },
                new Payment(2)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.CAD, 0.47m),
                    SettlementAmountMoney = new Money(Currency.USD, 1.00m)
                },
                new Payment(3)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.CAD, 1.50m),
                    SettlementAmountMoney = new Money(Currency.AUD, 2.02m)
                },
                new Payment(4)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.CAD, 1.50m),
                    SettlementAmountMoney = new Money(Currency.AUD, 2.00m)
                }
            };

            PaymentMapper.Instance.Expect(pm => pm.BulkInsertPaymentAmountAdjustmentHistory(Arg<List<PaymentAmountAdjustmentHistory>>.Is.Anything)).Throw(new Exception());
            EventLogger.Instance.Expect(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything));

            var manager = new CustomerBatchAmountManager();
            Assert.DoesNotThrow(() => manager.AdjustAndUpdatePaymentAmounts(batchAggregates, payments, partner, customer, batch));

            PaymentMapper.Instance.VerifyAllExpectations();
            EventLogger.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
        }

        [Test]
        public void AdjustBatchAmountAfterbooking_Works_UsingRohansSampleData()
        {
            var batch = new CustomerBatch
            {
                ActiveQuoteRequestId = 1,
                Id = 1
            };

            var batchAggregates = new List<CustomerBatchCurrencyAggregates>
            {
                new CustomerBatchCurrencyAggregates
                {
                    IsFixedAmountInSettlementCurrency= true,
                    TotalPaymentsMoney = new Money(Currency.USD,0m),
                    TotalPaymentsSettlementMoney = new Money(Currency.CAD, 385.50m)
                }
            };

            var quote = new Quote
            {
                Id = 1,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = true,
                        TradeMoney = new Money(Currency.USD, 308.01m),
                        SettlementMoney = new Money(Currency.CAD, 385.50m),
                        IsDirect = false,
                        RateValue = 0.799m
                    }
                }
            };

            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.USD, 0m),
                    SettlementAmountMoney = new Money(Currency.CAD, 114.9m)
                },
                new Payment(2)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.USD, 0m),
                    SettlementAmountMoney = new Money(Currency.CAD, 34.41m)
                },
                new Payment(3)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.USD, 0m),
                    SettlementAmountMoney = new Money(Currency.CAD, 221.3m)
                },
                new Payment(4)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.USD, 0m),
                    SettlementAmountMoney = new Money(Currency.CAD, 14.89m)
                },

            };

            QuoteMapper.Instance.Expect(qm => qm.GetQuote(batch.ActiveQuoteRequestId)).Return(quote);
            CustomerBatchCurrencyMapper.Instance.Expect(c => c.GetCustomerBatchCurrencyAggregatesByBatchId(batch.Id)).Return(batchAggregates);
            CustomerBatchCurrencyMapper.Instance.Expect(
                c => c.InsertCustomerBatchCurrency(Arg<int>.Is.Anything, Arg<Money>.Is.Anything,
                    Arg<Money>.Is.Anything, Arg<Money>.Is.Anything, Arg<bool>.Is.Anything)).Repeat.Times(1);
            PaymentMapper.Instance.Expect(p => p.GetPayments(Arg<CustomerBatch>.Is.Anything)).Return(payments);
            PaymentMapper.Instance.Expect(p => p.UpdatePaymentsAmount(Arg<List<Payment>>.Is.Anything));
            PaymentMapper.Instance.Expect(p => p.BulkInsertPaymentAmountAdjustmentHistory(Arg<List<PaymentAmountAdjustmentHistory>>.Is.Anything));

            var manager = new CustomerBatchAmountManager();
            Assert.DoesNotThrow(() => manager.AdjustBatchAmountAfterbooking(batch));

            var args =
                PaymentMapper.Instance.GetArgumentsForCallsMadeOn(
                    p =>
                        p.BulkInsertPaymentAmountAdjustmentHistory(Arg<List<PaymentAmountAdjustmentHistory>>.Is.Anything));
            var insertedHistories = (List<PaymentAmountAdjustmentHistory>)args[0][0];
            Assert.AreEqual(1, insertedHistories.Count); //Only 1 cent difference, so only 1 payments gets adjusted
            Assert.AreEqual(payments[0].Id, insertedHistories[0].PaymentId);    //the adjusted payment is the first payment in the list

            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchCurrencyMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();

        }

        [Test]
        public void CalculatePaymentAmount_MakeCorrectCalls()
        {
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            var customerBatchAmountManager = new CustomerBatchAmountManager();
            var quote = new Quote
            {
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = true,
                        SettlementMoney = new Money(new Currency("USD"), 0),
                        TradeMoney =  new Money(new Currency("CAD"), 0),
                        IsDirect = true,
                        RateValueInverted = 1.3333m
                    },
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = true,

                        SettlementMoney = new Money(new Currency("USD"), 0),
                        TradeMoney =  new Money(new Currency("GBP"), 0),
                        IsDirect = false,
                        RateValue = 1.4444m
                    },
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = false,
                        SettlementMoney = new Money(new Currency("CAD"), 0),
                        TradeMoney =  new Money(new Currency("GBP"), 0),
                        IsDirect = true,
                        RateValue = 1.5555m
                    },
                    new QuotedItem
                    {
                        IsAmountInSettlementCurrency = false,
                        SettlementMoney = new Money(new Currency("CAD"), 0),
                        TradeMoney =  new Money(new Currency("AUD"), 0),
                        IsDirect = false,
                        RateValueInverted = 1.9999m
                    }
                }
            };
            var payments = new List<Payment>
            {
                new Payment(1)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.CAD, 0),
                    SettlementAmountMoney = new Money(Currency.USD, 10.00m),
                },
                new Payment(2)
                {
                    IsFixedAmountInSettlementCurrency = true,
                    AmountMoney = new Money(Currency.GBP, 0),
                    SettlementAmountMoney = new Money(Currency.USD, 10.00m),
                },
                new Payment(3)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.GBP, 10.00m),
                    SettlementAmountMoney = new Money(Currency.CAD, 0),
                },
                new Payment(4)
                {
                    IsFixedAmountInSettlementCurrency = false,
                    AmountMoney = new Money(Currency.AUD, 10.00m),
                    SettlementAmountMoney = new Money(Currency.CAD, 0),
                }
            };
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<CustomerBatch>.Is.Anything)).Return(payments);

            var batch = new CustomerBatch { Id = 1 };
            customerBatchAmountManager.CalculatePaymentAmounts(batch, quote);
            Assert.AreEqual(13.33m, payments[0].AmountMoney.Amount);
            Assert.AreEqual(14.44m, payments[1].AmountMoney.Amount);
            Assert.AreEqual(15.56m, payments[2].SettlementAmountMoney.Amount);
            Assert.AreEqual(20.00m, payments[3].SettlementAmountMoney.Amount);

            PaymentMapper.Instance.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();

            QuoteMapper.Instance = null;
            PaymentMapper.Instance = null;
        }

    }
}
