﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Managers.FileProcessing.Validators;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.FileProcessing.Validators
{
    [TestFixture, Explicit]
    public class BankAccountValidatorFixture
    {
        [SetUp]
        public void SetUp()
        {
            CountryCacheMapper.Instance = MockRepository.GenerateMock<ICountryCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void ExceptionNotThrownWhenNoDataIsMissing()
        {
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });

            var bankAccount = new BankAccount
            {
                AccountNumber = "1234",
                BankAddress = new Address
                {
                    AddressLine1 = "some place",
                    City = "Denver",
                    CountryCode = "US",
                    StateOrProvince = "CO",
                    ZipOrPostalCode = "12345"
                },
                BankCode = "bankcode",
                BankName = "bankname",
                BranchCode = "branchcode",
                ExternalId = "123",
                Version = 123,
                ExternalAccountType = "asdf",
                CurrencyCode = "CAD"
            };

            Assert.DoesNotThrow(() => new BiBankAccountValidator("", "", bankAccount).Validate());
        }

        [Test]
        public void ExceptionThrownWhenAllDataIsMissing()
        {
            var bankAccount = new BankAccount();

            Assert.Throws<InvalidParsedDataException>(() => new BiBankAccountValidator("", "", bankAccount).Validate());
        }

        [Test]
        public void ExceptionReturnsErrorMessageWithListOfFieldsWhenAllDataIsMissing()
        {
            var bankAccount = new BankAccount();

            try
            {
                new BiBankAccountValidator("", "", bankAccount).Validate();
            }
            catch (InvalidParsedDataException ex)
            {
                Assert.AreEqual(ex.Message, "Source: Data Type: \r\nExternal Id:\r\nThe following fields are missing or invalid:\r\n     ExternalId\r\n     Version\r\n     ExternalAccountType\r\n     CountryCode\r\n     CurrencyCode\r\n     BankName\r\n     AccountNumber\r\n     BankCode or BranchCode\r\n     BankAddress\r\n");
            }
        }

        [Test]
        public void ExceptionReturnsErrorMessageWithListOfFieldsWhenSomeDataIsMissing()
        {
            var bankAccount = new BankAccount
            {
                BankCode = "1234",
                BankAddress = new Address
                {
                    AddressLine1 = "some place",
                }
            };

            try
            {
                new BiBankAccountValidator("", "", bankAccount).Validate();
            }
            catch (InvalidParsedDataException ex)
            {
                Assert.AreEqual(ex.Message, "Source: Data Type: \r\nExternal Id:\r\nThe following fields are missing or invalid:\r\n     ExternalId\r\n     Version\r\n     ExternalAccountType\r\n     CountryCode\r\n     CurrencyCode\r\n     BankName\r\n     AccountNumber\r\n     City\r\n     CountryCode\r\n     ZipOrPostalCode\r\n");
            }
        }

        [Test]
        public void ExceptionReturnsErrorMessageWithMissingProvinceWhenCountryIsCanada()
        {
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string>{"CA", "US"});

            var bankAccount = new BankAccount
            {
                AccountNumber = "1234",
                BankAddress = new Address
                {
                    AddressLine1 = "some place",
                    City = "Denver",
                    CountryCode = "CA",
                    ZipOrPostalCode = "12345"
                },
                BankCode = "bankcode",
                BankName = "bankname",
                BranchCode = "branchcode"
            };

            try
            {
                new BiBankAccountValidator("", "", bankAccount).Validate();
            }
            catch (InvalidParsedDataException ex)
            {
                Assert.AreEqual(ex.Message, "Source: Data Type: \r\nExternal Id:\r\nThe following fields are missing or invalid:\r\n     ExternalId\r\n     Version\r\n     ExternalAccountType\r\n     CurrencyCode\r\n     StateOrProvince\r\n");
            }
        }
    }
}
