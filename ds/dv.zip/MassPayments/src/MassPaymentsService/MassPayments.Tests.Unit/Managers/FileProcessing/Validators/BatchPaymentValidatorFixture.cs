﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Managers.FileProcessing.Validators;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.FileProcessing.Validators
{
    [TestFixture, Explicit]
    public class BatchPaymentValidatorFixture
    {
        [SetUp]
        public void Setup()
        {
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CustomerBatchMapper.Instance = null;
            CustomerMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
        }

        [Test]
        public void BatchPaymentValidator_DoesNotThrow_OnValidPayment()
        {
            var payment = new Payment("123","456")
            {
                AmountMoney = new Money(Currency.CAD, 3),
                CustomerBatchId = 3,
                Beneficiary = new Beneficiary
                {
                    ExternalId = "123",
                    Version = 10,
                    Identification = new Identification
                    {
                        EntityType = "individual",
                        FirstName = "gorilla",
                        LastName = "banana"
                    },
                    Address = new Address
                    {
                        AddressLine1 = "some place",
                        City = "Denver",
                        CountryCode = "US",
                        StateOrProvince = "CO",
                        ZipOrPostalCode = "12345"
                    }
                },
                PaymentMethod = PaymentMethod.ACH,
                TransactionSystemId = 123
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            
            Assert.DoesNotThrow(() => new BatchPaymentValidator("", "", payment).Validate());

            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnMissingWUBSExternalCustomerId()
        {
            var payment = GetSamplePayment();
            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnDisabledCustomer()
        {
            var payment = GetSamplePayment();

            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnMissingCustomer()
        {
            var payment = GetSamplePayment();

            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnInvalidAmount()
        {
            var payment = GetSamplePayment();

            //Amount check
            payment.AmountMoney = new Money(Currency.Null, -1);
            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnMissingBene()
        {
            var payment = GetSamplePayment();
            payment.Beneficiary = null;
            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnInvalidBene()
        {
            var payment = GetSamplePayment();

            payment.Beneficiary = new Beneficiary();
            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnInvalidCurrency()
        {
            var payment = GetSamplePayment();

            payment.AmountMoney = new Money(new Currency("ASDF"), 0);
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            payment.Beneficiary = new Beneficiary();
            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());

            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnDisabledCurrency()
        {
            var payment = GetSamplePayment();

            payment.AmountMoney = new Money(Currency.USD, 0);
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetDisabledCurrency());
            payment.Beneficiary = new Beneficiary();
            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());

            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BatchPaymentValidator_Throws_OnUnsupportedPaymentMethodForCurrency()
        {
            var payment = GetSamplePayment();

            payment.AmountMoney = new Money(Currency.USD, 0);
            payment.PaymentMethod = PaymentMethod.Draft;
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            payment.Beneficiary = new Beneficiary();
            Assert.Throws(typeof(InvalidParsedDataException), () => new BatchPaymentValidator("", "", payment).Validate());

            CustomerMapper.Instance.VerifyAllExpectations();
        }

        private Payment GetSamplePayment()
        {
            const int amount = 1;

            var bene = new Beneficiary
            {
                Identification = new Identification
                {
                    EntityType = "individual",
                    FirstName = "gorilla",
                    LastName = "banana"
                },
                Address = new Address
                {
                    AddressLine1 = "some place",
                    City = "Denver",
                    CountryCode = "US",
                    StateOrProvince = "CO",
                    ZipOrPostalCode = "12345"
                }
            };
            return new Payment("123","456")
            {
                CustomerBatchId = 3,
                AmountMoney = new Money(Currency.Null, amount),
                Beneficiary = bene
            };
        }
    }
}
