﻿using System.Text;
using MassPayments.Domain.Entities;
using MassPayments.Infrastructure.Encryption.Managers;
using MassPayments.Managers.FileProcessing;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.FileProcessing
{
    [TestFixture,Explicit]
    public class FileProcessorManagerFixture
    {
        [SetUp]
        public void SetUp()
        {
            CryptographyMapper.Instance = MockRepository.GenerateMock<ICryptograpyMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CryptographyMapper.Instance = null;
            PartnerMapper.Instance = null;
        }

        [Test]
        public void DecryptFileData_DoesNotChangeContent_IfContentLooksUnencrypted()
        {
            const string originalContent = "this does not look encrypted at all.";
            byte[] contentBytes = Encoding.UTF8.GetBytes(originalContent);
            var file = new File
            {
                FileNameWithExtension = "testFile.txt",
                Data = contentBytes
            };
            var fileProcessorManager = MockRepository.GeneratePartialMock<FileProcessorManager>();
            Assert.DoesNotThrow(() => fileProcessorManager.DecryptFileData(file));

            Assert.AreEqual(originalContent, file.FileContent);
        }

        [Test]
        public void DecryptFileData_ReturnsContentDecrypted_IfContentLooksEncrypted()
        {
            CryptographyMapper.Instance.Expect(m => m.GetDecryptionPassword("HPWL")).Return("password");
            PartnerMapper.Instance.Expect(m => m.GetPartnerByFilePrefix("HPWL")).Return(new Partner {Id = 1, Code = "HPWL"});

            const string encryptedContents = @"-----BEGIN PGP MESSAGE-----
Version: GnuPG v2

hQEMA0dN/DYoP5AqAQf+JfPYF3BrbUHdOqZCqQnkEB7curIFBHJ4sfcTIDJ+9rbe
On+v9R7NcLU4Hn+3YOyKkJIklnE603QLtZqCC72WIQOe2q207//zRCGz9+kq4E2A
oETzktQVRi9oMASWtJ1Qqrpbf0Go3pF4yLwtpOHNvO4O9/MzFt2I75L/wj901NUE
Eb3lCjsgSkL9rTjsgrbKnlF/UpGxFUTbfEIo1EWIZrsK2l8IgpAGCl2khJ56K7xP
uqJBNSGfkr/5W3XuXnhmk/B9XMa5M11HHhnS62oAgg9uYff8mQ0652TX7fcY2tII
G58gG72uIRRMOjx928ZK0UfoLezZau89uv8CDGxXn9JOATvtWDZEiCdjLV8mjTeG
KVlc59BJ3ePSEE1lYBt4h9NREf4Oz3WPFQoYhf8PSP4jHdZ0JYjzR7OYNDQroNR7
JAliZMYxuQG2Tk6ioL4k
=SO6r
-----END PGP MESSAGE-----
";

            byte[] contentBytes = Encoding.UTF8.GetBytes(encryptedContents);
            var file = new File
            {
                FileNameWithExtension = "HPWL_testFile.txt",
                Data = contentBytes
            };

            var encryptionManager = MockRepository.GeneratePartialMock<EncryptionManager>();
            encryptionManager.Stub(em => em.GetPublicKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPublicKey.asc");
            encryptionManager.Stub(em => em.GetPrivateKeyPathForPartner(Arg<Partner>.Is.Anything)).Return("PgpPrivateKey.asc");

            var fileProcessorManager = MockRepository.GeneratePartialMock<FileProcessorManager>(encryptionManager);
            Assert.DoesNotThrow(() => fileProcessorManager.DecryptFileData(file));

            Assert.AreEqual("decrypted string", file.FileContent);
            CryptographyMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetFilePrefix_ReturnsCorrectValue_AsEmbeddedInFileName()
        {
            var file = new File
            {
                FileNameWithExtension = "CODE_testFile.txt"
            };

            var fileProcessorManager = new FileProcessorManager();

            Assert.AreEqual("CODE", fileProcessorManager.GetFilePrefix(file));
        }

        [Test]
        public void GetFilePrefix_ReturnsFullFileName_IfNoPrefixDefined()
        {
            var file = new File
            {
                FileNameWithExtension = "CODEtestFile.txt"
            };

            var fileProcessorManager = new FileProcessorManager();

            Assert.AreEqual("CODEtestFile.txt", fileProcessorManager.GetFilePrefix(file));
        }
    }
}
