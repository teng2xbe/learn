﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Managers.FileProcessing.Validators;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.FileProcessing.Validators
{
    [TestFixture, Explicit]
    public class PaymentCashoutValidatorFixture
    {
        [SetUp]
        public void Setup()
        {
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CustomerBatchMapper.Instance = null;
            CustomerMapper.Instance = null;
            PaymentMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
        }

        [Test]
        public void PaymentCashoutValidator_DoesNotThrow_OnValidPayment()
        {
            var payment = GetSamplePayment();

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            Assert.DoesNotThrow(() => new PaymentCashoutValidator("", "", payment).Validate());

            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutValidator_Throws_OnMissingBank()
        {
            var payment = GetSamplePayment();

            payment.BankAccount = null;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            Assert.Throws(typeof(InvalidParsedDataException), () => new PaymentCashoutValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutValidator_Throws_OnInvalidBank()
        {
            var payment = GetSamplePayment();

            payment.BankAccount = new BankAccount();

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            Assert.Throws(typeof(InvalidParsedDataException), () => new PaymentCashoutValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutValidator_Throws_OnNullTransferId()
        {
            var bank = new BankAccount
            {
                AccountNumber = "1234",
                BankAddress = new Address
                {
                    AddressLine1 = "some place",
                    City = "Denver",
                    CountryCode = "US",
                    StateOrProvince = "CO",
                    ZipOrPostalCode = "12345"
                },
                BankCode = "bankcode",
                BankName = "bankname",
                BranchCode = "branchcode"
            };
            var payment = GetSamplePayment();

            //TransferId is null
            payment.BankAccount = bank;
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            Assert.Throws(typeof(InvalidParsedDataException), () => new PaymentCashoutValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutValidator_Throws_OnMissingPaymentMethod()
        {
            var payment = GetSamplePayment();

            payment.PaymentMethod = null;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            Assert.Throws(typeof(InvalidParsedDataException), () => new PaymentCashoutValidator("", "", payment).Validate());
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        private Payment GetSamplePayment()
        {
                      
            var bank = new BankAccount
            {
                AccountNumber = "1234",
                BankAddress = new Address
                {
                    AddressLine1 = "some place",
                    City = "Denver",
                    CountryCode = "US",
                    StateOrProvince = "CO",
                    ZipOrPostalCode = "12345"
                },
                BankCode = "bankcode",
                BankName = "bankname",
                BranchCode = "branchcode",
                ExternalId = "123",
                Version = 123,
                ExternalAccountType = "123",
                CurrencyCode = "CAD"
            };
           
            return new Payment("123","456")
            {
                CustomerBatchId = 1,
                AmountMoney = new Money(Currency.USD, 3),
                PaymentMethod = PaymentMethod.ACH,
                Beneficiary = new Beneficiary
                {
                    Identification = new Identification
                    {
                        EntityType = "individual",
                        FirstName = "gorilla",
                        LastName = "banana"
                    },
                    Address = new Address
                    {
                        AddressLine1 = "some place",
                        City = "Denver",
                        CountryCode = "US",
                        StateOrProvince = "CO",
                        ZipOrPostalCode = "12345"
                    },
                    ExternalId = "123",
                    Version = 123
                },
                BankAccount = bank,
                TransactionSystemId = 1,
                SettlementAmountMoney = new Money(Currency.CAD, 0)
            };   
        }

    }
}
