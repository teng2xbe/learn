﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Managers.FileProcessing.Validators;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.FileProcessing.Validators
{
    [TestFixture, Explicit]
    public class BeneficiaryValidatorFixture
    {
        [SetUp]
        public void SetUp()
        {
            CountryCacheMapper.Instance = MockRepository.GenerateMock<ICountryCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void ExceptionNotThrownWhenNoDataIsMissing()
        {
            var beneficiary = new Beneficiary
            {
                ExternalId = "123",
                Version = 10,
                Identification = new Identification
                {
                    EntityType = "individual",
                    FirstName = "gorilla",
                    LastName = "banana"
                },
                Address = new Address
                {
                    AddressLine1 = "some place",
                    City = "Denver",
                    CountryCode = "US",
                    StateOrProvince = "CO",
                    ZipOrPostalCode = "12345"
                }
            };

            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            Assert.DoesNotThrow(() => new BiBeneficiaryValidator("", "", beneficiary).Validate());
        }

        [Test]
        public void ExceptionThrownWhenAllDataIsMissing()
        {
            var beneficiary = new Beneficiary();

            Assert.Throws<InvalidParsedDataException>(() => new BiBeneficiaryValidator("", "", beneficiary).Validate());
        }

        [Test]
        public void ExceptionReturnsErrorMessageWithListOfFieldsWhenAllDataIsMissing()
        {
            var beneficiary = new Beneficiary();

            try
            {
                new BiBeneficiaryValidator("", "", beneficiary).Validate();
            }
            catch (InvalidParsedDataException ex)
            {
                Assert.AreEqual(ex.Message, "Source: Data Type: \r\nExternal Id:\r\nThe following fields are missing or invalid:\r\n     ExternalId\r\n     Version\r\n     Identification\r\n     Address\r\n");
            }
        }

        [Test]
        public void ExceptionReturnsErrorMessageWithListOfFieldsWhenSomeDataIsMissing()
        {
            var beneficiary = new Beneficiary
            {
                Identification = new Identification
                {
                    EntityType = "individual",
                },
                Address = new Address
                {
                    AddressLine1 = "some place",
                }
            };

            try
            {
                new BiBeneficiaryValidator("", "", beneficiary).Validate();
            }
            catch (InvalidParsedDataException ex)
            {
                Assert.AreEqual(ex.Message, "Source: Data Type: \r\nExternal Id:\r\nThe following fields are missing or invalid:\r\n     ExternalId\r\n     Version\r\n     FirstName or MiddleName or LastName or BusinessName\r\n     City\r\n     CountryCode\r\n     ZipOrPostalCode\r\n");
            }
        }

        [Test]
        public void ExceptionReturnsErrorMessageWithMissingProvinceWhenCountryIsCanada()
        {
            var beneficiary = new Beneficiary
            {
                Identification = new Identification
                {
                    EntityType = "individual",
                    FirstName = "gorilla",
                    LastName = "banana"
                },
                Address = new Address
                {
                    AddressLine1 = "some place",
                    City = "Vancouver",
                    CountryCode = "CA",
                    ZipOrPostalCode = "12345"
                }
            };

            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });

            try
            {
                new BiBeneficiaryValidator("", "", beneficiary).Validate();
            }
            catch (InvalidParsedDataException ex)
            {
                Assert.AreEqual(ex.Message, "Source: Data Type: \r\nExternal Id:\r\nThe following fields are missing or invalid:\r\n     ExternalId\r\n     Version\r\n     StateOrProvince\r\n");
            }
        }
    }
}
