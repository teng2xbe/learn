﻿using System;
using System.Collections.Generic;
using System.Text;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers.FileProcessing;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.FileProcessing
{
    [TestFixture, Explicit]
    public class BeneficiaryFileProcessorFixture
    {
        [SetUp]
        public void SetUp()
        {
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            FileMapper.Instance = MockRepository.GenerateStub<IFileMapper>();
            CountryCacheMapper.Instance = MockRepository.GenerateMock<ICountryCacheMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
        }

        [TearDown]
        public void TearDown()
        {
            FileMapper.Instance = null;
            CountryCacheMapper.Instance = null;
            PartnerMapper.Instance = null;
            ServiceCallContextManager.Instance = null;
        }

        [Test]
        public void ValidateJsonSchema_DoesNotThrow_ForValidSchema()
        {
            var beneFile = new File
            {
                Id = 1,
                FileContent = "{'wallets':[]}"
            };

            var beneFileProcessor = new BeneficiaryFileProcessor(beneFile);

            Assert.DoesNotThrow(beneFileProcessor.ValidateJsonSchema);
        }

        [Test]
        public void ValidateJsonSchema_Throws_ForInvalidSchema()
        {
            byte[] jsonBytes = Encoding.UTF8.GetBytes("{'beneficiaryid2':'cats'}");

            var beneFile = new File
            {
                Id = 1,
                FileContent = "{'beneficiaryid2':'cats'}"
            };

            var beneFileProcessor = new BeneficiaryFileProcessor(beneFile);
            Assert.Throws<InvalidFileSchemaException>(beneFileProcessor.ValidateJsonSchema);
        }

        [Test]
        public void BeneficiaryFileProcessor_Works()
        {
            var expectedCustomerId = "12345";
            var expectedBeneficiaryId = "12345";
            var expectedBeneficiaryVersion = "1";
            var expectedBankId = "12345";
            var expectedBankVersion = "123";

            var bankInfoString = string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                );

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedCustomerId,
                expectedBeneficiaryId,
                expectedBeneficiaryVersion,
                bankInfoString
                );

            var file = new File
            {
                FileContent = beneficiaryString,
                FileNameWithExtension = "HPWL_TEST.file"
            };

            var beneficiaryStorageProvider = new TestBeneficiaryStorageProvider();

            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).IgnoreArguments().Return(new Customer());
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Id = 1 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything))
                .IgnoreArguments()
                .Return(new Partner());
            StorageEventPublisher.Instance.BeneficiariesParsed += beneficiaryStorageProvider.HandleBeneficiariesInsertOrUpdate;

            Assert.DoesNotThrow(() => new BeneficiaryFileProcessor(file).Process());

            Assert.AreEqual(1, beneficiaryStorageProvider.BankCount);
            Assert.AreEqual(1, beneficiaryStorageProvider.BeneCount);

            StorageEventPublisher.Instance.BeneficiariesParsed -= beneficiaryStorageProvider.HandleBeneficiariesInsertOrUpdate;

            CustomerMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CountryCacheMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BeneficiaryFileProcessor_WithMultipleBank_Works()
        {
            var expectedCustomerId = "12345";
            var expectedBeneficiaryId = "12345";
            var expectedBeneficiaryVersion = "1";
            var expectedBankId1 = "12345";
            var expectedBankVersion1 = "123";
            var expectedBankId2 = "23456";
            var expectedBankVersion2 = "123";

            var bankInfoArrayString = new StringBuilder();
            bankInfoArrayString.Append(string.Format(
                SampleBankAccountString,
                expectedBankId1,
                expectedBankVersion1
                ));
            bankInfoArrayString.Append(",");
            bankInfoArrayString.Append(string.Format(
                SampleBankAccountString,
                expectedBankId2,
                expectedBankVersion2
                ));

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedCustomerId,
                expectedBeneficiaryId,
                expectedBeneficiaryVersion,
                bankInfoArrayString
                );

            var file = new File
            {
                FileContent = beneficiaryString,
                FileNameWithExtension = "HPWL_TEST.file"
            };
            var beneficiaryStorageProvider = new TestBeneficiaryStorageProvider();
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).IgnoreArguments().Return(new Customer());
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Id = 1 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything))
                .IgnoreArguments()
                .Return(new Partner());
            StorageEventPublisher.Instance.BeneficiariesParsed += beneficiaryStorageProvider.HandleBeneficiariesInsertOrUpdate;

            Assert.DoesNotThrow(() => new BeneficiaryFileProcessor(file).Process());

            Assert.AreEqual(2, beneficiaryStorageProvider.BankCount);
            Assert.AreEqual(1, beneficiaryStorageProvider.BeneCount);

            StorageEventPublisher.Instance.BeneficiariesParsed -= beneficiaryStorageProvider.HandleBeneficiariesInsertOrUpdate;
            CustomerMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CountryCacheMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BeneficiaryFileProcessor_WithMultipleBank_EventFiresCorrectTimes()
        {
            var expectedCustomerId = "12345";
            var expectedBeneficiaryId = "12345";
            var expectedBeneficiaryVersion = "1";
            var expectedBankId = "12345";
            var expectedBankVersion = "123";
            
            var bankInfoArrayString = new StringBuilder();

            var bankCount = 10;

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Id = 1 });
            for(int i = 0; i < bankCount; i++)
            {
                bankInfoArrayString.Append(string.Format(
                SampleBankAccountString,
                expectedBankId,
                expectedBankVersion
                ));
                if(i != 9)
                    bankInfoArrayString.Append(",");
            }

            var beneficiaryString = string.Format(
                SampleBeneficiaryString,
                expectedCustomerId,
                expectedBeneficiaryId,
                expectedBeneficiaryVersion,
                bankInfoArrayString
                );

            var file = new File
            {
                FileContent = beneficiaryString,
                FileNameWithExtension = "HPWL_Test.file"
            };

            var beneficiaryStorageProvider = new TestBeneficiaryStorageProvider();
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).IgnoreArguments().Return(new Customer());
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything))
                .IgnoreArguments()
                .Return(new Partner());

            StorageEventPublisher.Instance.BeneficiariesParsed += beneficiaryStorageProvider.HandleBeneficiariesInsertOrUpdate;

            Assert.DoesNotThrow(() => new BeneficiaryFileProcessor(file).Process());

            Assert.AreEqual(bankCount, beneficiaryStorageProvider.BankCount);
            Assert.AreEqual(1, beneficiaryStorageProvider.BeneCount);

            StorageEventPublisher.Instance.BeneficiariesParsed -= beneficiaryStorageProvider.HandleBeneficiariesInsertOrUpdate;
            CustomerMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        private const string SampleBankAccountString = @"
                                            {{
                                                'externalAccountId': '{0}',
                                                'versionNumber': '{1}',
                                                'externalAccountType': 'BANK_ACCOUNT_CANADA',
                                                'accountPurpose': 'SAVINGS',
                                                'currencyCode': 'USD',
                                                'bankName': 'BMO',
                                                'branchName': 'Metrotown Branch',
                                                'bankAddress': {{
                                                    'addressLine1': '736 Granville Street',
                                                    'addressLine2': 'test',
                                                    'addressLine3': 'test',
                                                    'city': 'Vancouver',
                                                    'stateProv': 'BC',
                                                    'postCode': 'V6Z1G3',
                                                    'countryCode': 'CA'
                                                }},
                                                'bankCode': '001',
                                                'branchCode': '23456',
                                                'accountNumber': '910002222',
                                                'displayName': 'A Friendly Name',
                                                
                                            }}";

        private const string SampleInvalidBankAccountString = @"
                                            {{
                                                'externalAccountId': '{0}',
                                                'versionNumber': '{1}',
                                                'externalAccountType': 'BANK_ACCOUNT_CANADA',
                                                'accountPurpose': 'SAVINGS',
                                                'currencyCode': 'USD',
                                                'branchName': 'Metrotown Branch',
                                                'bankAddress': {{
                                                    'addressLine1': '736 Granville Street',
                                                    'addressLine2': 'test',
                                                    'addressLine3': 'test',
                                                    'city': 'Vancouver',
                                                    'stateProv': 'BC',
                                                    'postCode': 'V6Z1G3',
                                                    'countryCode': 'CA'
                                                }},
                                                'bankCode': '001',
                                                'branchCode': '23456',
                                                'accountNumber': '910002222',
                                                'displayName': 'A Friendly Name',
                                                
                                            }}";

        private const string SampleBeneficiaryString = @"
                                    {{
                                        'wallets': [
                                            {{
                                                'clientCustomerId': '{0}',
                                                'walletNumber': '{1}',
                                                'clientProgramId': 'someId',
                                                'programId': 'someId',
                                                'profile': {{
                                                    'versionNumber': '{2}',
                                                    'identification': {{
                                                        'entityType': 'INDIVIDIAL',
                                                        'firstName': 'John',
                                                        'middleName': 'S',
                                                        'lastName': 'Doe',
                                                        'phoneNumber': '6048622810',
                                                        'mobileNumber': '6043698723',
                                                        'dateOfBirth': '1990-12-31',
                                                        'gender': 'MALE',
                                                        'businessName': 'A Name',
                                                        'businessRegistrationNumber': '12345',
                                                        'businessRegistrationCountry': '12345',
                                                        'businessRegistrationStateProv': 'BC',
                                                        'businessContactRole': 'asdf',
                                                        'industry': 'random',
                                                        'emailAddress': 'person@place.com'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }}
                                                }},
                                                'bankAccounts': [
                                                    {3}
                                                ]
                                            }}
                                        ]
                                    }}";

        private const string SampleInvalidBeneficiaryString = @"
                                    {{
                                        'wallets': [
                                            {{
                                                'clientCustomerId': '{0}',
                                                'walletNumber': '{1}',
                                                'clientProgramId': 'someId',
                                                'programId': 'someId',
                                                'profile': {{
                                                    'versionNumber': '{2}',
                                                    'identification': {{
                                                        'firstName': 'John',
                                                        'middleName': 'S',
                                                        'lastName': 'Doe',
                                                        'phoneNumber': '6048622810',
                                                        'mobileNumber': '6043698723',
                                                        'dateOfBirth': '1990-12-31',
                                                        'gender': 'MALE',
                                                        'businessName': 'A Name',
                                                        'businessRegistrationNumber': '12345',
                                                        'businessRegistrationCountry': '12345',
                                                        'businessRegistrationStateProv': 'BC',
                                                        'businessContactRole': 'asdf',
                                                        'industry': 'random',
                                                        'emailAddress': 'person@place.com'
                                                    }},
                                                    'address': {{
                                                        'addressLine1': '736 Granville Street',
                                                        'addressLine2': 'test',
                                                        'addressLine3': 'test',
                                                        'city': 'Vancouver',
                                                        'stateProv': 'BC',
                                                        'postCode': 'V6Z1G3',
                                                        'countryCode': 'CA'
                                                    }}
                                                }},
                                                'bankAccounts': [
                                                    {3}
                                                ]
                                            }}
                                        ]
                                    }}";
    }
}
