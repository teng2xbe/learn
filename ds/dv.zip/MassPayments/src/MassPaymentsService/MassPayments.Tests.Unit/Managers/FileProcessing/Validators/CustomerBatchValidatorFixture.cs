﻿using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Managers.FileProcessing.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.FileProcessing.Validators
{
    [TestFixture, Explicit]
    public class CustomerBatchValidatorFixture
    {
        [SetUp]
        public void Setup()
        {
        }

        [TearDown]
        public void TearDown()
        {
        }

        [Test]
        public void CustomerBatchValidator_DoesNotThrow_OnValidCustomerBatch()
        {
            var customerBatch = new CustomerBatch
            {
                ExternalId = "abc"
            };
            Assert.DoesNotThrow(() => new CustomerBatchValidator("", "", customerBatch).Validate());
        }

        [Test]
        public void CustomerBatchValidator_Throws_OnMissingFields()
        {
            var customerBatch = new CustomerBatch();
            Assert.Throws(typeof(InvalidParsedDataException), () => new CustomerBatchValidator("", "", customerBatch).Validate());
        }
    }
}

