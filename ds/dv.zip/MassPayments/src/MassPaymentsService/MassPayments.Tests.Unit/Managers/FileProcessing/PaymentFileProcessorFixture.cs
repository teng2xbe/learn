﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Gateways.Email.Interfaces;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Managers.FileProcessing;
using MassPayments.Managers.FileProcessing.Interfaces;
using MassPayments.Managers.Interfaces;
using MassPayments.Managers.Notification.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Providers.StorageProvider.EventArguments;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using System.Collections.Generic;

namespace MassPayments.Tests.Unit.Managers.FileProcessing
{
    [TestFixture,Explicit]
    public class PaymentFileProcessorFixture
    {
        [SetUp]
        public void SetUp()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            PaymentMethodRelationshipCacheMapper.Instance = MockRepository.GenerateMock<IPaymentMethodRelationshipCacheMapper>();
            FileMapper.Instance = MockRepository.GenerateMock<IFileMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            StorageEventPublisher.Instance = MockRepository.GenerateMock<IStorageEventPublisher>();
            EmailMessageGateway.Instance = MockRepository.GenerateMock<IEmailMessageGateway>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            FileProcessingLogger.Instance = MockRepository.GenerateMock<IFileProcessingLogger>();
            CountryCacheMapper.Instance = MockRepository.GenerateMock<ICountryCacheMapper>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
            CustomerBatchCurrencyMapper.Instance = MockRepository.GenerateMock<ICustomerBatchCurrencyMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            CustomerMapper.Instance = null;
            PaymentMethodRelationshipCacheMapper.Instance = null;
            FileMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
            EmailMessageGateway.Instance = null;
            EventLogger.Instance = null;
            FileProcessingLogger.Instance = null;
            CountryCacheMapper.Instance = null;
            QuoteMapper.Instance = null;
            PartnerMapper.Instance = null;
            ServiceCallContextManager.Instance = null;
            CustomerBatchCurrencyMapper.Instance = null;
        }

        [Test]
        public void PaymentBatchesProcessor_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var paymentBatchString = FileProcessorHelper.GetClientBatchString(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                CreatedOnUTC = DateTime.UtcNow,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            FileMapper.Instance.Stub(fm => fm.GetFile(Arg<int>.Is.Anything)).Return(file);
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything)).WhenCalled(_ =>
            {
                var batch = (CustomerBatch)_.Arguments[0];
                batch.Id = 123;
            }); ;
            var fileProcessor = MockRepository.GeneratePartialMock<PaymentBatchesFileProcessor>(file);
            StorageEventPublisher.Instance.Expect(sep => sep.OnBeneficiariesParsed(Arg<List<BeneficiaryEventArgs>>.Is.Anything));
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerId = 1, PartnerAssignedCustomerId = "1", TransactionSystemId = 1 });

            Assert.DoesNotThrow(() => fileProcessor.Process());

            FileProcessingLogger.Instance.AssertWasCalled(fpl => fpl.LogFileProcessingInfo(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            fileProcessor.AssertWasCalled(fp => fp.ValidateCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            fileProcessor.AssertWasCalled(fp => fp.ValidatePayment(Arg<Payment>.Is.Anything));
            CustomerBatchMapper.Instance.AssertWasCalled(pm => pm.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything), options => options.Repeat.Times(1));
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            StorageEventPublisher.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutProcessor_LogsPaymentErrorCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var paymentCashoutString = FileProcessorHelper.GetCashoutString(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };

            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            PaymentMethodRelationshipCacheMapper.Instance.Stub(pmrcp => pmrcp.GetPaymentMethodRelationshipDictionary()).Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });

            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            var fileProcessor = MockRepository.GeneratePartialMock<PaymentCashoutFileProcessor>(file);
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            paymentManager.Expect(pm => pm.SaveAsPaymentCashout(Arg<Payment>.Is.Anything)).Throw(new Exception());
            fileProcessor.PaymentManager = paymentManager;
            CustomerMapper.Instance.Stub(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            Assert.DoesNotThrow(() => fileProcessor.Process());
            EventLogger.Instance.AssertWasCalled(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything), options => options.Repeat.Times(1));
            //PaymentMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutProcessor_ReturnFalse_IfExceptionThrown()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var paymentCashoutString = FileProcessorHelper.GetCashoutString(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            PaymentMethodRelationshipCacheMapper.Instance.Stub(pmrcp => pmrcp.GetPaymentMethodRelationshipDictionary()).Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());

            var fileProcessor = MockRepository.GeneratePartialMock<PaymentCashoutFileProcessor>(file);
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            paymentManager.Expect(pm => pm.SaveAsPaymentCashout(Arg<Payment>.Is.Anything)).Throw(new Exception());
            fileProcessor.PaymentManager = paymentManager;
            fileProcessor.Expect(fp => fp.ValidatePayment(Arg<Payment>.Is.Anything)).Throw(new InvalidParsedDataException("123", "123", "123", null));

            bool result = true;
            Assert.DoesNotThrow(() => result = fileProcessor.Process());
            PaymentMapper.Instance.VerifyAllExpectations();
            Assert.IsFalse(result);

        }

        [Test]
        public void PaymentCashoutProcessor_LogsCustomerBatchErrorCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var paymentCashoutString = FileProcessorHelper.GetCashoutString(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            var fileProcessor = MockRepository.GeneratePartialMock<PaymentCashoutFileProcessor>(file);
            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            paymentManager.Stub(pm => pm.SaveAsPaymentBatch(new Payment(1)));
            fileProcessor.PaymentManager = paymentManager;
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());

            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1" });
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new CustomerBatch { Id = 1 });
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { Id = 1 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Id = 1 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner { Id = 1 });

            var customerBatchManager = MockRepository.GenerateMock<ICustomerBatchManager>();
            customerBatchManager.Expect(cum => cum.ProcessCustomerBatch(Arg<CustomerBatch>.Is.Anything, Arg<int>.Is.Anything, Arg<bool>.Is.Anything)).Throw(new Exception());
            fileProcessor.CustomerBatchManager = customerBatchManager;

            Assert.DoesNotThrow(() => fileProcessor.Process());
            EventLogger.Instance.AssertWasCalled(el => el.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything), options => options.Repeat.Times(1));
            CustomerMapper.Instance.VerifyAllExpectations();
            customerBatchManager.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentBatchesProcessor_MultiplePayments_Works()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payments = new List<Payment>();

            int paymentCount = 5;
            for (int i = 0; i < paymentCount; i++)
            {
                payments.Add(PaymentHelper.Instance.CreatePayment(customer, customerBatch));
            }
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            var paymentBatchString = FileProcessorHelper.GetClientBatchStringWithOneBatchAndMultiplePayment(customer, customerBatch, payments);

            var file = new File
            {
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                CreatedOnUTC = DateTime.UtcNow,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            FileMapper.Instance.Stub(fm => fm.GetFile(Arg<int>.Is.Anything)).Return(file);
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());

            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything)).WhenCalled(_ =>
            {
                var batch = (CustomerBatch)_.Arguments[0];
                batch.Id = 123;
            }); ;

            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerId = 1, PartnerAssignedCustomerId = "1", TransactionSystemId = 1 });

            Assert.DoesNotThrow(() => new PaymentBatchesFileProcessor(file).Process());
            CustomerBatchMapper.Instance.AssertWasCalled(pm => pm.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything), options => options.Repeat.Times(1));
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentBatchesProcessor_MultiplePaymentBatchesInMultipleBatches_Works()
        {
            int batchCount = 5;
            int paymentPerBatchCount = 5;
            var customer = CustomerHelper.Instance.CreateCustomer();
            var batchList = new List<CustomerBatch>();
            var paymentDictionary = new Dictionary<string, List<Payment>>();
            for (int i = 0; i < batchCount; i++)
            {
                var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
                batchList.Add(customerBatch);

                var paymentList = new List<Payment>();
                for (int j = 0; j < paymentPerBatchCount; j++)
                {
                    paymentList.Add(PaymentHelper.Instance.CreatePayment(customer, customerBatch));
                }
                paymentDictionary[customerBatch.ExternalId] = paymentList;
            }
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            var paymentBatchString = FileProcessorHelper.GetClientBatchStringWithMultipleBatchAndMultiplePayment(customer, batchList, paymentDictionary);

            var file = new File
            {
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                CreatedOnUTC = DateTime.UtcNow,
                FileNameWithExtension = "HPWL_Blah.json"
            };

            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());

            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything)).WhenCalled(_ =>
                                                                                                        {
                                                                                                            var batch = (CustomerBatch)_.Arguments[0];
                                                                                                            batch.Id = 123;
                                                                                                        });

            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1", TransactionSystemId = 1 });

            Assert.DoesNotThrow(() => new PaymentBatchesFileProcessor(file).Process());

            PaymentMapper.Instance.AssertWasCalled(pm => pm.InsertPayment(Arg<Payment>.Is.Anything), options => options.Repeat.Times(batchCount * paymentPerBatchCount));
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutProcessor_MultiplePayments_CustomerBatchOnlySavedOnce()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatches = new List<CustomerBatch>();
            var payments = new Dictionary<string, Payment>();
            int paymentCount = 5;
            for (int i = 0; i < paymentCount; i++)
            {
                var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
                customerBatches.Add(customerBatch);
                payments[customerBatch.ExternalId] = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            }
            var paymentCashoutString = FileProcessorHelper.GetMultipleCashoutString(customer, customerBatches, payments);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner
            {
                BankRefPrefix = "MPHW",
                Id = 123
            });
            QuoteMapper.Instance.Expect(qm => qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order { ConfirmationNumber = "123", OrderId = 123 });
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            CustomerBatchMapper.Instance.Expect(um => um.IsNewCustomerBatch(Arg<CustomerBatch>.Is.Anything)).Return(true);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything)).WhenCalled(_ =>
            {
                var batch = (CustomerBatch)_.Arguments[0];
                batch.Id = 123;
            }); ;
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1", TransactionSystemId = 1 });

            var paymentCashoutFileProcessor = new PaymentCashoutFileProcessor(file);
            var paymentManager = MockRepository.GeneratePartialMock<PaymentManager>();
            paymentCashoutFileProcessor.PaymentManager = paymentManager;
            StorageEventPublisher.Instance.Expect(sep => sep.OnBeneficiariesParsed(Arg<List<BeneficiaryEventArgs>>.Is.Anything));

            Assert.DoesNotThrow(() => paymentCashoutFileProcessor.Process());

            PaymentMapper.Instance.AssertWasCalled(pm => pm.InsertPayment(Arg<Payment>.Is.Anything), options => options.Repeat.Times(paymentCount));
            CustomerMapper.Instance.VerifyAllExpectations();
            StorageEventPublisher.Instance.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test, Explicit]
        public void PaymentCashoutProcessor_MultiplePayments_NotifyOnlyOnce()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatches = new List<CustomerBatch>();
            var payments = new Dictionary<string, Payment>();
            int paymentCount = 5;
            for (int i = 0; i < paymentCount; i++)
            {
                var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
                customerBatches.Add(customerBatch);
                payments[customerBatch.ExternalId] = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            }
            var paymentCashoutString = FileProcessorHelper.GetMultipleCashoutString(customer, customerBatches, payments);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
			PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<CustomerBatch>.Is.Anything, Arg<int>.Is.Anything))
            .Return(new List<Payment> { new Payment(1) });
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1" });
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new CustomerBatch { Id = 1 });
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { Id = 1 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });

            var paymentCashoutFileProcessor = MockRepository.GeneratePartialMock<PaymentCashoutFileProcessor>(file);
            var paymentManager = MockRepository.GeneratePartialMock<PaymentManager>();
            paymentCashoutFileProcessor.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            paymentCashoutFileProcessor.PaymentManager = paymentManager;
            paymentCashoutFileProcessor.Expect(pcfp => pcfp.ValidatePayment(Arg<Payment>.Is.Anything)).Throw(new InvalidParsedDataException("", "", "", new List<string>()));
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            CustomerBatchCurrencyMapper.Instance.Expect(
    cbcm => cbcm.GetCustomerBatchCurrencyAggregatesByBatchId(Arg<int>.Is.Anything))
    .Return(new List<CustomerBatchCurrencyAggregates>());
            Assert.DoesNotThrow(() => paymentCashoutFileProcessor.Process());
            paymentCashoutFileProcessor.NotificationManager.AssertWasCalled(nm => nm.NotifyFileProcessingFailure(Arg<string>.Is.Anything, Arg<string>.Is.Anything), options => options.Repeat.Times(1));
            FileProcessingLogger.Instance.AssertWasCalled(fm => fm.LogFileProcessingError(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<Exception>.Is.Anything), options => options.Repeat.Times(paymentCount));

            CustomerMapper.Instance.VerifyAllExpectations();
            StorageEventPublisher.Instance.VerifyAllExpectations();            
			PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test,Explicit]
        public void PaymentCashoutProcessor_LogWarningCorrectly_OnMissingPaymentBatch()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var paymentCashoutString = FileProcessorHelper.GetCashoutString(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner
            {
                BankRefPrefix = "MPHW",
                Id = 123
            });
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<CustomerBatch>.Is.Anything, Arg<int>.Is.Anything)).IgnoreArguments().Return(new List<Payment> { new Payment(1) });
            var fileProcessor = MockRepository.GeneratePartialMock<PaymentCashoutFileProcessor>(file);
            var paymentManager = MockRepository.GeneratePartialMock<PaymentManager>();
            paymentManager.Expect(pm => pm.LogWarning(Arg<string>.Is.Anything)).Repeat.Times(1);
            fileProcessor.PaymentManager = paymentManager;
            CustomerBatchCurrencyMapper.Instance.Expect(
                cbcm => cbcm.GetCustomerBatchCurrencyAggregatesByBatchId(Arg<int>.Is.Anything))
                .Return(new List<CustomerBatchCurrencyAggregates>());
            QuoteMapper.Instance.Expect(qm => qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order { ConfirmationNumber = "123", OrderId = 123 });
            CustomerBatchMapper.Instance.Expect(um => um.IsNewCustomerBatch(Arg<CustomerBatch>.Is.Anything)).Return(true);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new CustomerBatch { Id = 1 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            PaymentMapper.Instance.Expect(pm => pm.DoesPaymentExist(Arg<Payment>.Is.Anything)).Return(false);
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1", TransactionSystemId = 1 });
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());

            Assert.DoesNotThrow(() => fileProcessor.Process());

            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            paymentManager.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentCashoutProcessor_LogWarningCorrectly_OnMissingCustomerBatch()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var paymentCashoutString = FileProcessorHelper.GetCashoutString(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });
            var fileProcessor = MockRepository.GeneratePartialMock<PaymentCashoutFileProcessor>(file);
            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            customerBatchManager.Expect(um => um.LogWarning(Arg<string>.Is.Anything)).Repeat.Times(1);
            fileProcessor.CustomerBatchManager = customerBatchManager;
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1" });
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            Assert.DoesNotThrow(() => fileProcessor.Process());

            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            customerBatchManager.VerifyAllExpectations();
        }

        [Test, Ignore("Oleg to review test later")]
        public void PaymentCashoutProcessor_Works_OnMissiongSettlmentCurrencyCode()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.SettlementAmountMoney = null;
            var paymentCashoutString = FileProcessorHelper.GetCashoutString(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });
            var fileProcessor = MockRepository.GeneratePartialMock<PaymentCashoutFileProcessor>(file);
            var batchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            batchManager.Expect(um => um.LogWarning(Arg<string>.Is.Anything)).Repeat.Times(1);
            fileProcessor.CustomerBatchManager = batchManager;
            QuoteMapper.Instance.Expect(qm => qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order { ConfirmationNumber = "123", OrderId = 123 }).Repeat.Times(0);
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1" });
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);

            Assert.DoesNotThrow(() => fileProcessor.Process());

            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            batchManager.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }


        [Test]
        public void ReturnedPaymentProcessor_MakeCorrectCalls()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var returnedPaymentString = FileProcessorHelper.GetReturnedPayment(customer, customerBatch, payment);

            var file = new File
            {
                FileContent = returnedPaymentString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };

            QuoteMapper.Instance.Expect(qm => qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order { ConfirmationNumber = "123", OrderId = 123 });
            CountryCacheMapper.Instance.Stub(ccm => ccm.GetCountriesRequiringRegionsList()).Return(new List<string> { "CA", "US" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            CustomerMapper.Instance.Expect(cm => cm.GetCustomer(Arg<int>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1", TransactionSystemId = 1 });
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { Id = 1 });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            var paymentManager = MockRepository.GenerateMock<IPaymentManager>();
            var returnedPaymentFileProcessor = MockRepository.GeneratePartialMock<ReturnedPaymentFileProcessor>(file);
            returnedPaymentFileProcessor.PaymentManager = paymentManager;

            paymentManager.Expect(pm => pm.GetRelatedPaymentForReturnedPayment(Arg<string>.Is.Anything, Arg<int>.Is.Anything))
                .Return(new Payment(1))
                .Repeat.Times(1);
            paymentManager.Expect(pm => pm.SaveAsReturnedPayment(Arg<Payment>.Is.Anything)).Repeat.Times(1);
            StorageEventPublisher.Instance.Expect(sep => sep.OnBeneficiariesParsed(Arg<List<BeneficiaryEventArgs>>.Is.Anything));

            Assert.DoesNotThrow(() => returnedPaymentFileProcessor.Process());
            paymentManager.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            returnedPaymentFileProcessor.AssertWasCalled(fp => fp.ValidatePayment(Arg<Payment>.Is.Anything));
            StorageEventPublisher.Instance.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PaymentBatchesProcessor_ThrowException()
        {
            int batchCount = 5;
            int paymentPerBatchCount = 5;
            var customer = CustomerHelper.Instance.CreateCustomer();
            var batchList = new List<CustomerBatch>();
            var paymentDictionary = new Dictionary<string, List<Payment>>();
            for (int i = 0; i < batchCount; i++)
            {
                var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
                batchList.Add(customerBatch);

                var paymentList = new List<Payment>();
                for (int j = 0; j < paymentPerBatchCount; j++)
                {
                    paymentList.Add(PaymentHelper.Instance.CreatePayment(customer, customerBatch));
                }
                paymentDictionary[customerBatch.ExternalId] = paymentList;
            }
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            var paymentBatchString = FileProcessorHelper.GetClientBatchStringWithMultipleBatchAndMultiplePayment(customer, batchList, paymentDictionary);

            var file = new File
            {
                FileContent = paymentBatchString,
                Status = FileStatus.Pending,
                FileNameWithExtension = "HPWL_Blah.json"
            };
            FileMapper.Instance.Stub(fm => fm.GetFile(Arg<int>.Is.Anything)).Return(file);
            QuoteMapper.Instance.Expect(qm => qm.GetTransactionSystemIncomingOrder(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything)).Return(new Order { ConfirmationNumber = "123", OrderId = 123 });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMapper.Instance.Stub(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment>());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Return(new Customer { PartnerId = 1, PartnerAssignedCustomerId = "1", TransactionSystemId = 1 });
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));

            var batchFileProcessor = new PaymentBatchesFileProcessor(file);
            batchFileProcessor.PaymentManager = MockRepository.GenerateMock<IPaymentManager>();
            batchFileProcessor.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            batchFileProcessor.PaymentManager.Stub(pm => pm.SaveAsPaymentBatch(Arg<Payment>.Is.Anything)).Throw(new InvalidParsedDataException("", "", "", new List<string>()));
            Assert.Throws<ProcessClientBatchFailedException>(() => batchFileProcessor.Process());

            FileProcessingLogger.Instance.AssertWasCalled(fpl => fpl.LogFileProcessingError(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<Exception>.Is.Anything), options => options.Repeat.Times(batchCount));
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }


        [Test]
        public void ReturnedPaymentProcessor_MultiplePayments_NotifyOnlyOnce()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var payments = new List<Payment>();
            int paymentCount = 5;
            for (int i = 0; i < paymentCount; i++)
            {
                var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
                payments.Add(PaymentHelper.Instance.CreatePayment(customer, customerBatch));
            }
            var paymentCashoutString = FileProcessorHelper.GetMultipleReturnedPaymentString(customer, payments);

            var file = new File
            {
                FileContent = paymentCashoutString,
                Status = FileStatus.Pending,

                FileNameWithExtension = "HPWL_Blah.json"
            };
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            PaymentMethodRelationshipCacheMapper.Instance.Stub(epmcm => epmcm.GetPaymentMethodRelationshipDictionary())
                .Return(SupportedExternalPaymentMethod.GetSupportedExternalPaymentDictionary());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            CustomerMapper.Instance.Expect(cm => cm.GetCustomer(Arg<int>.Is.Anything)).Return(new Customer { PartnerAssignedCustomerId = "1" });
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new CustomerBatch { Id = 1 });
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { Id = 1 });

            var returnedPaymentFileProcessor = MockRepository.GeneratePartialMock<ReturnedPaymentFileProcessor>(file);
            var paymentManager = MockRepository.GeneratePartialMock<PaymentManager>();
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment> { new Payment(1) });
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerByFilePrefix(Arg<string>.Is.Anything)).Return(new Partner() { Id = 1 });

            returnedPaymentFileProcessor.NotificationManager = MockRepository.GenerateMock<INotificationManager>();
            returnedPaymentFileProcessor.PaymentManager = paymentManager;
            returnedPaymentFileProcessor.Expect(pcfp => pcfp.ValidatePayment(Arg<Payment>.Is.Anything)).Throw(new InvalidParsedDataException("", "", "", new List<string>()));
            Assert.DoesNotThrow(() => returnedPaymentFileProcessor.Process());

            returnedPaymentFileProcessor.NotificationManager.AssertWasCalled(nm => nm.NotifyFileProcessingFailure(Arg<string>.Is.Anything, Arg<string>.Is.Anything), options => options.Repeat.Times(1));
            FileProcessingLogger.Instance.AssertWasCalled(fm => fm.LogFileProcessingError(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<Exception>.Is.Anything), options => options.Repeat.Times(paymentCount));

            CustomerMapper.Instance.VerifyAllExpectations();
            StorageEventPublisher.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
        }
    }
}