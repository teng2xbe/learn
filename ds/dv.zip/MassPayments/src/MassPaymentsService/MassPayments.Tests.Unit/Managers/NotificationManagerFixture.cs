﻿using System;
using System.Collections.Generic;
using MassPayments.Gateways.Email.Interfaces;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Email.Domain;
using MassPayments.Infrastructure.Email.Enums;
using MassPayments.Infrastructure.Encryption.Exceptions;
using MassPayments.Managers.Notification;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class NotificationManagerFixture
    {
        [SetUp]
        public void SetUp()
        {
            EmailMessageGateway.Instance = MockRepository.GenerateMock<IEmailMessageGateway>();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetStringValue("Email.SupportRecipients")).Return("email3@cats.meow;email4@cats.cat");
        }

        [TearDown]
        public void TearDown()
        {
            EmailMessageGateway.Instance = null;
            ServiceSettings.Instance = null;
        }

        [Test]
        public void NotifyFileProcessingFailure_MakesCorrectCalls()
        {
            var notificationManager = MockRepository.GeneratePartialMock<NotificationManager>();

            notificationManager.Expect(m => m.CreateAndEnqueueEmail(Arg<EmailType>.Is.Equal(EmailType.FileProcessingError),
                Arg<List<string>>.Matches(l =>
                    l.Count == 2 &&
                    l[0].Equals("email3@cats.meow") &&
                    l[1].Equals("email4@cats.cat")),
                Arg<TemplateDataParameters>.Matches(p =>
                    p.ContainsKey("@FILENAME") && p["@FILENAME"].Equals("file.json") &&
                    p.ContainsKey("@ERROR_MESSAGE") && p["@ERROR_MESSAGE"].Equals("oh noes!") &&
                    p.ContainsKey("@ERROR_DETAILS") && p["@ERROR_DETAILS"].Equals("Failed to encrypt content: something") &&
                    p.ContainsKey("@ERROR_TIMESTAMP") && p["@ERROR_TIMESTAMP"].StartsWith(DateTime.Now.ToShortDateString())
                    )));

            var exception = new EncryptionFailedException("something");

            notificationManager.NotifyFileProcessingFailure("file.json", "oh noes!", exception);
            notificationManager.VerifyAllExpectations();
        }

        [Test]
        public void NotifyFileProcessingFailure_MakesCorrectCallsWithMultipleExceptions()
        {
            var notificationManager = MockRepository.GeneratePartialMock<NotificationManager>();

            notificationManager.Expect(m => m.CreateAndEnqueueEmail(Arg<EmailType>.Is.Equal(EmailType.FileProcessingError),
                Arg<List<string>>.Matches(l =>
                    l.Count == 2 &&
                    l[0].Equals("email3@cats.meow") &&
                    l[1].Equals("email4@cats.cat")),
                Arg<TemplateDataParameters>.Matches(p =>
                    p.ContainsKey("@FILENAME") && p["@FILENAME"].Equals("file.json") &&
                    p.ContainsKey("@ERROR_MESSAGE") && p["@ERROR_MESSAGE"].Equals("oh noes!") &&
                    p.ContainsKey("@ERROR_DETAILS") && p["@ERROR_DETAILS"].Equals("gorilla\r\n\r\nbanana\r\n\r\n") &&
                    p.ContainsKey("@ERROR_TIMESTAMP") && p["@ERROR_TIMESTAMP"].StartsWith(DateTime.Now.ToShortDateString())
                    )));

            var exceptions = new List<Exception>
            {
                new Exception("gorilla"),
                new Exception("banana")
            };

            notificationManager.NotifyFileProcessingFailure("file.json", "oh noes!", exceptions);

            notificationManager.VerifyAllExpectations();
        }
    }
}