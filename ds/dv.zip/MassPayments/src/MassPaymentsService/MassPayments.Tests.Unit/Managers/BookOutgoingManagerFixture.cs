﻿using System;
using System.Collections.Generic;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Batches;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Infrastructure.Polling;
using MassPayments.Infrastructure.Polling.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.ResourceAccess.OrdersRA;
using MassPayments.ResourceAccess.OrdersRA.Interfaces;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;


namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class BookOutgoingManagerFixture
    {
        private DateTime timeStamp;
        private IPublisher<Payment, CustomerBatch, Customer> paymentStatusUpdatedPublisher;

        [SetUp]
        public void Setup()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            PaymentBatchMapper.Instance = MockRepository.GenerateMock<IPaymentBatchMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            PaymentPoller.Instance = MockRepository.GenerateMock<IPaymentPoller>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            OrdersProviderFactory.InjectedOrdersProviderInterface = MockRepository.GenerateMock<IOrdersProvider>();
            OutOfHoldingMapper.Instance = MockRepository.GenerateMock<IOutOfHoldingMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            paymentStatusUpdatedPublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof (PaymentStatusUpdatedPublisher), paymentStatusUpdatedPublisher);
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
            CustomerMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            PaymentBatchMapper.Instance = null;
            EventLogger.Instance = null;
            PaymentPoller.Instance = null;
            QuoteMapper.Instance = null;
            PartnerMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
            CCTTServiceFactory.InjectedServiceInterface = null;
            ServiceCallContextManager.Instance = null;
            OrdersProviderFactory.InjectedOrdersProviderInterface = null;
            OrderMapper.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            paymentStatusUpdatedPublisher = null;
            ServiceSettings.Instance = null;
        }

        [Test]
        public void AggregatePayments_CorrectlyAggregatesPayments()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.CAD, 50m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(2) {AmountMoney = new Money(Currency.CAD, 30m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(3) {AmountMoney = new Money(Currency.CAD, 400m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(4) {AmountMoney = new Money(Currency.CAD, 300m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.Draft},
                
                new Payment(5) {AmountMoney = new Money(Currency.USD, 95m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(6) {AmountMoney = new Money(Currency.USD, 300m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                
                new Payment(7) {AmountMoney = new Money(Currency.CAD, 75m), TransactionSystemCustomerId = 2, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                
                new Payment(8) {AmountMoney = new Money(Currency.CAD, 125m), TransactionSystemCustomerId = 1, TransactionSystemId = 2, PaymentMethod = PaymentMethod.ACH},
                
                new Payment(9) {AmountMoney = new Money(Currency.CAD, 99m), TransactionSystemCustomerId = 2, TransactionSystemId = 2, PaymentMethod = PaymentMethod.ACH},
            };

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult
                {
                    AvailableBalance = 100,
                    BookedBalance = 100,
                    Currency = "CAD"
                });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch {BatchType = BatchType.PaymentRequest});

            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(5, aggregatedPayments.Count);
            Assert.AreEqual(2, aggregatedPayments[0].Count);
            Assert.AreEqual(80, aggregatedPayments[0].Total);
            Assert.AreEqual(1, aggregatedPayments[2].Count);
            Assert.AreEqual(75, aggregatedPayments[2].Total);
            Assert.AreEqual(0, aggregatedPayments[3].Total);
        }

        [Test]
        public void AggregatePayments_CorrectlyAggregatesPaymentsForMultipleBatches()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.CAD, 50m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(2) {AmountMoney = new Money(Currency.CAD, 30m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(3) {AmountMoney = new Money(Currency.USD, 50m), CustomerBatchId = 2, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(4) {AmountMoney = new Money(Currency.CAD, 300m), CustomerBatchId = 2, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
            };

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult
                {
                    AvailableBalance = 100,
                    BookedBalance = 100,
                    Currency = "CAD"
                });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(1, "CAD")).Return(new Order { OrderStatus = OrderStatus.Funded });
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(2, "CAD")).Return(new Order { OrderStatus = OrderStatus.Committed });
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(2, "USD")).Return(new Order { OrderStatus = OrderStatus.Committed });
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.ApiBatch });

            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(1, aggregatedPayments.Count);
            Assert.AreEqual(2, aggregatedPayments[0].Count);
            Assert.AreEqual(80, aggregatedPayments[0].Total);
        }

        [Test]
        public void AggregatePayments_CorrectlyAggregatesPaymentsForMultipleFundedBatches()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.CAD, 50m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(2) {AmountMoney = new Money(Currency.CAD, 30m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(3) {AmountMoney = new Money(Currency.USD, 50m), CustomerBatchId = 2, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(4) {AmountMoney = new Money(Currency.CAD, 300m), CustomerBatchId = 2, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
            };

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult { AvailableBalance = 500, BookedBalance = 500, Currency = "CAD" });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(1, "CAD")).Return(new Order { OrderStatus = OrderStatus.Funded });
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(2, "CAD")).Return(new Order { OrderStatus = OrderStatus.Funded });
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(2, "USD")).Return(new Order { OrderStatus = OrderStatus.Funded });
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.ApiBatch });

            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(2, aggregatedPayments.Count);
            Assert.AreEqual(3, aggregatedPayments[0].Count);
            Assert.AreEqual(380, aggregatedPayments[0].Total);
            Assert.AreEqual(1, aggregatedPayments[1].Count);
            Assert.AreEqual(50, aggregatedPayments[1].Total);

        }

        [Test]
        public void AggregatePayments_CorrectlyAggregatesPaymentsForBatchForFundedOrders()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.CAD, 50m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(2) {AmountMoney = new Money(Currency.CAD, 30m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(3) {AmountMoney = new Money(Currency.USD, 50m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(4) {AmountMoney = new Money(Currency.CAD, 300m), CustomerBatchId = 1, TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
            };

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult
                {
                    AvailableBalance = 100,
                    BookedBalance = 100,
                    Currency = "CAD"
                });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(1, "CAD")).Return(new Order {OrderStatus = OrderStatus.Funded});
            OrderMapper.Instance.Stub(om => om.GetOrderByBatchIdAndCurrency(1, "USD")).Return(new Order { OrderStatus = OrderStatus.Committed});
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.ApiBatch });

            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(1, aggregatedPayments.Count);
            Assert.AreEqual(2, aggregatedPayments[0].Count);
            Assert.AreEqual(80, aggregatedPayments[0].Total);
        }

        [Test]
        public void AggregatePayments_ReturnOnlyOneAggregatePayment_IfThereIsOnlyOneCurrencyAndPaymentMethod()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.CAD, 100), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(2) {AmountMoney = new Money(Currency.CAD, 300), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(3) {AmountMoney = new Money(Currency.CAD, 400), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH}
            };

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult()
                {
                    AvailableBalance = 100,
                    BookedBalance = 100,
                    Currency = "CAD"
                });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.PaymentRequest });

            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(1, aggregatedPayments.Count);
        }

        [Test]
        public void AggregatePayments_ReturnsAggregateForPaymentsWithSpecificPaymentMethod_IfPaymentsWithMultiplePaymentMethodsAreAvailable()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.CAD, 100.00m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(2) {AmountMoney = new Money(Currency.CAD, 150.00m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.Wire},
                new Payment(3) {AmountMoney = new Money(Currency.CAD, 300.00m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(4) {AmountMoney = new Money(Currency.CAD, 250.00m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.Wire},
                new Payment(5) {AmountMoney = new Money(Currency.CAD, 400.00m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment(6) {AmountMoney = new Money(Currency.CAD, 44.00m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH}
            };

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult()
                {
                    AvailableBalance = 600,
                    BookedBalance = 100,
                    Currency = "CAD"
                });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.PaymentRequest });

            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(1, aggregatedPayments.Count);
            Assert.AreEqual(2, aggregatedPayments[0].OriginalPayments.Count);
            Assert.AreEqual(3, aggregatedPayments[0].Count);
            Assert.AreEqual(PaymentMethod.ACH, aggregatedPayments[0].PaymentMethod);
            Assert.AreEqual(400, aggregatedPayments[0].Total);
            Assert.AreEqual(550, aggregatedPayments[0].TotalAllPaymentMethods);
        }

        [Test]
        public void AggregatePayments_ReturnsNoPayments_IfThereAreNoPayments()
        {
            var paymentList = new List<Payment>();
            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(aggregatedPayments.Count, 0);
        }

        [Test]
        public void AggregatePayments_ReturnsZeroTotal_IfPaymentIsForAnotherPaymentMethod()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.CAD, 150.00m), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.Wire},
            };

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult()
                {
                    AvailableBalance = 600,
                    BookedBalance = 100,
                    Currency = "CAD"
                });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.PaymentRequest });

            var bookOutgoingManager = new BookOutgoingManager();
            var aggregatedPayments = bookOutgoingManager.AggregatePayments(paymentList, PaymentMethod.ACH);

            Assert.AreEqual(1, aggregatedPayments.Count);
            Assert.AreEqual(0, aggregatedPayments[0].OriginalPayments.Count);
            Assert.AreEqual(0, aggregatedPayments[0].Total);
            Assert.AreEqual(150, aggregatedPayments[0].TotalAllPaymentMethods);
        }

        [Test]
        public void BookOutgoingOrder_ProvidesCorrectArgumentsToBackEndService()
        {
            var partnerAssignedCustomerId = "111";
            var paymentList = new List<Payment>
            {
                new Payment("", partnerAssignedCustomerId)
                {
                    Id = 1,
                    AmountMoney = new Money(Currency.USD, 100m),
                    TransactionSystemCustomerId = 111,
                    TransactionSystemId = 1,
                    PaymentMethod = PaymentMethod.ACH
                }
            };

            var customer = new Customer
            {
                TransactionSystemCustomerId = 111,
                PartnerAssignedCustomerId = partnerAssignedCustomerId
            };

            var customers = new List<Customer> { customer };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            var bookOutgoingManager = new BookOutgoingManager();
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(customer);
         
            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(m => m.BookOutgoingAggregateOrder(
                Arg<MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest>.Matches(r =>
                    r.SettlementCurrencyCode == "CAD" &&
                    r.ClientId == 111 &&
                    r.ItemsToBook.Count == 1 &&
                    r.ItemsToBook[0].IsAmountInSettlementCurrency == false &&
                    r.ItemsToBook[0].Amount == 100 &&
                    r.ItemsToBook[0].TradeCurrencyCode == "USD")));
            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Matches(r =>
                    r.ClientId == 111 &&
                    r.CurrencyCode == "USD"))).Return(new HoldingBalanceResult{Currency = "USD", AvailableBalance = 10000.00m, BookedBalance = 10000.00m});
            PaymentMapper.Instance.Expect(
               pm => pm.GetPaymentInterval(Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything))
               .Return(new PaymentInterval());
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.PaymentRequest });

            bookOutgoingManager.BookOutgoingOrder(paymentList, new Currency("CAD"), PaymentMethod.ACH);
            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void BookOutgoingOrder_DoesNotCallBookOutgoingAggregateOrder_WhenAggregatePaymentTotalIsZero()
        {
            var paymentList = new List<Payment>
            {
                new Payment(1) {AmountMoney = new Money(Currency.USD, 100m), TransactionSystemCustomerId = 111, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH}
            };
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            var bookOutgoingManager = new BookOutgoingManager();
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer() { TransactionSystemCustomerId = 111 });

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(m => m.BookOutgoingAggregateOrder(new MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest())).IgnoreArguments().Repeat.Never();

            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Matches(r =>
                    r.ClientId == 111 &&
                    r.CurrencyCode == "USD"))).Return(new HoldingBalanceResult { Currency = "USD", AvailableBalance = 10000.00m, BookedBalance = 10000.00m });
            PaymentMapper.Instance.Expect(
               pm => pm.GetPaymentInterval(Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything))
               .Return(new PaymentInterval());
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.PaymentRequest });

            bookOutgoingManager.BookOutgoingOrder(paymentList, new Currency("CAD"), PaymentMethod.Wire);

            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
        }

        [Test]
        public void BookOutgoingOrder_WillContinueBookingPayments_EvenAfterAnExceptionHasOccurred()
        {
            var partnerAssignedCustomerId = "111";
            var paymentList = new List<Payment>
            {
                new Payment("", partnerAssignedCustomerId)
                {
                    Id = 1,
                    AmountMoney = new Money(Currency.CAD, 100),
                    TransactionSystemCustomerId = 1,
                    TransactionSystemId = 1,
                    PaymentMethod = PaymentMethod.ACH
                },
                new Payment("", partnerAssignedCustomerId)
                {
                    Id = 2,
                    AmountMoney = new Money(Currency.CAD, 200),
                    TransactionSystemCustomerId = 2,
                    TransactionSystemId = 2,
                    PaymentMethod = PaymentMethod.ACH
                }
            };

            var customer = new Customer
            {
                TransactionSystemCustomerId = 111,
                PartnerAssignedCustomerId = partnerAssignedCustomerId
            };

            var customers = new List<Customer> { customer };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            var bookOutgoingManager = new BookOutgoingManager();
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(customer);
            
            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(
                x => x.BookOutgoingAggregateOrder(Arg<MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest>.Is.Anything))
                .Throw(new Exception())
                .Repeat.Times(1);
            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
                Return(new HoldingBalanceResult { Currency = "CAD", AvailableBalance = 10000.00m, BookedBalance = 10000.00m });
            PaymentMapper.Instance.Expect(
                pm => pm.GetPaymentInterval(Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything))
                .Return(new PaymentInterval());
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.PaymentRequest });

            Assert.DoesNotThrow(() => bookOutgoingManager.BookOutgoingOrder(paymentList, new Currency("CAD"),PaymentMethod.ACH));
            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();            
        }

        [Test]
        public void BookOutgoingOrder_WillReturnOnlySuccessfulPayments()
        {
            var partnerAssignedCustomerId = "111";
            var paymentList = new List<Payment>
            {
                new Payment("", partnerAssignedCustomerId) {Id = 1, AmountMoney = new Money(Currency.CAD, 100), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment("", partnerAssignedCustomerId) {Id = 2, AmountMoney = new Money(Currency.CAD, 200), TransactionSystemCustomerId = 2, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment("", partnerAssignedCustomerId) {Id = 3, AmountMoney = new Money(Currency.CAD, 200), TransactionSystemCustomerId = 2, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment("", partnerAssignedCustomerId) {Id = 4, AmountMoney = new Money(Currency.CAD, 300), TransactionSystemCustomerId = 3, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment("", partnerAssignedCustomerId) {Id = 5, AmountMoney = new Money(Currency.CAD, 150), TransactionSystemCustomerId = 3, TransactionSystemId = 1, PaymentMethod = PaymentMethod.Wire},
                new Payment("", partnerAssignedCustomerId) {Id = 6, AmountMoney = new Money(Currency.CAD, 400), TransactionSystemCustomerId = 4, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment("", partnerAssignedCustomerId) {Id = 7, AmountMoney = new Money(Currency.CAD, 500), TransactionSystemCustomerId = 5, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
                new Payment("", partnerAssignedCustomerId) {Id = 8, AmountMoney = new Money(Currency.CAD, 600), TransactionSystemCustomerId = 6, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
            };

            var customer = new Customer
            {
                TransactionSystemCustomerId = 111,
                PartnerAssignedCustomerId = partnerAssignedCustomerId
            };

            var customers = new List<Customer> { customer };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            var bookOutgoingManager = new BookOutgoingManager();
            var testProvider = new TestOrdersProviderFactory { ClientIdsThatWillFail = new List<int> { 2, 3 } };
            
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(customer);
            OrdersProviderFactory.InjectedOrdersProviderInterface = testProvider;
            CCTTServiceFactory.InjectedServiceInterface.Expect(m => m.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).
               Return(new HoldingBalanceResult { Currency = "CAD", AvailableBalance = 10000.00m, BookedBalance = 10000.00m });
            PaymentMapper.Instance.Expect(
               pm => pm.GetPaymentInterval(Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything))
               .Return(new PaymentInterval());
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CustomerBatchMapper.Instance.Stub(ccm => ccm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch { BatchType = BatchType.PaymentRequest });

            var successfulPayments = bookOutgoingManager.BookOutgoingOrder(paymentList, new Currency("CAD"), PaymentMethod.ACH);
            Assert.AreEqual(4, successfulPayments.Count);
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        [Test]
        public void FailedBookOutGoing_WillKickOffScheduleToRetry_ForFirstTime()
        {
            var currency = new Currency("USD");
            var paymentMethod = PaymentMethod.ACH;
            var aggregatePayment = new AggregatedPayment
            {
                Count = 2,
                Currency = currency,
                OriginalPayments = new List<Payment>
                {
                    new Payment(1) {AmountMoney = new Money(new Currency(currency.Code), 100), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                    new Payment(2) {AmountMoney = new Money(new Currency(currency.Code), 300), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                },
                PaymentMethod = paymentMethod,
                Total = 400,
                TransactionSystemCustomerId = 123,
                TransactionSystemId = 1
            };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();
            
            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(x => x.BookOutgoingAggregateOrder(Arg<MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest>.Is.Anything)).Throw(new Exception());
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentInterval(currency, paymentMethod)).Return(new PaymentInterval());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentScheduleErrorByPaymentIntervalAndStatus(Arg<int>.Is.Anything, Arg<PaymentScheduleStatus>.Is.Anything, Arg<int>.Is.Anything)).Throw(new ArgumentException());
            PaymentMapper.Instance.Expect(pm => pm.InsertPaymentScheduleError(Arg<PaymentScheduleError>.Is.Anything));
            PaymentPoller.Instance.Expect(pp => pp.SchedulePaymentBookingRetryJob(Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything, Arg<PaymentScheduleError>.Is.Anything, Arg<int>.Is.Anything));

            bookOutgoingManager.BookAggregatePayment(aggregatePayment, currency);

            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentPoller.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
        }

        [Test]
        public void FailedBookOutGoing_WillNotKickOffScheduleToRetry_ForSecondTime()
        {
            var currency = new Currency("USD");
            var paymentMethod = PaymentMethod.ACH;

            ServiceSettings.Instance.Expect(s => s.GetIntValue("BookingRetryIntervalInMinutes")).Return(1);
            var retryIntervalInMinutes = ServiceSettings.Instance.GetIntValue("BookingRetryIntervalInMinutes");

            var aggregatePayment = new AggregatedPayment
            {
                Count = 2,
                Currency = currency,
                OriginalPayments = new List<Payment>
                {
                    new Payment(1) {AmountMoney = new Money(new Currency(currency.Code), 100), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                    new Payment(2) {AmountMoney = new Money(new Currency(currency.Code), 300), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                },
                PaymentMethod = paymentMethod,
                Total = 400,
                TransactionSystemCustomerId = 123,
                TransactionSystemId = 1
            };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            var now = DateTime.Now;
            var paymentScheduleError = new PaymentScheduleError
            {
                Count = 1,
                Message = "",
                NextRetryTimeUTC = now,
            };
            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(x => x.BookOutgoingAggregateOrder(Arg<MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest>.Is.Anything)).Throw(new Exception());
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentInterval(currency, paymentMethod)).Return(new PaymentInterval());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentScheduleErrorByPaymentIntervalAndStatus(Arg<int>.Is.Anything, Arg<PaymentScheduleStatus>.Is.Anything, Arg<int>.Is.Anything)).Return(paymentScheduleError);
            PaymentMapper.Instance.Expect(pm => pm.UpdatePaymentScheduleError(Arg<PaymentScheduleError>.Is.Anything));

            PaymentPoller.Instance.Expect(pp => pp.SchedulePaymentBookingRetryJob(Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything, Arg<PaymentScheduleError>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(0);

            bookOutgoingManager.BookAggregatePayment(aggregatePayment, currency);
            Assert.AreEqual(2, paymentScheduleError.Count);
            Assert.AreEqual(now.AddMinutes(retryIntervalInMinutes).ToShortTimeString(), paymentScheduleError.NextRetryTimeUTC.ToShortTimeString());
            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentPoller.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
        }

        [Test]
        public void FailedBookOutGoing_WillStopSchedule_IfExceedMaxRetry()
        {
            var currency = new Currency("USD");
            var paymentMethod = PaymentMethod.ACH;
            ServiceSettings.Instance.Expect(s => s.GetIntValue("BookingRetryCount")).Return(3);
            var maxRetry = ServiceSettings.Instance.GetIntValue("BookingRetryCount");
            var aggregatePayment = new AggregatedPayment
            {
                Count = 2,
                Currency = currency,
                OriginalPayments = new List<Payment>
                {
                    new Payment(1) {AmountMoney = new Money(new Currency(currency.Code), 100), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                    new Payment(2) {AmountMoney = new Money(new Currency(currency.Code), 300), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                },
                PaymentMethod = paymentMethod,
                Total = 400,
                TransactionSystemCustomerId = 123,
                TransactionSystemId = 1
            };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            var now = DateTime.Now;
            var paymentScheduleError = new PaymentScheduleError
            {
                Count = maxRetry - 1,
                Message = "",
                NextRetryTimeUTC = now,
            };
            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(x => x.BookOutgoingAggregateOrder(Arg<MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest>.Is.Anything)).Throw(new Exception());
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentInterval(currency, paymentMethod)).Return(new PaymentInterval());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentScheduleErrorByPaymentIntervalAndStatus(Arg<int>.Is.Anything, Arg<PaymentScheduleStatus>.Is.Anything, Arg<int>.Is.Anything)).Return(paymentScheduleError);
            PaymentMapper.Instance.Expect(pm => pm.UpdatePaymentScheduleError(Arg<PaymentScheduleError>.Is.Anything));

            PaymentPoller.Instance.Expect(pp => pp.SchedulePaymentBookingRetryJob(Arg<Currency>.Is.Anything, Arg<PaymentMethod>.Is.Anything, Arg<PaymentScheduleError>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(0);
            PaymentPoller.Instance.Expect(pp => pp.StopPaymentBookingRetryJob(Arg<PaymentScheduleError>.Is.Anything));

            bookOutgoingManager.BookAggregatePayment(aggregatePayment, currency);
            Assert.AreEqual(maxRetry, paymentScheduleError.Count);
            Assert.AreEqual(now.ToShortTimeString(), paymentScheduleError.NextRetryTimeUTC.ToShortTimeString());

            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentPoller.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
        }

        [Test]
        public void FailedBookOutGoing_InsertPaymentValidationLog_IsCalled()
        {
            var currency = new Currency("USD");
            var paymentMethod = PaymentMethod.ACH;
            ServiceSettings.Instance.Expect(s => s.GetIntValue("BookingRetryCount")).Return(3);
            var maxRetry = ServiceSettings.Instance.GetIntValue("BookingRetryCount");
            var aggregatePayment = new AggregatedPayment
            {
                Count = 2,
                Currency = currency,
                OriginalPayments = new List<Payment>
                {
                    new Payment(1) {AmountMoney = new Money(new Currency(currency.Code), 100), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                    new Payment(2) {AmountMoney = new Money(new Currency(currency.Code), 300), TransactionSystemCustomerId = 1, TransactionSystemId = 1, PaymentMethod = paymentMethod},
                },
                PaymentMethod = paymentMethod,
                Total = 400,
                TransactionSystemCustomerId = 123,
                TransactionSystemId = 1
            };

            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            var now = DateTime.Now;
            var paymentScheduleError = new PaymentScheduleError
            {
                Count = maxRetry - 1,
                Message = "",
                NextRetryTimeUTC = now,
            };
            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(x => x.BookOutgoingAggregateOrder(Arg<MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest>.Is.Anything)).Throw(new Exception());
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentInterval(currency, paymentMethod)).Return(new PaymentInterval());
            PaymentMapper.Instance.Expect(pm => pm.GetPaymentScheduleErrorByPaymentIntervalAndStatus(Arg<int>.Is.Anything, Arg<PaymentScheduleStatus>.Is.Anything, Arg<int>.Is.Anything)).Return(paymentScheduleError);

            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            EventLogger.Instance.Expect(e => e.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Once();

            PaymentMapper.Instance.Expect(pm => pm.InsertPaymentValidationLog(Arg<PaymentValidationLog>.Is.Anything));

            bookOutgoingManager.BookAggregatePayment(aggregatePayment, currency);
            Assert.AreEqual(maxRetry, paymentScheduleError.Count);
            Assert.AreEqual(now.ToShortTimeString(), paymentScheduleError.NextRetryTimeUTC.ToShortTimeString());

            CustomerMapper.Instance.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            EventLogger.Instance.VerifyAllExpectations();
            EventLogger.Instance = null;
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
        }

        [Test]
        public void ProcessSanctionClearedPayments_SkipsAlreadyBookedPayments()
        {

            var alreadyBookedPayment = new Payment(11)
            {
                AmountMoney = new Money(Currency.CAD, 100),
                TransactionSystemCustomerId = 1,
                TransactionSystemId = 1,
                PaymentMethod = PaymentMethod.ACH,
                TransactionSystemOrderId = 324
            };

            var toBeBookedPayment = new Payment(12)
            {
                AmountMoney = new Money(Currency.CAD, 200),
                TransactionSystemCustomerId = 2,
                TransactionSystemId = 1,
                PaymentMethod = PaymentMethod.ACH
            };

            var sanctionClearedPaymentList = new List<Payment>
            {
               alreadyBookedPayment,
               toBeBookedPayment,
                new Payment(13) {AmountMoney = new Money(Currency.CAD, 150), TransactionSystemCustomerId = 3, TransactionSystemId = 1, PaymentMethod = PaymentMethod.Wire},
                new Payment(14) {AmountMoney = new Money(Currency.CAD, 400), TransactionSystemCustomerId = 4, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
            };

            var toBeIncludedIntoBookingProcessPayments = new List<Payment>
            {
                toBeBookedPayment,
                new Payment(13) {AmountMoney = new Money(Currency.CAD, 150), TransactionSystemCustomerId = 3, TransactionSystemId = 1, PaymentMethod = PaymentMethod.Wire},
                new Payment(14) {AmountMoney = new Money(Currency.CAD, 400), TransactionSystemCustomerId = 4, TransactionSystemId = 1, PaymentMethod = PaymentMethod.ACH},
            };

            var bookedPayments = new List<Payment>
            {
                toBeBookedPayment
            };

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<Currency>.Is.Anything, Arg<PaymentStatus>.Is.Anything)).Return(sanctionClearedPaymentList);
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            var bookOutgoingManager = MockRepository.GeneratePartialMock<BookOutgoingManager>();


            bookOutgoingManager.Expect(m => m.BookOutgoingOrder(toBeIncludedIntoBookingProcessPayments, Currency.CAD, PaymentMethod.ACH)).IgnoreArguments().Return(bookedPayments);

            var bookingResult = bookOutgoingManager.ProcessSanctionClearedPayments(Currency.CAD, PaymentMethod.ACH);
            Assert.AreEqual(1, bookingResult.NewBookedOutOfHoldingPayments.Count);
            Assert.AreEqual(toBeBookedPayment.Id, bookingResult.NewBookedOutOfHoldingPayments[0].Id);
            Assert.AreEqual(1, bookingResult.AlreadyBookedOutOfHoldingPayments.Count);
            Assert.AreEqual(alreadyBookedPayment.Id, bookingResult.AlreadyBookedOutOfHoldingPayments[0].Id);
        }
    }

    public class TestOrdersProviderFactory : IOrdersProvider
    {
        public List<int> ClientIdsThatWillFail;

        public OrdersFundedStatusResult GetOrdersFundedStatus(List<string> orderIds)
        {
            throw new NotImplementedException();
        }

        public List<BookedIncomingOrder> BookIncomingOrder(MassPayments.Domain.ValueObjects.Booking.BookIncomingOrdersRequest request, Quote quote,
            Customer customer)
        {
            throw new NotImplementedException();
        }

        public List<BookedIncomingOrder> BookBatch(CommitBatchRequest request, List<PaymentAmount> batchItems, Quote quote, Customer customer)
        {
            throw new NotImplementedException();
        }

        public MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderResult BookOutgoingAggregateOrder(MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderRequest request)
        {
            if (ClientIdsThatWillFail.Contains(request.ClientId))
            {
                throw new Exception();
            }

            return new MassPayments.Domain.ValueObjects.Booking.BookOutgoingOrderResult();
        }
    }
}
