﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Managers.PainGeneration.Assemblers;
using MassPayments.Managers.PainGeneration.JsonObjects;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using Newtonsoft.Json;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.PainGeneration.Assemblers
{

    [TestFixture]
    public class PainAssemblerFixture
    {
        private Partner partner;
        [SetUp]
        public void Setup()
        {
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            partner = new Partner { Code = "Hyperwallet", Id = 1, BankRefPrefix = "abc" };
            PartnerMapper.Instance.Stub(pm => pm.GetPartnersDictionary()).Return(new Dictionary<int, Partner> { { 1, partner } });
        }

        [TearDown]
        public void TearDown()
        {
            PartnerMapper.Instance = null;
            partner = null;
        }

        [Test]
        public void CreatePainJsonString_Should_Skip_Remittance_Data_When_NullOrEmpty()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var currencyDecimalPlaces = 2;
            payment.RemittanceData = new List<string>{"",null} ;
            var payments = new List<Payment> {payment};
            var resultJson = PainAssembler.CreatePainJsonString(payments, payment.SettlementCurrencyCode, currencyDecimalPlaces, payment.PaymentMethod.ToString());
            var result = JsonConvert.DeserializeObject<PainJson>(resultJson);
            Assert.AreEqual(0, result.Payments[0].RemittanceData.Count);
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void CreatePainJsonString_Should_NotSkip_Remittance_Data_When_Spaces()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var currencyDecimalPlaces = 2;
            payment.RemittanceData = new List<string> { " ", "valid", "yeah!" };
            var payments = new List<Payment> { payment };
            var resultJson = PainAssembler.CreatePainJsonString(payments, payment.SettlementCurrencyCode, currencyDecimalPlaces, payment.PaymentMethod.ToString());
            var result = JsonConvert.DeserializeObject<PainJson>(resultJson);
            Assert.AreEqual(3, result.Payments[0].RemittanceData.Count);
            PartnerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void CreatePaymentInstruction_ReturnsCorrectly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = new CustomerBatch { ExternalCustomerId = customer.PartnerAssignedCustomerId, ExternalId = "batchId" };
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var currencyDecimalPlaces = 2;
            payment.RemittanceData = new List<string> { " ", "valid", "yeah!" };
            var payments = new List<Payment> { payment };
           
            var paymentInstruction = PainAssembler.CreatePaymentInstruction(payments, payment.SettlementCurrencyCode, currencyDecimalPlaces, payment.PaymentMethod.ToString());

            PartnerMapper.Instance.VerifyAllExpectations();
            Assert.AreEqual(payment.SettlementCurrencyCode, paymentInstruction.CurrencyCode);
            Assert.AreEqual(currencyDecimalPlaces, paymentInstruction.CurrencyDecimalPlaces);
            Assert.AreEqual(payment.PaymentMethod.ToString(), paymentInstruction.PaymentMethod);
            Assert.AreEqual(1, paymentInstruction.Payments.Count);

            var paymentDetail = paymentInstruction.Payments[0];
            Assert.AreEqual(payment.Id, paymentDetail.PaymentId);
            Assert.AreEqual(payment.AmountMoney.Amount, paymentDetail.Amount);
            Assert.AreEqual(payment.TransactionSystemCustomerId, paymentDetail.ClientId);
            Assert.AreEqual(payment.RequestedReleaseDate, paymentDetail.RequestedReleaseDate);
            Assert.AreEqual(payment.TransactionSystemOrderNumber, paymentDetail.OutGoingConfirmation);
            Assert.AreEqual(payment.InstructionCodeForBank, paymentDetail.InstructionCodeForBank);
            Assert.AreEqual(payment.InstructionForBank, paymentDetail.InstructionInformation);
            Assert.AreEqual(3, paymentDetail.RemittanceData.Count);
            Assert.AreEqual(payment.RemittanceData[0], paymentDetail.RemittanceData[0]);
            Assert.AreEqual(payment.RemittanceData[1], paymentDetail.RemittanceData[1]);
            Assert.AreEqual(payment.RemittanceData[2], paymentDetail.RemittanceData[2]);

            Assert.AreEqual(payment.PurposeOfPayment, paymentDetail.PurposeOfPayment);
            Assert.AreEqual(Convert.ToString(payment.RemittanceType), paymentDetail.RemittanceType);
            Assert.AreEqual(partner.BankRefPrefix, paymentDetail.PartnerBankRefPrefix);
            Assert.AreEqual(partner.Code, paymentDetail.PaymentSource);

            Assert.AreEqual(payment.ThirdPartyRemitter.Id, paymentDetail.ThirdPartyRemitterId);
            Assert.AreEqual(payment.ThirdPartyRemitter.BusinessName, paymentDetail.ThirdPartyRemitterBusinessName);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine1, paymentDetail.ThirdPartyRemitterAddressLine1);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine2, paymentDetail.ThirdPartyRemitterAddressLine2);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.AddressLine3, paymentDetail.ThirdPartyRemitterAddressLine3);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.City, paymentDetail.ThirdPartyRemitterCity);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.StateOrProvince, paymentDetail.ThirdPartyRemitterStateOrProv);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.ZipOrPostalCode, paymentDetail.ThirdPartyRemitterZipOrPostal);
            Assert.AreEqual(payment.ThirdPartyRemitter.Address.CountryCode, paymentDetail.ThirdPartyRemitterCountryCode);

            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankCode, paymentDetail.IntermediaryBankCode);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.AccountNumber, paymentDetail.IntermediaryBankAccountNumber);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankName, paymentDetail.IntermediaryBankName);


            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.CountryCode, paymentDetail.IntermediaryBankCountryCode);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.AggregatedAddressLine, paymentDetail.IntermediaryBankAddressLine);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.City, paymentDetail.IntermediaryBankCity);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankAddress.StateOrProvince, paymentDetail.IntermediaryBankStateProvince);
            Assert.AreEqual(payment.BankAccount.IntermediaryBankAccount.BankBranchCode, paymentDetail.IntermediaryBankBranchCode);

            Assert.AreEqual(payment.BankAccount.BankCode, paymentDetail.BeneBankCode);
            Assert.AreEqual(payment.BankAccount.BankName, paymentDetail.BeneBankName);
            Assert.AreEqual(payment.BankAccount.DisplayName, paymentDetail.BeneAccountName);
            Assert.AreEqual(payment.BankAccount.AccountNumber, paymentDetail.BeneAccountNumber);
            Assert.AreEqual(payment.BankAccount.AccountPurpose, paymentDetail.BeneAccountType);
            Assert.AreEqual(payment.BankAccount.BankAddress.City, paymentDetail.BeneBankCity);
            Assert.AreEqual(payment.BankAccount.BankAddress.StateOrProvince, paymentDetail.BeneBankStateProvince);
            Assert.AreEqual(payment.BankAccount.BankAddress.ZipOrPostalCode, paymentDetail.BeneBankZipOrPostalCode);
            Assert.AreEqual(payment.BankAccount.BankAddress.CountryCode, paymentDetail.BeneBankCountryCode);
            Assert.AreEqual(payment.BankAccount.BankAddress.AggregatedAddressLine, paymentDetail.BeneBankAddressLine);
            Assert.AreEqual(payment.BankAccount.BranchCode, paymentDetail.BeneBankBranchCode);

            Assert.AreEqual(payment.Beneficiary.Identification.EntityType, paymentDetail.BeneEntityType);
            Assert.AreEqual(payment.Beneficiary.Identification.GetName(), paymentDetail.BeneName);
            Assert.AreEqual(payment.Beneficiary.Identification.PhoneNumber, paymentDetail.BenePhoneNumber);
            Assert.AreEqual(payment.Beneficiary.Identification.EmailAddress, paymentDetail.BeneEmailAddress);
            Assert.AreEqual(payment.Beneficiary.Address.City, paymentDetail.BeneCity);
            Assert.AreEqual(payment.Beneficiary.Address.StateOrProvince, paymentDetail.BeneStateProvince);
            Assert.AreEqual(payment.Beneficiary.Address.ZipOrPostalCode, paymentDetail.BeneZipOrPostalCode);
            Assert.AreEqual(payment.Beneficiary.Address.CountryCode, paymentDetail.BeneCountryCode);
            Assert.AreEqual(payment.Beneficiary.Address.AggregatedAddressLine, paymentDetail.BeneAddressLine);
        }
    }
}
