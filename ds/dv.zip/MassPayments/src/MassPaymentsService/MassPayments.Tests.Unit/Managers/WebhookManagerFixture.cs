﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Managers;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.Publishers.WebhookCommandPublishers;
using MassPayments.ResourceAccess.SubscriptionsRA;
using MassPayments.ResourceAccess.SubscriptionsRA.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class WebhookManagerFixture
    {
        private WebhookManager webhookManager;

        [SetUp]
        public void SetUp()
        {
            var mockedSubscriptionPrivoder = MockRepository.GenerateMock<ISubscriptionsProvider>();
            SubscriptionsProviderFactory.InjectedSubscriptionsProviderInterface = mockedSubscriptionPrivoder;
            webhookManager = new WebhookManager();
            PublisherFactory.CleanAllInjectedPublishers();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetIntValue("MaxWebhooks", 1)).Return(1);
        }

        [TearDown]
        public void TearDown()
        {
            ServiceCallContextManager.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            SubscriptionsProviderFactory.InjectedSubscriptionsProviderInterface = null;
            ServiceSettings.Instance = null;
        }

        [Test]
        public void AddWebHook_ReturnsNewGuidForWellFormedUri()
        {
            var webhook = new Webhook
            {
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };
            var partner = new Partner {Code = "Blahlah"};
            var mockedPublisher = MockRepository.GenerateMock<IPublisher<Webhook>>();
            PublisherFactory.InjectPublisherForTesting(typeof(CreateWebhookCommandPublisher), mockedPublisher);
            mockedPublisher.Expect(p => p.Publish(Arg<Webhook>.Is.Anything));
            var guid = webhookManager.AddWebHook(webhook, partner);

            mockedPublisher.VerifyAllExpectations();
            Assert.IsNotNull(guid);
        }

        [Test]
        public void AddWebHook_ReturnsThrowsExceptionForBadUri()
        {
            var webhook = new Webhook
            {
                IsPrimary = true,
                Uri = "https:/gorilla.com"
            };

            var partner = new Partner { Code = "Blahlah" };            
            var exception = Assert.Throws<InvalidUriException>(() => webhookManager.AddWebHook(webhook, partner));

            Assert.IsTrue(exception.InvalidInputFieldName.Contains("uri"));
        }

        [Test]
        public void AddWebHook_ThrowsExceptionIfUriAlreadyExists()
        {
            var existingWebhooks = new List<Webhook>
            {
                new Webhook { Uri = "https://gorilla.com" },
                new Webhook { Uri = "https://gorilla1.com" }
            };

            var webhook = new Webhook
            {
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(existingWebhooks);

            var exception = Assert.Throws<WebhookAlreadyExistsException>(() => webhookManager.AddWebHook(webhook, partner));

            Assert.IsTrue(exception.InvalidInputFieldName.Contains("uri"));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
        }

        [Test]
        public void AddWebHook_ThrowsExceptionIfNumberOfWebhooksIsGreaterThanDefinedLimit()
        {
            var existingWebhooks = new List<Webhook>
            {
                new Webhook { Uri = "https://gorilla1.com" },
                new Webhook { Uri = "https://gorilla2.com" }
            };

            var partner = new Partner { Code = "Blahlah" };
            var webhook = new Webhook
            {
                IsPrimary = true,
                Uri = "https://gorilla3.com"
            };

            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(existingWebhooks);

            Assert.Throws<WebhookLimitExceededException>(() => webhookManager.AddWebHook(webhook, partner));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
        }

        [Test]
        public void AddWebHook_DoesNotThrowExceptionIfNumberOfWebhooksIsLessThanDefinedLimit()
        {
            var existingWebhooks = new List<Webhook>
            {
                new Webhook { Uri = "https://gorilla1.com" },
                new Webhook { Uri = "https://gorilla2.com" }
            };

            var partner = new Partner { Code = "Blahlah" };
            var webhook = new Webhook
            {
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };

            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetIntValue("MaxWebhooks", 1)).Return(3);
            var mockedPublisher = MockRepository.GenerateMock<IPublisher<Webhook>>();
            PublisherFactory.InjectPublisherForTesting(typeof(CreateWebhookCommandPublisher), mockedPublisher);
            mockedPublisher.Expect(p => p.Publish(Arg<Webhook>.Is.Anything));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(existingWebhooks);

            Assert.DoesNotThrow(() => webhookManager.AddWebHook(webhook, partner));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
            mockedPublisher.VerifyAllExpectations();
        }

        [Test]
        public void AddWebHook_ReturnsThrowsExceptionForWrongScheme()
        {
            var webhook = new Webhook
            {
                IsPrimary = true,
                Uri = "http://gorilla.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            var exception = Assert.Throws<InvalidUriException>(() => webhookManager.AddWebHook(webhook, partner));

            Assert.IsTrue(exception.InvalidInputFieldName.Contains("uri"));
        }

        [Test]
        public void AddWebHook_SendsCommand()
        {
            var injectedPublisher = MockRepository.GenerateMock<IPublisher<Webhook>>();
            PublisherFactory.InjectPublisherForTesting(typeof(CreateWebhookCommandPublisher), injectedPublisher);

            injectedPublisher.Expect(p => p.Publish(Arg<Webhook>.Is.Anything)).Repeat.Once();

            var webhook = new Webhook
            {
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            Assert.DoesNotThrow(() => webhookManager.AddWebHook(webhook, partner));
            injectedPublisher.VerifyAllExpectations();
        }

        [Test]
        public void DeleteWebhook_Works()
        {
            var injectedPublisher = MockRepository.GenerateMock<IPublisher<Webhook>>();
            PublisherFactory.InjectPublisherForTesting(typeof(DeleteWebhookCommandPublisher), injectedPublisher);
            injectedPublisher.Expect(p => p.Publish(Arg<Webhook>.Is.Anything)).Repeat.Once();

            var webhook = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = true,
                Uri = "https://test.com"
            };

            var partner = new Partner { Code = "Blahlah" };

            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhook(Arg<Guid>.Is.Anything, Arg<Partner>.Is.Anything)).Return(webhook);
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(new List<Webhook>());

            Assert.DoesNotThrow(() => webhookManager.DeleteWebHook(webhook, partner));
            injectedPublisher.VerifyAllExpectations();
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
        }

        [Test]
        public void DeleteWebhook_ThrowsNotFoundException()
        {
            var webhook = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = true,
                Uri = "https://test.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhook(Arg<Guid>.Is.Anything, Arg<Partner>.Is.Anything)).Return(null);

            Assert.Throws<WebhookDoesNotExistsException>(() => webhookManager.DeleteWebHook(webhook, partner));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
        }

        [Test]
        public void DeleteWebhook_ThrowsPrimaryCannotBeDeletedException()
        {
            var id = Guid.NewGuid();
            var existingWebhooks = new List<Webhook>
            {
                new Webhook { Id = id, Uri = "https://test.com" },
                new Webhook { Id = Guid.NewGuid(), Uri = "https://test1.com" }
            };

            var webhook = new Webhook
            {
                Id = id,
                IsPrimary = true,
                Uri = "https://test.com"
            };
            var partner = new Partner { Code = "Blahlah" };

            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhook(Arg<Guid>.Is.Anything, Arg<Partner>.Is.Anything)).Return(webhook);
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(existingWebhooks);

            Assert.Throws<PrimaryWebhookCannotBeDeletedException>(() => webhookManager.DeleteWebHook(webhook, partner));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
        }

        [Test]
        public void UpdateWebhook_Works()
        {
            var injectedPublisher = MockRepository.GenerateMock<IPublisher<Webhook>>();
            PublisherFactory.InjectPublisherForTesting(typeof(UpdateWebhookCommandPublisher), injectedPublisher);

            injectedPublisher.Expect(p => p.Publish(Arg<Webhook>.Is.Anything)).Repeat.Once();

            var webhook = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            Assert.DoesNotThrow(() => webhookManager.UpdateWebhook(webhook, partner));
            injectedPublisher.VerifyAllExpectations();
        }

        [Test]
        public void UpdateWebhook_ThrowsIfIsPrimarySetToFalse()
        {
            var webhook = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = false,
                Uri = "https://gorilla.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            Assert.Throws<InvalidWebhookIsPrimaryValueException>(() => webhookManager.UpdateWebhook(webhook, partner));
        }

        [Test]
        public void UpdateWebhook_ThrowsExceptionIfUriAlreadyExists()
        {
            var id = Guid.NewGuid();

            var existingWebhooks = new List<Webhook>
            {
                new Webhook { Id = id, Uri = "https://gorilla.com" },
                new Webhook { Id = Guid.NewGuid(), Uri = "https://gorilla1.com" }
            };

            var webhook = new Webhook
            {
                Id = id,
                IsPrimary = true,
                Uri = "https://gorilla.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(existingWebhooks);

            var exception = Assert.Throws<WebhookAlreadyExistsException>(() => webhookManager.UpdateWebhook(webhook, partner));

            Assert.IsTrue(exception.InvalidInputFieldName.Contains("uri"));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
        }

        [Test]
        public void UpdateWebhook_DoesNotThrowIfUrlNotSubmitted()
        {
            var webhook = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = true
            };
            var mockedPublisher = MockRepository.GenerateMock<IPublisher<Webhook>>();
            PublisherFactory.InjectPublisherForTesting(typeof(UpdateWebhookCommandPublisher), mockedPublisher);
            mockedPublisher.Expect(p => p.Publish(Arg<Webhook>.Is.Anything));

            var partner = new Partner { Code = "Blahlah" };
            Assert.DoesNotThrow(() => webhookManager.UpdateWebhook(webhook, partner));
            mockedPublisher.VerifyAllExpectations();
        }

        [Test]
        public void UpdateWebhook_ThrowsExceptionIfIdDoesNotExist()
        {
            var id = Guid.NewGuid();

            var existingWebhook = new List<Webhook>
            {
                new Webhook { Id = id, Uri = "https://gorilla.com" }
            };

            var webhook = new Webhook
            {
                Id = Guid.NewGuid(),
                IsPrimary = true,
                Uri = "https://gorilla1.com"
            };

            var partner = new Partner { Code = "Blahlah" };
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(existingWebhook);

            Assert.Throws<WebhookDoesNotExistsException>(() => webhookManager.UpdateWebhook(webhook, partner));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
        }

        [Test]
        public void UpdateWebhook_DoesNotThrowExceptionIfIdDoesExist()
        {
            var id = Guid.NewGuid();

            var existingWebhook = new List<Webhook>
            {
                new Webhook { Id = id, Uri = "https://gorilla.com" }
            };

            var webhook = new Webhook
            {
                Id = id,
                IsPrimary = true,
                Uri = "https://gorilla1.com"
            };
            var mockedPublisher = MockRepository.GenerateMock<IPublisher<Webhook>>();
            PublisherFactory.InjectPublisherForTesting(typeof(UpdateWebhookCommandPublisher), mockedPublisher);
            mockedPublisher.Expect(p => p.Publish(Arg<Webhook>.Is.Anything));

            var partner = new Partner { Code = "Blahlah" };
            SubscriptionsProviderFactory.GetSubscriptionsProvider().Expect(s => s.GetWebhooks(Arg<Partner>.Is.Anything)).Return(existingWebhook);

            Assert.DoesNotThrow(() => webhookManager.UpdateWebhook(webhook,partner));
            SubscriptionsProviderFactory.GetSubscriptionsProvider().VerifyAllExpectations();
            mockedPublisher.VerifyAllExpectations();
        }
    }
}
