﻿using System.Collections.Generic;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Caches;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.ServiceProviders.WUBSHoldingEngine;
using MassPayments.Tests.Unit.Helpers;
using MassPayments.WUBSHoldingEngine;
using NUnit.Framework;
using Rhino.Mocks;
using IMassPaymentsService = MassPayments.CCTEntityManagement.IMassPaymentsService;
using ICCTTMassPayService = MassPayments.CCTMassPayments.IMassPaymentsService;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class HoldingBalanceManagerFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
        }

        /*WUBS H2H Service*/
        //[Test]
        //public void GetHoldingBalanceByCustomer_WUBS_ThrowsException()
        //{
        //    var customer = CustomerHelper.Instance.CreateCustomer();
        //    var holdingData = new HoldingData() { CurrencyCode = null };
        //    WubsHoldingEngineFactory.InjectedServiceInterface = MockRepository.GenerateMock<IHoldingEngineService>();
        //    WubsHoldingEngineFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalanceForCustomer(customer.TransactionSystemCustomerExternalId, "USD")).Return(holdingData);

        //    CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
        //    CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

        //    Assert.Throws<HoldingNotAvailableException>(() => new HoldingBalanceManager().GetHoldingBalanceByCustomer(customer, "USD"));
        //    WubsHoldingEngineFactory.InjectedServiceInterface = null;
        //}

        //[Test]
        //public void GetHoldingBalanceByCustomer_WUBS_MakesCorrectCalls()
        //{
        //    var customer = CustomerHelper.Instance.CreateCustomer();
        //    var holdingData = new HoldingData()
        //    {
        //        CurrencyCode = "CAD",
        //        AvailableBalance = new MoneyData() { CurrencyCode = "CAD", Amount = 100.00m },
        //        BookBalance = new MoneyData() { CurrencyCode = "CAD", Amount = 150.00m }
        //    };

        //    WubsHoldingEngineFactory.InjectedServiceInterface = MockRepository.GenerateMock<IHoldingEngineService>();
        //    WubsHoldingEngineFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalanceForCustomer(customer.TransactionSystemCustomerExternalId, "CAD")).Return(holdingData);

        //    var result = new HoldingBalanceManager().GetHoldingBalanceByCustomer(customer, "CAD");

        //    Assert.NotNull(result);

        //    WubsHoldingEngineFactory.InjectedServiceInterface = null;
        //}

        //[Test]
        //public void GetAllHoldingBalanceByCustomer_WUBS_ThrowsException()
        //{
        //    var customer = CustomerHelper.Instance.CreateCustomer();
        //    var holdingData = new HoldingData() { CurrencyCode = null };
        //    WubsHoldingEngineFactory.InjectedServiceInterface = MockRepository.GenerateMock<IHoldingEngineService>();
        //    WubsHoldingEngineFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalanceForCustomer(customer.TransactionSystemCustomerExternalId, "USD")).Return(holdingData);

        //    var holdingBalanceResult = new HoldingBalanceResult() { Currency = "USD", AvailableBalance = 0.0m, BookedBalance = 0.0m };
        //    CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<ICCTTMassPayService>();
        //    CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).Return(holdingBalanceResult);

        //    CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
        //    CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

        //    Assert.Throws<HoldingNotAvailableException>(() => new HoldingBalanceManager().GetAllHoldingBalanceByCustomer(customer, "USD"));

        //    WubsHoldingEngineFactory.InjectedServiceInterface = null;
        //}

        //[Test]
        //public void GetAllHoldingBalanceByCustomer_CCTT_ThrowsException()
        //{
        //    var customer = CustomerHelper.Instance.CreateCustomer();
        //    var holdingBalanceResult = new HoldingBalanceResult() { Currency = "USD", AvailableBalance = 0.0m, BookedBalance = 0.0m };
        //    CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<ICCTTMassPayService>();
        //    CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).Return(holdingBalanceResult);

        //    CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
        //    CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

        //    Assert.Throws<HoldingNotAvailableException>(() => new HoldingBalanceManager().GetAllHoldingBalanceByCustomer(customer, "USD"));

        //    CCTTServiceFactory.InjectedServiceInterface = null;
        //}

        //[Test]
        //public void GetHoldingBalanceByCustomer_CCTT_ThrowsException()
        //{
        //    var customer = CustomerHelper.Instance.CreateCustomer();
        //    var holdingBalanceResult = new HoldingBalanceResult() { Currency = "USD", AvailableBalance = 0.0m, BookedBalance = 0.0m };
        //    CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<ICCTTMassPayService>();
        //    CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).Return(holdingBalanceResult);
        //    CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
        //    CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

        //    Assert.Throws<HoldingNotAvailableException>(() => new HoldingBalanceManager().GetHoldingBalanceByCustomer(customer, "USD"));
        //    CCTTServiceFactory.InjectedServiceInterface = null;
        //}
        //[Test]
        //public void GetAllHoldingBalanceByCustomer_WUBS_MakesCorrectCalls()
        //{
        //    var customer = CustomerHelper.Instance.CreateCustomer();
        //    var result = new HoldingBalanceManager().GetAllHoldingBalanceByCustomer(customer, string.Empty);

        //    Assert.Greater(result.Count, 0);
        //}

        [Test]
        public void GetCurrencyHoldingBalanceByCustomer_CCTT_MakesCorrectCalls()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var holdingBalanceResult = new HoldingBalanceResult() { Currency = "CAD", AvailableBalance = 100.0m, BookedBalance = 100.0m };
            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<ICCTTMassPayService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.GetHoldingBalance(Arg<HoldingBalanceRequest>.Is.Anything)).Return(holdingBalanceResult);

            var result = new HoldingBalanceManager().GetCurrencyHoldingBalanceByCustomer(customer, Currency.CAD);

            Assert.NotNull(result);

            CCTTServiceFactory.GetService().VerifyAllExpectations();
            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void GetAllHoldingBalanceByCustomer_CCTT_MakesCorrectCalls()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var holdingBalanceResult = new List<HoldingBalanceResult>() {new HoldingBalanceResult(){ Currency = "CAD", AvailableBalance = 100.0m, BookedBalance = 100.0m }};
            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<ICCTTMassPayService>();
            CCTTServiceFactory.InjectedServiceInterface.Expect(sp => sp.GetAllHoldingBalances(Arg<int>.Is.Anything)).Return(holdingBalanceResult);
            var result = new HoldingBalanceManager().GetAllHoldingBalanceByCustomer(customer, Currency.Null);

            Assert.Greater(result.Count, 0);
            CCTTServiceFactory.GetService().VerifyAllExpectations();
            CCTTServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void GetAllHoldingBalanceByCustomer_ThrowsException_CurrencyNotRecognized()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            Assert.Throws<CurrencyNotRecognizedException>(() => new HoldingBalanceManager().GetAllHoldingBalanceByCustomer(customer, new Currency("101")));
        }
    }
}
