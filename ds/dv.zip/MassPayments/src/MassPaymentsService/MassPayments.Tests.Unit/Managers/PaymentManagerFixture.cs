﻿using MassPayments.Domain.Entities;
using MassPayments.Domain.Entities.PaymentRequest;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions.Resource.Payment;
using MassPayments.Gateways.Iris;
using MassPayments.Infrastructure.Encryption.Exceptions;
using MassPayments.Infrastructure.Encryption.Managers;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.Polling;
using MassPayments.Infrastructure.Polling.Interfaces;
using MassPayments.Managers;
using MassPayments.Managers.Notification.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;

namespace MassPayments.Tests.Unit.Managers
{
    ////[TestFixture]
    public class PaymentManagerFixture
    {
        private IPublisher<Payment, CustomerBatch, Customer> paymentStatusUpdatedpublisher;

        [SetUp]
        public void Setup()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            PaymentBatchMapper.Instance = MockRepository.GenerateMock<IPaymentBatchMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            PaymentPoller.Instance = MockRepository.GenerateMock<IPaymentPoller>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            PaymentRequestMapper.Instance = MockRepository.GenerateMock<IPaymentRequestMapper>();
            CustomerBatchCurrencyMapper.Instance = MockRepository.GenerateMock<ICustomerBatchCurrencyMapper>();
            paymentStatusUpdatedpublisher = MockRepository.GenerateMock<IPublisher<Payment, CustomerBatch, Customer>>();
            PublisherFactory.InjectPublisherForTesting(typeof(PaymentStatusUpdatedPublisher), paymentStatusUpdatedpublisher);
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.GetIntValue("MaxReturnedResources.Payments", 1000)).Return(1000);
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CurrencyPaymentMethodCache.Instance.Initialize();
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
            CustomerMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            PaymentBatchMapper.Instance = null;
            EventLogger.Instance = null;
            PaymentPoller.Instance = null;
            QuoteMapper.Instance = null;
            PartnerMapper.Instance = null;
            PaymentRequestMapper.Instance = null;
            PaymentRequestMapper.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
            paymentStatusUpdatedpublisher = null;
            ServiceSettings.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
        }

        [Test]
        public void ProcessPaymentBatch_MakeCorrectCalls()
        {
            var payment = new Payment(1);

            var paymentManager = new PaymentManager();

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything))
                .Return(new List<Payment>());
            PaymentMapper.Instance.Expect(pm => pm.InsertPayment(payment));
            PaymentMapper.Instance.Expect(pm => pm.InsertPaymentStatusHistory(Arg<int>.Is.Anything, Arg<PaymentStatus>.Is.Anything));

            Assert.DoesNotThrow(() => paymentManager.SaveAsPaymentBatch(payment));
            Assert.AreEqual(PaymentStatus.Created, payment.PaymentStatus);
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void ProcessPaymentBatch_MakeCorrectCalls_WhenCashoutExists()
        {
            var payment = new Payment(1);

            var paymentManager = new PaymentManager();

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<string>.Is.Anything, Arg<int>.Is.Anything))
                .Return(new List<Payment> { new Payment(1) { PaymentStatus = PaymentStatus.Committed } });
            PaymentMapper.Instance.Expect(pm => pm.InsertPayment(Arg<Payment>.Is.Anything)).Repeat.Times(0);
            PaymentMapper.Instance.Expect(pm => pm.InsertPaymentStatusHistory(Arg<int>.Is.Anything, Arg<PaymentStatus>.Is.Anything));

            Assert.DoesNotThrow(() => paymentManager.SaveAsPaymentBatch(payment));
            PaymentMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void ProcessPaymentCashout_MakeCorrectCalls()
        {
            var payment = new Payment(1);

            var paymentManager = MockRepository.GeneratePartialMock<PaymentManager>();

            PaymentMapper.Instance.Expect(pm => pm.InsertPayment(payment));
            PaymentMapper.Instance.Expect(pm => pm.DoesPaymentExist(payment)).Return(false);
            PaymentMapper.Instance.Expect(pm => pm.InsertPaymentStatusHistory(Arg<int>.Is.Anything, Arg<PaymentStatus>.Is.Anything));
            paymentManager.Expect(pm => pm.LogWarning(Arg<string>.Is.Anything));

            Assert.DoesNotThrow(() => paymentManager.SaveAsPaymentCashout(payment));
            Assert.AreEqual(PaymentStatus.Committed, payment.PaymentStatus);
            PaymentMapper.Instance.VerifyAllExpectations();
            paymentManager.VerifyAllExpectations();
        }

        [Test]
        public void ProcessExistingPayment_MakeCallsToUpdate()
        {
            var payment = new Payment(1);

            var paymentManager = new PaymentManager();

            PaymentMapper.Instance.Expect(pm => pm.UpdateBatchPayment(payment));
            PaymentMapper.Instance.Expect(pm => pm.DoesPaymentExist(payment)).Return(true);
            PaymentMapper.Instance.Expect(pm => pm.GetPayment(Arg<string>.Is.Anything, Arg<int>.Is.Anything, Arg<PaymentStatus>.Is.Anything)).Return(payment);
            Assert.DoesNotThrow(() => paymentManager.SaveAsPaymentCashout(payment));
            PaymentMapper.Instance.VerifyAllExpectations();
        }
        
        [Test]
        public void SavePaymentRequest_MakesCorrectCall()
        {
            var paymentManager = new PaymentManager();
            var request = new PaymentRequestToProcess
            {
                PartnerId = 1,
                CreatedOnUtc = DateTime.UtcNow,
                PaymentsToProcess = new List<PaymentRequest>()
            };

            PaymentRequestMapper.Instance.Expect(pm => pm.InsertPaymentRequest(request)).IgnoreArguments().Return(1);

            var result = paymentManager.SavePaymentRequest(request);

            Assert.IsNotNull(result);
            PaymentRequestMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void UpdatePaymentStatuses_WillCreateListsFromAPaymentBlockList()
        {
            var loadedPayments = new List<Payment> { new Payment(1) };
            var paymentBlockList = new GetPaymentStatusResult
            {
                PaymentBlockMessage = new List<PaymentBlockMessage>
                {
                    new PaymentBlockMessage {Id = "MPConcur-1", Status = IrisPaymentStatus.Block},
                    new PaymentBlockMessage {Id = "MPConcur-1", Status = IrisPaymentStatus.Unblock},
                    new PaymentBlockMessage {Id = "MPConcur-1", Status = IrisPaymentStatus.Unknown},
                    new PaymentBlockMessage {Id = "MPConcur-1", Status = IrisPaymentStatus.PermanentBlock}
                }
            };

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<List<int>>.Is.Anything)).Return(loadedPayments);
            CustomerBatchMapper.Instance.Expect(cbm => cbm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(new List<Customer> { new Customer() });

            var paymentManager = new PaymentManager();
            paymentManager.UpdatePaymentBlockStatuses(paymentBlockList.PaymentBlockMessage);
            var args = PaymentMapper.Instance.GetArgumentsForCallsMadeOn(
                   pm => pm.UpdatePaymentStatuses(Arg<List<Payment>>.Is.Anything));
            var payments = (List<Payment>)args[0][0];

            Assert.AreEqual(2, payments.Count);
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
        }

        [Test]
        public void UpdatePaymentStatuses_DoesNotCreatePaymentIfIdFailsToParse_DoesNotThrow()
        {
            var loadedPayments = new List<Payment> { new Payment(1) };
            var paymentBlockList = new GetPaymentStatusResult
            {
                PaymentBlockMessage = new List<PaymentBlockMessage>
                {
                    new PaymentBlockMessage {Id = "wrongId1", Status = IrisPaymentStatus.Unblock},
                    new PaymentBlockMessage {Id = "", Status = IrisPaymentStatus.Unblock},
                    new PaymentBlockMessage {Id = "123", Status = IrisPaymentStatus.Unblock},
                    new PaymentBlockMessage {Id = "abc-def", Status = IrisPaymentStatus.Unblock}
                }
            };

            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<List<int>>.Is.Anything)).Return(loadedPayments);
            CustomerBatchMapper.Instance.Expect(cbm => cbm.GetCustomerBatch(Arg<int>.Is.Anything)).Return(new CustomerBatch());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());
            CustomerMapper.Instance.Expect(pm => pm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(new List<Customer> { new Customer()});
            
            var paymentManager = new PaymentManager();
            paymentManager.UpdatePaymentBlockStatuses(paymentBlockList.PaymentBlockMessage);
            var args = PaymentMapper.Instance.GetArgumentsForCallsMadeOn(
              pm => pm.UpdatePaymentStatuses(Arg<List<Payment>>.Is.Anything));
            var payments = (List<Payment>)args[0][0];

            Assert.AreEqual(0, payments.Count);
            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerBatchCurrencyMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
        }

        [Test]
        public void SavePaymentBatchFile_SendsNotification_WhenEncryptionFails()
        {
            var payments = new List<Payment> { new Payment(1) };
            const int batchId = 123;
            string expectedFileName = $"bankBatches_{batchId}_{DateTime.Now.ToString("yyyy-MM-dd")}.json";

            PaymentBatchMapper.Instance.Expect(m => m.InsertPaymentBatch(Arg<List<int>>.Is.Anything)).Return(batchId);
            PaymentBatchMapper.Instance.Expect(m => m.UpdatePaymentBatch(batchId, expectedFileName, 0));

            var notificationManager = MockRepository.GenerateMock<INotificationManager>();
            notificationManager.Expect(m => m.NotifyFileProcessingFailure(
                Arg<string>.Is.Equal(expectedFileName),
                Arg<string>.Is.Equal("Failed to encrypt payment batch file."),
                Arg<EncryptionFailedException>.Is.Anything));

            var paymentManager = new PaymentManager(new EncryptionManager(), notificationManager);

            Assert.Throws<EncryptionFailedException>(() => paymentManager.SavePaymentBatchFile(payments, 0));

            PaymentBatchMapper.Instance.VerifyAllExpectations();
            notificationManager.VerifyAllExpectations();
        }

        [Test]
        public void GetPayment_Returns_FromPayment_Correctly()
        {
            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new Payment(1));

            var paymentManager = new PaymentManager();

            var payment = paymentManager.GetPayment(1, "1");

            Assert.IsNotNull(payment);
            PaymentMapper.Instance.AssertWasCalled(p => p.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            PaymentRequestMapper.Instance.AssertWasNotCalled(p => p.GetFailedPaymentRequest(Arg<int>.Is.Anything, Arg<string>.Is.Anything));

            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetPayment_Returns_FromPaymentRequest_Correctly()
        {
            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            PaymentRequestMapper.Instance.Expect(m => m.GetFailedPaymentRequest(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new PaymentRequest());

            var paymentManager = new PaymentManager();

            var payment = paymentManager.GetPayment(1, "1");

            Assert.IsNotNull(payment);
            PaymentMapper.Instance.AssertWasCalled(p => p.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            PaymentRequestMapper.Instance.AssertWasCalled(p => p.GetFailedPaymentRequest(Arg<int>.Is.Anything, Arg<string>.Is.Anything));

            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetBatchPayment_Returns_FromPayment_Correctly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, batch);

            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<CustomerBatch>.Is.Anything, Arg<string>.Is.Anything)).Return(payment);

            var resultPayment = new PaymentManager().GetPayment(batch, payment.ExternalId);

            Assert.IsNotNull(resultPayment);
            PaymentMapper.Instance.AssertWasCalled(p => p.GetPayment(Arg<CustomerBatch>.Is.Anything, Arg<string>.Is.Anything));
            PaymentRequestMapper.Instance.AssertWasNotCalled(p => p.GetFailedPaymentRequest(Arg<CustomerBatch>.Is.Anything, Arg<string>.Is.Anything));

            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetBatchPayment_Returns_FromPaymentRequest_Correctly()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var batch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var paymentRequest = new PaymentRequest();

            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<CustomerBatch>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            PaymentRequestMapper.Instance.Expect(m => m.GetFailedPaymentRequest(Arg<CustomerBatch>.Is.Anything, Arg<string>.Is.Anything)).Return(paymentRequest);

            var resultPayment = new PaymentManager().GetPayment(batch, null);

            Assert.IsNotNull(resultPayment);
            PaymentMapper.Instance.AssertWasCalled(p => p.GetPayment(Arg<CustomerBatch>.Is.Anything, Arg<string>.Is.Anything));
            PaymentRequestMapper.Instance.AssertWasCalled(p => p.GetFailedPaymentRequest(Arg<CustomerBatch>.Is.Anything, Arg<string>.Is.Anything));

            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void CancelPayment_ThrowsException_WhenNotFound()
        {
            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            PaymentRequestMapper.Instance.Expect(m => m.GetFailedPaymentRequest(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);

            var paymentManager = new PaymentManager();

            Assert.Throws<PaymentNotFoundException>(() => paymentManager.CancelPayment(1, ""));

            PaymentMapper.Instance.AssertWasCalled(p => p.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            PaymentRequestMapper.Instance.AssertWasCalled(p => p.GetFailedPaymentRequest(Arg<int>.Is.Anything, Arg<string>.Is.Anything));

            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void CancelBatchPayment_ThrowsException_WhenNotFound()
        {
            Assert.Throws<PaymentNotFoundException>(() => new PaymentManager().CancelBatchPayment(null, null));
        }

        [Test]
        public void CancelBatchPayment_ThrowsException_WhenBatchIsCommitted()
        {
            Assert.Throws<PaymentCannotBeCancelledException>(() => new PaymentManager().CancelBatchPayment(new CustomerBatch { BatchStatus = CustomerBatchStatus.Committed }, new Payment("testPayment1", null)));
        }

        [Test]
        public void CancelBatchPayment_DoesNotThrowException_ForStatusThatCanBeCancelled()
        {
            var partnerAssignedCustomerId = "111";
            var payment = new Payment("1", partnerAssignedCustomerId)
            {
                Id = 1,
                PaymentSourceId = 1,
                PaymentStatus = PaymentStatus.Committed,
                AmountMoney = new Money(new Currency("USD"), 10000),
                SettlementAmountMoney = new Money(new Currency("CAD"), 10000)
            };

            var customers = new List<Customer>
            {
                new Customer { PartnerAssignedCustomerId = partnerAssignedCustomerId }
            };

            CustomerMapper.Instance.Expect(cm => cm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(customers);
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "Blahlah" });
            PaymentMapper.Instance.Expect(m => m.UpdatePaymentStatuses(Arg<List<int>>.Is.Anything, Arg<List<PaymentStatus>>.Is.Anything, Arg<List<DateTime>>.Is.Anything));
            PaymentMapper.Instance.Expect(m => m.GetPayments(Arg<CustomerBatch>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<Payment> { payment });
            CustomerBatchCurrencyMapper.Instance.Expect(m => m.DeleteCustomerBatchCurrency(Arg<int>.Is.Anything, Arg<Money>.Is.Anything, Arg<Money>.Is.Anything));
            var paymentManager = new PaymentManager();

            Assert.DoesNotThrow(() => paymentManager.CancelBatchPayment(new CustomerBatch { BatchStatus = CustomerBatchStatus.Created }, payment));

            Assert.AreEqual(PaymentStatus.Cancelled, payment.PaymentStatus);

            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerBatchCurrencyMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void CancelPayment_ThrowsException_WhenNotAccepted()
        {
            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            PaymentRequestMapper.Instance.Expect(m => m.GetFailedPaymentRequest(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new PaymentRequest { PaymentId = "1" });

            var paymentManager = new PaymentManager();

            Assert.Throws<PaymentCannotBeCancelledException>(() => paymentManager.CancelPayment(1, "1"));

            PaymentMapper.Instance.AssertWasCalled(p => p.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            PaymentRequestMapper.Instance.AssertWasCalled(p => p.GetFailedPaymentRequest(Arg<int>.Is.Anything, Arg<string>.Is.Anything));

            PaymentMapper.Instance.VerifyAllExpectations();
            PaymentRequestMapper.Instance.VerifyAllExpectations();
        }

        [TestCase(1)]
        [TestCase(2)]
        [TestCase(3)]
        public void CancelPayment_DoesNotThrowException_ForStatusThatCanBeCancelled(int paymentStatus)
        {
            var partnerAssignedCustomerId = "111";
            var payment = new Payment("1", partnerAssignedCustomerId)
            {
                Id = 1,
                PaymentSourceId = 1,
                PaymentStatus = (PaymentStatus)paymentStatus
            };

            var customers = new List<Customer>
            {
                new Customer { PartnerAssignedCustomerId = partnerAssignedCustomerId }
            };

            CustomerMapper.Instance.Expect(cm => cm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(customers);
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "Blahlah" });
            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything))
                .Return(payment);

            var paymentManager = new PaymentManager();

            Assert.DoesNotThrow(() => paymentManager.CancelPayment(payment.PaymentSourceId, payment.ExternalId));

            PaymentMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void CancelPayment_DoesNotThrowException_PaymentInABatch()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            customerBatch.BatchType = BatchType.ApiBatch;

            var partnerAssignedCustomerId = "111";
            var payment = new Payment("1", partnerAssignedCustomerId)
            {
                Id = 1,
                PaymentSourceId = 1,
                PaymentStatus = (PaymentStatus)3,
                CustomerBatchId = customerBatch.Id
            };

            var customers = new List<Customer>
            {
                new Customer { PartnerAssignedCustomerId = partnerAssignedCustomerId }
            };

            CustomerMapper.Instance.Expect(cm => cm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(customers);
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "Blahlah" });
            PaymentMapper.Instance.Expect(m => m.GetPayment(Arg<int>.Is.Anything, Arg<string>.Is.Anything))
                .Return(payment);
            CustomerBatchMapper.Instance.Expect(m => m.GetCustomerBatch(Arg<int>.Is.Anything))
                .Return(customerBatch);
            CustomerBatchMapper.Instance.Expect(m => m.UpdateCustomerBatchActiveQuoteRequestId(Arg<int>.Is.Anything, Arg<string>.Is.Anything, Arg<int>.Is.Anything));

            var paymentManager = new PaymentManager();

            Assert.DoesNotThrow(() => paymentManager.CancelPayment(payment.PaymentSourceId, payment.ExternalId));

            PaymentMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
        }

        [Test]
        public void UpdateReturnedPayments_PublishesForUpdatedPaymentStatus_Returned()
        {
            var partnerAssignedCustomerId = "111";
            var returnedPayments = new List<Payment>
            {
                new ReturnedPayment("1", partnerAssignedCustomerId)
                {
                    Id = 1,
                    PaymentSourceId = 1,
                    PaymentStatus = PaymentStatus.Returned,
                    RejectReason = "returned from bank",
                    ReturnAmount = new Money(Currency.CAD, 50m)
                }
            };

            var customers = new List<Customer>
            {
                new Customer { PartnerAssignedCustomerId = partnerAssignedCustomerId }
            };

            PaymentMapper.Instance.Expect(m => m.GetPayments(Arg<List<int>>.Is.Anything)).Return(returnedPayments);
            CustomerMapper.Instance.Expect(cm => cm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(customers);            
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "Blahlah" });

            var paymentManager = new PaymentManager();
            paymentManager.UpdateReturnedPaymentsFromPain(returnedPayments);

            PaymentMapper.Instance.AssertWasCalled(m=>m.InsertReturnedPayments(returnedPayments));
            PaymentMapper.Instance.AssertWasCalled(m => m.UpdatePaymentStatuses(returnedPayments));
            PaymentMapper.Instance.AssertWasCalled(m => m.InsertUpdateReturnedPaymentStatusinHistory(returnedPayments));
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(returnedPayments[0], null, customers[0]));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void UpdatePaymentStatusBasedOnGPGAcceptance_PublishesForUpdatedPaymentStatus_Rejected()
        {
            var partnerAssignedCustomerId = "111";
            var rejectedPayment = new Payment("1", partnerAssignedCustomerId)
            {
                Id = 1,
                PaymentSourceId = 1,
                PaymentStatus = PaymentStatus.Rejected,
                GPGProcessedUTC = DateTime.Today
            };

            var customers = new List<Customer>
            {
                new Customer { PartnerAssignedCustomerId = partnerAssignedCustomerId }
            };

            CustomerMapper.Instance.Expect(cm => cm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(customers);
            PaymentMapper.Instance.Expect(m => m.GetPayments(Arg<List<int>>.Is.Anything)).Return(new List<Payment> { rejectedPayment });
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "Blahlah" });

            var paymentManager = new PaymentManager();
            paymentManager.UpdatePaymentStatusBasedOnGPGAcceptance(new List<Payment> { rejectedPayment });

            PaymentMapper.Instance.AssertWasCalled(m => m.InsertPaymentsRejected(Arg<List<Payment>>.Is.Anything));
            PaymentMapper.Instance.AssertWasCalled(m => m.UpdatePaymentStatuses(Arg<List<int>>.Is.Anything, Arg<List<PaymentStatus>>.Is.Anything, Arg<List<DateTime>>.Is.Anything));
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void UpdatePaymentStatusBasedOnGPGAcceptance_PublishesForUpdatedPaymentStatus_Accepted()
        {
            var partnerAssignedCustomerId = "111";
            var releasedPayment = new Payment("2", partnerAssignedCustomerId)
            {
                Id = 2,
                PaymentSourceId = 2,
                PaymentStatus = PaymentStatus.Released,
                GPGProcessedUTC = DateTime.Today
            };

            var customers = new List<Customer>
            {
                new Customer { PartnerAssignedCustomerId = partnerAssignedCustomerId }
            };

            CustomerMapper.Instance.Expect(cm => cm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(customers);
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner { Code = "Blahlah" });
            PaymentMapper.Instance.Expect(m => m.GetPayments(Arg<List<int>>.Is.Anything)).Return(new List<Payment> { releasedPayment });

            var paymentManager = new PaymentManager();
            paymentManager.UpdatePaymentStatusBasedOnGPGAcceptance(new List<Payment> { releasedPayment });

            PaymentMapper.Instance.AssertWasNotCalled(m => m.InsertPaymentsRejected(Arg<List<Payment>>.Is.Anything));
            PaymentMapper.Instance.AssertWasCalled(m => m.UpdatePaymentStatuses(Arg<List<int>>.Is.Anything, Arg<List<PaymentStatus>>.Is.Anything, Arg<List<DateTime>>.Is.Anything));
            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
            PaymentMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void PublishPaymentStatusChanged_MakeCorrectCalls()
        {
            var partnerAssignedCustomerId = "111";
            var paymentManager = new PaymentManager();
            var payments = new List<Payment>
            {
                new Payment("", partnerAssignedCustomerId) { Id = 1, PaymentSourceId = 1},
                new Payment("", partnerAssignedCustomerId) { Id = 2, PaymentSourceId = 2},
            };

            var customers = new List<Customer>
            {
                new Customer { PartnerAssignedCustomerId = partnerAssignedCustomerId }
            };

            CustomerMapper.Instance.Expect(cm => cm.GetCustomersByPartnerAndCustomerIds(Arg<int>.Is.Anything, Arg<List<string>>.Is.Anything)).Return(customers);
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(1)).Return(new Partner());
            PartnerMapper.Instance.Expect(p => p.GetPartnerById(2)).Throw(new ArgumentException());
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            EventLogger.Instance.Expect(e => e.WriteError(Arg<string>.Is.Anything, Arg<EventCode>.Is.Anything)).Repeat.Once();
            Assert.DoesNotThrow(() => paymentManager.PublishPaymentStatusChangedNotification(payments, new CustomerBatch()));

            paymentStatusUpdatedpublisher.AssertWasCalled(m => m.Publish(Arg<Payment>.Is.Anything, Arg<CustomerBatch>.Is.Anything, Arg<Customer>.Is.Anything));
            paymentStatusUpdatedpublisher.VerifyAllExpectations();
            EventLogger.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            EventLogger.Instance = null;
        }
    }
}
