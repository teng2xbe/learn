﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Bus;
using MassPayments.Managers.PainGeneration;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class PainManagerFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            ServiceSettings.Instance.Stub(s => s.UseNsbBetweenMpsAndPain()).Return(true);
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyPaymentMethodCacheMapper.Instance = null;
            MassPayBus.Instance = null;
            ServiceSettings.Instance = null;
        }

        [Test]
        public void GerenatePain_MakeCorrectCalls()
        {
            CurrencyPaymentMethodCacheMapper.Instance.Expect(cp => cp.GetPainSupportDictionary())
                .Return(new Dictionary<Tuple<string, PaymentMethod>, bool> { {new Tuple<string, PaymentMethod>("CAD", PaymentMethod.ACH), true }});
            var painManager = new PainManager();
            MassPayBus.Instance.Expect(bus => bus.SendLocal(Arg<ICommand>.Is.Anything));
            Assert.DoesNotThrow(() => painManager.GeneratePain(new List<Payment>(), new Currency("CAD"), PaymentMethod.ACH));
            MassPayBus.Instance.VerifyAllExpectations();
        }
    }
}
