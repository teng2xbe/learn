﻿using System;
using System.ServiceModel;
using MassPayments.CCTEntityManagement;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.ServiceProviders.CCTEntityManagement;
using NUnit.Framework;
using Rhino.Mocks;
using SettlementPaymentMethod = MassPayments.Domain.Enums.SettlementPaymentMethod;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class CustomerManagerFixture
    {
        private DateTime timeStamp;

        [SetUp]
        public void SetUp()
        {
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
        }

        [TearDown]
        public void TearDown()
        {
            CustomerMapper.Instance = null;
            PartnerMapper.Instance = null;
            ServiceCallContextManager.Instance = null;
            ServiceSettings.Instance = null;
        }

        [Test]
        public void GetCustomerById_MakesCorrectCalls()
        {
            DateTime ttlExpiration = DateTime.Now.AddHours(1);
            var customer = new Customer
            {
                Id = 1111,
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration
            };

            CustomerMapper.Instance.Expect(cm => cm.GetCustomer(Arg<int>.Is.Anything)).Return(customer);
            
            new CustomerManager().GetCustomerById(new Partner {Id = 1}, 1111);

            CustomerMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetCustomerById_ThrowsException()
        {
            var customerManager = MockRepository.GeneratePartialMock<CustomerManager>();
            CustomerMapper.Instance.Expect(cm => cm.GetCustomer(Arg<int>.Is.Anything)).Throw(new ArgumentException("Invalid customer ID: " + 1111));
            
            Assert.Throws<ArgumentException>(()=>customerManager.GetCustomerById(new Partner { Id = 1 }, 1111));

            customerManager.VerifyAllExpectations();
        }

        [Test]
        public void ValidateOrInsertCustomerForRestfulApiRequest_ThrowsException()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(1);
            var customer = new Customer
            {
                Id = 1111,
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 2,
                TTLExpiration = ttlExpiration,
                PartnerAssignedCustomerId = "Blah"
            };

            var customerManager = MockRepository.GeneratePartialMock<CustomerManager>();
            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByPartner(Arg<Partner>.Is.Anything, Arg<string>.Is.Anything)).Throw(new ArgumentException());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner());

            EntityManagementServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();
            EntityManagementServiceFactory.InjectedServiceInterface.Expect(service => service.GetMassPayClient(Arg<GetMassPayClientRequest>.Is.Anything)).Throw(new FaultException());
            Assert.Throws<ArgumentException>(() => customerManager.ValidateOrInsertCustomer(new Partner { Id = 1 }, customer.PartnerAssignedCustomerId));

            CustomerMapper.Instance.VerifyAllExpectations();
            customerManager.VerifyAllExpectations();

            EntityManagementServiceFactory.InjectedServiceInterface = null;
        }

        [Test]
        public void ValidateOrInsertCustomerForRestfulApiRequest_ThrowsException_If_CustomerId_Is_Null()
        {
            
            var customerManager = MockRepository.GeneratePartialMock<CustomerManager>();
            Assert.Throws<InvalidCustomerException>(() => customerManager.ValidateOrInsertCustomer(Arg<Partner>.Is.Anything, null));

            customerManager.VerifyAllExpectations();
        }

        [Test]
        public void ValidateAndRenewCustomerDetails_MakesCorrectCalls_TTLExpired()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(-1);
            var existingCustomer = new Customer
            {
                Id = 1111,
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                PartnerAssignedCustomerId = "Blah"
            };

            var loadedCustomer = new Customer
            {
                Id = 1111,
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                PartnerAssignedCustomerId = "Blah"
            };
            var partner = new Partner {Id = 1, Code = "Viking"};

            var customerManager = MockRepository.GeneratePartialMock<CustomerManager>();
            CustomerMapper.Instance.Expect(cm => cm.UpdateCustomer(existingCustomer));

            customerManager.Expect(cm => cm.LoadMassPayCustomerUsingClientProvider(Arg<string>.Is.Anything, Arg<Partner>.Is.Anything)).Return(loadedCustomer);
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(partner);

            customerManager.ValidateAndRenewCustomerDetails(existingCustomer, new Partner { Id = 1 });

            CustomerMapper.Instance.VerifyAllExpectations();
            customerManager.VerifyAllExpectations();
        }


        [Test]
        public void ValidateAndRenewCustomerDetails_UpdatesExixstingCustomer_WithLoadedCustomerDetails()
        {
            DateTime ttlExpiration = DateTime.Today.AddHours(-1);
            var existingCustomer = new Customer
            {
                Id = 1111,
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration,
                PartnerAssignedCustomerId = "Blah",
                SettlementCurrency = Currency.AUD,
                SettlementMethod = SettlementPaymentMethod.Wire
            };

            var loadedCustomer = new Customer
            {
                Id = 1111,
                Name = "Dogs",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                PartnerAssignedCustomerId = "Blah",
                SettlementCurrency = Currency.CAD,
                SettlementMethod = SettlementPaymentMethod.OtherDefault

            };
            var partner = new Partner { Id = 1, Code = "Viking" };

            var customerManager = MockRepository.GeneratePartialMock<CustomerManager>();
            CustomerMapper.Instance.Expect(cm => cm.UpdateCustomer(existingCustomer));

            customerManager.Expect(cm => cm.LoadMassPayCustomerUsingClientProvider(Arg<string>.Is.Anything, Arg<Partner>.Is.Anything)).Return(loadedCustomer);
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(partner);

            customerManager.ValidateAndRenewCustomerDetails(existingCustomer, new Partner { Id = 1 });

            CustomerMapper.Instance.VerifyAllExpectations();
            customerManager.VerifyAllExpectations();

            Assert.AreEqual("CAD", existingCustomer.SettlementCurrency.Code);
            Assert.AreEqual("Dogs", existingCustomer.Name);
            Assert.AreEqual(SettlementPaymentMethod.OtherDefault, existingCustomer.SettlementMethod);
        }

        [Test]
        public void ValidateandRenewCustomerDetails_MakesCorrectCalls_TTLValid()
        {
            DateTime ttlExpiration = DateTime.Now.AddHours(1);
            var customer = new Customer
            {
                Id = 1111,
                Name = "Cats Meowingshire",
                TransactionSystemCustomerId = 1,
                Status = CustomerStatus.Enabled,
                TransactionSystemId = 1,
                PartnerId = 1,
                TTLExpiration = ttlExpiration
            };

            Assert.DoesNotThrow(() => new CustomerManager().ValidateAndRenewCustomerDetails(customer, new Partner { Id = 1 }));
        }
    }
}
