﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects.Payments;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Managers.PaymentManaging;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging
{
    [TestFixture]
    public class PaymentValidatorFixture
    {
        private List<DomesticCountryGroup> domesticCountryGroups;

        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CurrencyPaymentMethodCache.Instance.Initialize();
            domesticCountryGroups = new List<DomesticCountryGroup>
            {
                new DomesticCountryGroup
                {
                    CountryCodes = new List<string> {"PR", "GU", "MP", "VI", "US"},
                    Currency = Currency.USD
                },
                new DomesticCountryGroup
                {
                    CountryCodes = new List<string> {"CA"},
                    Currency = Currency.CAD
                },

            };
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(c => c.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyCache.Instance.Reinitialize();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
            ServiceSettings.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyCache.Instance = null;
        }

        [Test]
        public void ValidationAcceptsEmptyBankAddress_ForDomesticPayment_ForCoupledModel()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "us";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var partner = new Partner {PaymentModel = PaymentModel.Coupled};
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.AddressLine1 = null;
            payment.BankAccount.BankAddress.City = null;
            payment.BankAccount.BankAddress.StateOrProvince = null;
            payment.BankAccount.BankAddress.ZipOrPostalCode = null;
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.ThirdPartyRemitter = null;

            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));
        }

        [Test]
        public void ValidationAcceptsPartialBankAddress_ForDomesticPayment_ForCoupledModel()
        {
            var partner = new Partner { PaymentModel = PaymentModel.Coupled };
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "us";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.AddressLine1 = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));

            payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.City = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));

            payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.StateOrProvince = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));

            payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.ZipOrPostalCode = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));
        }

        [Test]
        public void ValidationAcceptsEmptyBankAddress_ForDomesticPayment_ForDecoupledModel()
        {
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "us";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            var partner = new Partner { PaymentModel = PaymentModel.Decoupled };
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.AddressLine1 = null;
            payment.BankAccount.BankAddress.City = null;
            payment.BankAccount.BankAddress.StateOrProvince = null;
            payment.BankAccount.BankAddress.ZipOrPostalCode = null;
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.CAD, 123);   //settlement doesn't have to be domestic
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.ThirdPartyRemitter = null;

            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));
        }

        [Test]
        public void ValidationAcceptsPartialBankAddress_ForDomesticPayment_ForDecoupledModel()
        {
            var partner = new Partner { PaymentModel = PaymentModel.Decoupled };
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "us";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.CAD, 123);   //settlement doesn't have to be domestic
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.AddressLine1 = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));

            payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.CAD, 123);   //settlement doesn't have to be domestic
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.City = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));

            payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.CAD, 123);   //settlement doesn't have to be domestic
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.StateOrProvince = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));

            payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.CAD, 123);   //settlement doesn't have to be domestic
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.BankAccount.BankAddress.ZipOrPostalCode = null;
            payment.ThirdPartyRemitter = null;
            Assert.AreEqual(string.Empty, PaymentValidator.Validate(payment, partner, customer, domesticCountryGroups, true, false));
        }


        [Test]
        public void IsDomesticPayment_ForCoupledModel()
        {
            var partner = new Partner { PaymentModel = PaymentModel.Coupled };
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "us";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.USD,123);
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            Assert.IsTrue(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups[0]));
            Assert.IsTrue(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups));
        }

        [Test]
        public void IsDomesticPayment_ReturnsFalse_ForCoupledModel()
        {
            var partner = new Partner { PaymentModel = PaymentModel.Coupled };
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "UK";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.USD, 123);
            payment.Beneficiary.Address.CountryCode = "UK";
            payment.BankAccount.BankAddress.CountryCode = "UK";
            Assert.IsFalse(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups[0]));
            Assert.IsFalse(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups));
        }

        [Test]
        public void IsDomesticPayment_ForDecoupledModel()
        {
            var partner = new Partner { PaymentModel = PaymentModel.Decoupled };
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "us";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.AUD, 123);
            payment.Beneficiary.Address.CountryCode = "us";
            payment.BankAccount.BankAddress.CountryCode = "us";
            Assert.IsTrue(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups[0]));
            Assert.IsFalse(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups[1]));
            Assert.IsTrue(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups));
        }

        [Test]
        public void IsDomesticPayment_ReturnsFalse_ForDeoupledModel()
        {
            var partner = new Partner { PaymentModel = PaymentModel.Decoupled };
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "UK";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.AUD, 123);
            payment.Beneficiary.Address.CountryCode = "UK";
            payment.BankAccount.BankAddress.CountryCode = "UK";
            Assert.IsFalse(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups[0]));
            Assert.IsFalse(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups[1]));
            Assert.IsFalse(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups));
        }

        [Test]
        public void IsDomesticPayment_WithMultipleCountryCodes()
        {
            var partner = new Partner { PaymentModel = PaymentModel.Decoupled };
            var customer = CustomerHelper.Instance.CreateCustomer();
            customer.CountryCode = "VI";
            var customerBatch = CustomerBatchHelper.Instance.CreateCustomerBatch(customer);
            var payment = PaymentHelper.Instance.CreatePayment(customer, customerBatch);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(Currency.USD, 123);
            payment.SettlementAmountMoney = new Money(Currency.AUD, 123);
            payment.Beneficiary.Address.CountryCode = "PR";
            payment.BankAccount.BankAddress.CountryCode = "GU";
            Assert.IsTrue(PaymentValidator.IsDomesticPayment(payment, partner, customer, domesticCountryGroups[0]));
        }
    }
}
