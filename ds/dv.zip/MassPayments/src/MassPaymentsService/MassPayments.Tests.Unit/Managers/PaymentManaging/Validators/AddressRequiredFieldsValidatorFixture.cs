﻿using MassPayments.Domain.Entities;
using MassPayments.Managers.PaymentManaging.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging.Validators
{
    [TestFixture]
    public class AddressRequiredFieldsValidatorFixture
    {
        [Test]
        public void AddressRequiredFieldsValidator_Success()
        {
            var result = new AddressRequiredFieldsValidator(CreateAddress()).Validate();
            Assert.AreEqual(string.Empty, result);
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_Address_IsNotProvided()
        {
            var result = new AddressRequiredFieldsValidator(null).Validate();
            Assert.AreNotEqual("", result);
        }

        [Test]
        public void AddressRequiredFieldsValidator_GeneratesCorrectMessage_When_Address_IsNotProvided()
        {
            var result = new AddressRequiredFieldsValidator(null).Validate();
            Assert.AreEqual("1003:address", result);
        }
        
        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_Line1_IsNotProvided()
        {
            var address = CreateAddress();
            address.AddressLine1 = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.AddressLine1", result);
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_City_IsNotProvided()
        {
            var address = CreateAddress();
            address.City = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.City", result);
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_StateProv_IsNotProvided()
        {
            var address = CreateAddress();
            address.StateOrProvince = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.StateOrProvince", result);
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_Zip_IsNotProvided()
        {
            var address = CreateAddress();
            address.ZipOrPostalCode = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.ZipOrPostalCode", result);
        }

        [Test]
        public void AddressRequiredFieldsValidator_Fails_When_CountryCode_IsNotProvided()
        {
            var address = CreateAddress();
            address.CountryCode = "";
            var result = new AddressRequiredFieldsValidator(address).Validate();
            Assert.AreEqual("1003:address.CountryCode", result);
        }


        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrProvince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
