﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Managers.PaymentManaging.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging.Validators
{
    [TestFixture]
    public class ThirdPartyRemitterValidatorFixture
    {
        [Test]
        public void ThirdPartyRemitterValidator_Success()
        {
            var result = new ThirdPartyRemitterValidator(CreateThirdPartyRemitter(), true).Validate();
            Assert.AreEqual(result, string.Empty);
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_ThirdPartyRemitter_IsProvided_For_NotEnabledPartner()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, false).Validate();
            Assert.AreEqual("1006:thirdPartyRemitter", result);
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_ThirdPartyRemitter_IsNotProvided_For_EnabledPartner()
        {
            var result = new ThirdPartyRemitterValidator(null, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter");
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_Id_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.Id = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter.id");
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_TwoOrMoreRequired_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.Id = null;
            thirdPartyRemitter.BusinessName = "";
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter.id");
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_Type_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.Type = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter.type");
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_ThirdPartyRemitter_TypeIsWrong()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.Type = "blah";
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual("1003:thirdPartyRemitter.type", result);

            thirdPartyRemitter.Type = "corporation";
            result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual("", result);

            thirdPartyRemitter.Type = "partnership";
            result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual("", result);
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_VersionedOn_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.VersionedOn = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter.versionedOn");
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_VersionedOn_IsNotValidDate()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.VersionedOn = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter.versionedOn");
        }

        [Test]
        public void ThirdPartyRemitterValidator_Fails_When_BusinessName_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.BusinessName = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter.businessName");
        }

        [Test]
        public void ThirdPartyRemitterValidator_GeneratesCorrectMessage_When_Address_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.Address = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, "1003:thirdPartyRemitter.address");
        }

        [Test]
        public void ThirdPartyRemitterValidator_GeneratesCorrectMessage_When_Identification_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.Identification = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual("1004:thirdPartyRemitter.identificationType or thirdPartyRemitter.identification", result);
        }

        [Test]
        public void ThirdPartyRemitterValidator_GeneratesCorrectMessage_When_IdentificationAndType_IsNotProvided()
        {
            var thirdPartyRemitter = CreateThirdPartyRemitter();
            thirdPartyRemitter.IdentificationType = null;
            thirdPartyRemitter.Identification = null;
            var result = new ThirdPartyRemitterValidator(thirdPartyRemitter, true).Validate();
            Assert.AreEqual(result, string.Empty);
        }

        private ThirdPartyRemitter CreateThirdPartyRemitter()
        {
            return new ThirdPartyRemitter
            {
                Id = "myid",
                VersionedOn = DateTime.Now.ToString(),
                Type = "corporation",
                BusinessName = "mybus",
                Address = CreateAddress(),    
                IdentificationType = "Business Registration No",
                Identification = "123456"
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrProvince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
