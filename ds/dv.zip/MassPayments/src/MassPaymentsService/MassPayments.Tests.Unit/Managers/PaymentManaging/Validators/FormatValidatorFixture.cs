﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Managers.PaymentManaging.Validators;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging.Validators
{
    [TestFixture]
    public class FormatValidatorFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
        }

        [TestCase("euro")]
        [TestCase("CA")]
        [TestCase("$")]
        [TestCase("pesos")]
        public void FormatValidator_Currency_Fails(string currencyCode)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency(currencyCode), 100);

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var val = new FormatValidator(payment).Validate();
            Assert.AreEqual("1005:currency", val);
        }

        [TestCase("CAD")]
        [TestCase("USD")]
        public void FormatValidator_Currency_Success(string currencyCode)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency(currencyCode), 100);

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var val = new FormatValidator(payment).Validate();
            Assert.AreEqual(string.Empty, val);
        }

        [Test]
        public void FormatValidator_PaymentMethod_Fails()
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            payment.PaymentMethod = PaymentMethod.Draft;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var val = new FormatValidator(payment).Validate();
            Assert.AreEqual("1115:paymentMethod", val);
        }

        [Test]
        public void FormatValidator_PaymentMethod_Success()
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            payment.PaymentMethod = PaymentMethod.ACH;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var val = new FormatValidator(payment).Validate();
            Assert.AreEqual(string.Empty, val);
        }

        [TestCase("euro")]
        [TestCase("CA")]
        [TestCase("$")]
        [TestCase("pesos")]
        public void FormatValidator_SettlementCurrency_Fails(string currencyCode)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency("CAD"), 100);
            payment.SettlementAmountMoney = new Money(new Currency(currencyCode), 0);

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var val = new FormatValidator(payment).Validate();
            Assert.AreEqual("1005:settlementCurrency", val);
        }

        
        [TestCase("CAD")]
        [TestCase("USD")]
        public void FormatValidator_SettlementCurrency_Success(string currencyCode)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency(currencyCode), 100);
            payment.SettlementAmountMoney = new Money(new Currency(currencyCode), 0);

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var val = new FormatValidator(payment).Validate();
            Assert.AreEqual(string.Empty, val);
        }
        private Payment CreatePayment(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            return new Payment(externalPaymentId, "444")
            {
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerReference = "123",
                PaymentMethod = PaymentMethod.Wire,
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                AmountMoney = new Money(new Currency("USD"), 100)
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Address = CreateAddress(),
//                LastUpdatedOn = DateTime.UtcNow.ToString(),
                Type = "BUSINESS",
                Version = 1
            };
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                ExternalAccountType = "checking",
                BankAddress = CreateAddress(),
                BranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                VersionedOn = DateTime.UtcNow.ToString(),
                Version = 1
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrProvince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}

