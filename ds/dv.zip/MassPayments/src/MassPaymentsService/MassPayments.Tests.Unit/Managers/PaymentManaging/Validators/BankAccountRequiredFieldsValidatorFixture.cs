﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Managers.PaymentManaging.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging.Validators
{
    [TestFixture]
    public class BankAccountRequiredFieldsValidatorFixture
    {
        [Test]
        public void BankAccountRequiredFieldsValidator_Success()
        {
            var result = new BankAccountRequiredFieldsValidator(CreateBankAccount("1")).Validate();
            Assert.AreEqual(string.Empty, result);
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_BankAccount_IsNotProvided()
        {
            var result = new BankAccountRequiredFieldsValidator(CreateBankAccount("")).Validate();
            Assert.AreNotEqual(result, string.Empty);
        }
        
        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_Id_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.ExternalId = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.Id", result);
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_VersionedOn_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.VersionedOn = null;
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.versionedOn", result);
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_AccountNo_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.AccountNumber = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.AccountNumber", result);
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_BankName_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.BankName = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.BankName", result);
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_BankOrBranchCode_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.BranchCode = "";
            bankAccount.BankCode = "";
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1004:bankAccount.BankCode", result);
        }

        [Test]
        public void BankAccountRequiredFieldsValidator_Fails_When_Address_IsNotProvided()
        {
            var bankAccount = CreateBankAccount("2");
            bankAccount.BankAddress = null;
            var result = new BankAccountRequiredFieldsValidator(bankAccount).Validate();
            Assert.AreEqual("1003:bankAccount.BankAddress", result);
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                ExternalId = id,
                AccountNumber = "acct no",
                ExternalAccountType = "checking",
                BankAddress = CreateAddress(),
                BranchCode = "br code",
                BankCode = "bnk code",
                BankAccountOwnerName = "bank account name",
                BankName = "bnk name",
                BranchName = "br name",
                VersionedOn = DateTime.UtcNow.ToString(),
                Version = 1
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrProvince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
