﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Managers.PaymentManaging.Validators;
using MassPayments.Infrastructure.Caches;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging.Validators
{
    [TestFixture]
    public class PaymentRequiredFieldsValidatorFixture
    {
        [SetUp]
        public void SetUp()
        {
            PaymentValidationCache.Instance.Initialize();
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Success()
        {
            var req = CreatePayment("1", 0, 1, DateTime.UtcNow.ToString());
            req.PaymentMethod = null;
            var val = new PaymentRequiredFieldsValidator(req).Validate();
            Assert.Greater(val, string.Empty);
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Fails_When_PaymentRequestIsNotProvided()
        {
            var val = new PaymentRequiredFieldsValidator(null).Validate();
            Assert.AreEqual("1003:payment", val);
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Fails_When_PaymentMethod_IsNotProvided()
        {
            var payment = CreatePayment("1", 0, 1, DateTime.UtcNow.ToString());
            payment.PaymentMethod = null;
            var val = new PaymentRequiredFieldsValidator(payment).Validate();
            Assert.AreEqual("1003:paymentMethod", val);
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Fails_When_PaymentId_IsNotProvided()
        {
            var payment = CreatePayment("", 0, 1, DateTime.UtcNow.ToString());
            var val = new PaymentRequiredFieldsValidator(payment).Validate();
            Assert.AreEqual("1003:paymentid", val);
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Fails_When_Currency_IsNotProvided()
        {
            var payment = CreatePayment("1", 0, 1, DateTime.UtcNow.ToString());
            payment.AmountMoney = null;
            
            var val = new PaymentRequiredFieldsValidator(payment).Validate();
            Assert.AreEqual("1003:currency", val);
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Fails_When_Amount_IsZero_Or_NotProvided()
        {
            var payment = CreatePayment("1", 0, 1, DateTime.UtcNow.ToString());
            payment.AmountMoney = new Money(new Currency("USD"), 0);
            var val = new PaymentRequiredFieldsValidator(payment).Validate();
            Assert.AreEqual("1003:amount", val);
        }

        [Test]
        public void PaymentRequiredFieldsValidator_Fails_When_Beneficiary_IsNotProvided()
        {
            var payment = CreatePayment("1", 0, 1, DateTime.UtcNow.ToString());
            payment.Beneficiary = null;
            var val = new PaymentRequiredFieldsValidator(payment).Validate();
            Assert.AreEqual("1003:beneficiary", val); 
        }

        private Payment CreatePayment(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            return new Payment(externalPaymentId, null)
            {
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerReference = "123",
                PaymentMethod = PaymentMethod.Wire,
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                AmountMoney = new Money(new Currency("USD"), 100)
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Address = CreateAddress(),
//                LastUpdatedOn = DateTime.UtcNow.ToString(),
                Type = "BUSINESS",
                Version = 1
            };
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                ExternalAccountType = "checking",
                BankAddress = CreateAddress(),
                BranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                VersionedOn = DateTime.UtcNow.ToString(),
                Version = 1
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrProvince = "WA",
                ZipOrPostalCode = "90210"
            };
        }
    }
}
