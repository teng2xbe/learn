﻿using System;
using MassPayments.Domain.Entities;
using MassPayments.Managers.PaymentManaging.Validators;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging.Validators
{
    [TestFixture]
    public class BeneficiaryRequiredFieldsValidatorFixture
    {
        [Test]
        public void BeneficiaryRequiredFieldsValidator_Success()
        {
            var result = new BeneficiaryRequiredFieldsValidator(CreateBeneficiary("1")).Validate();
            Assert.AreEqual(string.Empty, result);
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Beneficiary_IsNotProvided()
        {
            var result = new BeneficiaryRequiredFieldsValidator(CreateBeneficiary(null)).Validate();
            Assert.AreNotEqual(0, string.Empty);
        }
        
        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Id_IsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.ExternalId = "";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.Id", result);
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_VersionedOn_IsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.VersionedOn = null;
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.VersionedOn", result);
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Type_IsNotIndividualOrBusiness()
        {
            var bene = CreateBeneficiary("2");
            bene.Identification.EntityType = "b/i";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.Type", result);
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Type_IsIndividual_ButNameIsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.Identification.EntityType = "individual";
            bene.Identification.LastName = "";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1004:beneficiary.LastName", result);
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Type_IsBusiness_ButBusinessNameIsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.Identification.EntityType = "business";
            bene.Identification.BusinessName = "";
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1004:beneficiary.BusinessName", result);
        }

        [Test]
        public void BeneficiaryRequiredFieldsValidator_Fails_When_Address_IsNotProvided()
        {
            var bene = CreateBeneficiary("2");
            bene.Address = null;
            var result = new BeneficiaryRequiredFieldsValidator(bene).Validate();
            Assert.AreEqual("1003:beneficiary.Address", result);
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                ExternalId = id,
                Address = CreateAddress(),
                Identification = CreateIdentification(),
//                LastUpdatedOn = DateTime.UtcNow.ToString(),
                Type = "BUSINESS",
                Version = 1,
                VersionedOn = "123"
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrProvince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

        private Identification CreateIdentification()
        {
            return new Identification()
            {
                FirstName = "test",
                LastName = "testlast",
                EntityType = "individual"
            };
        }
    }
}
