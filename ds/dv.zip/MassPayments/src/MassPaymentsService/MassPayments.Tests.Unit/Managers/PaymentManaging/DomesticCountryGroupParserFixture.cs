﻿using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects.Payments;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Managers.PaymentManaging;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging
{
    [TestFixture]
    public class DomesticCountryGroupParserFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());
            CurrencyPaymentMethodCache.Instance.Initialize();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
        }

        [Test]
        public void GetDomesticCountryGroups_Works()
        {
            var groups = new DomesticCountryGroupParser().ParseFromString("USD:PR,GU,MP,VI,US;");
            Assert.AreEqual(1, groups.Count);
            Assert.AreEqual(5, groups[0].CountryCodes.Count);
            Assert.AreEqual("PR", groups[0].CountryCodes[0]);
            Assert.AreEqual("GU", groups[0].CountryCodes[1]);
            Assert.AreEqual("MP", groups[0].CountryCodes[2]);
            Assert.AreEqual("VI", groups[0].CountryCodes[3]);
            Assert.AreEqual("US", groups[0].CountryCodes[4]);

            groups = new DomesticCountryGroupParser().ParseFromString("USD:PR,GU,MP,VI,US");
            Assert.AreEqual(1, groups.Count);
            Assert.AreEqual(5, groups[0].CountryCodes.Count);
            Assert.AreEqual("PR", groups[0].CountryCodes[0]);
            Assert.AreEqual("GU", groups[0].CountryCodes[1]);
            Assert.AreEqual("MP", groups[0].CountryCodes[2]);
            Assert.AreEqual("VI", groups[0].CountryCodes[3]);
            Assert.AreEqual("US", groups[0].CountryCodes[4]);

            groups = new DomesticCountryGroupParser().ParseFromString("USD:  PR ,  GU ,   MP   ,VI , US;");
            Assert.AreEqual(1, groups.Count);
            Assert.AreEqual(5, groups[0].CountryCodes.Count);
            Assert.AreEqual("PR", groups[0].CountryCodes[0]);
            Assert.AreEqual("GU", groups[0].CountryCodes[1]);
            Assert.AreEqual("MP", groups[0].CountryCodes[2]);
            Assert.AreEqual("VI", groups[0].CountryCodes[3]);
            Assert.AreEqual("US", groups[0].CountryCodes[4]);
        }

        [Test]
        public void IncorrectlyFormattedSetting_ReturnsEmptyDomesticCountryGroups()
        {
            var groups = new DomesticCountryGroupParser().ParseFromString("PR,GU,MP,VI,US;");
            Assert.AreEqual(0, groups.Count);

            groups = new DomesticCountryGroupParser().ParseFromString("");
            Assert.AreEqual(0, groups.Count);
        }
    }
}
