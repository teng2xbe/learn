﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
//using MassPayments.Domain.Entities.PaymentRequest;
//using MassPayments.Domain.Entities.PaymentRequest.Validators;
using MassPayments.Domain.Enums;
using MassPayments.Managers.PaymentManaging.Validators;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.Enums;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.PaymentManaging.Validators
{
    [TestFixture]
    public class RemittanceTypeValidatorFixture
    {
        [SetUp]
        public void Setup()
        {
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyPaymentMethodCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyPaymentMethodCacheMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            CurrencyCacheMapper.Instance = null;
            CurrencyPaymentMethodCacheMapper.Instance = null;
            CustomerMapper.Instance = null;
        }

        [Test]
        public void Validate_Fails_ForNonUsdAchPaymentWithRemittanceTypeSpecified()
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency("CAD"), 100);
            payment.RemittanceType = RemittanceType.CTX;

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(payment).Validate();
            Assert.IsFalse(string.IsNullOrEmpty(result));
            Assert.AreEqual(((int)ErrorCode.RemittanceTypeMismatch) + ":remittanceType", result);
        }

        [TestCase("US", RemittanceType.Undefined, false, null)]
        [TestCase("US", RemittanceType.CTX, true, "1118")]
        [TestCase("US", RemittanceType.CCD, true, "1118")]
        [TestCase("MX", RemittanceType.PPD, true, "1118")]
        [TestCase("US", RemittanceType.IAT, true, "1118")]
        [TestCase("US", RemittanceType.PPD, false, null)]
        [TestCase("MX", RemittanceType.IAT, false, null)]
        [TestCase("", RemittanceType.IAT, false, null)]
        [TestCase(null, RemittanceType.IAT, false, null)]
        public void Validate_WorksCorrectly_ForSupportedCombinationForIndividualBenefiary(string countryCode, RemittanceType remittanceType, bool expectedToFailValidation, string expectedErrorCode)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);
            
            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency("USD"), 100);
            payment.Beneficiary.Type = "individual";
            payment.RemittanceType = remittanceType;

            CustomerMapper.Instance.Stub(ccm => ccm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer {CountryCode = countryCode});
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(payment).Validate();
            Assert.AreEqual(expectedToFailValidation, !string.IsNullOrEmpty(result));
            if (expectedToFailValidation)
                Assert.AreEqual(expectedErrorCode + ":remittanceType", result);
        }

        [TestCase("US", RemittanceType.IAT, true)]
        [TestCase("MX", RemittanceType.IAT, false)]
        [TestCase(null, RemittanceType.IAT, false)]
        [TestCase("US", RemittanceType.PPD, true)]
        [TestCase("MX", RemittanceType.PPD, true)]
        [TestCase("US", RemittanceType.CCD, false)]
        [TestCase("CA", RemittanceType.CCD, true)]
        [TestCase("", RemittanceType.CCD, true)]
        public void Validate_WorksCorrectly_ForBusinessBenefiary(string countryCode, RemittanceType remittanceType, bool expectedToFailValidation)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);

            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency("USD"), 100);
            payment.Beneficiary.Type = "business";
            payment.RemittanceType = remittanceType;

            CustomerMapper.Instance.Stub(ccm => ccm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer { CountryCode = countryCode });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(payment).Validate();
            Assert.AreEqual(expectedToFailValidation, !string.IsNullOrEmpty(result));
            if (expectedToFailValidation)
                Assert.AreEqual("1118:remittanceType", result);
        }

        [TestCase("US", 1, false)]
        [TestCase("MX", 1, true)]
        [TestCase("MX", 0, true)]
        [TestCase("US", 0, true)]
        [TestCase("US", 2, false)]
        public void Validate_WorksCorrectly_WhenCTXForBusinessBenefiary(string countryCode, int numberOfRemittanceRecords, bool expectedToFailValidation)
        {
            var lastUpdatedOn = DateTime.UtcNow.ToString("u");
            var payment = CreatePayment("1", 0, 1, lastUpdatedOn);

            payment.PaymentMethod = PaymentMethod.ACH;
            payment.AmountMoney = new Money(new Currency("USD"), 100);
            payment.Beneficiary.Type = "business";
            payment.RemittanceType = RemittanceType.CTX;

            if (numberOfRemittanceRecords > 0)
            {
                payment.RemittanceData = new List<string>();
                for (var i = 0; i < numberOfRemittanceRecords; i++)
                    payment.RemittanceData.Add("ref" + i );
            }

            CustomerMapper.Instance.Stub(ccm => ccm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer { CountryCode = countryCode });
            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyPaymentMethodCacheMapper.Instance.Stub(cpmc => cpmc.GetCurrencyPaymentMethodsDictionary()).Return(SupportedPaymentMethodForCurrency.GetSupportedPaymentMethodForCurrency());

            var result = new RemittanceTypeValidator(payment).Validate();
            Assert.AreEqual(expectedToFailValidation, !string.IsNullOrEmpty(result));
            if (expectedToFailValidation)
                Assert.AreEqual("1118:remittanceType", result);
        }

        private Payment CreatePayment(string externalPaymentId, int itemIndex, int version, string lastUpdatedOn)
        {
            return new Payment(externalPaymentId, "444")
            {
                BankAccount = CreateBankAccount("1"),
                Beneficiary = CreateBeneficiary("1"),
                PartnerReference = "123",
                PaymentMethod = PaymentMethod.Wire,
                PurposeOfPayment = "prpse of pymt",
                InstructionForBank = "remitref1",
                InstructionCodeForBank = "remitref2",
                AmountMoney = new Money(new Currency("USD"), 100)
            };
        }

        private Beneficiary CreateBeneficiary(string id)
        {
            return new Beneficiary
            {
                Address = CreateAddress(),
                //                LastUpdatedOn = DateTime.UtcNow.ToString(),
                Type = "BUSINESS",
                Version = 1
            };
        }

        private BankAccount CreateBankAccount(string id)
        {
            return new BankAccount
            {
                AccountNumber = "acct no",
                ExternalAccountType = "checking",
                BankAddress = CreateAddress(),
                BranchCode = "br code",
                BankCode = "bnk code",
                BankName = "bnk name",
                BranchName = "br name",
                VersionedOn = DateTime.UtcNow.ToString(),
                Version = 1
            };
        }

        private Address CreateAddress()
        {
            return new Address
            {
                AddressLine1 = "line 1",
                AddressLine2 = "line 2",
                AddressLine3 = "",
                City = "cty",
                CountryCode = "US",
                StateOrProvince = "WA",
                ZipOrPostalCode = "90210"
            };
        }

    }
}
