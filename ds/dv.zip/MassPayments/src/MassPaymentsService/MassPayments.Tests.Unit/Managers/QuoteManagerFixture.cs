﻿using System;
using System.Collections.Generic;
using MassPayments.CCTMassPayments;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Infrastructure.Polling;
using MassPayments.Infrastructure.Polling.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.ServiceProviders.CCTTMassPayments;
using MassPayments.Tests.Unit.Helpers;
using NUnit.Framework;
using Rhino.Mocks;
using QuoteRequest = MassPayments.Domain.ValueObjects.Quoting.QuoteRequest;
using QuoteRequestItem = MassPayments.Domain.ValueObjects.Quoting.QuoteRequestItem;


namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class QuoteManagerFixture
    {
        private DateTime timeStamp;

        [SetUp]
        public void Setup()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            PaymentBatchMapper.Instance = MockRepository.GenerateMock<IPaymentBatchMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            PaymentPoller.Instance = MockRepository.GenerateMock<IPaymentPoller>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();

            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });

            CurrencyCacheMapper.Instance.Stub(ccm => ccm.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyCache.Instance.Reinitialize();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>(); 
            ServiceSettings.Instance.Stub(s => s.GetIntValue("QuoteExpiryDurationInSeconds", 60)).Return(60);
            ServiceSettings.Instance.Stub(s => s.GetIntValue("QuoteExpiryDurationInSecondsSameCurrencyPair", 43200)).Return(43200);
        }

        [TearDown]
        public void TearDown()
        {
            ServiceCallContextManager.Instance = null;

            PaymentMapper.Instance = null;
            CustomerMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            PaymentBatchMapper.Instance = null;
            EventLogger.Instance = null;
            PaymentPoller.Instance = null;
            QuoteMapper.Instance = null;
            PartnerMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            OrderMapper.Instance = null;
            ServiceSettings.Instance = null;
        }

        [Test]
        public void CreateQuoteDoesNotThrowExceptionIfBatchIdDoesNotExist()
        {
            CCTTServiceFactory.InjectedServiceInterface = MockRepository.GenerateMock<IMassPaymentsService>();

            CCTTServiceFactory.InjectedServiceInterface.Expect(x => x.Quote(Arg<CCTMassPayments.QuoteRequest>.Is.Anything)).Return(
                new QuoteResult { QuotedItems = new List<QuoteResultItem>() });

            QuoteMapper.Instance.Expect(qm => qm.GetQuote(1)).IgnoreArguments().Return(new Quote
                {
                    CustomerId = 4,
                    RequestTimeUtc = timeStamp.AddMilliseconds(-10), 
                    PartnerId = 2, 
                    Id = 123456,
                    ExpirationTimeUtc = timeStamp.AddMinutes(5), 
                    DurationInSec = 600, 
                    CustomerBatchExternalId = "VIKING4"
                });

            var quoteRequest = new QuoteRequest
            {
                ItemsToQuote = new List<QuoteRequestItem>
                {
                    new QuoteRequestItem {FixedTradeMoney = new Money(Currency.AUD, 1.0m), FixedSettlementMoney = new Money(Currency.USD, 0)}
                }
            };
            
            Assert.DoesNotThrow(() => new QuoteManager().CreateQuote(quoteRequest, new Customer()));

            QuoteMapper.Instance.VerifyAllExpectations();
            CCTTServiceFactory.InjectedServiceInterface.VerifyAllExpectations();
        }

        [Test]
        public void GetQuoteRequest_UpdatesQuoteToExpiredState_WhenCreatedQuoteHasExpired()
        {
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(1)).IgnoreArguments().Return(new Quote
                {
                    CustomerId = 4, 
                    RequestTimeUtc = DateTime.Now.AddMilliseconds(-10), 
                    PartnerId = 2, 
                    Id = 123456,
                    ExpirationTimeUtc = timeStamp.ToUniversalTime().AddMinutes(-5), 
                    DurationInSec = 600, 
                    CustomerBatchExternalId = "VIKING4",
                    Status = QuoteRequestStatus.Created
                });

            var dateTimeForExpirationUpdate = timeStamp.ToUniversalTime().AddMinutes(-5).AddSeconds(1);

            Quote loadedQuote = null;
            Assert.DoesNotThrow(() => loadedQuote = new QuoteManager().GetQuote(1));
            Assert.AreEqual(QuoteRequestStatus.Expired, loadedQuote.Status);
            Assert.AreEqual(dateTimeForExpirationUpdate, loadedQuote.LastUpdatedOnUtc);
        }

        [Test]
        public void GetQuoteRequest_ReturnsQuoteAsLoaded_WhenCreatedQuoteHasNotExpired()
        {
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(1)).IgnoreArguments().Return(new Quote
            {
                CustomerId = 4,
                RequestTimeUtc = DateTime.Now.AddMilliseconds(-10),
                PartnerId = 2,
                Id = 123456,
                ExpirationTimeUtc = timeStamp.ToUniversalTime().AddMinutes(1),
                DurationInSec = 600,
                CustomerBatchExternalId = "VIKING4",
                Status = QuoteRequestStatus.Created,
                LastUpdatedOnUtc = timeStamp.ToUniversalTime(),
            });

            Quote loadedQuote = null;
            Assert.DoesNotThrow(() => loadedQuote = new QuoteManager().GetQuote(1));
            Assert.AreEqual(QuoteRequestStatus.Created, loadedQuote.Status);
            Assert.AreEqual(timeStamp.ToUniversalTime(), loadedQuote.LastUpdatedOnUtc);
        }

        [Test]
        public void GetQuoteRequest_ReturnsQuoteAsLoaded_WhenQuoteIsNotInCreatedState()
        {
            var lastUpdatedTimestamp = timeStamp.AddMinutes(10).ToUniversalTime();
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(1)).IgnoreArguments().Return(new Quote
            {
                CustomerId = 4,
                RequestTimeUtc = DateTime.Now.AddMilliseconds(-10),
                PartnerId = 2,
                Id = 123456,
                ExpirationTimeUtc = timeStamp.ToUniversalTime().AddMinutes(-5),
                DurationInSec = 600,
                CustomerBatchExternalId = "VIKING4",
                Status = QuoteRequestStatus.Committed,
                LastUpdatedOnUtc = lastUpdatedTimestamp
            });

            Quote loadedQuote = null;
            Assert.DoesNotThrow(() => loadedQuote = new QuoteManager().GetQuote(1));
            Assert.AreEqual(QuoteRequestStatus.Committed, loadedQuote.Status);
            Assert.AreEqual(lastUpdatedTimestamp, loadedQuote.LastUpdatedOnUtc);
        }

        [Test]
        public void GetQuoteRequestAndValidateItCanBeBooked_ThrowsInvalidQuoteException_WhenQuoteIsNotFound()
        {
            var customer = new Customer { PartnerAssignedCustomerId = "123", Id = 2 };
            var quote = new Quote { Id = 1, CustomerId = 2, Status = QuoteRequestStatus.Failed };

            Assert.Throws<InvalidQuoteException>(() => new QuoteManager().ValidateThatQuoteCanBeBooked(quote, customer));
        }

        [Test]
        public void ValidateThatQuoteCanBeBooked_ThrowsInvalidQuoteException_WhenBatchQuoteIdIs0()
        {
            var quote = new Quote { Id = 0, Status = QuoteRequestStatus.Created};
            var customer = new Customer { PartnerAssignedCustomerId = "123", Id = 2 };

            Assert.Throws<InvalidQuoteException>(() => new QuoteManager().ValidateThatQuoteCanBeBooked(quote, customer));
        }

        [Test]
        public void ValidateThatQuoteCanBeBooked_ThrowsInvalidQuoteException_WhenQuoteStatusIsFailed()
        {
            var quote = new Quote { Id = 1, Status = QuoteRequestStatus.Failed };
            var customer = new Customer { PartnerAssignedCustomerId = "123", Id = 2 };

            Assert.Throws<InvalidQuoteException>(() => new QuoteManager().ValidateThatQuoteCanBeBooked(quote, customer));
        }

        [Test]
        public void ValidateThatQuoteCanBeBooked_ThrowsInvalidQuoteException_WhenQuoteIsNull()
        {
            var customer = new Customer { PartnerAssignedCustomerId = "123", Id = 2 };

            Assert.Throws<InvalidQuoteException>(() => new QuoteManager().ValidateThatQuoteCanBeBooked(null, customer));
        }

        [Test]
        public void GetQuoteRequestAndValidateItCanBeBooked_ThrowsAccessDenied_WhenQuoteDoesNotBelonsToCustomer()
        {
            var customerWithDifferentId = new Customer { PartnerAssignedCustomerId = "123", Id = 2 };
            var quote = new Quote { Id = 1 };

            Assert.Throws<AccessDeniedException>(() => new QuoteManager().ValidateThatQuoteCanBeBooked(quote, customerWithDifferentId));
        }

        [Test]
        public void GetQuoteRequestAndValidateItCanBeBooked_ThrowsAlreadyCommitted_WhenQuoteInCommittedState()
        {
            var customerWithValidId = new Customer { PartnerAssignedCustomerId = "123", Id = 4 };
            var quote = new Quote { Id = 1, CustomerId = 4, Status = QuoteRequestStatus.Committed};

            Assert.Throws<QuoteAlreadyCommittedException>(() => new QuoteManager().ValidateThatQuoteCanBeBooked(quote, customerWithValidId));
        }

        [Test]
        public void GetQuoteRequestAndValidateItCanBeBooked_ThrowsExpired_WhenQuoteHasExpired()
        {
            var customerWithValidId = new Customer { PartnerAssignedCustomerId = "123", Id = 4 };
            var quote = new Quote { Id = 1, CustomerId = 4, Status = QuoteRequestStatus.Expired };

            Assert.Throws<QuoteExpiredException>(() => new QuoteManager().ValidateThatQuoteCanBeBooked(quote, customerWithValidId));
        }
    }
}
