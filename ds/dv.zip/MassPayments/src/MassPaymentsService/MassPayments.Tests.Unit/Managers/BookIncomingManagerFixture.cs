﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Exceptions;
using MassPayments.Infrastructure.Bus;
using MassPayments.Infrastructure.Logger;
using MassPayments.Infrastructure.Logger.Interfaces;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Infrastructure.Polling;
using MassPayments.Infrastructure.Polling.Interfaces;
using MassPayments.Managers;
using MassPayments.Managers.Interfaces;
using MassPayments.Managers.Subscription.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using MassPayments.ResourceAccess.OrdersRA;
using MassPayments.ResourceAccess.OrdersRA.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using NServiceBus;
using NUnit.Framework;
using Rhino.Mocks;
using Order = MassPayments.Domain.Entities.Order;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class BookIncomingManagerFixture
    {
        private DateTime timeStamp;
        private IPublisher<Order> orderStatusUpdatedPublisher;

        [SetUp]
        public void Setup()
        {
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            PaymentBatchMapper.Instance = MockRepository.GenerateMock<IPaymentBatchMapper>();
            EventLogger.Instance = MockRepository.GenerateMock<IEventLogger>();
            PaymentPoller.Instance = MockRepository.GenerateMock<IPaymentPoller>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            OrdersProviderFactory.InjectedOrdersProviderInterface = MockRepository.GenerateMock<IOrdersProvider>();
            MassPayBus.Instance = MockRepository.GenerateMock<IBus>();
            orderStatusUpdatedPublisher = MockRepository.GenerateMock<IPublisher<Order>>();
            PublisherFactory.InjectPublisherForTesting(typeof(OrderStatusUpdatedPublisher), orderStatusUpdatedPublisher);

            timeStamp = DateTime.Now;
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(timeStamp, new Partner { Id = 2, Name = "Concur" });
        }

        [TearDown]
        public void TearDown()
        {
            PaymentMapper.Instance = null;
            CustomerMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            PaymentBatchMapper.Instance = null;
            EventLogger.Instance = null;
            PaymentPoller.Instance = null;
            QuoteMapper.Instance = null;
            PartnerMapper.Instance = null;
            OrderMapper.Instance = null;
            OrdersProviderFactory.InjectedOrdersProviderInterface = null;
            ServiceCallContextManager.Instance = null;
            orderStatusUpdatedPublisher = null;
            ServiceCallContextManager.Instance = null;
            MassPayBus.Instance = null;
            PublisherFactory.CleanAllInjectedPublishers();
        }

        [Test]
        public void GetOrders_MakesCorrectCall()
        {
            var bookIncomingManager = new BookIncomingManager();
            var orderIdList = new List<string> { "TR1234" };
            const int partnerId = 2;
            var orders = new List<Order> 
            { 
                new Order {
                    ConfirmationNumber = "TR1234", 
                    OrderStatus = OrderStatus.Committed, 
                    LastUpdatedOn = DateTime.Now, 
                    PartnerAssignedCustomerId = "TEST_UNIT",
                    SettlementCurrencyCode = "CAD"
                }
            };
            OrderMapper.Instance.Expect(pm => pm.GetOrdersByOrderNumbers(orderIdList)).IgnoreArguments().Return(orders);

            var result = bookIncomingManager.GetOrders(orderIdList, partnerId);

            Assert.AreEqual(orders[0].ConfirmationNumber, result[0].ConfirmationNumber);
            Assert.IsNotNull(result);
            OrderMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetOrders_ReturnsNotFound_WhenOrderBelongsToDifferentPartner()
        {
            var bookIncomingManager = new BookIncomingManager();
            var orderIdList = new List<string> { "TR1234" };
            const int partnerId = 2;
            var orders = new List<Order> 
            { 
                new Order {
                    ConfirmationNumber = "TR1234", 
                    OrderStatus = OrderStatus.Committed, 
                    LastUpdatedOn = DateTime.Now, 
                    PartnerAssignedCustomerId = "TEST_UNIT",
                    SettlementCurrencyCode = "CAD",
                    PartnerReference = "OrderRef1"
                }
            };
            OrderMapper.Instance.Expect(pm => pm.GetOrdersByOrderNumbers(orderIdList)).IgnoreArguments().Return(orders);

            var result = bookIncomingManager.GetOrders(orderIdList, partnerId);

            Assert.IsNotNull(result);
            Assert.AreEqual(orders[0].ConfirmationNumber, result[0].ConfirmationNumber);
            Assert.AreEqual(OrderStatus.NotFound, orders[0].OrderStatus);

            OrderMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetOrders_CallsGetOrdersFundedStatusAndKeepsStatus_ForCommittedButNotFundedOrders()
        {
            var bookIncomingManager = new BookIncomingManager();
            var orderIdList = new List<string> { "TR1234" };
            const string orderIds = "TR1234";
            const int partnerId = 2;
            var orders = new List<Order> 
            { 
                new Order {
                    PartnerId = partnerId,
                    ConfirmationNumber = "TR1234", 
                    OrderStatus = OrderStatus.Committed, 
                    CreatedOn = timeStamp.AddMinutes(-10), 
                    LastUpdatedOn = timeStamp.AddMinutes(-10), 
                    PartnerAssignedCustomerId = "TEST_UNIT",
                    SettlementCurrencyCode = "CAD",
                    PartnerReference = "OrderRef1"
                }
            };
            OrderMapper.Instance.Expect(om => om.GetOrdersByOrderNumbers(orderIdList)).IgnoreArguments().Return(orders);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(orders)).IgnoreArguments().Repeat.Never();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList))
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult()
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = orderIds,
                            IsFunded = false,
                            IsOrderFound = true
                        }
                    }
                });

            var result = bookIncomingManager.GetOrders(orderIdList, partnerId);

            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();

            Assert.IsNotNull(result);
            Assert.AreEqual("TR1234", result[0].ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Committed, result[0].OrderStatus);
            Assert.AreEqual(timeStamp.AddMinutes(-10), result[0].LastUpdatedOn);
            Assert.AreEqual(timeStamp.AddMinutes(-10), result[0].CreatedOn);

        }

        [Test]
        public void GetOrders_CallsGetOrdersFundedStatusAndKeepsStatus_ForAlreadyFundedOrders()
        {
            var bookIncomingManager = new BookIncomingManager();
            const string committedOrderId = "TR1235";
            const string fundedOrderId = "TR1236";
            var orderIdList = new List<string> { committedOrderId };
            var orderIds = new List<string> { fundedOrderId +"," + committedOrderId};
            const int partnerId = 2;
            var orders = new List<Order> 
            { 
                new Order {
                    PartnerId = partnerId,
                    ConfirmationNumber = fundedOrderId, 
                    OrderStatus = OrderStatus.Funded, 
                    CreatedOn = timeStamp.AddMinutes(-10), 
                    LastUpdatedOn = timeStamp.AddMinutes(-5), 
                    PartnerAssignedCustomerId = "TEST_UNIT",
                    SettlementCurrencyCode = "CAD",
                    PartnerReference = "OrderRef1"
                },
                new Order {
                    PartnerId = partnerId,
                    ConfirmationNumber = committedOrderId, 
                    OrderStatus = OrderStatus.Committed, 
                    CreatedOn = timeStamp.AddMinutes(-10), 
                    LastUpdatedOn = timeStamp.AddMinutes(-10), 
                    PartnerAssignedCustomerId = "TEST_UNIT",
                    SettlementCurrencyCode = "CAD",
                    PartnerReference = "OrderRef2"
                }
            };
            OrderMapper.Instance.Expect(om => om.GetOrdersByOrderNumbers(orderIdList)).IgnoreArguments().Return(orders);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(orders)).IgnoreArguments().Repeat.Never();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList))
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult()
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = committedOrderId,
                            IsFunded = false,
                            IsOrderFound = true
                        }
                    }
                });

            var result = bookIncomingManager.GetOrders(orderIds, partnerId);

            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();

            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Count);
            var expectedFundedOrder = result.Find(o => o.ConfirmationNumber == fundedOrderId);
            Assert.IsNotNull(expectedFundedOrder);
            Assert.AreEqual("TR1236", expectedFundedOrder.ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Funded, expectedFundedOrder.OrderStatus);
            Assert.AreEqual(timeStamp.AddMinutes(-5), expectedFundedOrder.LastUpdatedOn);
            Assert.AreEqual(timeStamp.AddMinutes(-10), expectedFundedOrder.CreatedOn);

            var expectedCommittedOrder = result.Find(o => o.ConfirmationNumber == committedOrderId);
            Assert.IsNotNull(expectedCommittedOrder);
            Assert.AreEqual("TR1235", expectedCommittedOrder.ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Committed, expectedCommittedOrder.OrderStatus);
            Assert.AreEqual(timeStamp.AddMinutes(-10), expectedCommittedOrder.LastUpdatedOn);
            Assert.AreEqual(timeStamp.AddMinutes(-10), expectedCommittedOrder.CreatedOn);
        }

        [Test]
        public void GetOrders_CallsGetOrdersFundedStatusAndUpdatesStatus_ForCommittedAndFundedOrders()
        {
            var bookIncomingManager = new BookIncomingManager();
            var orderIdList = new List<string> { "TR1234" };
            const string orderIds = "TR1234";
            const int partnerId = 2;
            var orders = new List<Order> 
            { 
                new Order {
                    PartnerId = partnerId,
                    ConfirmationNumber = "TR1234", 
                    OrderStatus = OrderStatus.Committed, 
                    CreatedOn = timeStamp.AddMinutes(-10), 
                    LastUpdatedOn = timeStamp.AddMinutes(-10), 
                    PartnerAssignedCustomerId = "TEST_UNIT",
                    SettlementCurrencyCode = "CAD",
                    PartnerReference = "OrderRef1"
                }
            };
            OrderMapper.Instance.Expect(om => om.GetOrdersByOrderNumbers(orderIdList)).IgnoreArguments().Return(orders);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(orders)).IgnoreArguments().Repeat.Once();


            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList))
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult()
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = orderIds,
                            IsFunded = true,
                            IsOrderFound = false,
                            FundedOnUtc = timeStamp.AddMinutes(-5)
                        }
                    }
                });

            var result = bookIncomingManager.GetOrders(orderIdList, partnerId);

            orderStatusUpdatedPublisher.AssertWasCalled(m => m.Publish(Arg<Order>.Is.Anything));
            orderStatusUpdatedPublisher.VerifyAllExpectations();
            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();

            Assert.IsNotNull(result);
            Assert.AreEqual("TR1234", result[0].ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Funded, result[0].OrderStatus);
            Assert.AreEqual(timeStamp.AddMinutes(-10), result[0].CreatedOn);


        }

        [Test]
        public void GetOrder_CallsGetOrdersFundedStatusAndKeepsStatus_ForCommittedButNotFundedOrder()
        {
            var bookIncomingManager = new BookIncomingManager();
            var orderIdList = new List<string> { "TR1234" };
            const string orderId = "TR1234";
            const int partnerId = 2;
            var committedOrder = new Order
            {
                PartnerId = partnerId,
                ConfirmationNumber = "TR1234",
                OrderStatus = OrderStatus.Committed,
                CreatedOn = timeStamp.AddMinutes(-10),
                LastUpdatedOn = timeStamp.AddMinutes(-10),
                PartnerAssignedCustomerId = "TEST_UNIT",
                SettlementCurrencyCode = "CAD",
                PartnerReference = "OrderRef1"
            };

            OrderMapper.Instance.Expect(om => om.GetOrder(orderId)).Return(committedOrder);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(new List<Order>())).IgnoreArguments().Repeat.Never();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList)) 
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult()
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = orderId,
                            IsFunded = false,
                            IsOrderFound = true
                        }
                    }
                });

            var result = bookIncomingManager.GetOrder(orderId, partnerId);

            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();

            Assert.IsNotNull(result);
            Assert.AreEqual("TR1234", result.ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Committed, result.OrderStatus);
            Assert.AreEqual(timeStamp.AddMinutes(-10), result.LastUpdatedOn);
            Assert.AreEqual(timeStamp.AddMinutes(-10), result.CreatedOn);
        }

        [Test]
        public void GetOrder_CallsGetOrdersFundedStatusAndUpdatesStatus_ForCommittedAndFundedOrder()
        {
            var bookIncomingManager = new BookIncomingManager();
            var orderIdList = new List<string> { "TR1234" };
            const string orderId = "TR1234";
            const int partnerId = 2;
            var committedOrder = new Order
            {
                PartnerId = partnerId,
                ConfirmationNumber = "TR1234",
                OrderStatus = OrderStatus.Committed,
                CreatedOn = timeStamp.AddMinutes(-10),
                LastUpdatedOn = timeStamp.AddMinutes(-10),
                PartnerAssignedCustomerId = "TEST_UNIT",
                SettlementCurrencyCode = "CAD",
                PartnerReference = "OrderRef1"
            };

            OrderMapper.Instance.Expect(om => om.GetOrder(orderId)).Return(committedOrder);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(new List<Order>())).IgnoreArguments().Repeat.Once();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList))
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult()
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = orderId,
                            IsFunded = true,
                            IsOrderFound = true,
                            FundedOnUtc = timeStamp
                        }
                    }
                });

            var result = bookIncomingManager.GetOrder(orderId, partnerId);

            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();

            Assert.IsNotNull(result);
            Assert.AreEqual("TR1234", result.ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Funded, result.OrderStatus);
            Assert.AreEqual(timeStamp.AddMinutes(-10), result.CreatedOn);
        }

        [Test]
        public void CheckAndUpdateOrdersFundedStatus_UpdatesForCommittedOrder()
        {
            var bookIncomingManager = MockRepository.GeneratePartialMock<BookIncomingManager>();
            var orderIdList = new List<string> { "TR1234" };
            const string orderId = "TR1234";
            const int partnerId = 2;
            var committedOrders = new List<Order> { new Order
            {
                PartnerId = partnerId,
                ConfirmationNumber = "TR1234",
                OrderStatus = OrderStatus.Committed,
                CreatedOn = timeStamp.AddMinutes(-10),
                LastUpdatedOn = timeStamp.AddMinutes(-10),
                PartnerAssignedCustomerId = "TEST_UNIT",
                SettlementCurrencyCode = "CAD",
                PartnerReference = "OrderRef1"
            }};

            OrderMapper.Instance.Expect(om => om.GetOrdersByStatus(OrderStatus.Committed)).Return(committedOrders);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(new List<Order>())).IgnoreArguments().Repeat.Once();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList))
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult()
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = orderId,
                            IsFunded = true,
                            IsOrderFound = true,
                            FundedOnUtc = timeStamp
                        }
                    }
                });
            
            bookIncomingManager.CheckAndUpdateOrdersFundedStatus();

            orderStatusUpdatedPublisher.AssertWasCalled(m => m.Publish(Arg<Order>.Is.Anything));
            orderStatusUpdatedPublisher.VerifyAllExpectations();
            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
            
            Assert.AreEqual("TR1234", committedOrders[0].ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Funded, committedOrders[0].OrderStatus);
        }


        [Test]
        public void CheckAndUpdateOrdersFundedStatus_UpdatesForFundedOrder()
        {
            var bookIncomingManager = MockRepository.GeneratePartialMock<BookIncomingManager>();
            var orderIdList = new List<string> { "TR1234" };
            const string orderId = "TR1234";
            const int partnerId = 2;
            var committedOrders = new List<Order> { new Order
            {
                PartnerId = partnerId,
                ConfirmationNumber = "TR1234",
                OrderStatus = OrderStatus.Committed,
                CreatedOn = timeStamp.AddMinutes(-10),
                LastUpdatedOn = timeStamp.AddMinutes(-10),
                PartnerAssignedCustomerId = "TEST_UNIT",
                SettlementCurrencyCode = "CAD",
                PartnerReference = "OrderRef1"
            }};

            OrderMapper.Instance.Expect(om => om.GetOrdersByStatus(OrderStatus.Committed)).Return(committedOrders);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(new List<Order>())).IgnoreArguments().Repeat.Once();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList))
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult()
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = orderId,
                            IsFunded = true,
                            IsOrderFound = true,
                            FundedOnUtc = timeStamp
                        }
                    }
                });

            bookIncomingManager.CheckAndUpdateOrdersFundedStatus();

            orderStatusUpdatedPublisher.AssertWasCalled(m => m.Publish(Arg<Order>.Is.Anything));
            orderStatusUpdatedPublisher.VerifyAllExpectations();
            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();

            Assert.AreEqual("TR1234", committedOrders[0].ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Funded, committedOrders[0].OrderStatus);
        }

        [Test]
        public void HandleSuccessfulBooking_WorksCorrectly()
        {
            var quoteManager = MockRepository.GenerateMock<IQuoteManager>();
            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var invoiceManager = MockRepository.GenerateMock<IInvoiceManager>();
            var bookIncomingManager = MockRepository.GeneratePartialMock<BookIncomingManager>(invoiceManager, subscriptionManager, quoteManager);
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999,
                PartnerId = 2
            };

            var quote = new Quote
            {
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        SettlementMoney = new Money(Currency.CAD, 100.00m),
                        TradeMoney = new Money(Currency.USD, 0m)
                    }
                }
            };

            var bookedOrders = new List<BookedIncomingOrder>
            {
                new BookedIncomingOrder
                {
                    OrderId = 111,
                    ConfirmationNumber = "a conf number1",
                    SettlementCurrencyCode = "CAD",
                    LineItems = new List<BookedIncomingOrderItem>
                    {
                        new BookedIncomingOrderItem
                        {
                            TradeAmount = 100.00m,
                            TradeCurrencyCode = "USD"
                        }
                    }
                }
            };

            var orders = bookIncomingManager.GetOrdersFromBookedIncomingOrders(bookedOrders, quote, customer, "");
            OrderMapper.Instance.Expect(om => om.UpdateOrders(orders)).IgnoreArguments().Repeat.Once();
            quoteManager.Expect(c => c.UpdateQuoteAfterOrderBooked(quote, orders)).IgnoreArguments().Repeat.Once();
            bookIncomingManager.Expect(c => c.ShouldGenerateInvoice(customer)).Return(false);

            bookIncomingManager.HandleSuccessfulBooking(customer, bookedOrders, quote, new Partner(), "");

            orderStatusUpdatedPublisher.AssertWasCalled(m => m.Publish(Arg<Order>.Is.Anything));
            orderStatusUpdatedPublisher.VerifyAllExpectations();
            quoteManager.VerifyAllExpectations();
            OrderMapper.Instance.VerifyAllExpectations();
            bookIncomingManager.VerifyAllExpectations();
        }

        [Test]
        public void CreateIncomingAggregateOrderBookResult_MapsFieldsCorrectly_FromOrders()
        {
            var now = DateTime.Now;
            var bookedOrders = new List<Order>
                {
                    new Order
                    {
                        OrderId = 111,
                        ConfirmationNumber = "a conf number                    ",
                        CreatedOn = now,
                        SettlementCurrencyCode = "CAD"
                    }
                };

             var customerBatch = new CustomerBatch
                {
                    Id = 5454,
                    ExternalId = "Batch001"
                };

            const string customerId = "Gorilla";
            var bookingManager = new BookIncomingManager();
            CustomerBatchMapper.Instance.Expect(om => om.GetCustomerBatch(customerBatch.Id)).Return(customerBatch);

            var result = bookingManager.CreateIncomingAggregateOrderBookResult(bookedOrders, customerId, OrderStatus.Committed, customerBatch.Id);

            Assert.AreEqual(1, result.BookedOrders.Count);
            Assert.AreEqual(now, result.BookedOrders[0].CreatedOn);
            Assert.AreEqual(bookedOrders[0].ConfirmationNumber.Trim(), result.BookedOrders[0].OrderConfirmationNo);
            Assert.AreEqual(OrderStatus.Committed.ToString(), result.BookedOrders[0].OrderStatus);
            Assert.AreEqual(customerId, result.BookedOrders[0].PartnerAssignedCustomerId);
            Assert.AreEqual(bookedOrders[0].SettlementCurrencyCode, result.BookedOrders[0].SettlementCurrencyCode);
        }

        [Test]
        public void GetOrdersFromBookedIncomingOrders_CorrectlyCreatesOrderList()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999,
                PartnerId = 2
            };

            var quotedItems = new List<QuotedItem>
            {
                new QuotedItem
                {
                    SettlementMoney = new Money(Currency.CAD, 0),
                    TradeMoney = new Money(Currency.USD, 0),
                    TransactionSystemQuoteId = 1234
                },
            };

            var quoteRequest = new Quote()
            {
                Id = 555,
                QuotedItems = quotedItems
            };
            var incomingRequest = new BookIncomingOrdersRequest
            {
                PartnerReference = "parternReferenceTest"
            };
            
            var bookedOrders = new List<BookedIncomingOrder>
            {
                new BookedIncomingOrder
                {
                    OrderId = 111,
                    ConfirmationNumber = "a conf number1",
                    SettlementCurrencyCode = "CAD",
                    LineItems = new List<BookedIncomingOrderItem>
                    {
                        new BookedIncomingOrderItem
                        {
                            TradeAmount = 100.00m,
                            TradeCurrencyCode = "USD"
                        }
                    }
                },
                new BookedIncomingOrder
                {
                    OrderId = 111,
                    ConfirmationNumber = "a conf number1",
                    OrderDate = new DateTime(1971, 2, 26),
                    SettlementCurrencyCode = "CAD",
                    LineItems = new List<BookedIncomingOrderItem>
                    {
                        new BookedIncomingOrderItem
                        {
                            TradeAmount = 100.00m,
                            TradeCurrencyCode = "USD"
                        }
                    }
                },
                new BookedIncomingOrder
                {
                    OrderId = 222,
                    ConfirmationNumber = "a conf number2",
                    OrderDate = new DateTime(1971, 2, 26),
                    SettlementCurrencyCode = "CAD",
                    LineItems = new List<BookedIncomingOrderItem>
                    {
                        new BookedIncomingOrderItem
                        {
                            TradeAmount = 100.00m,
                            TradeCurrencyCode = "USD"
                        }
                    }
                }
            };
            var bookingManager = new BookIncomingManager();
            var orders = bookingManager.GetOrdersFromBookedIncomingOrders(bookedOrders, quoteRequest, customer, incomingRequest.PartnerReference);

            Assert.AreEqual(2, orders.Count);
            Assert.Greater(orders[1].OrderItems.Count, 0);
            Assert.AreEqual(111, orders[0].OrderId);
            Assert.AreEqual("a conf number1", orders[0].ConfirmationNumber);
            Assert.AreEqual(1234, orders[0].TransactionSystemQuoteId);
            Assert.AreEqual(OrderStatus.Committed, orders[0].OrderStatus);
            Assert.AreEqual(999, orders[0].TransactionSystemCustomerId);
            Assert.AreEqual(2, orders[0].PartnerId);
            Assert.AreEqual(555, orders[0].QuoteRequestId);
            Assert.AreEqual("parternReferenceTest",orders[0].PartnerReference);
            Assert.AreEqual(222, orders[1].OrderId);
            Assert.AreEqual("a conf number2", orders[1].ConfirmationNumber);
            Assert.AreEqual(1234, orders[1].TransactionSystemQuoteId);
            Assert.AreEqual(OrderStatus.Committed, orders[1].OrderStatus);
            Assert.AreEqual(999, orders[1].TransactionSystemCustomerId);
            Assert.AreEqual(2, orders[1].PartnerId);
            Assert.AreEqual(555, orders[1].QuoteRequestId);
            Assert.AreEqual("CAD", orders[1].SettlementCurrencyCode);
            Assert.AreEqual("parternReferenceTest", orders[1].PartnerReference);
        }

        [Test]
        public void GetOrderItemsFromBookedIncomingOrder_CorrectlyCreatesOrderItemList()
        {
            var bookedOrder = new BookedIncomingOrder
            {
                OrderId = 111,
                ConfirmationNumber = "a conf number1",
                SettlementCurrencyCode = "CAD",
                LineItems = new List<BookedIncomingOrderItem>
                {
                    new BookedIncomingOrderItem
                    {
                        TradeAmount = 100.00m,
                        TradeCurrencyCode = "USD"
                    },
                    new BookedIncomingOrderItem
                    {
                        TradeAmount = 100.00m,
                        TradeCurrencyCode = "AUD"
                    },
                    new BookedIncomingOrderItem
                    {
                        TradeAmount = 100.00m,
                        TradeCurrencyCode = "GBP"
                    }
                }
            };

            var bookingManager = new BookIncomingManager();
            var items = bookingManager.GetOrderItemsFromBookedIncomingOrder(bookedOrder);

            Assert.AreEqual(3, items.Count);
            Assert.AreEqual(111, items[0].OrderId);
            Assert.AreEqual("CAD", items[0].SettlementCurrencyCode);
            Assert.AreEqual("USD", items[0].TargetCurrencyCode);
            Assert.AreEqual("AUD", items[1].TargetCurrencyCode);
            Assert.AreEqual("GBP", items[2].TargetCurrencyCode);
            Assert.AreEqual(100.00m, items[0].Amount);
            Assert.AreEqual(100.00m, items[1].Amount);
            Assert.AreEqual(100.00m, items[2].Amount);
        }

        [Test]
        public void GetOrder_ConvertsLastUpdatedOnToUTC()
        {
            var bookIncomingManager = new BookIncomingManager();
            var orderIdList = new List<string> { "TR1234" };
            const string orderId = "TR1234";
            const int partnerId = 2;
            var committedOrder = new Order
            {
                PartnerId = partnerId,
                ConfirmationNumber = "TR1234",
                OrderStatus = OrderStatus.Committed,
                CreatedOn = timeStamp,
            };

            OrderMapper.Instance.Expect(om => om.GetOrder(orderId)).Return(committedOrder);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(new List<Order>())).IgnoreArguments();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(orderIdList))
                .IgnoreArguments()
                .Return(new OrdersFundedStatusResult
                {
                    Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = orderId,
                            IsFunded = true,
                            IsOrderFound = true,
                            FundedOnUtc = new DateTime(2015, 11, 10, 1, 0, 0).ToUniversalTime()
                        }
                    }
                });

            var result = bookIncomingManager.GetOrder(orderId, partnerId);

            OrderMapper.Instance.VerifyAllExpectations();
            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();

            Assert.IsNotNull(result);

            Assert.AreEqual(new DateTime(2015, 11, 10, 1 + TimeZoneInfo.Local.BaseUtcOffset.Negate().Hours, 0, 0), result.LastUpdatedOn);
        }

        [Test]
        public void BookIncomingOrder_MakesCorrectCalls()
        {
            var quoteManager = MockRepository.GenerateMock<IQuoteManager>();
            var bookIncomingManager = MockRepository.GeneratePartialMock<BookIncomingManager>(null, null, quoteManager);

            var request = new BookIncomingOrdersRequest
            {
                OrdersToBook = new List<BookIncomingOrderRequest>()
            };
            var customer = CustomerHelper.Instance.CreateCustomer();
            var quote = new Quote
            {
                CustomerId = customer.Id,
                QuotedItems = new List<QuotedItem>()
            };

            quoteManager.Expect(q => q.GetQuoteByGuid(Arg<string>.Is.Anything)).Return(quote);
            quoteManager.Expect(q => q.ValidateThatQuoteCanBeBooked(null, null)).IgnoreArguments();
            OrdersProviderFactory.GetOrdersProvider().Expect(f => f.BookIncomingOrder(null, null, null)).IgnoreArguments();
            bookIncomingManager.Expect(b => b.HandleSuccessfulBooking(null, null, null,null)).IgnoreArguments();
            bookIncomingManager.Expect(b => b.UpdateCustomerBatch(null, null, null)).IgnoreArguments().Return(0);
            bookIncomingManager.Expect(b => b.CreateIncomingAggregateOrderBookResult(null, null, OrderStatus.Cancelled, 0)).IgnoreArguments().Return(new BookIncomingOrdersResult());

            Assert.DoesNotThrow(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
            quoteManager.VerifyAllExpectations();
            bookIncomingManager.VerifyAllExpectations();
        }

        [Test]
        public void BookIncomingOrder_ThrowsCorrectExceptionWhenQuoteIsNull()
        {
            var quoteManager = MockRepository.GenerateMock<IQuoteManager>();
            var bookIncomingManager = new BookIncomingManager(null, null, quoteManager);

            var request = new BookIncomingOrdersRequest();
            var customer = CustomerHelper.Instance.CreateCustomer();

            quoteManager.Expect(q => q.GetQuoteByGuid(Arg<string>.Is.Anything)).Return(null);
            quoteManager.Expect(q => q.ValidateThatQuoteCanBeBooked(null, customer)).Throw(new InvalidQuoteException());

            Assert.Throws<InvalidQuoteException>(() => bookIncomingManager.BookIncomingOrder(request, customer, new Partner()));
            quoteManager.VerifyAllExpectations();
        }

        [Test]
        public void GetOrder_CallsGetOrdersByPartnerId_ReturnsAllOrders()
        {
            var bookIncomingManager = new BookIncomingManager();
            const int partnerId = 2;
            var orders = new List<Order>
            {
                new Order {
                    PartnerId = partnerId,
                    ConfirmationNumber = "TR1234",
                    OrderStatus = OrderStatus.Committed,
                    CreatedOn = timeStamp.AddMinutes(-10),
                    LastUpdatedOn = timeStamp.AddMinutes(-10),
                    PartnerAssignedCustomerId = "TEST_UNIT",
                    SettlementCurrencyCode = "CAD",
                    PartnerReference = "OrderRef1"
                }
            };
            OrderMapper.Instance.Expect(om => om.GetOrdersByPartnerId(Arg<int>.Is.Anything)).IgnoreArguments().Return(orders);
            OrderMapper.Instance.Expect(om => om.UpdateOrderStatus(orders)).IgnoreArguments().Repeat.Once();

            OrdersProviderFactory.InjectedOrdersProviderInterface.Expect(op => op.GetOrdersFundedStatus(Arg<List<string>>.Is.Anything)).IgnoreArguments().Return(new OrdersFundedStatusResult
            {
                Orders = new List<OrderFundedStatusResult>
                    {
                        new OrderFundedStatusResult
                        {
                            OrderId = "TR1234",
                            IsFunded = true,
                            IsOrderFound = true,
                            FundedOnUtc = new DateTime(2015, 11, 10, 1, 0, 0)
                        }
                    }
            });

            var result = bookIncomingManager.GetOrders(null, partnerId);

            OrdersProviderFactory.InjectedOrdersProviderInterface.VerifyAllExpectations();
            OrderMapper.Instance.AssertWasCalled(o => o.GetOrdersByPartnerId(Arg<int>.Is.Anything));
            OrderMapper.Instance.AssertWasNotCalled(o => o.GetOrdersByOrderNumbers(Arg<List<string>>.Is.Anything));
            OrderMapper.Instance.VerifyAllExpectations();

            Assert.IsNotNull(result);
            Assert.AreEqual("TR1234", result[0].ConfirmationNumber);
            Assert.AreEqual(OrderStatus.Funded, result[0].OrderStatus);
            Assert.AreEqual(timeStamp.AddMinutes(-10), result[0].CreatedOn);
        }
    }
}

