﻿using System;
using System.IO;
using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Gateways.Invoice;
using MassPayments.Infrastructure.Encryption.Managers;
using MassPayments.Managers;
using MassPayments.Managers.Interfaces;
using MassPayments.Managers.InvoiceHandling;
using MassPayments.Managers.Subscription;
using MassPayments.Managers.Subscription.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;
using File = System.IO.File;

namespace MassPayments.Tests.Unit.Managers.InvoiceHandling
{
    public class OutgoingReportHandlingStrategyFixture
    {

        private string testFilePath;

        [SetUp]
        public void SetUp()
        {
            InvoiceGateway.Instance = MockRepository.GenerateMock<IInvoiceGateway>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            InvoiceTypeCacheMapper.Instance = MockRepository.GenerateMock<IInvoiceTypeCacheMapper>();
            OutOfHoldingMapper.Instance = MockRepository.GenerateMock<IOutOfHoldingMapper>();
        }

        [TearDown]
        public void TearDown()
        {
            InvoiceGateway.Instance = null;
            QuoteMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            CustomerMapper.Instance = null;
            PartnerMapper.Instance = null;
            OrderMapper.Instance = null;
            InvoiceTypeCacheMapper.Instance = null;
            OutOfHoldingMapper.Instance = null;

            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = null;
            if (testFilePath != null && File.Exists(testFilePath))
                File.Delete(testFilePath);

        }

        [Test]
        public void ProcessIncomingPdfFile_MakeCorrectCalls()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "MPRD_123_321_123_2010-10-10.pdf");
            if (!File.Exists(testFilePath))
                File.WriteAllText(testFilePath, "some data");

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), subscriptionManager, customerManager);
            subscriptionManager.Expect(sb => sb.InvoiceGenerated(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            var mockedStrategy = MockRepository.GeneratePartialMock<OutgoingReportHandlingStrategy>(customerManager, subscriptionManager, new EncryptionManager());
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.UpdateReceiptFileIdForReport(Arg<int>.Is.Anything, Arg<int>.Is.Anything));
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 1,PaymentModel = MassPayments.Domain.Enums.PaymentModel.Decoupled };
            PartnerMapper.Instance.Expect(um => um.GetPartnerByCode(Arg<string>.Is.Anything))
                .Return(partner);
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(Arg<string>.Is.Anything, Arg<Partner>.Is.Anything)).Repeat.Times(1).Return("blah");
            invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath);
            invoiceManager.VerifyAllExpectations();
            subscriptionManager.VerifyAllExpectations();
            OutOfHoldingMapper.Instance.VerifyAllExpectations();
            mockedStrategy.VerifyAllExpectations();

       }

        [Test]
        public void ProcessIncomingPdfFile_ThrowsWithBadFileName()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "MPRD_123_321_123.pdf");
            if (!File.Exists(testFilePath))
                File.WriteAllText(testFilePath, "some data");
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), new SubscriptionManager(), new CustomerManager());
            var mockedStrategy = MockRepository.GeneratePartialMock<OutgoingReportHandlingStrategy>(new CustomerManager(), new SubscriptionManager(), new EncryptionManager());
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.UpdateReceiptFileIdForReport(1, 123));
            Assert.Throws<InvalidInvoiceFileNameException>(() => invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath));
            invoiceManager.VerifyAllExpectations();
            mockedStrategy.VerifyAllExpectations();

        }

        [Test]
        public void ProcessIncomingPdfFile_ThrowsWithReportIdUnableToParse()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "MPRD_123_321_abc_2010-10-20.pdf");
            if (!File.Exists(testFilePath))
                File.WriteAllText(testFilePath, "some data");
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), new SubscriptionManager(), new CustomerManager());
            var mockedStrategy = MockRepository.GeneratePartialMock<OutgoingReportHandlingStrategy>(new CustomerManager(), new SubscriptionManager(), new EncryptionManager());
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;
            OutOfHoldingMapper.Instance.Expect(ohm => ohm.UpdateReceiptFileIdForReport(1, 123));
            Assert.Throws<InvalidInvoiceFileNameException>(() => invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath));
            invoiceManager.VerifyAllExpectations();
            mockedStrategy.VerifyAllExpectations();


        }
    }
}
