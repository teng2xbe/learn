﻿using MassPayments.Domain.Entities;
using MassPayments.Exceptions;
using MassPayments.Gateways.Invoice;
using MassPayments.Infrastructure.Encryption.Managers;
using MassPayments.Managers;
using MassPayments.Managers.Interfaces;
using MassPayments.Managers.InvoiceHandling;
using MassPayments.Managers.Subscription;
using MassPayments.Managers.Subscription.Interfaces;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Encryption.Managers.Interfaces;
using MassPayments.Publishers;
using MassPayments.Publishers.Interfaces;
using IOFile = System.IO.File;
using PublisherFactory = MassPayments.Managers.Subscription.PublisherFactory;

namespace MassPayments.Tests.Unit.Managers.InvoiceHandling
{
    [TestFixture]
    public class AggregateInvoiceHandlingStrategyFixture
    {

        private string testFilePath;
        private IPublisher<AggregateInvoiceFile> invoiceGeneratedPublisher;

        [SetUp]
        public void SetUp()
        {
            InvoiceGateway.Instance = MockRepository.GenerateMock<IInvoiceGateway>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            InvoiceTypeCacheMapper.Instance = MockRepository.GenerateMock<IInvoiceTypeCacheMapper>();
            FileMapper.Instance = MockRepository.GenerateMock<IFileMapper>();
            
            invoiceGeneratedPublisher = MockRepository.GenerateStub<IPublisher<AggregateInvoiceFile>>();
            MassPayments.Publishers.PublisherFactory.InjectPublisherForTesting(typeof(AggregateInvoiceGeneratedPublisher), invoiceGeneratedPublisher);

        }

        [TearDown]
        public void TearDown()
        {
            InvoiceGateway.Instance = null;
            QuoteMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            CustomerMapper.Instance = null;
            PartnerMapper.Instance = null;
            OrderMapper.Instance = null;
            InvoiceTypeCacheMapper.Instance = null;
            FileMapper.Instance = null;

            MassPayments.Publishers.PublisherFactory.CleanAllInjectedPublishers();

            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = null;
            if (testFilePath != null && IOFile.Exists(testFilePath))
                IOFile.Delete(testFilePath);

        }

        [Test]
        public void ProcessIncomingPdfFile_MakeCorrectCalls()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.pdf");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 1, PaymentModel = PaymentModel.Coupled };

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var encryptionManager = MockRepository.GenerateMock<IEncryptionManager>();
            subscriptionManager.Expect(sb => sb.InvoiceGenerated(Arg<int>.Is.Anything, Arg<string>.Is.Anything));

            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(customerManager, subscriptionManager, encryptionManager);
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1).Repeat.Once();
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder("invoice_123_8e432c64-96e3-42f1-a9a9-aa0698e268f7_321.pdf", partner)).Return("path").Repeat.Once();

            QuoteMapper.Instance.Expect(qm => qm.GetQuote(Arg<int>.Is.Anything)).Return(new Quote { CustomerBatchExternalId = "123", QuoteGuid = "8e432c64-96e3-42f1-a9a9-aa0698e268f7" });

            CustomerBatchMapper.Instance.Expect(qm => qm.GetCustomerBatchByQuoteId(123)).Return(new CustomerBatch { ExternalId = "123" });
            
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            
            OrderMapper.Instance.Expect(om => om.GetOrdersByQuoteRequest(123)).Return(new List<Order> { new Order {ConfirmationNumber = "TT123"} }).Repeat.Once();

            invoiceGeneratedPublisher.Expect(p => p.Publish(Arg<AggregateInvoiceFile>.Is.Anything)).IgnoreArguments().Repeat.Once();

            PartnerMapper.Instance.Expect(um => um.GetPartnerById(Arg<int>.Is.Anything))
                .Return(partner);

            mockedStrategy.ProcessInvoice(testFilePath);

            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            subscriptionManager.VerifyAllExpectations();
            invoiceGeneratedPublisher.VerifyAllExpectations();
            mockedStrategy.VerifyAllExpectations();
        }

        [Test]
        public void ProcessIncomingPdfFile_MakeCorrectCalls_ForTypeTwo()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.pdf");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 2, PaymentModel = PaymentModel.Coupled };

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var encryptionManager = MockRepository.GenerateMock<IEncryptionManager>();

            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(customerManager, subscriptionManager, encryptionManager);
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1).Repeat.Once();
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder("invoice_123_8e432c64-96e3-42f1-a9a9-aa0698e268f7_123.pdf", partner)).Return("path").Repeat.Once();

            invoiceGeneratedPublisher.Expect(p => p.Publish(Arg<AggregateInvoiceFile>.Is.Anything)).IgnoreArguments().Repeat.Once();

            subscriptionManager.Expect(sb => sb.InvoiceGenerated(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            customerManager.Expect(cm => cm.GetCustomerById(Arg<Partner>.Is.Anything, Arg<int>.Is.Anything))
                .Return(new Customer { PartnerAssignedCustomerId = "123" });
            
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(Arg<int>.Is.Anything)).Return(new Quote { CustomerBatchExternalId = "123", QuoteGuid = "8e432c64-96e3-42f1-a9a9-aa0698e268f7" });
            CustomerBatchMapper.Instance.Expect(qm => qm.GetCustomerBatchByQuoteId(123)).Return(new CustomerBatch { ExternalId = "123" });
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            OrderMapper.Instance.Expect(om => om.GetOrdersByQuoteRequest(123)).Return(new List<Order> { new Order { ConfirmationNumber = "TT123" } }).Repeat.Once();

            PartnerMapper.Instance.Expect(um => um.GetPartnerById(Arg<int>.Is.Anything))
                .Return(partner);

            mockedStrategy.ProcessInvoice(testFilePath);

            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            customerManager.VerifyAllExpectations();
            subscriptionManager.VerifyAllExpectations();
            invoiceGeneratedPublisher.VerifyAllExpectations();
            mockedStrategy.VerifyAllExpectations();

        }

        [Test]
        public void ProcessIncomingPdfFile_GeneratesProperFileName()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.pdf");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");

            var fileBytes = Encoding.UTF8.GetBytes("some data");

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), subscriptionManager, customerManager);
            subscriptionManager.Expect(sb => sb.InvoiceGenerated(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(customerManager, subscriptionManager, new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(123)).Return(new Quote { Id = 123, CustomerId = 2, CustomerBatchExternalId = "4455", PartnerId = 2 });
            CustomerBatchMapper.Instance.Expect(qm => qm.GetCustomerBatchByQuoteId(123)).Return(new CustomerBatch { ExternalId = "4455"});
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 1, PaymentModel = PaymentModel.Coupled};
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(2))
                .Return(partner);

            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(Arg<string>.Is.Anything, Arg<Partner>.Is.Anything)).Repeat.Times(1).Return("blah");
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;

            invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath);
            invoiceManager.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            subscriptionManager.VerifyAllExpectations();

        }

        [Test]
        public void ProcessIncomingPdfFile_GeneratesProperFileName_ForTypeTwo()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.pdf");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");

            var fileBytes = Encoding.UTF8.GetBytes("some data");

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), subscriptionManager, customerManager);
            subscriptionManager.Expect(sb => sb.InvoiceGenerated(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            customerManager.Expect(cm => cm.GetCustomerById(Arg<Partner>.Is.Anything,Arg<int>.Is.Anything))
                .Return(new Customer { PartnerAssignedCustomerId = "paci" });
            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(customerManager, subscriptionManager, new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);

            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(123)).Return(new Quote { Id = 123, QuoteGuid = "8e432c64-96e3-42f1-a9a9-aa0698e268f7", CustomerId = 2, CustomerBatchExternalId = "4455", PartnerId = 2 });
            CustomerBatchMapper.Instance.Expect(qm => qm.GetCustomerBatchByQuoteId(123)).Return(new CustomerBatch { ExternalId = "4455" });
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 2, PaymentModel = PaymentModel.Coupled};
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(2))
                .Return(partner);

            string expectedInvoiceFileName = "invoice_paci_8e432c64-96e3-42f1-a9a9-aa0698e268f7_4455.pdf";
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(expectedInvoiceFileName, partner)).Repeat.Times(1).Return("blah");
            invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath);
            invoiceManager.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            subscriptionManager.VerifyAllExpectations();
            customerManager.VerifyAllExpectations();
        }

        [Test]
        public void ProcessIncomingPdfFile_GeneratesProperFileName_WhenCustomerBatchIsNotSet()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.pdf");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");

            var fileBytes = Encoding.UTF8.GetBytes("some data");

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), subscriptionManager, customerManager);
            subscriptionManager.Expect(sb => sb.InvoiceGenerated(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(customerManager, subscriptionManager, new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);

            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(123)).Return(new Quote { Id = 321, QuoteGuid = "8e432c64-96e3-42f1-a9a9-aa0698e268f7", CustomerId = 2, PartnerId = 2 });
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 1, PaymentModel = PaymentModel.Decoupled};
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(2))
                .Return(partner);

            string expectedInvoiceFileName = "invoice_8e432c64-96e3-42f1-a9a9-aa0698e268f7_321.pdf";
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(expectedInvoiceFileName, partner)).Repeat.Times(1).Return("blah");
            invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath);
            invoiceManager.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            subscriptionManager.VerifyAllExpectations();

        }

        [Test]
        public void ProcessIncomingPdfFile_GeneratesProperFileName_WhenCustomerBatchIsNotSet_ForTypeTwo()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.pdf");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");

            var fileBytes = Encoding.UTF8.GetBytes("some data");

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), subscriptionManager, customerManager);
            subscriptionManager.Expect(sb => sb.InvoiceGenerated(Arg<int>.Is.Anything, Arg<string>.Is.Anything));
            customerManager.Expect(cm => cm.GetCustomerById(Arg<Partner>.Is.Anything, Arg<int>.Is.Anything))
                .Return(new Customer { PartnerAssignedCustomerId = "paci" });
            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(customerManager, subscriptionManager, new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;

            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(123)).Return(new Quote { Id = 321, QuoteGuid = "8e432c64-96e3-42f1-a9a9-aa0698e268f7", CustomerId = 2, PartnerId = 2 });
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 2, PaymentModel = PaymentModel.Decoupled };
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(2))
                .Return(partner);

            string expectedInvoiceFileName = "invoice_paci_8e432c64-96e3-42f1-a9a9-aa0698e268f7.pdf";
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(expectedInvoiceFileName, partner)).Repeat.Times(1).Return("blah");
            invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath);
            invoiceManager.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            subscriptionManager.VerifyAllExpectations();
            customerManager.VerifyAllExpectations();

        }

        [Test]
        public void ProcessIncomingPdfFile_Throws_WithInvalidIncomingPDFFileName()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "InvalidName.txt");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");

            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();
            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(new CustomerManager(), new SubscriptionManager(), new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);

            //mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(Arg<int>.Is.Anything)).Return(new Quote());
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(Arg<int>.Is.Anything))
                .Return(new Partner { Id = 2, Code = "MP2" });

            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(Arg<string>.Is.Anything, Arg<Partner>.Is.Anything)).Repeat.Times(1);
            Assert.Throws(typeof(InvalidInvoiceFileNameException), () => invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath));

        }

        [Test]
        public void ProcessIncomingPdfFile_Throws_WithInvalidNumberIncomingPDFFileName()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "MPID_NOTANUMBER_BLAH_DATE.PDF");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");

            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(new CustomerManager(), new SubscriptionManager(), new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;

            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(Arg<int>.Is.Anything)).Return(new Quote());
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(Arg<int>.Is.Anything))
                .Return(new Partner { Id = 2, Code = "MP2" });
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(Arg<string>.Is.Anything, Arg<Partner>.Is.Anything)).Repeat.Times(1);
            Assert.Throws(typeof(FormatException), () => invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath));

        }

        [Test]
        public void ProcessIncomingPdfFile_Throws_WithInvalidIncomingPDFFileNameExtension()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.random_extension");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");
            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(new CustomerManager(), new SubscriptionManager(), new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;

            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();
            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);
            QuoteMapper.Instance.Expect(qm => qm.GetQuote(Arg<int>.Is.Anything)).Return(new Quote());
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(Arg<int>.Is.Anything))
                .Return(new Partner { Id = 2, Code = "MP2" });
            mockedStrategy.Expect(im => im.EncryptAndSaveToOutputFolder(Arg<string>.Is.Anything, Arg<Partner>.Is.Anything)).Repeat.Times(1);
            Assert.Throws(typeof(InvalidInvoiceFileNameException), () => invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath));

        }

        [Test]
        public void ProcessIncomingPdfFile_ThrowsInvalidInvoiceTypeError()
        {
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Test_123_321.pdf");
            if (!IOFile.Exists(testFilePath))
                IOFile.WriteAllText(testFilePath, "some data");

            var subscriptionManager = MockRepository.GenerateMock<ISubscriptionManager>();
            var customerManager = MockRepository.GenerateMock<ICustomerManager>();

            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>(new EncryptionManager(), subscriptionManager, customerManager);
            var mockedStrategy = MockRepository.GeneratePartialMock<AggregateInvoiceHandlingStrategy>(customerManager, subscriptionManager, new EncryptionManager());
            InvoiceHandlingStrategyFactory.InjectedStrageyForTesting = mockedStrategy;

            mockedStrategy.Expect(im => im.SaveInvoiceFile(Arg<string>.Is.Anything)).Return(1);

            QuoteMapper.Instance.Expect(qm => qm.GetQuote(Arg<int>.Is.Anything)).Return(new Quote { CustomerBatchExternalId = "123" });
            OrderMapper.Instance.Expect(um => um.UpdateOrderInvoiceByQuoteRequestId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Repeat.Times(1);
            var partner = new Partner { Id = 2, Code = "MP2", InvoiceTypeId = 3 };
            PartnerMapper.Instance.Expect(um => um.GetPartnerById(Arg<int>.Is.Anything))
                .Return(partner);
            Assert.Throws<InvoiceTypeNotSupportedException>(() => invoiceManager.ProcessIncomingPdfInvoiceFile(testFilePath));
            invoiceManager.VerifyAllExpectations();
            QuoteMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();

        }
    }
}
