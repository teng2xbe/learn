﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.Enums;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Exceptions;
using MassPayments.Infrastructure;
using MassPayments.Infrastructure.Caches;
using MassPayments.Infrastructure.OperationContexts;
using MassPayments.Infrastructure.OperationContexts.Interfaces;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using MassPayments.Tests.Unit.Helpers;
using MassPaymentsCommon.WCFContracts.RESTContracts;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class CustomerBatchManagerFixture
    {
        [SetUp]
        public void Setup()
        {
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CustomerBatchCurrencyMapper.Instance = MockRepository.GenerateMock<ICustomerBatchCurrencyMapper>();
            ServiceCallContextManager.Instance = MockRepository.GenerateStub<IServiceCallContextManager>();
            ServiceCallContextManager.Instance.CurrentContext = new ServiceCallContext(DateTime.Now, new Partner { Id = 1, Name = "HyperWallet" });
            PaymentMapper.Instance = MockRepository.GenerateMock<IPaymentMapper>();
            CurrencyCacheMapper.Instance = MockRepository.GenerateMock<ICurrencyCacheMapper>();
            CurrencyCacheMapper.Instance.Stub(c => c.GetCurrencyDictionary()).Return(SupportedCurrency.GetSupportedCurrency());
            CurrencyCache.Instance.Reinitialize();

            ValidationRules.Instance = MockRepository.GenerateMock<IValidationRules>();
            ValidationRules.Instance.Expect(s => s.GetStringValue("ValidationRule.Format.ExternalID", "[a-zA-Z0-9-_]{1,38}")).Return("[a-zA-Z0-9-_]{1,38}");
        }

        [TearDown]
        public void TearDown()
        {
            CustomerMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            CustomerBatchCurrencyMapper.Instance = null;
            ServiceCallContextManager.Instance = null;
            PaymentMapper.Instance = null;
            CurrencyCacheMapper.Instance = null;
            CurrencyCache.Instance = null;
            ValidationRules.Instance = null;
        }

        [Test, Explicit("file base related, could be removed.")]
        public void SaveNewCustomerBatch_MakeCorrectCalls()
        {
            var customerBatch = new CustomerBatch
            {
                ExternalId = "test",
                ExternalCustomerId = "test"
            };
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(customerBatch));
            CustomerBatchMapper.Instance.Expect(um => um.SaveBatchFile(Arg<BatchFile>.Is.Anything));
            CustomerBatchMapper.Instance.Expect(um => um.IsNewBatchFile(Arg<BatchFile>.Is.Anything)).Return(true);
            Assert.DoesNotThrow(() => new CustomerBatchManager().ProcessCustomerBatch(customerBatch, 1234, false));

            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void UpdateCustomerBatch_ApiBatchTypeWithBatchId_MakeCorrectCalls()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };
            
            var orderRequest = new BookIncomingOrdersRequest
            {
                ShouldEnsureCustomerBatch = false,
                BatchId = "Batch001",
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(new Currency("USD"), 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };

            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            Assert.DoesNotThrow(() => new BookIncomingManager().UpdateCustomerBatch(orderRequest, quoteRequest, customer));

            CustomerBatchMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void UpdateCustomerBatch_ApiBatchTypeNoBatchId_MakeCorrectCalls()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var orderRequest = new BookIncomingOrdersRequest
            {
                ShouldEnsureCustomerBatch = false,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(new Currency("USD"), 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };

            Assert.DoesNotThrow(() => new BookIncomingManager().UpdateCustomerBatch(orderRequest, quoteRequest, customer));

            CustomerBatchMapper.Instance.AssertWasNotCalled(u => u.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));
        }

        [Test]
        public void UpdateCustomerBatch_FileBatchType_ThrowsException()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var orderRequest = new BookIncomingOrdersRequest
            {
                ShouldEnsureCustomerBatch = true,
                OrdersToBook = new List<BookIncomingOrderRequest>
                {
                    new BookIncomingOrderRequest
                    {
                        SettlementCurrency = Currency.USD,
                        ItemsToBook = new List<BookIncomingOrderRequestItem>
                        {
                            new BookIncomingOrderRequestItem
                            {
                                AmountMoney = new Money(new Currency("USD"), 101.01m),
                                IsAmountInSettlementCurrency = true,
                                TradeCurrency = Currency.CAD
                            }
                        }
                    }
                }
            };

            var quoteRequest = new Quote
            {
                CustomerId = customer.Id,
                Id = 555,
                CustomerBatchExternalId = "ExternalId001",
                QuotedItems = new List<QuotedItem>
                {
                    new QuotedItem
                    {
                        TransactionSystemQuoteId = 1234,
                        SettlementMoney = new Money(Currency.USD, 0),
                        TradeMoney = new Money(Currency.CAD, 0)
                    }
                }
            };

            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything,  Arg<string>.Is.Anything)).Return(new CustomerBatch());
            CustomerBatchMapper.Instance.Expect(um => um.UpdateCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            Assert.DoesNotThrow(() => new BookIncomingManager().UpdateCustomerBatch(orderRequest, quoteRequest, customer));

            CustomerBatchMapper.Instance.VerifyAllExpectations();
        }

        [Test, Explicit("file base related, could be removed.")]
        public void SaveNewCustomerBatch_MakeCorrectCalls_WithWarning()
        {
            var customerBatch = new CustomerBatch
            {
                ExternalId = "test",
                ExternalCustomerId = "test"
            };

            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(customerBatch));
            CustomerBatchMapper.Instance.Expect(um => um.SaveBatchFile(Arg<BatchFile>.Is.Anything));
            CustomerBatchMapper.Instance.Expect(um => um.IsNewBatchFile(Arg<BatchFile>.Is.Anything)).Return(true);
            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            customerBatchManager.Expect(cum => cum.LogWarning(Arg<string>.Is.Anything));

            Assert.DoesNotThrow(() => customerBatchManager.ProcessCustomerBatch(customerBatch, 1234, true));

            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            customerBatchManager.VerifyAllExpectations();
        }

        [Test,Explicit("file base related, could be removed.")]
        public void LoadCustomerBatchForPayments_Works()
        {
            var customerBatch = new CustomerBatch
            {
                ExternalId = "test",
                ExternalCustomerId = "test"
            };

            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(null);
            CustomerBatchMapper.Instance.Expect(um => um.InsertCustomerBatch(customerBatch));
            CustomerBatchMapper.Instance.Expect(um => um.SaveBatchFile(Arg<BatchFile>.Is.Anything));
            CustomerBatchMapper.Instance.Expect(um => um.IsNewBatchFile(Arg<BatchFile>.Is.Anything)).Return(true);
            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            customerBatchManager.Expect(cum => cum.LogWarning(Arg<string>.Is.Anything));

            Assert.DoesNotThrow(() => customerBatchManager.ProcessCustomerBatch(customerBatch, 1234, true));

            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            customerBatchManager.VerifyAllExpectations();
        }

        [Test,Explicit("file base related, could be removed.")]
        public void SaveCustomerBatch_Updates_IfCustomerBatchIsCreatedByBooking()
        {
            var customerBatch = new CustomerBatch
            {
                ExternalId = "test",
                ExternalCustomerId = "test"
            };
            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new CustomerBatch { Id = 123 });
            CustomerBatchMapper.Instance.AssertWasNotCalled(um => um.InsertCustomerBatch(customerBatch));
            CustomerBatchMapper.Instance.Expect(um => um.SaveBatchFile(Arg<BatchFile>.Is.Anything));
            CustomerBatchMapper.Instance.Expect(um => um.UpdateCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            CustomerBatchMapper.Instance.Expect(um => um.IsNewBatchFile(Arg<BatchFile>.Is.Anything)).Return(true);
            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            customerBatchManager.AssertWasNotCalled(cum => cum.LogWarning(Arg<string>.Is.Anything));
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<CustomerBatch>.Is.Anything))
                .Return(new List<Payment>());
            
            Assert.DoesNotThrow(() => customerBatchManager.ProcessCustomerBatch(customerBatch, 1234, true));

            CustomerMapper.Instance.VerifyAllExpectations();
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            customerBatchManager.VerifyAllExpectations();
        }

        [Test]
        public void CreateBatch_InsertsNewBatchWhenBatchDoesNotExist()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new BatchRequestData
                {
                    Reference = "Insert Batch"
                };

            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Throw(new ArgumentException());
            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            
            Assert.DoesNotThrow(() => customerBatchManager.CreateBatch(customer, "1234" , requestData ));

            CustomerBatchMapper.Instance.AssertWasNotCalled(u => u.UpdateCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            customerBatchManager.VerifyAllExpectations();
        }
        [Test]
        public void CreateBatch_UpdateBatchWhenBatchExist()
        {
            var customer = new Customer
            {
                Id = 777,
                PartnerAssignedCustomerId = "888",
                TransactionSystemCustomerId = 999
            };

            var requestData = new BatchRequestData
            {
                Reference = "Insert Batch"
            };

            CustomerBatchMapper.Instance.Expect(um => um.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(new CustomerBatch{ExternalCustomerId = "888"});
            
            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            PaymentMapper.Instance.Expect(pm => pm.GetPayments(Arg<CustomerBatch>.Is.Anything, Arg<int>.Is.Anything))
          .Return(new List<Payment> { new Payment(1) });
            Assert.DoesNotThrow(() => customerBatchManager.CreateBatch(customer, "1234", requestData));
            CustomerBatchMapper.Instance.AssertWasNotCalled(u => u.InsertCustomerBatch(Arg<CustomerBatch>.Is.Anything));
            CustomerBatchMapper.Instance.VerifyAllExpectations();
            customerBatchManager.VerifyAllExpectations();
        }

        [Test]
        public void PopulateBatchAmounts_MakeCorrectCalls()
        {
            var batch = new CustomerBatch
            {
                Id = 1,
                BatchStatus = CustomerBatchStatus.Created
            };
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatchAmounts(batch)).Return(new List<PaymentAmount>());
            new CustomerBatchManager().PopulateBatchAmounts(batch);
            CustomerBatchMapper.Instance.VerifyAllExpectations();

            batch.BatchStatus = CustomerBatchStatus.Committed;
            CustomerBatchCurrencyMapper.Instance.Expect(c => c.GetCustomerBatchCurrencyAggregatesByBatchId(batch.Id));
            new CustomerBatchManager().PopulateBatchAmounts(batch);
            CustomerBatchCurrencyMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GetCustomerBatch_ById_MakeCorrectCalls()
        {
            CustomerBatch loadedBatch = null;
            var batch = new CustomerBatch
            {
                Id = 1,
                BatchStatus = CustomerBatchStatus.Created,
                BatchType = BatchType.ApiBatch
            };
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatch(batch.Id)).Return(batch);
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatchAmounts(batch)).Return(new List<PaymentAmount>());

            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            Assert.DoesNotThrow(() => loadedBatch = customerBatchManager.GetCustomerBatch(batch.Id));

            CustomerBatchMapper.Instance.VerifyAllExpectations();
            Assert.IsNotNull(loadedBatch);
        }

        [Test]
        public void GetCustomerBatch_ByCustomerIdandExternalBatchId_BatchExists_MakeCorrectCalls()
        {
            CustomerBatch loadedBatch = null;

            var batch = new CustomerBatch
            {
                Id = 1,
                BatchStatus = CustomerBatchStatus.Created,
                BatchType = BatchType.ApiBatch,
                CustomerId = 1,
                ExternalId = "batch01"
            };

            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything)).Return(batch);
            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatchAmounts(batch)).Return(new List<PaymentAmount>());

            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            Assert.DoesNotThrow(() => loadedBatch = customerBatchManager.GetCustomerBatch(batch.CustomerId, batch.ExternalId));

            CustomerBatchMapper.Instance.VerifyAllExpectations();
            Assert.IsNotNull(loadedBatch);
        }

        [Test]
        public void GetCustomerBatch_ByCustomerIdandExternalBatchId_BatchNotExists_MakeCorrectCalls()
        {
            var batch = new CustomerBatch
            {
                Id = 1,
                BatchStatus = CustomerBatchStatus.Created,
                BatchType = BatchType.ApiBatch,
                CustomerId = 1,
                ExternalId = "batch01"
            };

            CustomerBatchMapper.Instance.Expect(c => c.GetCustomerBatch(Arg<int>.Is.Anything, Arg<string>.Is.Anything))
                .Throw(new ArgumentException());

            var customerBatchManager = MockRepository.GeneratePartialMock<CustomerBatchManager>();
            Assert.Throws<CustomerBatchNotFoundException>(() => customerBatchManager.GetCustomerBatch(batch.CustomerId, batch.ExternalId));

            CustomerBatchMapper.Instance.VerifyAllExpectations();
        }
    }
}
