﻿using System;
using System.Collections.Generic;
using MassPayments.Domain.Entities;
using MassPayments.Domain.ValueObjects;
using MassPayments.Domain.ValueObjects.Booking;
using MassPayments.Gateways.Invoice;
using MassPayments.Gateways.Invoice.Assemblers;
using MassPayments.Gateways.Invoice.Entities;
using MassPayments.Infrastructure;
using MassPayments.Managers;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers
{
    [TestFixture]
    public class InvoiceManagerFixture
    {
        [SetUp]
        public void SetUp()
        {
            InvoiceGateway.Instance = MockRepository.GenerateMock<IInvoiceGateway>();
            QuoteMapper.Instance = MockRepository.GenerateMock<IQuoteMapper>();
            CustomerBatchMapper.Instance = MockRepository.GenerateMock<ICustomerBatchMapper>();
            CustomerMapper.Instance = MockRepository.GenerateMock<ICustomerMapper>();
            PartnerMapper.Instance = MockRepository.GenerateMock<IPartnerMapper>();
            OrderMapper.Instance = MockRepository.GenerateMock<IOrderMapper>();
            InvoiceTypeCacheMapper.Instance = MockRepository.GenerateMock<IInvoiceTypeCacheMapper>();
            OutOfHoldingMapper.Instance = MockRepository.GenerateMock<IOutOfHoldingMapper>();
            ServiceSettings.Instance = MockRepository.GenerateMock<IServiceSettings>();
        }

        [TearDown]
        public void TearDown()
        {
            InvoiceGateway.Instance = null;
            QuoteMapper.Instance = null;
            CustomerBatchMapper.Instance = null;
            CustomerMapper.Instance = null;
            PartnerMapper.Instance = null;
            OrderMapper.Instance = null;
            InvoiceTypeCacheMapper.Instance = null;
            OutOfHoldingMapper.Instance = null;
            ServiceSettings.Instance = null;
        }

        [Test]
        public void GenerateOutOfHoldingReportDataFile_MakeCorrectCalls()
        {
            var partner = new Partner();
            
            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();

            OutOfHoldingMapper.Instance.Expect(cm => cm.GetOutOfHoldingOrders(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new List<OutOfHoldingOrder>());
            CustomerMapper.Instance.Expect(cm => cm.GetCustomer(Arg<int>.Is.Anything)).Return(new Customer());
            InvoiceGateway.Instance.Expect(ig => ig.GetOutOfHoldingReportXml(Arg<AggregateInvoice>.Is.Anything)).Repeat.Times(0);

            invoiceManager.ProcessOutOfHoldingReport(partner, Arg<int>.Is.Anything, Arg<int>.Is.Anything);

            OutOfHoldingMapper.Instance.VerifyAllExpectations();
            InvoiceGateway.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            InvoiceTypeCacheMapper.Instance.VerifyAllExpectations();
        }

        [Test]
        public void GenerateInvoice_MakeCorrectCalls()
        {
            var aggregatedOrders = new List<BookedIncomingOrder>
                {
                    new BookedIncomingOrder
                    {
                        ConfirmationNumber = "something"
                    }
                };

            var invoiceManager = MockRepository.GeneratePartialMock<InvoiceManager>();

            InvoiceGateway.Instance.Expect(ig => ig.GetIncomingInvoiceXml(Arg<AggregateInvoice>.Is.Anything)).Repeat.Times(1);

            CustomerMapper.Instance.Expect(cm => cm.GetCustomerByTransactionSystemCustomerId(Arg<int>.Is.Anything, Arg<int>.Is.Anything)).Return(new Customer());
            PartnerMapper.Instance.Expect(pm => pm.GetPartnerById(Arg<int>.Is.Anything)).Return(new Partner(){InvoiceTypeId = 1});
            InvoiceTypeCacheMapper.Instance.Expect(itm => itm.GetInvoiceTypeDictionary()).Return(new Dictionary<int, string> { { 1, "Type 1" } });
            invoiceManager.GenerateInvoice(aggregatedOrders, Arg<int>.Is.Anything, Arg<int>.Is.Anything);

            InvoiceGateway.Instance.VerifyAllExpectations();
            CustomerMapper.Instance.VerifyAllExpectations();
            PartnerMapper.Instance.VerifyAllExpectations();
            InvoiceTypeCacheMapper.Instance.VerifyAllExpectations();
        }

        [Test, Explicit]
        public void GenerateInvoiceFromOrders()
        {
            var clientInfo = new ClientDetailInfo
            {
                OfficeId = 16,
                OfficeFaxNumber = "416-981-2252",
                OfficeAddress = "Scotia Plaza, 100 Yonge Street, 15th Floor Toronto, Ontario M5C 2W1",
                OfficePhoneNumber = "416-359-3700",
                AccountNumber = "KO1224-MP",
                AddressLine1 = "135 Liberty Street, Suite 101",
                AddressLine2 = "",
                AddressLine3 = "",
                City = "Toronto",
                CountryCode = "CA",
                CompanyName = "KO1224-MP – Kobo Writing Life",
                DefaultUserName = "Kobouser1 Kobouser1",
                PostalCode = "M6K 1A7",
                State = "ON",
                ProcessCenterCode = "CA",
                OfficeLegalEntityLongName = "Custom House ULC, a Western Union company",
                OfficeLegalEntityShortName = "Custom House",
                OfficeLegalEntityLicenseNumber = "",
                InvoiceLanguageCode = "enGB"
            };
            
      
            var orders = new List<BookedIncomingOrder>
            {
                new BookedIncomingOrder // multiple orders
                {
                    ConfirmationNumber = "CNTR1189856",
                    SettlementPaymentMethod = "Edebit",
                    SettlementBankAccount = new BookedIncomingOrderBankAccount
                    {
                        AccountNumber = "476961502417",
                        BankAccountOwnerName = "Custom House ULC",
                        BankName = "Scotia Bank",
                        SWIFTCode = "NOSCCATT",
                        RoutingCode = "000247696"
                    },
                    SettlementCurrencyCode = "CAD",
                    LineItems = new List<BookedIncomingOrderItem> //multiple line items
                    {
                        new BookedIncomingOrderItem
                        {
                            Number = 1,
                            RateValue = 1.0188m,
                            TradeAmount = 7380.39m,
                            TradeCurrencyCode = "AUD",
                            SettlementAmount = 7519.14m,
                            Fee = 0
                        },

                        new BookedIncomingOrderItem
                        {
                            Number = 2,
                            RateValue = 1,
                            TradeAmount = 43900.89m,
                            TradeCurrencyCode = "CAD",
                            SettlementAmount = 43900.89m,
                            Fee = 0
                        },
                        new BookedIncomingOrderItem
                        {
                            Number = 3,
                            RateValue = 2.13m,
                            TradeAmount = 35.95m,
                            TradeCurrencyCode = "GBP",
                            SettlementAmount = 76.57m,
                            Fee = 0
                        },
                        new BookedIncomingOrderItem
                        {
                            Number = 4,
                            RateValue = 0.1829m,
                            TradeAmount = 2862.58m,
                            TradeCurrencyCode = "HKD",
                            SettlementAmount = 523.57m,
                            Fee = 0
                        }

                    }
                }
            };

            string partnerCode = "HyperWallet";    //partner code
            int quoteId = 12527;    // mps quote id
            DateTime orderDate = new DateTime(2015, 12, 15, 12, 25, 35); //date when order created
            string invoiceType = "Type 1";    //invoice type of partner in InvoiceType table

            var invoiceGateway = MockRepository.GeneratePartialMock<InvoiceGateway>();

           // invoiceGateway.Expect(ig => ig.GetInvoiceXmlFileName(Arg<AggregateInvoice>.Is.Anything)).Return(fileName); 

            var aggregateInvoice = AggregateInvoiceAssembler.ToAggregateInvoice(orders, clientInfo);
            aggregateInvoice.ClientDetail.InvoiceType = invoiceType;
            aggregateInvoice.ClientDetail.PartnerCode = partnerCode;
            aggregateInvoice.OrderHeader.Number = quoteId;
            aggregateInvoice.OrderHeader.OrderDate = orderDate;
            invoiceGateway.GetIncomingInvoiceXml(aggregateInvoice);

            /*
             *  NOTE:
             *  After xml file is gerenated,
             *   <FileCopyConnector></FileCopyConnector> section has to be changed accordly for prod enviroment
             */
        }
    }
}
