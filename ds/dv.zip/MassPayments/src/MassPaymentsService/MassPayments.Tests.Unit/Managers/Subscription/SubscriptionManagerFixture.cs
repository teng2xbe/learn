﻿using System;
using MassPayments.Domain.Entities.Subscription;
using MassPayments.Domain.Enums;
using MassPayments.Infrastructure.Utility;
using MassPayments.Managers.Subscription;
using MassPayments.Mappers;
using MassPayments.Mappers.Interfaces;
using NUnit.Framework;
using Rhino.Mocks;

namespace MassPayments.Tests.Unit.Managers.Subscription
{

    [TestFixture]
    public class SubscriptionManagerFixture
    {
        [SetUp]
        public void Setup()
        {
            SubscriptionMapper.Instance = MockRepository.GenerateMock<ISubscriptionMapper>();
            DateTimeProvider.Instance = MockRepository.GenerateMock<IDateTimeProvider>();

        }
        
        [TearDown]
        public void TearDown()
        {
            SubscriptionMapper.Instance = null;
            DateTimeProvider.Instance = null;
        }


        [Test]
        public void InvoiceGenerated_MakesCorrectCallsWithCorrectArguments()
        {
            var timestamp = new DateTime(2016,01,01,10,15,00);
            DateTimeProvider.Instance.Expect(dtp => dtp.GetCurrenUtcDateTime()).Return(timestamp).Repeat.Once();

            var filePath = "invoice_234_544.pdf";

            SubscriptionMapper.Instance.Expect(sm => sm.InsertSubscriptionEvent(Arg<SubscriptionEvent>.Matches(e=>e.SubscriptionEventType.Equals(SubscriptionEventType.InvoiceGenerated)&&e.CreatedOnUtc.Equals(timestamp)))).Repeat.Once();

            Assert.DoesNotThrow(()=> new SubscriptionManager().InvoiceGenerated(3, filePath));

            DateTimeProvider.Instance.VerifyAllExpectations();
            SubscriptionMapper.Instance.VerifyAllExpectations();
        }
    }
}
