﻿using MassPayments.Managers.Subscription.EventArgumentAssemblers;
using MassPayments.Managers.Subscription.JsonEventArguments;
using NUnit.Framework;

namespace MassPayments.Tests.Unit.Managers.Subscription.EventArgumentAssemblers
{
    [TestFixture]
    public class InvoiceGeneratedAssemblerFixture
    {
        [Test]
        public void Convert_ToJson_Works()
        {
            var eventArg = new InvoiceGeneratedEventArgument {PartnerId = 3, PathToInvoice = "test.pdf"};
            
            var converted = InvoiceGeneratedAssembler.Convert(eventArg);
            Assert.IsTrue(converted.Contains("\"PartnerId\":3"));
            Assert.IsTrue(converted.Contains("\"PathToInvoice\":\"test.pdf\""));
        }

        [Test]
        public void Convert_EventArgument_Works()
        {
            var jsonString = "{\"PartnerId\":44,\"PathToInvoice\":\"invoice_123_345.pdf\"}";

            var eventArg = InvoiceGeneratedAssembler.Convert(jsonString);

            Assert.AreEqual(44, eventArg.PartnerId);
            Assert.AreEqual("invoice_123_345.pdf", eventArg.PathToInvoice);
        }
    }
}
