﻿using Common.Contracts.MassPayments.Messages.Events;
using MassPayments.Tests.Endpoints.Infrastructure;
using NUnit.Framework;

namespace MassPayments.Tests.Endpoints.EventsFixture
{
    [TestFixture]
    [Explicit]
    public class PingRequestedEventFixture: BaseFixture
    {
        [Test]
        public void PingRequestedEvent_WhenPublished_Reached_SnsSubscriber()
        {
            var ctx = new Context();
            NServiceBus.AcceptanceTesting.Scenario.Define(ctx)
                .WithEndpoint<MassPayments>(b =>
                    b.Given((bus, context) =>
                        SubscriptionBehavior.OnEndpointSubscribed(s =>
                        {
                            if (s.SubscriberReturnAddress.Queue.Contains("SubscriptionsAndNotifications"))
                                context.SnsIsSubscribed = true;
                        }))
                        .When(context => context.SnsIsSubscribed,
                            bus => bus.Publish<PingRequestedEvent>(m => m.SubscriberCode = "Blahlah"))
                )
                .WithEndpoint<SubscriptionsAndNotifications>()
                .Done(c => c.PingIsRequested)
                .Run();

            Assert.IsTrue(ctx.SnsIsSubscribed);
            Assert.IsTrue(ctx.PingIsRequested);
        }
    }
}
