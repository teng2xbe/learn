﻿using Common.Contracts.MassPayments.Messages.Events;
using MassPayments.Tests.Endpoints.Infrastructure;
using NUnit.Framework;

namespace MassPayments.Tests.Endpoints.EventsFixture
{
    [TestFixture]
    [Explicit]
    public class PaymentStatusUpdatedEventFixture : BaseFixture
    {
        [Test]
        public void PaymentStatusUpdatedEvent_WhenPublished_Reached_SnsSubscriber()
        {
            var ctx = new Context();
            NServiceBus.AcceptanceTesting.Scenario.Define(ctx)
                .WithEndpoint<MassPayments>(b =>
                    b.Given((bus, context) =>
                        SubscriptionBehavior.OnEndpointSubscribed(s =>
                        {
                            if (s.SubscriberReturnAddress.Queue.Contains("SubscriptionsAndNotifications"))
                                context.SnsIsSubscribed = true;
                        }))
                        .When(context => context.SnsIsSubscribed,
                            bus => bus.Publish<PaymentStatusUpdatedEvent>(m => m.SubscriberCode = "blahlah"))
                )
                .WithEndpoint<SubscriptionsAndNotifications>()
                .Done(c => c.PaymentStatusIsUpdated)
                .Run();

            Assert.IsTrue(ctx.SnsIsSubscribed);
            Assert.IsTrue(ctx.PaymentStatusIsUpdated);
        }
    }
}
