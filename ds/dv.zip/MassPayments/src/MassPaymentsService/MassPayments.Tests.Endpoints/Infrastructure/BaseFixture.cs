﻿using Common.Contracts.MassPayments.Messages.Events;
using NServiceBus;
using NServiceBus.AcceptanceTesting;
using NServiceBus.MessageMutator;

namespace MassPayments.Tests.Endpoints.Infrastructure
{
    public abstract class BaseFixture
    {
        public class Context : ScenarioContext
        {
            public bool PingIsRequested { get; set; }
            public bool PaymentStatusIsUpdated { get; set; }
            public bool SnsIsSubscribed { get; set; }
        }

        public class MassPayments : EndpointConfigurationBuilder
        {
            public MassPayments()
            {
                EndpointSetup<DefaultServer>(config =>
                {
                    config.UseTransport<SqlServerTransport>().DefaultSchema("nsb");
                    config.EndpointName("MassPayments");
                    config.UseSerialization<JsonSerializer>();
                    config.EnableInstallers();
                    config.UsePersistence<NHibernatePersistence>();
                    config.Conventions()
                        .DefiningCommandsAs(t => t.Namespace == "MassPayments.Messages.Commands")
                        .DefiningEventsAs(t => t.Namespace == "MassPayments.Messages.Events")
                        .DefiningMessagesAs(t => t.Namespace == "MassPayments.Messages");
                });

            }

            class MassPaymentsInspector : IMutateOutgoingMessages, INeedInitialization
            {
                public Context Context { get; set; }
                public object MutateOutgoing(object message)
                {

                    if (message is PingRequestedEvent)
                        Context.PingIsRequested = true;

                    if (message is PaymentStatusUpdatedEvent)
                        Context.PaymentStatusIsUpdated = true;

                    return message;
                }

                public void Customize(BusConfiguration configuration)
                {
                    configuration.RegisterComponents(c => c.ConfigureComponent<MassPaymentsInspector>(DependencyLifecycle.InstancePerCall));
                }
            }
        }

        public class SubscriptionsAndNotifications : EndpointConfigurationBuilder
        {
            public SubscriptionsAndNotifications()
            {
                EndpointSetup<DefaultServer>(config =>
                {
                    config.UseTransport<SqlServerTransport>().DefaultSchema("nsb");
                    config.EndpointName("SubscriptionsAndNotifications");
                    config.UseSerialization<JsonSerializer>();
                    config.EnableInstallers();
                    config.UsePersistence<NHibernatePersistence>();
                    config.Conventions()
                        .DefiningCommandsAs(t => t.Namespace == "MassPayments.Messages.Commands")
                        .DefiningEventsAs(t => t.Namespace == "MassPayments.Messages.Events")
                        .DefiningMessagesAs(t => t.Namespace == "MassPayments.Messages");
                })
                    .AddMapping<PingRequestedEvent>(typeof(MassPayments))
                    .AddMapping<PaymentStatusUpdatedEvent>(typeof(MassPayments));
            }

            class SubscriptionsAndNotificationsInspector : IMutateOutgoingMessages, INeedInitialization
            {
                public Context Context { get; set; }

                public object MutateOutgoing(object message)
                {
                    return message;
                }

                public void Customize(BusConfiguration configuration)
                {
                    configuration.RegisterComponents(c => c.ConfigureComponent<SubscriptionsAndNotificationsInspector>(DependencyLifecycle.InstancePerCall));
                }
            }
        }
    }
}
