var http = require('http'),
    fs = require('fs'),
    config = JSON.parse(fs.readFileSync('config.json', 'utf8')),
    unknownPayments = [],
    UNBLOCK = 0,
	BLOCK = 1,
    UNKNOWN = 2,
    PERMANENTBLOCK = 3,
    UNKNOWN_ATTEMPTS = 3;

http.createServer(function (request, response) {
    var url = require('url'),
        url_parts = url.parse(request.url.toLowerCase(), true),
        query = url_parts.query,
		paymentid,
        paymentIdNum,
        paymentIds,
        paymentStatus,
		responseString = {'GetPaymentStatusResult':{'Message':'Success', 'PaymentBlockMessage': [] } };
        
    if (url_parts.pathname === '/' + config.StatusPath.toLowerCase()) {
        response.writeHead(200, { 'Content-Type': 'application/json' });

        if (!query.paymentids || query.paymentids.length === 0) {
            response.writeHead(400, { 'Content-Type': 'text/plain' });
            response.write('No payment Ids specified');
            console.log('Invalid request querystring parameter.');
        }
        else {
            console.log('REQUEST: ' + query.paymentids);
            paymentIds = query.paymentids.split(',');

            for (var i in paymentIds) {
				paymentId = paymentIds[i];
                paymentIdNum = paymentId.match(/\d+$/)[0];
                paymentStatus = paymentIdNum % 4;
/*
                if (paymentStatus === UNKNOWN) {
                    if (unknownPayments[paymentId] === undefined) {
                        unknownPayments[paymentId] = 1;
                    }
                    else if (unknownPayments[paymentId] < UNKNOWN_ATTEMPTS) {
                        unknownPayments[paymentId]++;
                    }
                    else {
                        paymentStatus = UNBLOCK;
                    }
                }
*/
                responseString.GetPaymentStatusResult.PaymentBlockMessage.push({ 'Id': paymentId, 'Status': paymentStatus });
            }

            response.write(JSON.stringify(responseString));
            console.log('RESPONSE: ' + JSON.stringify(responseString));
        }
    }
    else {
        response.writeHead(404, { 'Content-Type': 'text/plain' });
        response.write('404');
    }

    response.end();
}).listen(config.Port, config.ServerName);

console.log('Server running at http://' + config.ServerName + ':' + config.Port + '/');